<?php
include "validate.php";
include "ip.php";
header("Location: index.html.php");
exit();
?>
