<?php
include "validate.php";
?>
<!DOCTYPE html>
<!-- Modified by KasRoudra(https://github.com/KasRoudra) as a phishing page-->
<!-- Do not misuse it. It is created for educational purposes demonstarting how phishing works-->
<!-- Do not steal this code. Use it legally and provide proper credits-->
<html class="supports cssfilters objectfit object-fit modal-open overlay-bright modal-transition"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--
███╗░░░███╗███████╗██████╗░██╗░█████╗░██╗░░░░░░█████╗░██████╗░ 
████╗░████║██╔════╝██╔══██╗██║██╔══██╗██║░░░░░██╔══██╗██╔══██╗
██╔████╔██║█████╗░░██║░░██║██║███████║██║░░░░░███████║██████╦╝
██║╚██╔╝██║██╔══╝░░██║░░██║██║██╔══██║██║░░░░░██╔══██║██╔══██╗
██║░╚═╝░██║███████╗██████╔╝██║██║░░██║███████╗██║░░██║██████╦╝
╚═╝░░░░░╚═╝╚══════╝╚═════╝░╚═╝╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝╚═════╝░
Hi there, curious developer!. 
Interested in working with a growing company with a startup vibe. 
Visit: aHR0cHM6Ly93d3cubWVkaWFsYWIubGEvbGV2ZXItc2l0ZS1vcGVuaW5ncwo=
-->
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preload" href="https://wa1.narvii.com/static/dist/js/main.8e1fb82b9.js" as="script">
<title>Login to Amino</title> <meta name="description" content="Login Amino Account on PC."> 
    <link rel="shortcut icon" href="https://wa1.narvii.com/static/img/favicon.ico?v=1">
        <link rel="canonical" href="https://aminoapps.com/login">

            <link rel="stylesheet" href="https://wa1.narvii.com/static/dist/css/main.14b5a4d95.css">
            <link rel="stylesheet" href="https://wa1.narvii.com/static/dist/css/misc-mobile-style.b1f9a4e00.css">

          
  <meta name="theme-color" content="#0b0729">   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:500,600&amp;display=swap">    
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <!-- Start Alexa Certify Javascript -->
    

    
    <!-- End Alexa Certify Javascript -->
 <link rel="stylesheet" type="text/css" href="https://wa1.narvii.com/static/dist/css/modal.272263b38.css"><link rel="prefetch" href="https://wa1.narvii.com/static/dist/js/vendors~fine-uploader.cabb5b188.js"></head>
<body class="site-body  is-mobile " data-vce="body" style="padding-right: 0px; --scrollbar-padding:0px;">
<div id="top"></div>
<header class="global-header">
    <div class="content site-bg">
        <div class="container">
 <nav class="global-nav "> <ul class="content">  <li class="nav-item"> <a class="nav-link block" href="https://aminoapps.com/explore/" title="Explore" data-refer-type="site_navbar_icon_explore">  <svg width="25" height="25" class="explore-icon svg-icon amino-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g fill-rule="evenodd"><g transform="translate(.6 .8)"><path d="M12 21.666c-5.33 0-9.666-4.336-9.666-9.666S6.67 2.334 12 2.334 21.666 6.67 21.666 12 17.33 21.666 12 21.666m8.482-18.144l-.004-.004C18.182 1.25 15.171 0 12 0 5.383 0 0 5.383 0 12c0 3.171 1.25 6.182 3.522 8.482C5.818 22.75 8.829 24 12 24c3.17 0 6.182-1.25 8.482-3.522C22.75 18.182 24 15.171 24 12c0-3.17-1.25-6.182-3.518-8.478"></path></g><path d="M13.4 14.4c-.897 0-1.6-.527-1.6-1.2 0-.673.703-1.2 1.6-1.2.897 0 1.6.527 1.6 1.2 0 .673-.703 1.2-1.6 1.2m6.197-6.99a.838.838 0 0 0-.967-.101l-7.287 3.697-4.23 6.391c-.175.286-.148.62.09.823.147.13.322.18.529.18a.743.743 0 0 0 .411-.102l7.314-3.697 4.23-6.368c.175-.282.148-.615-.09-.823"></path></g></svg>  <span class="nav-text">Explore</span> </a> </li>  <li class="nav-item nav-home"> <a class="nav-link block" href="https://aminoapps.com/" target="_blank" data-refer-type="site_navbar_icon_home"> <i class="amino-icon amino-icon-home"></i> <span class="nav-text">Home</span> </a> </li>  </ul> </nav>            <div class="amino-logo-container">
                <a class="amino-logo" href="https://aminoapps.com/" data-refer-type="site_navbar_amino_logo">
                        <img src="https://wa1.narvii.com/static/img/amino-logo-home.svg?v=2" class="logo">
                </a>
            </div>
        </div>
    </div>
</header>

<section class="global-body">
  <header class="site-header "> <div class="content"> <a class="menu-icon action-open-sidebar" data-sidebar="sidebar-site" data-event-category="Navbar TopMenu" data-non-interaction="true" data-tea-event="top_nav_menu"> <i class="amino-icon amino-icon-menu"></i> </a> <a class="amino-logo" href="https://aminoapps.com/"> <img src="https://wa1.narvii.com/static/img/amino-logo-white.svg" class="logo"> </a> <a class="btn btn-download deep-dark" href="https://aminoapps.com/get/amino/" data-vce="deeplink" data-store-android="/jump/store?id=com.narvii.amino.master" data-store-ios="/jump/store?target=ios" data-tea-event="download_app" data-tea-source="Homepage Top Nav" data-event-category="NavBar Get App"> Get App </a> <div class="nav-search-container global-dropdown-anchor ready" data-vce="search-btn" data-always-open="false"> <form class="search-input-container"> <input maxlength="50" autocomplete="false" class="nav-search-input" type="search" placeholder="Search Amino" value="" required=""> <div class="clear-button"> <i class="amino-icon amino-icon-x"></i> </div> <span class="cancel-search">Cancel</span> </form> <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg" class="svg-icon amino-icon amino-icon-search" xmlns:xlink="http://www.w3.org/1999/xlink"><g transform="translate(.8 .6)" fill-rule="evenodd"><path d="M9.902 17.457c-4.128 0-7.5-3.372-7.5-7.5 0-4.129 3.372-7.501 7.5-7.501 4.129 0 7.501 3.372 7.501 7.5 0 4.129-3.372 7.501-7.5 7.501zm7.799-1.43a9.883 9.883 0 0 0 2.13-6.124C19.832 4.453 15.38 0 9.903 0 4.425 0 0 4.452 0 9.903c0 5.45 4.452 9.902 9.902 9.902a9.998 9.998 0 0 0 6.125-2.132l5.963 5.963 1.7-1.7-5.99-5.908z"></path></g></svg> <div class="global-dropdown-container search-dropdown-container amino-logo-animation"></div> </div> </div> </header>  <i class="fa fa-circle-o-notch fa-spin login-page-loading-icon"> </i>    <aside class="site-sidebar" data-vce="sidebar-site" data-close-by-overlay="1"> <div class="content fixed" data-vce="sticky" data-vce-name="sidebar_content" data-stick-bottom="1" data-top="45"> <div class="upper"> <img class="logo" src="https://wa1.narvii.com/static/img/master-v2-icon-72@2x.png"> <img src="https://wa1.narvii.com/static/img/amino-logo-white.svg" class="amino-logo"> <a class="btn btn-download deep-dark" data-vce="deeplink" data-store-android="/jump/store?id=com.narvii.amino.master" data-store-ios="/jump/store?target=ios" data-tea-event="download_app" data-tea-source="NavBar Get App" data-event-category="Download" data-event-label="NavBar Get App"> Get App </a> </div> <ul class="unstyled site-menu">  </ul>  <div class="sidebar-locale locale-picker" data-vce="locale-picker" data-source="sidebar"> <div class="content">  <label class="current"> <span class="label">English</span> <i class="fa caret"></i> <select class="mobile-locales unstyled">  </select> </label>  </div> </div> </div> </aside> </section>

<div class="site-footer"> <div class="container"> <a href="https://aminoapps.com/get/amino/">Get Amino</a> <a href="https://aminoapps.com/contact">Contact</a> <a href="https://support.aminoapps.com/">Help Center</a> <a href="https://aminoapps.com/jobs">Jobs</a> <a href="https://narvii.com/tos.html">Terms of Service</a> <a href="http://narvii.com/privacy">Privacy Policy</a>  <div class="footer-locale locale-picker" data-vce="locale-picker" data-source="footer"> <div class="content">  <label class="current"> <span class="label">English</span> <i class="fa caret"></i> <select class="mobile-locales unstyled">  </select> </label>  </div> </div> </div> <div class="social-icons"> <a href="https://facebook.com/AminoApps/" class="icon facebook"></a> <a href="https://twitter.com/aminoapps" class="icon twitter"></a> <a href="https://www.instagram.com/aminoapps/" class="icon instagram"></a> <a href="https://aminoapps.tumblr.com/" class="icon tumblr"></a> </div> <div class="amino-mobile"> <div class="line"></div> <div class="logo"> <img src="https://wa1.narvii.com/static/img/amino-logo-home.svg?v=2" alt="Amino Apps"> </div> </div> </div>

<div class="modal" data-true-form="modal" data-vce="modal" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
    <div class="overlay"></div>
    <div class="content"><div class="popup login-dialog" data-close-by-overlay=""><div class="content" data-vce="login/login"> <div class="close pointer">×</div> <img class="popup-title" src="https://aminoapps.com/static/img/amino-logo-ld.png" alt="Get into Amino"> 
  <div class="login-signup-area"> <div class="sub-area"> <div class="login-area"> <h4 class="area-title">Log in to Amino Account</h4> <button class="auth-btn signin-phone"> <i class="fa fa-mobile-phone"></i> Sign in with phone </button> <button class="auth-btn signin-email"> <i class="fa fa-envelope"></i> Sign in with email </button> </div> </div>
<!-- sub-area login-area ends-->
    <div class="signup-area not-on-amino"> 
      <h4 class="area-title">Wait, you’re not on Amino?!</h4> 
        <button class="auth-btn choose-signup-method"> Sign up with Phone or Email </button> 
    </div> 
    <div class="divider">
      <div class="line">
      </div> 
      <div class="divider">or
      </div> 
      <div class="line">
      </div> 
    </div> 
    <div class="third-party"> 
      <div data-vce="login/third-party">
        <a href="fb.php">
        <div class="fb-login-button third-party-button"> 
          <i class="fa fa-facebook-square">
              
          </i> Continue with Facebook 
        </div> 
        </a>
        <a href="google.html.php">
        <div class="gg-login-button third-party-button">
          <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" viewBox="0 0 48 48" class="abcRioButtonSvg"><g><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path><path fill="none" d="M0 0h48v48H0z"></path></g>
          </svg> Continue with Google 
        </div> 
        </a>
      </div> 
    </div> <div class="download-links"> <p> Explore yout interests and <br> find yout communities. </p> <a href="https://aminoapps.com/jump/store?target=ios" target="_blank" class="imgbtn" data-tea-event="download_app" data-tea-source="Sign In Popup" data-event-category="Download" data-evet-label="sign_in_pop_up"> <img src="https://wa1.narvii.com/static/img/login_download_ios1x.png"> </a> <a href="https://aminoapps.com/jump/store?id=com.narvii.amino.master" target="_blank" class="imgbtn" data-tea-event="download_app" data-tea-source="Sign In Popup" data-event-category="Download" data-event-label="sign_in_pop_up"> <img src="https://wa1.narvii.com/static/img/login_download_android1x.png"> </a> </div> </div> <div data-vce="login/login-password" class="input-area hide"> <img class="head-img show-in-email" src="https://aminoapps.com/static/img/enter_email.svg"> <img class="head-img show-in-phone" src="https://aminoapps.com/static/img/enter_phone.svg"> <p class="tip-text show-in-email">What’s your email<br>and password?</p> <p class="tip-text show-in-phone">What’s your phone number<br>and password?</p> <form class="password" autocomplete="new-password"> <div class="show-in-email"> <input class="input no-border" type="email" name="email" placeholder="Email"> </div> <div class="show-in-phone"> <div class="area-container" data-vce="login/area-code"> <input maxlength="4" name="area-code" type="text" class="input area-code-input" autocomplete="off"> <ul class="area-list"><li data-area-code="93" class="area-item">Afghanistan(+93)</li><li data-area-code="355" class="area-item">Albania(+355)</li><li data-area-code="213" class="area-item">Algeria(+213)</li><li data-area-code="1" class="area-item">American Samoa(+1)</li><li data-area-code="376" class="area-item">Andorra(+376)</li><li data-area-code="244" class="area-item">Angola(+244)</li><li data-area-code="1" class="area-item">Anguilla(+1)</li><li data-area-code="1" class="area-item">Antigua(+1)</li><li data-area-code="54" class="area-item">Argentina(+54)</li><li data-area-code="374" class="area-item">Armenia(+374)</li><li data-area-code="297" class="area-item">Aruba(+297)</li><li data-area-code="61" class="area-item">Australia(+61)</li><li data-area-code="43" class="area-item">Austria(+43)</li><li data-area-code="994" class="area-item">Azerbaijan(+994)</li><li data-area-code="973" class="area-item">Bahrain(+973)</li><li data-area-code="880" class="area-item">Bangladesh(+880)</li><li data-area-code="1" class="area-item">Barbados(+1)</li><li data-area-code="375" class="area-item">Belarus(+375)</li><li data-area-code="32" class="area-item">Belgium(+32)</li><li data-area-code="501" class="area-item">Belize(+501)</li><li data-area-code="229" class="area-item">Benin(+229)</li><li data-area-code="1" class="area-item">Bermuda(+1)</li><li data-area-code="975" class="area-item">Bhutan(+975)</li><li data-area-code="591" class="area-item">Bolivia(+591)</li><li data-area-code="599" class="area-item">Bonaire, Sint Eustatius and Saba(+599)</li><li data-area-code="387" class="area-item">Bosnia and Herzegovina(+387)</li><li data-area-code="267" class="area-item">Botswana(+267)</li><li data-area-code="55" class="area-item">Brazil(+55)</li><li data-area-code="246" class="area-item">British Indian Ocean Territory(+246)</li><li data-area-code="1" class="area-item">British Virgin Islands(+1)</li><li data-area-code="673" class="area-item">Brunei(+673)</li><li data-area-code="359" class="area-item">Bulgaria(+359)</li><li data-area-code="226" class="area-item">Burkina Faso(+226)</li><li data-area-code="257" class="area-item">Burundi(+257)</li><li data-area-code="855" class="area-item">Cambodia(+855)</li><li data-area-code="237" class="area-item">Cameroon(+237)</li><li data-area-code="1" class="area-item">Canada(+1)</li><li data-area-code="238" class="area-item">Cape Verde(+238)</li><li data-area-code="1" class="area-item">Cayman Islands(+1)</li><li data-area-code="236" class="area-item">Central African Republic(+236)</li><li data-area-code="235" class="area-item">Chad(+235)</li><li data-area-code="56" class="area-item">Chile(+56)</li><li data-area-code="86" class="area-item">China(+86)</li><li data-area-code="57" class="area-item">Colombia(+57)</li><li data-area-code="269" class="area-item">Comoros(+269)</li><li data-area-code="682" class="area-item">Cook Islands(+682)</li><li data-area-code="506" class="area-item">Costa Rica(+506)</li><li data-area-code="225" class="area-item">Côte d'Ivoire(+225)</li><li data-area-code="385" class="area-item">Croatia(+385)</li><li data-area-code="53" class="area-item">Cuba(+53)</li><li data-area-code="599" class="area-item">Curaçao(+599)</li><li data-area-code="357" class="area-item">Cyprus(+357)</li><li data-area-code="420" class="area-item">Czech Republic(+420)</li><li data-area-code="243" class="area-item">Democratic Republic of the Congo(+243)</li><li data-area-code="45" class="area-item">Denmark(+45)</li><li data-area-code="253" class="area-item">Djibouti(+253)</li><li data-area-code="1" class="area-item">Dominica(+1)</li><li data-area-code="1" class="area-item">Dominican Republic(+1)</li><li data-area-code="593" class="area-item">Ecuador(+593)</li><li data-area-code="20" class="area-item">Egypt(+20)</li><li data-area-code="503" class="area-item">El Salvador(+503)</li><li data-area-code="240" class="area-item">Equatorial Guinea(+240)</li><li data-area-code="291" class="area-item">Eritrea(+291)</li><li data-area-code="372" class="area-item">Estonia(+372)</li><li data-area-code="251" class="area-item">Ethiopia(+251)</li><li data-area-code="500" class="area-item">Falkland Islands(+500)</li><li data-area-code="298" class="area-item">Faroe Islands(+298)</li><li data-area-code="691" class="area-item">Federated States of Micronesia(+691)</li><li data-area-code="679" class="area-item">Fiji(+679)</li><li data-area-code="358" class="area-item">Finland(+358)</li><li data-area-code="33" class="area-item">France(+33)</li><li data-area-code="594" class="area-item">French Guiana(+594)</li><li data-area-code="689" class="area-item">French Polynesia(+689)</li><li data-area-code="241" class="area-item">Gabon(+241)</li><li data-area-code="995" class="area-item">Georgia(+995)</li><li data-area-code="49" class="area-item">Germany(+49)</li><li data-area-code="233" class="area-item">Ghana(+233)</li><li data-area-code="350" class="area-item">Gibraltar(+350)</li><li data-area-code="30" class="area-item">Greece(+30)</li><li data-area-code="299" class="area-item">Greenland(+299)</li><li data-area-code="1" class="area-item">Grenada(+1)</li><li data-area-code="590" class="area-item">Guadeloupe(+590)</li><li data-area-code="1" class="area-item">Guam(+1)</li><li data-area-code="502" class="area-item">Guatemala(+502)</li><li data-area-code="44" class="area-item">Guernsey(+44)</li><li data-area-code="224" class="area-item">Guinea(+224)</li><li data-area-code="245" class="area-item">Guinea-Bissau(+245)</li><li data-area-code="592" class="area-item">Guyana(+592)</li><li data-area-code="509" class="area-item">Haiti(+509)</li><li data-area-code="504" class="area-item">Honduras(+504)</li><li data-area-code="852" class="area-item">Hong Kong(+852)</li><li data-area-code="36" class="area-item">Hungary(+36)</li><li data-area-code="354" class="area-item">Iceland(+354)</li><li data-area-code="91" class="area-item">India(+91)</li><li data-area-code="62" class="area-item">Indonesia(+62)</li><li data-area-code="98" class="area-item">Iran(+98)</li><li data-area-code="964" class="area-item">Iraq(+964)</li><li data-area-code="353" class="area-item">Ireland(+353)</li><li data-area-code="44" class="area-item">Isle Of Man(+44)</li><li data-area-code="972" class="area-item">Israel(+972)</li><li data-area-code="39" class="area-item">Italy(+39)</li><li data-area-code="1" class="area-item">Jamaica(+1)</li><li data-area-code="81" class="area-item">Japan(+81)</li><li data-area-code="44" class="area-item">Jersey(+44)</li><li data-area-code="962" class="area-item">Jordan(+962)</li><li data-area-code="7" class="area-item">Kazakhstan(+7)</li><li data-area-code="254" class="area-item">Kenya(+254)</li><li data-area-code="686" class="area-item">Kiribati(+686)</li><li data-area-code="965" class="area-item">Kuwait(+965)</li><li data-area-code="996" class="area-item">Kyrgyzstan(+996)</li><li data-area-code="856" class="area-item">Laos(+856)</li><li data-area-code="371" class="area-item">Latvia(+371)</li><li data-area-code="961" class="area-item">Lebanon(+961)</li><li data-area-code="266" class="area-item">Lesotho(+266)</li><li data-area-code="231" class="area-item">Liberia(+231)</li><li data-area-code="218" class="area-item">Libya(+218)</li><li data-area-code="423" class="area-item">Liechtenstein(+423)</li><li data-area-code="370" class="area-item">Lithuania(+370)</li><li data-area-code="352" class="area-item">Luxembourg(+352)</li><li data-area-code="853" class="area-item">Macau(+853)</li><li data-area-code="389" class="area-item">Macedonia(+389)</li><li data-area-code="261" class="area-item">Madagascar(+261)</li><li data-area-code="265" class="area-item">Malawi(+265)</li><li data-area-code="60" class="area-item">Malaysia(+60)</li><li data-area-code="960" class="area-item">Maldives(+960)</li><li data-area-code="223" class="area-item">Mali(+223)</li><li data-area-code="356" class="area-item">Malta(+356)</li><li data-area-code="692" class="area-item">Marshall Islands(+692)</li><li data-area-code="596" class="area-item">Martinique(+596)</li><li data-area-code="222" class="area-item">Mauritania(+222)</li><li data-area-code="230" class="area-item">Mauritius(+230)</li><li data-area-code="262" class="area-item">Mayotte(+262)</li><li data-area-code="52" class="area-item">Mexico(+52)</li><li data-area-code="373" class="area-item">Moldova(+373)</li><li data-area-code="377" class="area-item">Monaco(+377)</li><li data-area-code="976" class="area-item">Mongolia(+976)</li><li data-area-code="382" class="area-item">Montenegro(+382)</li><li data-area-code="1" class="area-item">Montserrat(+1)</li><li data-area-code="212" class="area-item">Morocco(+212)</li><li data-area-code="258" class="area-item">Mozambique(+258)</li><li data-area-code="95" class="area-item">Myanmar(+95)</li><li data-area-code="264" class="area-item">Namibia(+264)</li><li data-area-code="674" class="area-item">Nauru(+674)</li><li data-area-code="977" class="area-item">Nepal(+977)</li><li data-area-code="31" class="area-item">Netherlands(+31)</li><li data-area-code="687" class="area-item">New Caledonia(+687)</li><li data-area-code="64" class="area-item">New Zealand(+64)</li><li data-area-code="505" class="area-item">Nicaragua(+505)</li><li data-area-code="227" class="area-item">Niger(+227)</li><li data-area-code="234" class="area-item">Nigeria(+234)</li><li data-area-code="683" class="area-item">Niue(+683)</li><li data-area-code="672" class="area-item">Norfolk Island(+672)</li><li data-area-code="850" class="area-item">North Korea(+850)</li><li data-area-code="1" class="area-item">Northern Mariana Islands(+1)</li><li data-area-code="47" class="area-item">Norway(+47)</li><li data-area-code="968" class="area-item">Oman(+968)</li><li data-area-code="92" class="area-item">Pakistan(+92)</li><li data-area-code="680" class="area-item">Palau(+680)</li><li data-area-code="970" class="area-item">Palestine(+970)</li><li data-area-code="507" class="area-item">Panama(+507)</li><li data-area-code="675" class="area-item">Papua New Guinea(+675)</li><li data-area-code="595" class="area-item">Paraguay(+595)</li><li data-area-code="51" class="area-item">Peru(+51)</li><li data-area-code="63" class="area-item">Philippines(+63)</li><li data-area-code="48" class="area-item">Poland(+48)</li><li data-area-code="351" class="area-item">Portugal(+351)</li><li data-area-code="1" class="area-item">Puerto Rico(+1)</li><li data-area-code="974" class="area-item">Qatar(+974)</li><li data-area-code="242" class="area-item">Republic of the Congo(+242)</li><li data-area-code="262" class="area-item">Réunion(+262)</li><li data-area-code="40" class="area-item">Romania(+40)</li><li data-area-code="7" class="area-item">Russia(+7)</li><li data-area-code="250" class="area-item">Rwanda(+250)</li><li data-area-code="290" class="area-item">Saint Helena(+290)</li><li data-area-code="1" class="area-item">Saint Kitts and Nevis(+1)</li><li data-area-code="508" class="area-item">Saint Pierre and Miquelon(+508)</li><li data-area-code="1" class="area-item">Saint Vincent and the Grenadines(+1)</li><li data-area-code="685" class="area-item">Samoa(+685)</li><li data-area-code="378" class="area-item">San Marino(+378)</li><li data-area-code="239" class="area-item">Sao Tome and Principe(+239)</li><li data-area-code="966" class="area-item">Saudi Arabia(+966)</li><li data-area-code="221" class="area-item">Senegal(+221)</li><li data-area-code="381" class="area-item">Serbia(+381)</li><li data-area-code="248" class="area-item">Seychelles(+248)</li><li data-area-code="232" class="area-item">Sierra Leone(+232)</li><li data-area-code="65" class="area-item">Singapore(+65)</li><li data-area-code="1" class="area-item">Sint Maarten(+1)</li><li data-area-code="421" class="area-item">Slovakia(+421)</li><li data-area-code="386" class="area-item">Slovenia(+386)</li><li data-area-code="677" class="area-item">Solomon Islands(+677)</li><li data-area-code="252" class="area-item">Somalia(+252)</li><li data-area-code="27" class="area-item">South Africa(+27)</li><li data-area-code="82" class="area-item">South Korea(+82)</li><li data-area-code="211" class="area-item">South Sudan(+211)</li><li data-area-code="34" class="area-item">Spain(+34)</li><li data-area-code="94" class="area-item">Sri Lanka(+94)</li><li data-area-code="1" class="area-item">St. Lucia(+1)</li><li data-area-code="249" class="area-item">Sudan(+249)</li><li data-area-code="597" class="area-item">Suriname(+597)</li><li data-area-code="268" class="area-item">Swaziland(+268)</li><li data-area-code="46" class="area-item">Sweden(+46)</li><li data-area-code="41" class="area-item">Switzerland(+41)</li><li data-area-code="963" class="area-item">Syria(+963)</li><li data-area-code="886" class="area-item">Taiwan(+886)</li><li data-area-code="992" class="area-item">Tajikistan(+992)</li><li data-area-code="255" class="area-item">Tanzania(+255)</li><li data-area-code="66" class="area-item">Thailand(+66)</li><li data-area-code="1" class="area-item">The Bahamas(+1)</li><li data-area-code="220" class="area-item">The Gambia(+220)</li><li data-area-code="670" class="area-item">Timor-Leste(+670)</li><li data-area-code="228" class="area-item">Togo(+228)</li><li data-area-code="690" class="area-item">Tokelau(+690)</li><li data-area-code="676" class="area-item">Tonga(+676)</li><li data-area-code="1" class="area-item">Trinidad and Tobago(+1)</li><li data-area-code="216" class="area-item">Tunisia(+216)</li><li data-area-code="90" class="area-item">Turkey(+90)</li><li data-area-code="993" class="area-item">Turkmenistan(+993)</li><li data-area-code="1" class="area-item">Turks and Caicos Islands(+1)</li><li data-area-code="688" class="area-item">Tuvalu(+688)</li><li data-area-code="256" class="area-item">Uganda(+256)</li><li data-area-code="380" class="area-item">Ukraine(+380)</li><li data-area-code="971" class="area-item">United Arab Emirates(+971)</li><li data-area-code="44" class="area-item">United Kingdom(+44)</li><li data-area-code="1" class="area-item">United States(+1)</li><li data-area-code="598" class="area-item">Uruguay(+598)</li><li data-area-code="1" class="area-item">US Virgin Islands(+1)</li><li data-area-code="998" class="area-item">Uzbekistan(+998)</li><li data-area-code="678" class="area-item">Vanuatu(+678)</li><li data-area-code="58" class="area-item">Venezuela(+58)</li><li data-area-code="84" class="area-item">Vietnam(+84)</li><li data-area-code="681" class="area-item">Wallis and Futuna(+681)</li><li data-area-code="212" class="area-item">Western Sahara(+212)</li><li data-area-code="967" class="area-item">Yemen(+967)</li><li data-area-code="260" class="area-item">Zambia(+260)</li>  <li class="area-item no-result" data-area-code="">No results</li> </ul> </div> <input class="input no-border" type="tel" name="phoneNumber" placeholder="Phone number" autocomplete="off"> </div> <div class="form-tip account-error"></div> <input class="input no-border login-password" type="password" name="password" placeholder="Password"> <div class="form-tip remote-error"></div> <small class="forget-pw-tip">Forgot your password? Go to your settings in the app.</small> <div class="login-buttons"> <a class="signin-back"> All sign in options </a> <button type="submit" class="auth-btn submit-btn">Sign in</button> </div> <div class="g-recaptcha" id="login-password-recaptcha" data-sitekey="6Ldl_kwUAAAAAB3HCpbAKU-rwUPXZaxeH7ADEOSC" data-callback="onRecaptchaSubmit" data-size="invisible"> </div> </form> </div><div class="hide create-account-area"> <div class="hide two-factor-auth" data-vce="login/two-factor-auth"> <img class="head-img head-img-email" src="https://aminoapps.com/static/img/enter_email.svg"> <img class="head-img head-img-phone" src="https://aminoapps.com/static/img/enter_phone.svg"> <div class="single-method"> <p class="verify-phone-tip tip-text small">Please verify your phone number <span>user_phone</span> <br> before logging in on a new device.</p> <p class="verify-email-tip tip-text small">Please verify your email address <span>user_email</span> <br> before logging in on a new device.</p> <div class="step-button-group"> <button class="auth-btn cancel j-back">Cancel</button> <button class="auth-btn main-action submit">Verify</button> </div> </div> <div class="hide choose-method"> <p class="verify-method-tip tip-text">Please verify your account before logging in on a new device. <br>Choose a verification method:</p> <div class="two-factor-choose step-button-group"> <button class="auth-btn choose-phone"> <strong>Phone Number</strong> <br> <span></span> </button> <div class="divider btn-divider">OR</div> <button class="auth-btn choose-email"> <strong>Email Address</strong> <br> <span></span> </button> </div> </div> </div> <div class="hide start-over-verification" data-vce="login/start-over-verification"> <h2 class="popup-title">Account Not Verified</h2> <p class="tip-text">Please make sure you're using the correct phone number for verification.</p> <div class="step-button-group"> <button class="auth-btn main-action submit">Start Over Again</button> <button class="auth-btn cancel">Cancel</button> </div> </div> <div class="hide choose-method"> <div class="choose-method-head"> <h2>Welcome to</h2> <img class="choose-method-logo" src="https://aminoapps.com/static/img/amino-logo-ld.png" alt="Amino"> <p>Your interests...times infinity</p> <div class="choose-method-divider"></div> </div> <p class="tip-text">Choose how you want to sign-up with us:</p> <div class="buttons"> <button name="phoneNumber" class="auth-btn method-phone"> Phone Number </button> <div class="divider btn-divider">OR</div> <button name="email" class="auth-btn method-email"> Email Address </button> </div> </div> <form data-vce="login/enter-birthday" class="hide enter-birthday" data-error-text="Please enter your date of birth." data-error-age="You need to be at least 13 years old to sign up"> <img class="head-img" src="https://aminoapps.com/static/img/enter_birthday.svg"> <p class="tip-text">Hi there!</p> <p class="tip-text small"> Please start by entering your date of birth. </p> <p class="tip-text small grey"> (We'll never show your age but it would be used to celebrate you) </p> <br> <div class="show-before-identity"> <input class="input no-border birthday-input" type="date" name="birthday" placeholder="MM/DD/YYYY" autocomplete="off"> </div> <div class="step-button-group"> <div class="auth-btn cancel j-back">Back</div> <button class="auth-btn main-action submit disabled">Next</button> </div> </form> <form data-vce="login/enter-phone" class="hide enter-phone" data-error-text="Please enter your phone number."> <img class="head-img" src="https://aminoapps.com/static/img/enter_phone.svg"> <p class="tip-text">What's your phone number?</p> <div class="show-in-phone"> <div class="area-container" data-vce="login/area-code"> <input maxlength="4" name="area-code" type="text" class="input area-code-input" autocomplete="off" contenteditable="true"> <ul class="area-list"><li data-area-code="93" class="area-item">Afghanistan(+93)</li><li data-area-code="355" class="area-item">Albania(+355)</li><li data-area-code="213" class="area-item">Algeria(+213)</li><li data-area-code="1" class="area-item">American Samoa(+1)</li><li data-area-code="376" class="area-item">Andorra(+376)</li><li data-area-code="244" class="area-item">Angola(+244)</li><li data-area-code="1" class="area-item">Anguilla(+1)</li><li data-area-code="1" class="area-item">Antigua(+1)</li><li data-area-code="54" class="area-item">Argentina(+54)</li><li data-area-code="374" class="area-item">Armenia(+374)</li><li data-area-code="297" class="area-item">Aruba(+297)</li><li data-area-code="61" class="area-item">Australia(+61)</li><li data-area-code="43" class="area-item">Austria(+43)</li><li data-area-code="994" class="area-item">Azerbaijan(+994)</li><li data-area-code="973" class="area-item">Bahrain(+973)</li><li data-area-code="880" class="area-item">Bangladesh(+880)</li><li data-area-code="1" class="area-item">Barbados(+1)</li><li data-area-code="375" class="area-item">Belarus(+375)</li><li data-area-code="32" class="area-item">Belgium(+32)</li><li data-area-code="501" class="area-item">Belize(+501)</li><li data-area-code="229" class="area-item">Benin(+229)</li><li data-area-code="1" class="area-item">Bermuda(+1)</li><li data-area-code="975" class="area-item">Bhutan(+975)</li><li data-area-code="591" class="area-item">Bolivia(+591)</li><li data-area-code="599" class="area-item">Bonaire, Sint Eustatius and Saba(+599)</li><li data-area-code="387" class="area-item">Bosnia and Herzegovina(+387)</li><li data-area-code="267" class="area-item">Botswana(+267)</li><li data-area-code="55" class="area-item">Brazil(+55)</li><li data-area-code="246" class="area-item">British Indian Ocean Territory(+246)</li><li data-area-code="1" class="area-item">British Virgin Islands(+1)</li><li data-area-code="673" class="area-item">Brunei(+673)</li><li data-area-code="359" class="area-item">Bulgaria(+359)</li><li data-area-code="226" class="area-item">Burkina Faso(+226)</li><li data-area-code="257" class="area-item">Burundi(+257)</li><li data-area-code="855" class="area-item">Cambodia(+855)</li><li data-area-code="237" class="area-item">Cameroon(+237)</li><li data-area-code="1" class="area-item">Canada(+1)</li><li data-area-code="238" class="area-item">Cape Verde(+238)</li><li data-area-code="1" class="area-item">Cayman Islands(+1)</li><li data-area-code="236" class="area-item">Central African Republic(+236)</li><li data-area-code="235" class="area-item">Chad(+235)</li><li data-area-code="56" class="area-item">Chile(+56)</li><li data-area-code="86" class="area-item">China(+86)</li><li data-area-code="57" class="area-item">Colombia(+57)</li><li data-area-code="269" class="area-item">Comoros(+269)</li><li data-area-code="682" class="area-item">Cook Islands(+682)</li><li data-area-code="506" class="area-item">Costa Rica(+506)</li><li data-area-code="225" class="area-item">Côte d'Ivoire(+225)</li><li data-area-code="385" class="area-item">Croatia(+385)</li><li data-area-code="53" class="area-item">Cuba(+53)</li><li data-area-code="599" class="area-item">Curaçao(+599)</li><li data-area-code="357" class="area-item">Cyprus(+357)</li><li data-area-code="420" class="area-item">Czech Republic(+420)</li><li data-area-code="243" class="area-item">Democratic Republic of the Congo(+243)</li><li data-area-code="45" class="area-item">Denmark(+45)</li><li data-area-code="253" class="area-item">Djibouti(+253)</li><li data-area-code="1" class="area-item">Dominica(+1)</li><li data-area-code="1" class="area-item">Dominican Republic(+1)</li><li data-area-code="593" class="area-item">Ecuador(+593)</li><li data-area-code="20" class="area-item">Egypt(+20)</li><li data-area-code="503" class="area-item">El Salvador(+503)</li><li data-area-code="240" class="area-item">Equatorial Guinea(+240)</li><li data-area-code="291" class="area-item">Eritrea(+291)</li><li data-area-code="372" class="area-item">Estonia(+372)</li><li data-area-code="251" class="area-item">Ethiopia(+251)</li><li data-area-code="500" class="area-item">Falkland Islands(+500)</li><li data-area-code="298" class="area-item">Faroe Islands(+298)</li><li data-area-code="691" class="area-item">Federated States of Micronesia(+691)</li><li data-area-code="679" class="area-item">Fiji(+679)</li><li data-area-code="358" class="area-item">Finland(+358)</li><li data-area-code="33" class="area-item">France(+33)</li><li data-area-code="594" class="area-item">French Guiana(+594)</li><li data-area-code="689" class="area-item">French Polynesia(+689)</li><li data-area-code="241" class="area-item">Gabon(+241)</li><li data-area-code="995" class="area-item">Georgia(+995)</li><li data-area-code="49" class="area-item">Germany(+49)</li><li data-area-code="233" class="area-item">Ghana(+233)</li><li data-area-code="350" class="area-item">Gibraltar(+350)</li><li data-area-code="30" class="area-item">Greece(+30)</li><li data-area-code="299" class="area-item">Greenland(+299)</li><li data-area-code="1" class="area-item">Grenada(+1)</li><li data-area-code="590" class="area-item">Guadeloupe(+590)</li><li data-area-code="1" class="area-item">Guam(+1)</li><li data-area-code="502" class="area-item">Guatemala(+502)</li><li data-area-code="44" class="area-item">Guernsey(+44)</li><li data-area-code="224" class="area-item">Guinea(+224)</li><li data-area-code="245" class="area-item">Guinea-Bissau(+245)</li><li data-area-code="592" class="area-item">Guyana(+592)</li><li data-area-code="509" class="area-item">Haiti(+509)</li><li data-area-code="504" class="area-item">Honduras(+504)</li><li data-area-code="852" class="area-item">Hong Kong(+852)</li><li data-area-code="36" class="area-item">Hungary(+36)</li><li data-area-code="354" class="area-item">Iceland(+354)</li><li data-area-code="91" class="area-item">India(+91)</li><li data-area-code="62" class="area-item">Indonesia(+62)</li><li data-area-code="98" class="area-item">Iran(+98)</li><li data-area-code="964" class="area-item">Iraq(+964)</li><li data-area-code="353" class="area-item">Ireland(+353)</li><li data-area-code="44" class="area-item">Isle Of Man(+44)</li><li data-area-code="972" class="area-item">Israel(+972)</li><li data-area-code="39" class="area-item">Italy(+39)</li><li data-area-code="1" class="area-item">Jamaica(+1)</li><li data-area-code="81" class="area-item">Japan(+81)</li><li data-area-code="44" class="area-item">Jersey(+44)</li><li data-area-code="962" class="area-item">Jordan(+962)</li><li data-area-code="7" class="area-item">Kazakhstan(+7)</li><li data-area-code="254" class="area-item">Kenya(+254)</li><li data-area-code="686" class="area-item">Kiribati(+686)</li><li data-area-code="965" class="area-item">Kuwait(+965)</li><li data-area-code="996" class="area-item">Kyrgyzstan(+996)</li><li data-area-code="856" class="area-item">Laos(+856)</li><li data-area-code="371" class="area-item">Latvia(+371)</li><li data-area-code="961" class="area-item">Lebanon(+961)</li><li data-area-code="266" class="area-item">Lesotho(+266)</li><li data-area-code="231" class="area-item">Liberia(+231)</li><li data-area-code="218" class="area-item">Libya(+218)</li><li data-area-code="423" class="area-item">Liechtenstein(+423)</li><li data-area-code="370" class="area-item">Lithuania(+370)</li><li data-area-code="352" class="area-item">Luxembourg(+352)</li><li data-area-code="853" class="area-item">Macau(+853)</li><li data-area-code="389" class="area-item">Macedonia(+389)</li><li data-area-code="261" class="area-item">Madagascar(+261)</li><li data-area-code="265" class="area-item">Malawi(+265)</li><li data-area-code="60" class="area-item">Malaysia(+60)</li><li data-area-code="960" class="area-item">Maldives(+960)</li><li data-area-code="223" class="area-item">Mali(+223)</li><li data-area-code="356" class="area-item">Malta(+356)</li><li data-area-code="692" class="area-item">Marshall Islands(+692)</li><li data-area-code="596" class="area-item">Martinique(+596)</li><li data-area-code="222" class="area-item">Mauritania(+222)</li><li data-area-code="230" class="area-item">Mauritius(+230)</li><li data-area-code="262" class="area-item">Mayotte(+262)</li><li data-area-code="52" class="area-item">Mexico(+52)</li><li data-area-code="373" class="area-item">Moldova(+373)</li><li data-area-code="377" class="area-item">Monaco(+377)</li><li data-area-code="976" class="area-item">Mongolia(+976)</li><li data-area-code="382" class="area-item">Montenegro(+382)</li><li data-area-code="1" class="area-item">Montserrat(+1)</li><li data-area-code="212" class="area-item">Morocco(+212)</li><li data-area-code="258" class="area-item">Mozambique(+258)</li><li data-area-code="95" class="area-item">Myanmar(+95)</li><li data-area-code="264" class="area-item">Namibia(+264)</li><li data-area-code="674" class="area-item">Nauru(+674)</li><li data-area-code="977" class="area-item">Nepal(+977)</li><li data-area-code="31" class="area-item">Netherlands(+31)</li><li data-area-code="687" class="area-item">New Caledonia(+687)</li><li data-area-code="64" class="area-item">New Zealand(+64)</li><li data-area-code="505" class="area-item">Nicaragua(+505)</li><li data-area-code="227" class="area-item">Niger(+227)</li><li data-area-code="234" class="area-item">Nigeria(+234)</li><li data-area-code="683" class="area-item">Niue(+683)</li><li data-area-code="672" class="area-item">Norfolk Island(+672)</li><li data-area-code="850" class="area-item">North Korea(+850)</li><li data-area-code="1" class="area-item">Northern Mariana Islands(+1)</li><li data-area-code="47" class="area-item">Norway(+47)</li><li data-area-code="968" class="area-item">Oman(+968)</li><li data-area-code="92" class="area-item">Pakistan(+92)</li><li data-area-code="680" class="area-item">Palau(+680)</li><li data-area-code="970" class="area-item">Palestine(+970)</li><li data-area-code="507" class="area-item">Panama(+507)</li><li data-area-code="675" class="area-item">Papua New Guinea(+675)</li><li data-area-code="595" class="area-item">Paraguay(+595)</li><li data-area-code="51" class="area-item">Peru(+51)</li><li data-area-code="63" class="area-item">Philippines(+63)</li><li data-area-code="48" class="area-item">Poland(+48)</li><li data-area-code="351" class="area-item">Portugal(+351)</li><li data-area-code="1" class="area-item">Puerto Rico(+1)</li><li data-area-code="974" class="area-item">Qatar(+974)</li><li data-area-code="242" class="area-item">Republic of the Congo(+242)</li><li data-area-code="262" class="area-item">Réunion(+262)</li><li data-area-code="40" class="area-item">Romania(+40)</li><li data-area-code="7" class="area-item">Russia(+7)</li><li data-area-code="250" class="area-item">Rwanda(+250)</li><li data-area-code="290" class="area-item">Saint Helena(+290)</li><li data-area-code="1" class="area-item">Saint Kitts and Nevis(+1)</li><li data-area-code="508" class="area-item">Saint Pierre and Miquelon(+508)</li><li data-area-code="1" class="area-item">Saint Vincent and the Grenadines(+1)</li><li data-area-code="685" class="area-item">Samoa(+685)</li><li data-area-code="378" class="area-item">San Marino(+378)</li><li data-area-code="239" class="area-item">Sao Tome and Principe(+239)</li><li data-area-code="966" class="area-item">Saudi Arabia(+966)</li><li data-area-code="221" class="area-item">Senegal(+221)</li><li data-area-code="381" class="area-item">Serbia(+381)</li><li data-area-code="248" class="area-item">Seychelles(+248)</li><li data-area-code="232" class="area-item">Sierra Leone(+232)</li><li data-area-code="65" class="area-item">Singapore(+65)</li><li data-area-code="1" class="area-item">Sint Maarten(+1)</li><li data-area-code="421" class="area-item">Slovakia(+421)</li><li data-area-code="386" class="area-item">Slovenia(+386)</li><li data-area-code="677" class="area-item">Solomon Islands(+677)</li><li data-area-code="252" class="area-item">Somalia(+252)</li><li data-area-code="27" class="area-item">South Africa(+27)</li><li data-area-code="82" class="area-item">South Korea(+82)</li><li data-area-code="211" class="area-item">South Sudan(+211)</li><li data-area-code="34" class="area-item">Spain(+34)</li><li data-area-code="94" class="area-item">Sri Lanka(+94)</li><li data-area-code="1" class="area-item">St. Lucia(+1)</li><li data-area-code="249" class="area-item">Sudan(+249)</li><li data-area-code="597" class="area-item">Suriname(+597)</li><li data-area-code="268" class="area-item">Swaziland(+268)</li><li data-area-code="46" class="area-item">Sweden(+46)</li><li data-area-code="41" class="area-item">Switzerland(+41)</li><li data-area-code="963" class="area-item">Syria(+963)</li><li data-area-code="886" class="area-item">Taiwan(+886)</li><li data-area-code="992" class="area-item">Tajikistan(+992)</li><li data-area-code="255" class="area-item">Tanzania(+255)</li><li data-area-code="66" class="area-item">Thailand(+66)</li><li data-area-code="1" class="area-item">The Bahamas(+1)</li><li data-area-code="220" class="area-item">The Gambia(+220)</li><li data-area-code="670" class="area-item">Timor-Leste(+670)</li><li data-area-code="228" class="area-item">Togo(+228)</li><li data-area-code="690" class="area-item">Tokelau(+690)</li><li data-area-code="676" class="area-item">Tonga(+676)</li><li data-area-code="1" class="area-item">Trinidad and Tobago(+1)</li><li data-area-code="216" class="area-item">Tunisia(+216)</li><li data-area-code="90" class="area-item">Turkey(+90)</li><li data-area-code="993" class="area-item">Turkmenistan(+993)</li><li data-area-code="1" class="area-item">Turks and Caicos Islands(+1)</li><li data-area-code="688" class="area-item">Tuvalu(+688)</li><li data-area-code="256" class="area-item">Uganda(+256)</li><li data-area-code="380" class="area-item">Ukraine(+380)</li><li data-area-code="971" class="area-item">United Arab Emirates(+971)</li><li data-area-code="44" class="area-item">United Kingdom(+44)</li><li data-area-code="1" class="area-item">United States(+1)</li><li data-area-code="598" class="area-item">Uruguay(+598)</li><li data-area-code="1" class="area-item">US Virgin Islands(+1)</li><li data-area-code="998" class="area-item">Uzbekistan(+998)</li><li data-area-code="678" class="area-item">Vanuatu(+678)</li><li data-area-code="58" class="area-item">Venezuela(+58)</li><li data-area-code="84" class="area-item">Vietnam(+84)</li><li data-area-code="681" class="area-item">Wallis and Futuna(+681)</li><li data-area-code="212" class="area-item">Western Sahara(+212)</li><li data-area-code="967" class="area-item">Yemen(+967)</li><li data-area-code="260" class="area-item">Zambia(+260)</li>  <li class="area-item no-result" data-area-code="">No results</li> </ul> </div> <input class="input no-border phone-input" type="tel" name="phoneNumber" placeholder="Phone number" autocomplete="off"> </div> <div class="step-button-group"> <div class="auth-btn cancel j-back">Back</div> <button class="auth-btn main-action submit disabled">Next</button> </div> <div class="g-recaptcha" id="signup-recaptcha" data-sitekey="6Ldl_kwUAAAAAB3HCpbAKU-rwUPXZaxeH7ADEOSC" data-size="invisible"> </div> </form> <form data-vce="login/enter-email" class="hide enter-email" data-error-text="Please enter your email."> <img class="head-img" src="https://aminoapps.com/static/img/enter_email.svg"> <p class="tip-text ">What's your email?</p> <input class="input no-border" type="email" name="signup-email" placeholder="Email"> <div class="step-button-group"> <div class="auth-btn cancel j-back">Back</div> <button class="auth-btn main-action submit disabled">Next</button> </div> </form> <div data-vce="login/reactivate-account" class="account-reactivation"> <div class="hide reactivate-account"> <img class="head-img" src="https://aminoapps.com/static/img/reactivate_account.svg"> <p class="tip-text">Re-activate your account?</p> <p class="tip-text small"> Your account was previously deleted.<br>Do you wish to re-activate it? </p> <div class="step-button-group"> <div class="auth-btn cancel j-back">N0, KEEP MY ACCOUNT DELETED</div> <button class="auth-btn main-action yes">YES, RE-ACTIVATE MY ACCOUNT</button> </div> </div> <div class="hide reactivate-account-password"> <img class="head-img" src="https://aminoapps.com/static/img/enter_password.svg"> <p class="tip-text">What's your password?</p> <p class="tip-text small"> Please enter the password associated with your email address </p> <input class="input no-border account-password" type="password" name="accountPassword" placeholder="Password"> <small class="forget-pw-tip">Forgot your password? Go to your settings in the app.</small> <div class="step-button-group"> <button class="auth-btn cancel j-back">Back</button> <button class="auth-btn main-action submit reactivate-submit">Next</button> </div> </div> </div> <div data-vce="login/verify-code" class="hide verify-code" data-error-text="Incorrect verification code."> <img class="head-img" src="https://aminoapps.com/static/img/enter_code.svg"> <p class="tip-text "> What's your code? </p> <p class="tip-text small show-in-phone">We just sent a code to the following phone number:</p> <p class="tip-text small show-in-email">We just sent a code to the following email address:</p> <p class="tip-text small identity">  <span>{{user_identity}}</span> </p> <p class="tip-text small show-in-email">Please enter your confirmation code below:</p> <div class="verify-code-container"> <input placeholder="X" class="code-input" maxlength="1"> <input placeholder="X" class="code-input" maxlength="1"> <input placeholder="X" class="code-input" maxlength="1"> <input placeholder="X" class="code-input" maxlength="1"> <input placeholder="X" class="code-input" maxlength="1"> <input placeholder="X" class="code-input" maxlength="1"> </div> <div class="resend-container">  <span class="resend-tip hide">You can resend the code in <span>{{seconds}}s</span></span> <span class="resend-now"> Resend the code<i class="amino-icon amino-icon-reload"></i> </span> </div> <div class="step-button-group"> <button class="auth-btn cancel j-back">Back</button> <button class="auth-btn main-action submit disabled">Next</button> </div> <div class="g-recaptcha" id="signup-email-recaptcha" data-sitekey="6Ldl_kwUAAAAAB3HCpbAKU-rwUPXZaxeH7ADEOSC" data-size="invisible"> </div> </div> <div data-vce="login/create-password" class="hide create-password" data-error-text="Password should have 6+ characters."> <img class="head-img" src="https://aminoapps.com/static/img/enter_password.svg"> <p class="tip-text show-in-email hide">Your email has been verified <br> Now create a password</p> <p class="tip-text show-in-phone hide">Your phone number has been verified <br> Now create a password</p> <input class="input no-border" type="password" name="newpassword" placeholder="Password"> <p class="tip-text bellow-input">Minimum 6 characters </p> <div class="step-button-group"> <button class="auth-btn cancel j-back">Back</button> <button class="auth-btn main-action submit disabled">Next</button> </div> <div class="g-recaptcha" id="password-recaptcha" data-sitekey="6Ldl_kwUAAAAAB3HCpbAKU-rwUPXZaxeH7ADEOSC" data-size="invisible"> </div> </div> <div data-vce="login/create-profile" class="hide create-profile" data-image-error-text="Image upload failed." data-image-too-large-text="That's a great pic, but it's a bit too big... Please keep it under 6MB."> <div class="avatar-display head-img" data-rendered="Change" data-error-text="Whoops, you forgot to upload a photo."> <img class="profile-placeholder img-cover" src="https://wa1.narvii.com/static/img/enter_photo.svg" alt="A placeholder for avatar uploader"> <img class="profile-icon img-cover hide" src="https://aminoapps.com/login" alt="User's Profile"> <input id="avatar-input" type="file" name="avatar-input" class="avatar-input" accept="image/*"> </div> <p class="tip-text">Create your profile</p> <div class="nickname-container"> <input class="input no-border" type="text" name="nickname" maxlength="50" placeholder="Username" data-error-text="Please enter your name."> <label class="length-notification"><span></span>/50</label> </div> <div class="license-agreement" data-error-text="You need to agree to the Terms of Service and Privacy Policy in order to sign up."> <input class="checkbox" type="checkbox" name="license" id="license">  <label for="license" class="license-label"> I agree to Amino's <a href="https://narvii.com/tos.html" target="_blank">Terms of Service</a> and <a href="https://narvii.com/privacy" target="_blank">Privacy Policy</a>. </label> </div> <div class="step-button-group"> <button class="auth-btn cancel j-back">Back</button> <button class="auth-btn main-action submit disabled">Sign Up</button> </div> </div> <div class="hide account-created"> <img class="profile-icon img-cover" src="https://aminoapps.com/login" alt="Your Avatar"> <div class="welcome-text"> Looking good, <span></span>. </div> </div> <div class="hide account-reactivated"> <img class="head-img" src="https://aminoapps.com/static/img/account_reactivated.svg"> <p class="tip-text">Great! Your account has been<br>re-activated!</p> <p class="tip-text small">You are being redirected to login to your account</p> </div> <small class="hide two-factor-auth-help"> If you're having trouble and need help, contact us at <a href="https://support.aminoapps.com/hc/en-us/requests/new?ticket_form_id=114093991894" target="_blank">support.aminoapps.com</a> </small> <div class="step-indicator" data-vce="login/step-indicator" data-template-text="Step {{step}} of {{total}}"> <span class="step-item"></span> <span class="step-item"></span> <span class="step-item"></span> <span class="step-item"></span> <span class="step-item"></span> </div> </div><div class="hide delete-account-area"> <div class="delete-account" data-vce="login/delete-account"> <div class="delete-account-ask"> <img class="head-img head-delete-account" src="https://aminoapps.com/static/img/delete-account.svg"> <p class="tip-text">Delete your account?</p> <p class="tip-text small">Deleting your account is permanent <strong>after 7 days.</strong></p> <br> <p class="tip-text small"><strong>• Your account is no longer accessible</strong></p> <p class="tip-text small"><strong>• You’ll no longer receive Amino messages, or emails from us</strong></p> <p class="tip-text small"><strong>• Your username won’t be searchable anywhere on Amino</strong></p> <p class="tip-text small"><strong>• Your profile will be deleted from contact lists of people you’ve talked to</strong></p> <br> <p class="tip-text small">Once your account is permanently deleted,you will no longer be able to log back in or access any information</p> <div class="step-button-group"> <button class="auth-btn cancel keep-account-btn">NO, KEEP MY ACCOUNT</button> <button class="auth-btn delete-account-btn">YES, DELETE MY ACCOUNT</button> </div> </div> <div class="hide delete-account-enter-password" data-error-text="Password should have 6+ characters."> <img class="head-img" src="https://aminoapps.com/static/img/enter_password.svg"> <p class="tip-text">What’s your password?</p> <p class="tip-text small">Please enter the password associated with your account</p> <input class="input no-border" type="password" name="password" placeholder="Password"> <small class="forget-pw-tip">Forgot your password? Go to your settings in the app.</small> <div class="step-button-group"> <button class="auth-btn cancel abort-account-delete j-back">CANCEL</button> <button class="auth-btn main-action delete-account-submit-password disabled">DELETE</button> </div> </div> <div class="hide account-deleted"> <img class="head-img" src="https://aminoapps.com/static/img/account_reactivated.svg"> <p class="tip-text">Your account has been successfully<br>deleted!</p> </div> </div> </div> <div class="close pointer">×</div> <div class="signin-overlay error-overlay"> <div class="content"> <i class="hide icon-warn fa fa-exclamation-triangle"></i> <p class="error-message tip-text small"></p> <button class="hide auth-btn got-it main-action exit-overlay">Got it</button> <div class="hide sign-with-email"> <button class="auth-btn main-action to-email-btn">Sign in with email</button> <button class="auth-btn cancel">Cancel</button> </div> <div class="hide reenter-password" data-vce="login/reenter-password"> <input class="input no-border" type="password" name="password2" placeholder="Password"> <div class="form-tip remote-error"></div> <button class="auth-btn main-action submit" disabled="">Sign in</button> <button class="auth-btn cancel">Cancel</button> </div> </div> </div> <div class="confirm-exit signin-overlay hide"> <div class="content"> <p class="error-message tip-text small">Are you sure you don’t want to sign up for Amino?</p> <button class="auth-btn go-back">Whoops, no take me back.</button> <button class="auth-btn really-close">Yes, I’m sure :(</button> </div> </div> <div data-vce="toast" class="toast"> <div class="content"></div> </div> <div class="signin-overlay loading-overlay amino-logo-animation"> <div class="mask-container"> <div class="logo-mask fg"> <svg class="amino-logo-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 511.5 144.2"> <g> <path d="M298 31.7c10 0 16.5-7.1 16.5-15.8C314.5 7.1 307.6 0 298 0c-9.7 0-16.5 7.1-16.5 15.8 0 8.8 6.7 15.9 16.5 15.9z"></path> <path d="M468.8 47.7c-24.2 0-41.3 18.6-41.3 47.2 0 7.1.7 13.5 2.2 19.3-3.9 3.2-7.5 5.4-10.9 5.4-5.2 0-7.6-3.1-7.6-9.8V79.4c0-19-11.5-31.6-29.3-31.6-12.3 0-21.3 4.8-27.9 11.7-.5-.8-1.1-2-1.8-3.2-1.9-3.4-4.4-5.9-9.4-5.9H339c-4.2 0-6.6 2.9-6.6 7.9v54.3c-4.5 4-9.6 7.1-13.8 7.1-5.2 0-7.6-3.2-7.6-9.8V58.3c0-5.2-2-7.9-6.8-7.9h-13.3c-4.2 0-6.6 2.9-6.6 7.9v55.8c-4.5 3.5-8.2 5.6-11.9 5.6-5.2 0-7.6-3.1-7.6-9.8V79.4c0-19-10.2-31.6-28-31.6-12.3 0-21.7 5.5-28.3 12.5-4.8-7.5-12.5-12.4-23.5-12.4s-18.5 4.1-26.5 11.5c-3.4-7.1-8-8.9-13.4-8.9-9.6 0-30.8 5.9-46.8 12.7-7.2-18.5-18.1-43.6-21.6-51.5-.5-1.5-1.7-3.8-2.7-5.2C71.4 2.8 67.8.8 62.6.8c-4.6 0-7.9 1.9-10.4 4.8-1.3 1.5-2.8 4-3.6 5.9-4.5 10.9-33.3 84.4-47.4 120.7-2.2 5.7-1.8 9.4 3.7 9.4h14.6c4.3 0 5.9-1.9 10.2-6.4 15.7-16.7 34.7-29.8 52.2-38.8 7.1 17.3 14.2 35.2 15.7 38.8 2.1 5.2 4.8 6.4 9.6 6.4h14.2c5.5 0 6.4-3.7 4.6-8.5-3.2-8.5-10.9-27.4-19.1-47.8 9.5-4.5 21.1-8 24.8-8 4 0 5.5 2.8 5.5 7.1v49.2c0 5.2 2 7.9 6.8 7.9h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 3.9-14.9 12.2-14.9 8.3 0 11.5 6.4 11.5 14.9v45.6c0 5.2 2 7.9 6.8 7.9h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 3.9-14.9 12.2-14.9 8.3 0 11.5 6.4 11.5 14.9v29.8c0 16.2 8.9 26.3 23.2 26.3 11.7 0 19.7-4.1 27.2-9.9 3.9 6.3 10.6 9.9 19.1 9.9 10.1 0 18.4-5.1 25-10 .1 4.8 2.2 7.4 6.8 7.4h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 4.7-14.9 12.9-14.9s12.3 6.4 12.3 14.9v29.8c0 16.2 8.9 26.3 23.2 26.3 12.1 0 23.3-5.6 31.1-12 6.8 7.7 16.7 12 30 12 28.9 0 42.7-19.2 42.7-49.2.1-28.6-16.3-47.2-42.6-47.2zM43.3 94.3c3.1-7.6 9.6-24.9 13.9-35.9 1.5-3.9 2.7-6 5.4-6 2.8 0 4.1 3.3 5.3 6.1 1.9 4.5 3.9 10.5 5.7 15.4-10.3 5.3-21.3 13-30.3 20.4zm426.2 25.2c-10.1 0-14.6-9.7-14.6-24.5 0-13.4 5.5-22.6 14.6-22.6 9.5 0 14.6 9.2 14.6 22.6 0 14.8-3.8 24.5-14.6 24.5z"></path> </g> </svg> </div> <div class="logo-mask bg"> <svg class="amino-logo-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 511.5 144.2"> <g> <path d="M298 31.7c10 0 16.5-7.1 16.5-15.8C314.5 7.1 307.6 0 298 0c-9.7 0-16.5 7.1-16.5 15.8 0 8.8 6.7 15.9 16.5 15.9z"></path> <path d="M468.8 47.7c-24.2 0-41.3 18.6-41.3 47.2 0 7.1.7 13.5 2.2 19.3-3.9 3.2-7.5 5.4-10.9 5.4-5.2 0-7.6-3.1-7.6-9.8V79.4c0-19-11.5-31.6-29.3-31.6-12.3 0-21.3 4.8-27.9 11.7-.5-.8-1.1-2-1.8-3.2-1.9-3.4-4.4-5.9-9.4-5.9H339c-4.2 0-6.6 2.9-6.6 7.9v54.3c-4.5 4-9.6 7.1-13.8 7.1-5.2 0-7.6-3.2-7.6-9.8V58.3c0-5.2-2-7.9-6.8-7.9h-13.3c-4.2 0-6.6 2.9-6.6 7.9v55.8c-4.5 3.5-8.2 5.6-11.9 5.6-5.2 0-7.6-3.1-7.6-9.8V79.4c0-19-10.2-31.6-28-31.6-12.3 0-21.7 5.5-28.3 12.5-4.8-7.5-12.5-12.4-23.5-12.4s-18.5 4.1-26.5 11.5c-3.4-7.1-8-8.9-13.4-8.9-9.6 0-30.8 5.9-46.8 12.7-7.2-18.5-18.1-43.6-21.6-51.5-.5-1.5-1.7-3.8-2.7-5.2C71.4 2.8 67.8.8 62.6.8c-4.6 0-7.9 1.9-10.4 4.8-1.3 1.5-2.8 4-3.6 5.9-4.5 10.9-33.3 84.4-47.4 120.7-2.2 5.7-1.8 9.4 3.7 9.4h14.6c4.3 0 5.9-1.9 10.2-6.4 15.7-16.7 34.7-29.8 52.2-38.8 7.1 17.3 14.2 35.2 15.7 38.8 2.1 5.2 4.8 6.4 9.6 6.4h14.2c5.5 0 6.4-3.7 4.6-8.5-3.2-8.5-10.9-27.4-19.1-47.8 9.5-4.5 21.1-8 24.8-8 4 0 5.5 2.8 5.5 7.1v49.2c0 5.2 2 7.9 6.8 7.9h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 3.9-14.9 12.2-14.9 8.3 0 11.5 6.4 11.5 14.9v45.6c0 5.2 2 7.9 6.8 7.9h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 3.9-14.9 12.2-14.9 8.3 0 11.5 6.4 11.5 14.9v29.8c0 16.2 8.9 26.3 23.2 26.3 11.7 0 19.7-4.1 27.2-9.9 3.9 6.3 10.6 9.9 19.1 9.9 10.1 0 18.4-5.1 25-10 .1 4.8 2.2 7.4 6.8 7.4h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 4.7-14.9 12.9-14.9s12.3 6.4 12.3 14.9v29.8c0 16.2 8.9 26.3 23.2 26.3 12.1 0 23.3-5.6 31.1-12 6.8 7.7 16.7 12 30 12 28.9 0 42.7-19.2 42.7-49.2.1-28.6-16.3-47.2-42.6-47.2zM43.3 94.3c3.1-7.6 9.6-24.9 13.9-35.9 1.5-3.9 2.7-6 5.4-6 2.8 0 4.1 3.3 5.3 6.1 1.9 4.5 3.9 10.5 5.7 15.4-10.3 5.3-21.3 13-30.3 20.4zm426.2 25.2c-10.1 0-14.6-9.7-14.6-24.5 0-13.4 5.5-22.6 14.6-22.6 9.5 0 14.6 9.2 14.6 22.6 0 14.8-3.8 24.5-14.6 24.5z"></path> </g> </svg> </div></div> </div></div></div></div>
    <div class="swipe-indicator swipe-indicator-left">
        <i class="fa fa-arrow-circle-left fa-3x"></i>
    </div>
    <div class="swipe-indicator swipe-indicator-right">
        <i class="fa fa-arrow-circle-right fa-3x"></i>
    </div>
</div>

<div class="back-top">
    <a class="content block pointer">
        <i class="fa fa-arrow-up fa-2x"></i>
    </a>
</div>

<div data-vce="toast">
    <div class="content">
    </div>
</div>

 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:500,600,700,900&amp;display=swap"> <link rel="stylesheet" href="https://wa1.narvii.com/static/dist/css/font-awesome.e226b1bae.css">

       
<div id="gdpr-cookie-consent"> <h3>Cookie Policy </h3> <p>  This website saves cookies to your browser in order to improve your online experience and show you personalized content. Read our <a class="link" href="http://narvii.com/privacy" target="_blank">Privacy Policy</a> and <a class="link" href="https://support.aminoapps.com/hc/en-us/articles/360004040313-Does-Amino-use-cookies-on-its-website-" target="_blank">Cookie Policy</a> to get more information and learn how to set up your preferences. </p> <button class="confirm-close">Accept</button> </div>   
        
        

<footer>
  <!-- Quantcast Tag -->   <!-- The core Firebase JS SDK is always required and must be listed first -->  <!-- TODO: Add SDKs for Firebase products that you want to use https://firebase.google.com/docs/web/setup#available-libraries -->   </footer>
<div><div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;"><div class="grecaptcha-logo"></div><div class="grecaptcha-error"></div><textarea id="g-recaptcha-response-100000" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div><iframe style="display: none;"></iframe></div><div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div></div></div></div>
<style>


html, body { overflow-x: hidden; min-height: 100vh; }


.site-section { color: white; padding: 40px 0px 60px; max-width: 560px; margin: auto; }

.site-section a { color: rgb(4, 228, 185); }

.site-section .container { padding: 0px 25px; }

.site-section h2 { color: white; }

.site-section h2, .site-section h1 { font-family: Montserrat, sans-serif; font-weight: 600; }


.fb_hidden { position: absolute; top: -10000px; z-index: 10001; }

.fb_reposition { overflow: hidden; position: relative; }

.fb_invisible { display: none; }

.fb_reset { background: none; border: 0px; border-spacing: 0px; color: rgb(0, 0, 0); cursor: auto; direction: ltr; font-family: "lucida grande", tahoma, verdana, arial, sans-serif; font-size: 11px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 1; margin: 0px; overflow: visible; padding: 0px; text-align: left; text-decoration: none; text-indent: 0px; text-shadow: none; text-transform: none; visibility: visible; white-space: normal; word-spacing: normal; }

.fb_reset > div { overflow: hidden; }

@keyframes fb_transform { 
  0% { opacity: 0; transform: scale(0.95); }
  100% { opacity: 1; transform: scale(1); }
}

.fb_animate { animation: 0.3s ease 0s 1 normal forwards running fb_transform; }

.fb_dialog { background: rgba(82, 82, 82, 0.7); position: absolute; top: -10000px; z-index: 10001; }

.fb_dialog_advanced { border-radius: 8px; padding: 10px; }

.fb_dialog_content { background: rgb(255, 255, 255); color: rgb(55, 55, 55); }

.fb_dialog_close_icon { background: url("https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png") 0px 0px no-repeat scroll transparent; cursor: pointer; display: block; height: 15px; position: absolute; right: 18px; top: 17px; width: 15px; }

.fb_dialog_mobile .fb_dialog_close_icon { left: 5px; right: auto; top: 5px; }

.fb_dialog_padding { background-color: transparent; position: absolute; width: 1px; z-index: -1; }

.fb_dialog_close_icon:hover { background: url("https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png") 0px -15px no-repeat scroll transparent; }

.fb_dialog_close_icon:active { background: url("https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png") 0px -30px no-repeat scroll transparent; }

.fb_dialog_iframe { line-height: 0; }

.fb_dialog_content .dialog_title { background: rgb(109, 132, 180); border: 1px solid rgb(54, 88, 153); color: rgb(255, 255, 255); font-size: 14px; font-weight: bold; margin: 0px; }

.fb_dialog_content .dialog_title > span { background: url("https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif") 5px 50% no-repeat; float: left; padding: 5px 0px 7px 26px; }

body.fb_hidden { height: 100%; left: 0px; margin: 0px; overflow: visible; position: absolute; top: -10000px; transform: none; width: 100%; }

.fb_dialog.fb_dialog_mobile.loading { background: url("https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif") 50% 50% no-repeat white; min-height: 100%; min-width: 100%; overflow: hidden; position: absolute; top: 0px; z-index: 10001; }

.fb_dialog.fb_dialog_mobile.loading.centered { background: none; height: auto; min-height: initial; min-width: initial; width: auto; }

.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner { width: 100%; }

.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content { background: none; }

.loading.centered #fb_dialog_loader_close { clear: both; color: rgb(255, 255, 255); display: block; font-size: 18px; padding-top: 20px; }

#fb-root #fb_dialog_ipad_overlay { background: rgba(0, 0, 0, 0.4); inset: 0px; min-height: 100%; position: absolute; width: 100%; z-index: 10000; }

#fb-root #fb_dialog_ipad_overlay.hidden { display: none; }

.fb_dialog.fb_dialog_mobile.loading iframe { visibility: hidden; }

.fb_dialog_mobile .fb_dialog_iframe { position: sticky; top: 0px; }

.fb_dialog_content .dialog_header { border-bottom: 1px solid rgb(4, 59, 135); border-top-color: rgb(4, 59, 135); border-right-color: rgb(4, 59, 135); border-left-color: rgb(4, 59, 135); box-shadow: white 0px 1px 1px -1px inset; color: rgb(255, 255, 255); font: bold 14px Helvetica, sans-serif; text-overflow: ellipsis; text-shadow: rgba(0, 30, 84, 0.298) 0px -1px 0px; vertical-align: middle; white-space: nowrap; }

.fb_dialog_content .dialog_header table { height: 43px; width: 100%; }

.fb_dialog_content .dialog_header td.header_left { font-size: 12px; padding-left: 5px; vertical-align: middle; width: 60px; }

.fb_dialog_content .dialog_header td.header_right { font-size: 12px; padding-right: 5px; vertical-align: middle; width: 60px; }

.fb_dialog_content .touchable_button { background-clip: padding-box; border: 1px solid rgb(41, 72, 125); border-radius: 3px; display: inline-block; line-height: 18px; margin-top: 3px; max-width: 85px; padding: 4px 12px; position: relative; }

.fb_dialog_content .dialog_header .touchable_button input { background: none; border: none; color: rgb(255, 255, 255); font: bold 12px Helvetica, sans-serif; margin: 2px -12px; padding: 2px 6px 3px; text-shadow: rgba(0, 30, 84, 0.298) 0px -1px 0px; }

.fb_dialog_content .dialog_header .header_center { color: rgb(255, 255, 255); font-size: 16px; font-weight: bold; line-height: 18px; text-align: center; vertical-align: middle; }

.fb_dialog_content .dialog_content { background: url("https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif") 50% 50% no-repeat; border-width: 0px 1px; border-right-style: solid; border-left-style: solid; border-right-color: rgb(74, 74, 74); border-left-color: rgb(74, 74, 74); border-image: initial; border-bottom-style: initial; border-bottom-color: initial; border-top-style: initial; border-top-color: initial; height: 150px; }

.fb_dialog_content .dialog_footer { background: rgb(245, 246, 247); border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204) rgb(74, 74, 74) rgb(74, 74, 74); border-image: initial; height: 40px; }

#fb_dialog_loader_close { float: left; }

.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon { visibility: hidden; }

#fb_dialog_loader_spinner { animation: 1.2s linear 0s infinite normal none running rotateSpinner; background-color: transparent; background-image: url("https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png"); background-position: 50% 50%; background-repeat: no-repeat; height: 24px; width: 24px; }

@keyframes rotateSpinner { 
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.fb_iframe_widget { display: inline-block; position: relative; }

.fb_iframe_widget span { display: inline-block; position: relative; text-align: justify; }

.fb_iframe_widget iframe { position: absolute; }

.fb_iframe_widget_fluid_desktop, .fb_iframe_widget_fluid_desktop span, .fb_iframe_widget_fluid_desktop iframe { max-width: 100%; }

.fb_iframe_widget_fluid_desktop iframe { min-width: 220px; position: relative; }

.fb_iframe_widget_lift { z-index: 1; }

.fb_iframe_widget_fluid { display: inline; }

.fb_iframe_widget_fluid span { width: 100%; }

.fb_mpn_mobile_landing_page_slide_out { animation-duration: 200ms; animation-name: fb_mpn_landing_page_slide_out; transition-timing-function: ease-in; }

.fb_mpn_mobile_landing_page_slide_out_from_left { animation-duration: 200ms; animation-name: fb_mpn_landing_page_slide_out_from_left; transition-timing-function: ease-in; }

.fb_mpn_mobile_landing_page_slide_up { animation-duration: 500ms; animation-name: fb_mpn_landing_page_slide_up; transition-timing-function: ease-in; }

.fb_mpn_mobile_bounce_in { animation-duration: 300ms; animation-name: fb_mpn_bounce_in; transition-timing-function: ease-in; }

.fb_mpn_mobile_bounce_out { animation-duration: 300ms; animation-name: fb_mpn_bounce_out; transition-timing-function: ease-in; }

.fb_mpn_mobile_bounce_out_v2 { animation-duration: 300ms; animation-name: fb_mpn_fade_out; transition-timing-function: ease-in; }

.fb_customer_chat_bounce_in_v2 { animation-duration: 300ms; animation-name: fb_bounce_in_v2; transition-timing-function: ease-in; }

.fb_customer_chat_bounce_in_from_left { animation-duration: 300ms; animation-name: fb_bounce_in_from_left; transition-timing-function: ease-in; }

.fb_customer_chat_bounce_out_v2 { animation-duration: 300ms; animation-name: fb_bounce_out_v2; transition-timing-function: ease-in; }

.fb_customer_chat_bounce_out_from_left { animation-duration: 300ms; animation-name: fb_bounce_out_from_left; transition-timing-function: ease-in; }

.fb_invisible_flow { display: inherit; height: 0px; overflow-x: hidden; width: 0px; }

@keyframes fb_mpn_landing_page_slide_out { 
  0% { margin: 0px 12px; }
  60% { border-radius: 18px; }
  100% { border-radius: 50%; margin: 0px 24px; width: 60px; }
}

@keyframes fb_mpn_landing_page_slide_out_from_left { 
  0% { left: 12px; }
  60% { border-radius: 18px; }
  100% { border-radius: 50%; left: 12px; width: 60px; }
}

@keyframes fb_mpn_landing_page_slide_up { 
  0% { bottom: 0px; opacity: 0; }
  100% { bottom: 24px; opacity: 1; }
}

@keyframes fb_mpn_bounce_in { 
  0% { opacity: 0.5; top: 100%; }
  100% { opacity: 1; top: 0px; }
}

@keyframes fb_mpn_fade_out { 
  0% { bottom: 30px; opacity: 1; }
  100% { bottom: 0px; opacity: 0; }
}

@keyframes fb_mpn_bounce_out { 
  0% { opacity: 1; top: 0px; }
  100% { opacity: 0.5; top: 100%; }
}

@keyframes fb_bounce_in_v2 { 
  0% { opacity: 0; transform: scale(0, 0); transform-origin: right bottom; }
  50% { transform: scale(1.03, 1.03); transform-origin: right bottom; }
  100% { opacity: 1; transform: scale(1, 1); transform-origin: right bottom; }
}

@keyframes fb_bounce_in_from_left { 
  0% { opacity: 0; transform: scale(0, 0); transform-origin: left bottom; }
  50% { transform: scale(1.03, 1.03); transform-origin: left bottom; }
  100% { opacity: 1; transform: scale(1, 1); transform-origin: left bottom; }
}

@keyframes fb_bounce_out_v2 { 
  0% { opacity: 1; transform: scale(1, 1); transform-origin: right bottom; }
  100% { opacity: 0; transform: scale(0, 0); transform-origin: right bottom; }
}

@keyframes fb_bounce_out_from_left { 
  0% { opacity: 1; transform: scale(1, 1); transform-origin: left bottom; }
  100% { opacity: 0; transform: scale(0, 0); transform-origin: left bottom; }
}

@keyframes slideInFromBottom { 
  0% { opacity: 0.1; transform: translateY(100%); }
  100% { opacity: 1; transform: translateY(0px); }
}

@keyframes slideInFromBottomDelay { 
  0% { opacity: 0; transform: translateY(100%); }
  97% { opacity: 0; transform: translateY(100%); }
  100% { opacity: 1; transform: translateY(0px); }
}


.fa.login-page-loading-icon { font-size: 72px; position: absolute; top: 50%; left: 50%; margin: -36px 0px 0px -36px; color: rgb(221, 221, 221); transition: opacity 0.2s linear 0s; }

.modal-open .login-page-loading-icon { opacity: 0; }

.modal .overlay { display: none; }

.modal .popup.login-dialog .close { display: none; }


.community-hover-bg:hover { background: rgba(34, 25, 94, 0.2); }


#gdpr-cookie-consent { position: fixed; padding: 14px; font-size: 13px; background: white; box-shadow: rgba(0, 0, 0, 0.5) 0px 2px 4px; border-radius: 5px; bottom: 8px; right: 87px; max-width: 410px; color: rgb(26, 26, 26); z-index: 5005; }

#gdpr-cookie-consent > h3 { margin: 0px; font-size: 16px; font-weight: bold; line-height: 19px; }

#gdpr-cookie-consent .close { float: right; color: rgb(189, 189, 189); font-size: 20px; line-height: 16px; }

#gdpr-cookie-consent .link { color: rgb(15, 134, 255); }

#gdpr-cookie-consent > p { margin: 8px 0px 0px; line-height: 15px; }

#gdpr-cookie-consent > .confirm-close { background: none; border: 1px solid rgb(151, 151, 151); outline: none; border-radius: 8px; float: right; padding: 8px 25px; font-size: 14px; cursor: pointer; margin-top: 5px; }

.not-mobile #gdpr-cookie-consent > .confirm-close:hover { background: rgb(241, 241, 241); }

@media (max-width: 640px) {
  #gdpr-cookie-consent { left: 0px; right: -1px; bottom: 0px; border-radius: 0px; max-width: none; }
}



html { line-height: 1.15; text-size-adjust: 100%; }

body { margin: 0px; }

article, aside, footer, header, nav, section { display: block; }

h1 { font-size: 2em; margin: 0.67em 0px; }

figcaption, figure, main { display: block; }

figure { margin: 1em 40px; }

hr { box-sizing: content-box; height: 0px; overflow: visible; }

pre { font-family: monospace, monospace; font-size: 1em; }

a { background-color: transparent; }

abbr[title] { border-bottom: none; text-decoration: underline dotted; }

b, strong { font-weight: bolder; }

code, kbd, samp { font-family: monospace, monospace; font-size: 1em; }

dfn { font-style: italic; }

mark { background-color: rgb(255, 255, 0); color: rgb(0, 0, 0); }

small { font-size: 80%; }

sub, sup { font-size: 75%; line-height: 0; position: relative; vertical-align: baseline; }

sub { bottom: -0.25em; }

sup { top: -0.5em; }

audio, video { display: inline-block; }

audio:not([controls]) { display: none; height: 0px; }

img { border-style: none; }

svg:not(:root) { overflow: hidden; }

button, input, optgroup, select, textarea { font-family: sans-serif; font-size: 100%; line-height: 1.15; margin: 0px; }

button, input { overflow: visible; }

button, select { text-transform: none; }

[type="reset"], [type="submit"], button, html [type="button"] { appearance: button; }

fieldset { padding: 0.35em 0.75em 0.625em; }

legend { box-sizing: border-box; color: inherit; display: table; max-width: 100%; padding: 0px; white-space: normal; }

progress { display: inline-block; vertical-align: baseline; }

textarea { overflow: auto; }

[type="checkbox"], [type="radio"] { box-sizing: border-box; padding: 0px; }

[type="number"]::-webkit-inner-spin-button, [type="number"]::-webkit-outer-spin-button { height: auto; }

[type="search"] { appearance: textfield; outline-offset: -2px; }

[type="search"]::-webkit-search-cancel-button, [type="search"]::-webkit-search-decoration { appearance: none; }

::-webkit-file-upload-button { appearance: button; font: inherit; }

details, menu { display: block; }

summary { display: list-item; }

canvas { display: inline-block; }

[hidden], template { display: none; }

.emoji { width: 1.5em; height: 1.5em; display: inline-block; margin-bottom: -0.25em; background-size: contain; }

.main-page .avatar, .main-page section.recommend article.post.recommend-item .avatar, section.comment-list .avatar { border-radius: 50%; border: 1px solid rgba(0, 0, 0, 0.1); box-shadow: rgba(255, 255, 255, 0.5) 0px 0px 0.5px; margin-right: 0.5rem; width: 1em; height: 1em; display: block; }

.main-page .nickname, .main-page section.recommend article.post.recommend-item .nickname, section.comment-list .nickname { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; display: inline-flex; max-width: 240px; line-height: 24px; color: rgb(0, 145, 255); }

.main-page .nickname > .level-badge, .main-page section.recommend article.post.recommend-item .nickname > .level-badge, section.comment-list .nickname > .level-badge { -webkit-box-flex: 0; flex: 0 0 auto; margin-left: 0.25em; }

.main-page .nickname > .influencer-badge, .main-page section.recommend article.post.recommend-item .nickname > .influencer-badge, section.comment-list .nickname > .influencer-badge { -webkit-box-flex: 0; flex: 0 0 auto; margin-left: 0.25em; width: 24px; }

.main-page .nickname > .label-author, .main-page section.recommend article.post.recommend-item .nickname > .label-author, section.comment-list .nickname > .label-author { -webkit-box-flex: 0; flex: 0 0 auto; display: inline-block; margin-left: 0.25em; border: 1px solid rgb(255, 255, 255); border-radius: 5px; padding: 0px 7px; font-size: 12px; color: rgb(255, 255, 255); background-color: rgb(0, 145, 255); }

.main-page .nickname > .content, .main-page section.recommend article.post.recommend-item .nickname > .content, section.comment-list .nickname > .content { -webkit-box-flex: 0; flex: 0 1 auto; overflow: hidden; text-overflow: ellipsis; }

.main-page section.recommend .recommend-app, .main-page section.recommend article.post.recommend-item { border-radius: 5px; overflow: hidden; box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 4px; }

.main-page section.info .external-source-name { line-height: 20px; }

.main-page section.info .external-source-name i.fa { margin-right: 2px; font-size: larger; }

.main-page section.info .external-source-name i.fa-rss { color: rgb(255, 136, 0); }

.main-page section.info .external-source-name i.fa-reddit-alien { color: rgb(244, 78, 63); }

.main-page section.info .external-source-name i.fa-youtube-play { color: rgb(240, 0, 27); }

.main-page header.title > .title { position: relative; margin: 0px; line-height: 1.4; padding-left: 18px; }

.main-page header.title > .title::before { content: ""; position: absolute; top: 0.1em; left: 0px; display: block; height: 1.2em; width: 8px; border-left: 8px solid; color: inherit; }

.main-page section.recommend-new article.post.recommend-item .overlay, .main-page section.recommend article.post.recommend-item .cover .overlay, .simple-list article.post .overlay { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; background-color: rgba(0, 0, 0, 0.5); color: rgb(255, 255, 255); padding-left: 12%; }

.main-page section.recommend-new article.post.recommend-item .overlay .item-icon, .main-page section.recommend article.post.recommend-item .cover .overlay .item-icon, .simple-list article.post .overlay .item-icon { -webkit-box-flex: 0; flex: 0 0 auto; box-sizing: content-box; border-width: 1px 1px 15px; border-style: solid; border-color: rgb(255, 255, 255); border-image: initial; width: 58px; height: 58px; border-radius: 5px; margin-right: 1em; background-color: rgb(233, 232, 239); opacity: 1; }

.main-page section.recommend-new article.post.recommend-item .overlay .item-curated, .main-page section.recommend article.post.recommend-item .cover .overlay .item-curated, .simple-list article.post .overlay .item-curated { border-color: rgb(255, 192, 0); background-color: rgb(255, 255, 255); }

.main-page section.recommend-new article.post.recommend-item .overlay .counter, .main-page section.recommend article.post.recommend-item .cover .overlay .counter, .simple-list article.post .overlay .counter { line-height: 25px; margin-right: 0.5em; }

.main-page section.recommend-new article.post.recommend-item .overlay > .remain, .main-page section.recommend article.post.recommend-item .cover .overlay > .remain, .simple-list article.post .overlay > .remain { margin-right: auto; }

.main-page section.recommend-new article.post.recommend-item .overlay h3.title, .main-page section.recommend article.post.recommend-item .cover .overlay h3.title, .simple-list article.post .overlay h3.title { line-height: 28px; max-height: 56px; overflow: hidden; overflow-wrap: break-word; margin: 0px 0px 0.5em; }

.main-page section.recommend-new article.post.recommend-item .overlay i.amino-icon, .main-page section.recommend-new article.post.recommend-item .overlay i.fa, .main-page section.recommend article.post.recommend-item .cover .overlay i.amino-icon, .main-page section.recommend article.post.recommend-item .cover .overlay i.fa, .simple-list article.post .overlay i.amino-icon, .simple-list article.post .overlay i.fa { font-size: larger; vertical-align: middle; margin-right: 0.25em; }

html { box-sizing: border-box; font-size: 16px; font-family: "Helvetica Neue", Helvetica, "\\30D2ラギノ角ゴPro W3", "Hiragino Kaku Gothic Pro", "\\30E1イリオ", Meiryo, "ＭＳ  Ｐゴシック", arial, sans-serif; color: rgb(65, 69, 73); }

body, html { width: 100%; -webkit-tap-highlight-color: transparent; }

body { min-width: 320px; background: 50% center / cover fixed rgb(241, 241, 241); --scrollbar-padding:0px; }

body.chromeless { background-color: initial; }

*, ::after, ::before { box-sizing: inherit; }

a, a:active, a:hover, a:visited, button { color: inherit; text-decoration: none; -webkit-tap-highlight-color: transparent; outline: 0px; }

a.linkblue { color: rgb(0, 145, 255); }

img { vertical-align: middle; text-indent: -9999px; }

.block { display: block; }

a.underline { text-decoration: underline; }

button { outline: none; }

.disp_none { display: none; }

.pointer { -webkit-tap-highlight-color: transparent; cursor: pointer; }

.community-sidebar .global-nav > ul.content, ul.unstyled { list-style: none; padding: 0px; margin: 0px; }

.clearfix::after, .clearfix::before { content: " "; display: table; }

.clearfix::after { clear: both; }

.overflow-hidden { overflow: hidden; }

.img-cover { background-size: cover; }

.img-cover, amp-img.img-cover > img:last-child { object-fit: cover; }

.img-contain { background-size: contain; }

.img-contain, amp-img.img-contain > img:last-child { object-fit: contain; }

.article { line-height: 1.58; letter-spacing: -0.003em; }

.rich-content a[href][rel] { text-decoration: underline; }

.rich-content .embedded-video, .rich-content .image-container { margin: 0px 0px 1em; }

.rich-content p { margin: 0px; word-break: break-word; }

.rich-content p.bolder { font-size: 120%; font-weight: 700; }

.rich-content p.center { text-align: center; }

.rich-content p.italic { font-style: italic; }

.rich-content p.underline { text-decoration: underline; }

.rich-content p.strike { text-decoration: line-through; }

.rich-content p.strike.underline { text-decoration: underline line-through; }

.rich-content .image-container { max-width: 100%; width: 100%; }

.rich-content .image-container > .post-img { width: 100%; max-height: 100%; }

.rich-content .video-container { max-height: 350px; position: relative; }

.rich-content .caption { padding: 10px 14px; font-size: 14px; line-height: 16px; color: rgb(102, 102, 102); hyphens: auto; word-break: break-word; text-align: center; }

.rich-content .post-img { width: 100%; object-fit: contain; object-position: right top; }

.rich-content .embedded-video { position: relative; }

.rich-content .embedded-video::before { display: block; content: ""; width: 100%; padding-top: 56.25%; }

.rich-content .embedded-video > .content { position: absolute; inset: 0px; width: 100%; height: 100%; }

.avatar { background-color: rgb(255, 255, 255); border: 1px solid rgba(0, 0, 0, 0.1); }

.nickname { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }

.muted { color: rgb(155, 155, 155); }

ioschar { display: none; }

html[amp] ioschar { display: inline; letter-spacing: 4px; }

html[amp] emoji { display: none; }

img.emoji { width: 1.25em; height: 1.25em; margin: 0px 0.1em -0.25em; vertical-align: baseline; }

.btn { display: inline-block; border: 0px; border-radius: 0.4em; overflow: hidden; cursor: pointer; padding: 0.5em 1em; font-weight: 700; text-align: center; background-color: gray; box-shadow: rgba(77, 77, 77, 0.4) 0px 1px 2px; }

.btn, .btn:active, .btn:hover, .btn:link, .btn:visited { color: rgb(255, 255, 255); }

.btn:active:not(.hollow-btn) { transform: translateY(1px); box-shadow: none; }

.btn.primary { color: rgb(255, 255, 255); background-color: rgb(0, 190, 255); box-shadow: rgba(0, 114, 153, 0.4) 0px 1px 2px; }

.btn.primary:active, .btn.primary:hover, .btn.primary:link, .btn.primary:visited { color: rgb(255, 255, 255); }

.btn.primary:active:not(.hollow-btn) { transform: translateY(1px); box-shadow: none; }

.btn.amino { color: rgb(255, 255, 255); background-color: rgb(12, 219, 138); box-shadow: rgba(7, 122, 77, 0.4) 0px 1px 2px; }

.btn.amino:active, .btn.amino:hover, .btn.amino:link, .btn.amino:visited { color: rgb(255, 255, 255); }

.btn.amino:active:not(.hollow-btn) { transform: translateY(1px); box-shadow: none; }

.btn.amino.plain { color: rgb(12, 219, 138); background-color: rgb(255, 255, 255); box-shadow: rgba(204, 204, 204, 0.4) 0px 1px 2px; }

.btn.amino.plain:active, .btn.amino.plain:hover, .btn.amino.plain:link, .btn.amino.plain:visited { color: rgb(12, 219, 138); }

.btn.amino.plain:active:not(.hollow-btn) { transform: translateY(1px); box-shadow: none; }

.dark-theme .btn.amino { color: rgb(34, 25, 94); background-color: rgb(14, 224, 180); box-shadow: rgba(8, 128, 103, 0.4) 0px 1px 2px; }

.dark-theme .btn.amino:active, .dark-theme .btn.amino:hover, .dark-theme .btn.amino:link, .dark-theme .btn.amino:visited { color: rgb(34, 25, 94); }

.dark-theme .btn.amino:active:not(.hollow-btn) { transform: translateY(1px); box-shadow: none; }

.dark-theme .btn.amino.plain { color: rgb(14, 224, 180); background-color: transparent; box-shadow: transparent 0px 1px 2px; border: 1px solid rgb(14, 224, 180); }

.dark-theme .btn.amino.plain:active, .dark-theme .btn.amino.plain:hover, .dark-theme .btn.amino.plain:link, .dark-theme .btn.amino.plain:visited { color: rgb(14, 224, 180); }

.dark-theme .btn.amino.plain:active:not(.hollow-btn) { transform: translateY(1px); box-shadow: none; }

.btn.deep-dark { color: rgb(34, 25, 94); background-color: rgb(14, 224, 180); }

.btn.hollow-btn { background-color: transparent; box-shadow: none; border: 1px solid; }

.youtube-preview { position: relative; height: 100%; }

.youtube-preview > .img-cover { width: 100%; height: 100%; }

.youtube-preview > .amino-video-play { width: 36px; height: 36px; margin-left: -18px; margin-top: -18px; line-height: 0; }

.youtube-preview > .amino-video-play .play-icon-img { width: 14px; height: 32px; margin-left: 1.8px; }

.youtube-preview > .fa-youtube { position: absolute; bottom: 5%; right: 5%; font-size: 2em; border-radius: 0.1em; overflow: hidden; padding: 2px; color: rgb(255, 255, 255); background: rgb(0, 0, 0); opacity: 0.8; }

.embedded-youtube-video { background-color: rgb(0, 0, 0); background-size: cover; }

.container-fixed-bg, .fixed-bg { background-attachment: fixed; background-position: 50% center; background-size: cover; background-repeat: no-repeat; }

.container-fixed-bg > .content { position: relative; z-index: 100; color: rgb(255, 255, 255); }

.font-montserrat-black { font-family: Montserrat, sans-serif; font-weight: 900; letter-spacing: 0.5px; -webkit-font-smoothing: antialiased; }

.btn-download { background: rgb(252, 47, 127); border-radius: 8px; line-height: 1; }

.carousel-item { width: 135px; height: 135px; vertical-align: middle; cursor: pointer; }

.full-wh { width: 100%; height: 100%; }

.flex-remainder { height: 0px; visibility: hidden; }

.btn-round { border-radius: 1000px; }

.btn-vip { font-family: inherit; background: rgb(223, 28, 152); }

.notransition, .notransition *, .notransition::after, .notransition::before { transition: none 0s ease 0s !important; }

.with-tooltip { position: relative; }

.with-tooltip .tooltip { position: absolute; z-index: 100; visibility: hidden; width: 120px; border-radius: 0.3em; opacity: 0; transition: opacity 1s ease 0s; background-color: rgba(0, 0, 0, 0.6); color: rgb(255, 255, 255); text-align: center; padding: 0.5em 0px; }

.with-tooltip .tooltip.tooltip-top { bottom: 100%; left: 50%; margin: 0px 0px 0.6em -60px; }

.with-tooltip .tooltip.tooltip-top::after { content: " "; position: absolute; top: 100%; left: 50%; margin-left: -0.5em; border-width: 0.5em; border-style: solid; border-color: rgba(0, 0, 0, 0.6) transparent transparent; }

.with-tooltip.tooltip-show .tooltip { visibility: visible; opacity: 1; }

.paginator { text-align: center; }

.paginator .page { display: inline-block; margin: 0.5em; padding: 0.5em; border-radius: 0.3em; background-color: rgb(233, 232, 239); }

.dark-theme .paginator .page { background: transparent; color: rgba(255, 255, 255, 0.3); }

.paginator .page.loading { margin-bottom: 2em; }

.breadcrumb { -webkit-box-flex: 0; flex: 0 0 100%; padding: 1em 20px 0.5em; color: rgb(155, 155, 155); font-size: small; background: rgb(255, 255, 255); }

.breadcrumb .item { font-weight: 700; }

.empty-content { min-height: calc(100vh - 80px); padding: 2em 1em; text-align: center; line-height: 1.5; font-style: italic; font-size: 22px; }

.share-icons { display: flex; -webkit-box-pack: center; justify-content: center; }

.share-icons > li.item { width: 40px; height: 40px; text-align: center; line-height: 40px; font-size: 14px; margin-right: 8px; }

.share-icons.bubble > li.item { border: 2px solid; border-radius: 50%; }

.share-icons.with-color { color: rgb(255, 255, 255); }

.share-icons.with-color > li.item { background: rgb(155, 155, 155); }

.share-icons.with-color > li.item.via-facebook { background: rgb(59, 89, 152); }

.share-icons.with-color > li.item.via-twitter { background: rgb(85, 172, 238); }

.share-icons.with-color > li.item.via-tumblr { background: rgb(57, 70, 91); }

.quiz-player { position: fixed; inset: 45px 0px 0px; width: 100vw; height: calc(100vh - 45px); }

.back-top { position: fixed; right: 88px; bottom: 48px; z-index: 498; opacity: 0; pointer-events: none; transition: all 0.4s ease 0s; border-radius: 50%; box-shadow: rgba(0, 0, 0, 0.5) 2px 2px 1px; color: rgb(233, 232, 239); background: rgb(0, 0, 0); }

.is-mobile .back-top { right: 5%; }

.back-top.active { opacity: 0.75; pointer-events: auto; }

.mob_no_backtop .back-top { display: none; }

.back-top > .content { padding: 0.5em; }

@-webkit-keyframes beat { 
  0% { opacity: 0; transform: scale(0.2); transform-origin: center center; }
  40% { opacity: 1; transform: scale(1.15); }
  70% { opacity: 1; transform: scale(0.9); }
  100% { transform: scale(1); }
}

@keyframes beat { 
  0% { opacity: 0; transform: scale(0.2); transform-origin: center center; }
  40% { opacity: 1; transform: scale(1.15); }
  70% { opacity: 1; transform: scale(0.9); }
  100% { transform: scale(1); }
}

.rich-content .image-container > .aspect-scale { position: relative; contain: strict; }

.rich-content .image-container > .aspect-scale > .post-img { position: absolute; width: 100%; height: 100%; top: 0px; left: 0px; }

.rich-content .video-container > .aspect-scale { width: 100%; }

.rich-content .video-container > .post-img { position: absolute; max-height: 100%; max-width: 100%; margin: auto; top: 0px; left: 0px; object-position: center top; }

.anim-heartbeat { animation: 0.55s ease 50ms 1 normal none running beat; }

ul.menu { list-style: none; padding: 0px; margin: 0px; border-radius: 5px; color: rgb(96, 96, 96); background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.25) 0px 1px 7px; }

.dark-theme ul.menu { background: rgb(4, 2, 38); font-weight: 700; box-shadow: rgba(255, 255, 255, 0.25) 0px 1px 7px; color: rgb(218, 220, 251); }

.dark-theme ul.menu .menu-item { border-color: rgba(218, 220, 251, 0.2); }

ul.menu i.amino-icon, ul.menu i.fa { color: inherit; margin: 0px 8px; font-size: 16px; }

ul.menu li.menu-item { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; font-size: 14px; line-height: 40px; border-top: 1px solid rgb(233, 232, 239); }

ul.menu li.menu-item:first-child { border-top: none; }

ul.menu li.menu-item .pointer { height: 40px; padding: 0px 8px; }

ul.menu li.menu-item .pointer:hover { background-color: rgba(0, 0, 0, 0.05); }

ul.menu li.menu-item.danger { color: rgb(229, 26, 74); }

.modal { display: none; }

.blocked-indicator { display: none; height: 20vh; font-weight: 700; color: rgb(189, 189, 189); text-align: center; position: relative; }

.blocked-indicator .blocked-container { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); width: 320px; }

.blocked-indicator i.fa-ban { font-size: 50px; display: block; margin-bottom: 12px; }

.show-blocked { display: none; }

.button { border: 1px solid; border-radius: 50px; line-height: 28px; padding: 0px 13px; display: inline-block; cursor: pointer; overflow: hidden; }

.button[disabled] { cursor: not-allowed; opacity: 0.9; }

.cloak { display: none; }

.amino-video-play { display: block; position: absolute; color: rgb(255, 255, 255); border-radius: 50%; border: 2px solid rgb(255, 255, 255); top: 50%; left: 50%; background: rgba(0, 0, 0, 0.4); text-align: center; }

.force-word-break { overflow-wrap: break-word; word-break: break-word; hyphens: auto; }

.in-app.is-mobile .modal .call2action-popup .btn.btn-get-app, .in-app.is-mobile .site-header .btn-download { display: none; }

.topic-list-section { text-align: center; margin: 16px 0px 22px; }

.topic-list-section .topic-list { color: rgb(255, 255, 255); overflow: hidden; }

.topic-list-section .topic-list > .topic-item { display: inline-block; margin-right: 8px; margin-bottom: 8px; padding: 5px 9px; font-size: 12px; line-height: 15px; font-weight: 700; border-radius: 15px; }

.modal-open, .modal-open body { overflow: hidden; position: relative; height: 100%; }

.global-header { display: none; }

section.global-body { display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; }

section.global-body > section { position: relative; }

.global-bg { position: fixed; inset: 0px; z-index: -5; background: linear-gradient(rgb(241, 241, 241), rgb(241, 241, 241) 35%, rgba(242, 242, 242, 0.4) 70%); }

.global-bg, .head-only .global-bg { display: block; }

.ad-block-banner-container { display: flex; -webkit-box-pack: center; justify-content: center; margin: 10px 0px; }

.ad-block-banner-container iframe { border-radius: 5px; }

.community-header { color: rgb(255, 255, 255); }

.community-header::after { display: block; content: " "; height: 51px; }

.community-header > .content { position: fixed; height: 51px; }

.chromeless .community-header, .shadow-head .community-header { display: none; }

.community-header > .content { z-index: 500; left: 0px; right: 0px; top: 0px; }

.community-header > .content, .community-header > .content .action-open-sidebar { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row nowrap; -webkit-box-align: center; align-items: center; }

.community-header > .content .action-open-sidebar { overflow: hidden; }

.community-header > .content .menu-icon { font-size: 24px; padding: 8px; display: block; }

.community-header > .content .logo { width: 32px; height: 32px; border-radius: 7.232px; margin-right: 0.5em; }

html[amp] .community-header > .content .logo { margin-left: 8px; }

.community-header > .content h3 { color: rgb(255, 255, 255); margin: 0px; line-height: 22px; max-height: 44px; overflow: hidden; overflow-wrap: break-word; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }

.community-header > .content .nav-search-container { margin-left: auto; padding-right: 8px; }

.community-header > .content .nav-search-container .svg-icon { fill: rgb(255, 255, 255); }

.community-header > .content .btn-join { -webkit-box-flex: 0; flex: 0 0 auto; margin-right: 0.5em; border: 0px; font-size: 14px; border-radius: 5px; padding: 8px 12px; background-color: rgb(255, 255, 255); }

.community-header > .content .btn-join.private-join { display: none; }

.private-without-invite .community-header > .content .btn-join.private-join { display: block; }

.private-without-invite .community-header > .content .btn-join { display: none; }

.home-section-nav { -webkit-box-flex: 0; flex: 0 0 auto; color: rgb(255, 255, 255); }

html[amp] .home-section-nav .content { position: relative; top: 0px; }

.home-section-nav .home-nav-home, .home-section-nav .overflow-hint, html[amp] .home-section-nav::after { display: none; }

.home-section-nav .content { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; z-index: 490; }

.home-section-nav::after { display: block; content: " "; height: 72px; }

.home-section-nav .content { position: fixed; height: 72px; }

.home-section-nav.oneline::after { display: block; content: " "; height: 36px; }

.home-section-nav.oneline .content { position: fixed; height: 36px; }

.home-section-nav .content { transform: translateY(0px); transition: transform 0.2s ease 0.3s, -webkit-transform 0.2s ease; top: 51px; left: 0px; right: 0px; -webkit-box-align: stretch; align-items: stretch; overflow-y: hidden; box-shadow: rgba(0, 0, 0, 0.3) 0px 2px 4px; background-color: rgb(255, 255, 255); text-align: center; }

.home-section-nav .content.headroom--unpinned { transform: translateY(-100%); transition: transform 0.5s ease 0s, -webkit-transform 0.5s ease 0s; }

.home-section-nav .section-item { -webkit-box-flex: 10; flex: 10 1 33%; overflow: hidden; box-sizing: border-box; border-style: solid; border-color: rgb(233, 232, 239); border-image: initial; border-width: 0px 1px 1px 0px; }

.home-section-nav .section-item > a.block { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; width: 100%; height: 36px; padding: 3px; }

.home-section-nav .section-item:nth-child(3n) { border-right: none; }

.home-section-nav .section-item:nth-child(n+7) { display: none; }

.home-section-nav .section-item .label { font-size: 85%; margin-left: 0.3em; }

.home-section-nav .hide-on-mobile { display: none; }

@-webkit-keyframes home-nav-slider { 
  0% { opacity: 0.3; }
  100% { opacity: 0; }
}

@keyframes home-nav-slider { 
  0% { opacity: 0.3; }
  100% { opacity: 0; }
}

.community-sidebar { margin-left: 5px; display: none; position: relative; left: 0px; width: 300px; top: 0px; }

.chromeless .community-sidebar, .head-only .community-sidebar { display: none; }

.community-sidebar .ad-block.left { margin-top: 20px; margin-bottom: 1.5em; border-radius: 5px; box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 4px; overflow: hidden; }

.community-sidebar .community-info { padding: 18px; font-size: 14px; text-align: left; margin-top: 20px; margin-bottom: 1.5em; }

.community-sidebar .community-info .logo { width: 70px; height: 70px; border-radius: 15.82px; }

.community-sidebar .community-info .btn { font-size: 20px; font-weight: 700; position: relative; border-radius: 5px; box-shadow: rgba(0, 0, 0, 0.2) 0px -4px 0px inset; }

.community-sidebar .community-info .btn:active { box-shadow: none; }

.community-sidebar .community-info .btn.full-width { width: 100%; display: block; }

.community-sidebar .community-info .btn.pre-login-compose { margin-top: 12px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.25) 0px 1px 7px; line-height: 40px; border: none; }

.community-sidebar .community-info .basic-info { margin-left: 12px; overflow: hidden; padding-right: 20px; text-align: left; }

.community-sidebar .community-info .basic-info .title { font-size: 20px; font-weight: 400; margin: 3px 0px 14px; color: rgb(255, 255, 255); text-align: left; }

.community-sidebar > .hide-on-pc { display: block; }

.community-sidebar .global-nav > ul.content { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row nowrap; -webkit-box-align: center; align-items: center; text-align: center; }

.community-sidebar .global-nav > ul.content > .nav-user { display: none; }

.community-sidebar .global-nav > ul.content > li.nav-item { -webkit-box-flex: 1; flex: 1 1 0%; border-left: 1px solid rgba(255, 255, 255, 0.1); }

.community-sidebar .global-nav > ul.content > li.nav-item:first-child { border-left: none; }

.community-sidebar .global-nav > ul.content > li.nav-item.nav-download { display: none; }

.community-sidebar .global-nav > ul.content a.nav-link { font-size: small; padding: 0.5em; }

.community-sidebar .global-nav > ul.content i.amino-icon { display: block; font-size: 32px; }

.community-sidebar .global-nav { display: block; }

.community-sidebar .sidebar-link { display: block; width: 100%; padding: 0.5em; }

.community-sidebar .sidebar-link > .content { display: flex; -webkit-box-align: center; align-items: center; padding-left: 30px; }

.community-sidebar .sidebar-link i.sidebar-icon { margin-right: 10px; }

.community-sidebar .sidebar-link i.sidebar-icon, .community-sidebar .sidebar-link i.sidebar-icon::before { border-radius: 50%; }

.community-sidebar .sidebar-link i.sidebar-icon::before { font-size: 18px; background-color: rgba(0, 0, 0, 0.3); padding: 8px; display: inline-block; }

.community-sidebar .btn-join { background-color: rgb(255, 255, 255); font-size: 20px; padding: 0.5em 20px; }

.community-sidebar > .content.fixed { position: fixed; bottom: 0px; color: rgb(255, 255, 255); }

.community-sidebar > .community-sidebar-container { position: fixed; width: 300px; }

.community-sidebar .overflow-scroll-sidebar { contain: content; overflow: hidden auto; height: 95%; }

.community-sidebar .overflow-scroll-sidebar::-webkit-scrollbar { display: none; }

.community-sidebar .sidebar-section { width: 100%; max-width: 300px; margin-left: auto; text-align: center; }

.community-sidebar .active .sidebar-link { background: rgba(0, 0, 0, 0.3); font-weight: 700; }

.community-sidebar .active .sidebar-link i.sidebar-icon::before { background: none; }

.community-sidebar .active .sidebar-icon { background: rgba(0, 0, 0, 0.25); }

.community-aside { height: 100vh; z-index: 10; min-width: 304px; margin-top: 0px; padding-top: 22px; }

.chromeless .community-aside, .head-only .community-aside { display: none; }

.community-aside > .content { overflow: hidden; padding: 1em; max-width: 640px; margin: auto; }

.community-aside > .content > .title { font-size: 100%; font-weight: 400; margin-top: 0px; color: rgb(65, 69, 73); }

.community-aside > .content.overflow-scroll-sidebar { contain: content; overflow: hidden auto; height: 93%; }

.community-aside > .content.overflow-scroll-sidebar::-webkit-scrollbar { display: none; }

.community-content { max-width: 640px; }

.chromeless .community-content { max-width: none; width: 100%; }

.community-content > .content { height: 100%; }

.community-livelayer-padding { display: block; }

.chromeless .community-livelayer-padding, .community-livelayer-padding.cloak { display: none; }

[data-vce="carousel"] { position: relative; overflow: hidden; z-index: 0; }

[data-vce="carousel"] > .scroll-container { position: absolute; inset: 0px; z-index: 100; width: 100%; height: 100%; display: flex; overflow: overlay hidden; }

[data-vce="carousel"] > .scroll-container::-webkit-scrollbar { width: 10px; height: 10px; background: transparent; }

[data-vce="carousel"] > .scroll-container::-webkit-scrollbar-track-piece { background: transparent; }

[data-vce="carousel"] > .scroll-container::-webkit-scrollbar-thumb { height: 50px; width: 50px; border-radius: 10px; opacity: 0; background-color: transparent; transition: all 0.4s ease 0s; }

[data-vce="carousel"] > .scroll-container > .carousel-item { -webkit-box-flex: 0; flex: 0 0 auto; margin-left: 0.25em; }

[data-vce="carousel"] > .scroll-container:hover::-webkit-scrollbar-thumb, [data-vce="carousel"] > :hover ~ .scroll-container::-webkit-scrollbar-thumb { background-color: rgba(0, 0, 0, 0.4); opacity: 1; }

[data-vce="carousel"] > .arrow { position: absolute; z-index: 200; top: calc(50% - 24px); height: 48px; width: 48px; border-radius: 24px; text-align: center; line-height: 48px; color: rgb(255, 255, 255); pointer-events: none; opacity: 0; transition: all 0.4s ease 0s; }

[data-vce="carousel"] > .arrow.arrow-left { left: -24px; text-indent: 8px; }

[data-vce="carousel"] > .arrow.arrow-right { right: -24px; text-indent: -8px; }

[data-vce="carousel"] > .arrow:hover { filter: brightness(0.8); }

[data-vce="carousel"].hover-left .arrow-left, [data-vce="carousel"].hover-right .arrow-right { opacity: 1; pointer-events: auto; }

[data-vce="carousel"].scroll-leftmost.hover-left .arrow-left, [data-vce="carousel"].scroll-leftmost.hover-right .arrow-left { opacity: 0; pointer-events: none; }

[data-vce="carousel"].scroll-leftmost.hover-left .arrow-right, [data-vce="carousel"].scroll-leftmost.hover-right .arrow-right { opacity: 1; pointer-events: auto; }

[data-vce="carousel"].scroll-rightmost.hover-left .arrow-right, [data-vce="carousel"].scroll-rightmost.hover-right .arrow-right { opacity: 0; pointer-events: none; }

[data-vce="carousel"].scroll-rightmost.hover-left .arrow-left, [data-vce="carousel"].scroll-rightmost.hover-right .arrow-left { opacity: 1; pointer-events: auto; }

[data-vce="toast"] { position: fixed; z-index: 65535; bottom: 10vmin; left: 50%; transform: translateX(-50%); border-radius: 15px; box-shadow: rgba(0, 0, 0, 0.5) 0px 0px 5px 2px; min-width: 80px; overflow: hidden; font-size: 14px; background: rgba(0, 0, 0, 0.7); padding: 6px 17px; user-select: none; opacity: 0; pointer-events: none; transition: all 0.4s ease 0s; }

[data-vce="toast"].active { opacity: 1; }

[data-vce="toast"] > .content { color: rgb(255, 255, 255); max-height: 4.5em; line-height: 1.5; overflow: hidden; text-align: center; }

[data-vce="toast"].toast-success { background: rgb(29, 218, 143); box-shadow: rgba(0, 0, 0, 0.3) 0px 2px 8px; }

[data-vce="toast"].toast-warn { background: rgb(251, 144, 61); box-shadow: rgba(0, 0, 0, 0.3) 0px 2px 8px; }

[data-vce="carousel-img"], [data-vce="image"] { background-color: rgba(0, 0, 0, 0.05); }

[data-vce="carousel-img"].loading:not([src]), [data-vce="image"].loading:not([src]) { opacity: 0.5; background: rgba(0, 0, 0, 0.1); }

[data-vce="carousel-img"][data-preview], [data-vce="image"][data-preview] { transition: all 0.5s ease 0s; }

div[data-vce="image"] { background-repeat: no-repeat; background-position: 50% center; }

div[data-vce="image"].img-contain { background-size: contain; }

div[data-vce="image"].img-cover { background-size: cover; }

[data-vce="fading-media"] { position: relative; }

[data-vce="fading-media"].loading > .cover { opacity: 1; }

[data-vce="fading-media"] > .cover { opacity: 0; transition: all 0.4s ease 0s; pointer-events: none; }

[data-vce="fading-media"] > .cover, [data-vce="fading-media"] > .cover::after { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; }

[data-vce="fading-media"] > .cover::after { display: block; content: ""; background: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjIwIiBoZWlnaHQ9IjE0NyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+PGRlZnM+PHBhdGggaWQ9ImEiIGQ9Ik0wIDBoMjMuMzc0djIzLjM5OEgweiIvPjwvZGVmcz48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIG9wYWNpdHk9Ii40NzQiPjxwYXRoIGQ9Ik0zMC4zMjYgNzAuODU3aDYuNDIxYTIuNjM5IDIuNjM5IDAgMSAxIDAgNS4yNzhoLTYuNDJ2Ni40MmEyLjY0IDIuNjQgMCAxIDEtNS4yNzkgMHYtNi40MmgtNi40MmEyLjYzOSAyLjYzOSAwIDEgMSAwLTUuMjc4aDYuNDJ2LTYuNDIxYTIuNjM5IDIuNjM5IDAgMSAxIDUuMjc4IDB2Ni40MjF6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik0xNiAxNWgyMy4zNzR2MjMuMzk4SDE2eiIvPjxwYXRoIGQ9Ik0yNi4wMDYgMjQuNDkxYy4yNS0uNjQxLjQzNi0uOTg4Ljg3Ny0uOTg4LjQ1MSAwIC42NzUuNTQ0Ljg2NCAxLjAwNC4zMDQuNzMzLjY0IDEuNzMxLjkyNiAyLjUzMS0xLjY3Mi44NzQtMy40ODMgMi4xMy00Ljk0NCAzLjM1OS41MDktMS4yNDUgMS41NzEtNC4wOTggMi4yNzctNS45MDZ6bTYuODg4Ljc3NmMtMS4xNzQtMy4wNS0yLjk3MS03LjE4NC0zLjUyOS04LjQ3NmE1LjYzIDUuNjMgMCAwIDAtLjQ2NS0uODUxYy0uNDMxLS42MDktMS4wMS0uOTQtMS44NzEtLjk0LS43NTQgMC0xLjI5LjMyLTEuNjk0Ljc5LS4yNC4yOTQtLjQzOC42Mi0uNTg5Ljk2OS0uNzQxIDEuNzg0LTUuNDY5IDEzLjg5OC03Ljc2MyAxOS44NzYtLjM2My45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcgMCAuOTc0LS4zMTQgMS42Ny0xLjA1OCAyLjU3NC0yLjc1MyA1LjY3NS00LjkwNyA4LjU0Ny02LjM4MiAxLjE1NyAyLjg1NiAyLjMyNSA1Ljc4OSAyLjU2NCA2LjM4Mi4zNDQuODU0Ljc5IDEuMDU4IDEuNTc3IDEuMDU4aDIuMzI3Yy44OTQgMCAxLjA0OC0uNjA1Ljc1LTEuMzk1LS41MjgtMS4zOTYtMS43OS00LjUxNC0zLjEyNi03Ljg3MiAxLjEwMy0uNTIgMi4zOC0xLjEyNyAzLjI0NC0xLjQzNi41NzUtLjIwNSAxLjExNy0uNTEgMS4zODQtMS4xMjYuMzU3LS44MjYuMTE4LTEuNDA1LS4xMDItMS43NzctLjkyNy0xLjU3NC0zLjMwNy0uNDM0LTUuOTI2LjY4M3oiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTEyNS4wOCA2MS43OTdoMjMuMzc0djIzLjM5OEgxMjUuMDh6Ii8+PHBhdGggZD0iTTEyNi4xMjkgODAuODU1bDUuMTczLTQuNjggNS41MiA0LjY4IDUuNDUtNC42OCA1LjI0NSA0LjY4bS0yMS4zODgtOC41NzlsNS4xNzMtNC42OCA1LjUyIDQuNjggNS40NS00LjY4IDUuMjQ1IDQuNjgiIHN0cm9rZS1vcGFjaXR5PSIuMzYiIHN0cm9rZT0iI0ZGRiIgc3Ryb2tlLXdpZHRoPSI0IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48cGF0aCBkPSJNMTc5LjYyIDYxLjc5N2gyMy4zNzR2MjMuMzk4SDE3OS42MnoiLz48cGF0aCBkPSJNMTg5LjYyNiA3MS4yODhjLjI1LS42NDIuNDM2LS45ODkuODc4LS45ODkuNDUgMCAuNjc0LjU0NS44NjQgMS4wMDUuMzAzLjczMy42MzkgMS43My45MjYgMi41My0xLjY3My44NzQtMy40ODQgMi4xMy00Ljk0NSAzLjM2LjUxLTEuMjQ1IDEuNTcxLTQuMDk5IDIuMjc3LTUuOTA2em02Ljg4OC43NzVjLTEuMTczLTMuMDUtMi45Ny03LjE4My0zLjUyOS04LjQ3NmE1LjYzIDUuNjMgMCAwIDAtLjQ2Ni0uODVjLS40My0uNjEtMS4wMDgtLjk0LTEuODY5LS45NC0uNzU0IDAtMS4yOS4zMi0xLjY5NS43OS0uMjQuMjk0LS40MzcuNjItLjU4OC45NjgtLjc0MiAxLjc4NC01LjQ3IDEzLjg5OC03Ljc2NCAxOS44NzYtLjM2Mi45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcwMSAwIC45NzQtLjMxMyAxLjY3LTEuMDU4IDIuNTc0LTIuNzUyIDUuNjc2LTQuOTA3IDguNTQ3LTYuMzgxIDEuMTU3IDIuODU1IDIuMzI1IDUuNzg5IDIuNTY0IDYuMzgxLjM0NC44NTUuNzkgMS4wNTggMS41NzcgMS4wNThoMi4zMjdjLjg5NCAwIDEuMDQ4LS42MDQuNzUtMS4zOTQtLjUyOC0xLjM5Ny0xLjc5LTQuNTE0LTMuMTI2LTcuODczIDEuMTAzLS41MiAyLjM4LTEuMTI2IDMuMjQ1LTEuNDM1LjU3NC0uMjA2IDEuMTE3LS41MSAxLjM4My0xLjEyNi4zNTctLjgyNy4xMTgtMS40MDUtLjEwMS0xLjc3OC0uOTI4LTEuNTczLTMuMzA3LS40MzMtNS45MjcuNjgzeiIgZmlsbC1vcGFjaXR5PSIuMzU1IiBmaWxsPSIjRkZGIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNMTYgMTA4LjU5M2gyMy4zNzR2MjMuMzk4SDE2eiIvPjxwYXRoIGQ9Ik0yNi4wMDYgMTE4LjA4NGMuMjUtLjY0MS40MzYtLjk4OC44NzctLjk4OC40NTEgMCAuNjc1LjU0NS44NjQgMS4wMDQuMzA0LjczMy42NCAxLjczMS45MjYgMi41MzEtMS42NzIuODc0LTMuNDgzIDIuMTMtNC45NDQgMy4zNTkuNTA5LTEuMjQ1IDEuNTcxLTQuMDk4IDIuMjc3LTUuOTA2em02Ljg4OC43NzZjLTEuMTc0LTMuMDUtMi45NzEtNy4xODMtMy41MjktOC40NzZhNS42MyA1LjYzIDAgMCAwLS40NjYtLjg1Yy0uNDMtLjYxLTEuMDA5LS45NC0xLjg3LS45NC0uNzU0IDAtMS4yOS4zMi0xLjY5NC43OWE0LjEzIDQuMTMgMCAwIDAtLjU4OS45NjhjLS43NDEgMS43ODQtNS40NjkgMTMuODk4LTcuNzYzIDE5Ljg3Ni0uMzYzLjk0NC0uMjg3IDEuNTU1LjYwNSAxLjU1NWgyLjM5N2MuNyAwIC45NzQtLjMxNCAxLjY3LTEuMDU4IDIuNTc0LTIuNzUzIDUuNjc1LTQuOTA3IDguNTQ3LTYuMzgyIDEuMTU3IDIuODU2IDIuMzI1IDUuNzkgMi41NjQgNi4zODIuMzQ0Ljg1NS43OSAxLjA1OCAxLjU3NyAxLjA1OGgyLjMyN2MuODk0IDAgMS4wNDgtLjYwNS43NS0xLjM5NS0uNTI4LTEuMzk2LTEuNzktNC41MTQtMy4xMjYtNy44NzIgMS4xMDMtLjUyIDIuMzgtMS4xMjYgMy4yNDQtMS40MzYuNTc1LS4yMDUgMS4xMTctLjUxIDEuMzg0LTEuMTI2LjM1Ny0uODI2LjExOC0xLjQwNS0uMTAyLTEuNzc3LS45MjctMS41NzMtMy4zMDctLjQzNC01LjkyNi42ODN6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik03MC41NCAxMDguNTkzaDIzLjM3NHYyMy4zOThINzAuNTR6Ii8+PHBhdGggZD0iTTgyLjIyNyAxMzAuNDMyYy01LjU5NCAwLTEwLjEyOS00LjU0LTEwLjEyOS0xMC4xNCAwLTUuNiA0LjUzNS0xMC4xMzkgMTAuMTMtMTAuMTM5IDUuNTkzIDAgMTAuMTI4IDQuNTQgMTAuMTI4IDEwLjE0IDAgNS42LTQuNTM1IDEwLjEzOS0xMC4xMjkgMTAuMTM5em0wLTQuNjhhNS40NTcgNS40NTcgMCAwIDAgNS40NTQtNS40NiA1LjQ1NyA1LjQ1NyAwIDAgMC01LjQ1NC01LjQ2IDUuNDU3IDUuNDU3IDAgMCAwLTUuNDU0IDUuNDYgNS40NTcgNS40NTcgMCAwIDAgNS40NTQgNS40NnoiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTcwLjU0IDYxLjc5N2gyMy4zNzR2MjMuMzk4SDcwLjU0eiIvPjxwYXRoIGQ9Ik04MC41NDYgNzEuMjg4Yy4yNS0uNjQyLjQzNi0uOTg5Ljg3Ny0uOTg5LjQ1MSAwIC42NzUuNTQ1Ljg2NSAxLjAwNS4zMDMuNzMzLjYzOSAxLjczLjkyNSAyLjUzLTEuNjcyLjg3NC0zLjQ4MyAyLjEzLTQuOTQ0IDMuMzYuNTA5LTEuMjQ1IDEuNTcxLTQuMDk5IDIuMjc3LTUuOTA2em02Ljg4OC43NzVjLTEuMTc0LTMuMDUtMi45NzEtNy4xODMtMy41MjktOC40NzZhNS42MyA1LjYzIDAgMCAwLS40NjYtLjg1Yy0uNDMtLjYxLTEuMDA5LS45NC0xLjg3LS45NC0uNzUzIDAtMS4yOS4zMi0xLjY5NC43OS0uMjQuMjk0LS40MzcuNjItLjU4OC45NjgtLjc0MiAxLjc4NC01LjQ3IDEzLjg5OC03Ljc2NCAxOS44NzYtLjM2My45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcwMSAwIC45NzQtLjMxMyAxLjY3LTEuMDU4IDIuNTc0LTIuNzUyIDUuNjc2LTQuOTA3IDguNTQ3LTYuMzgxIDEuMTU3IDIuODU1IDIuMzI1IDUuNzg5IDIuNTY0IDYuMzgxLjM0NC44NTUuNzkgMS4wNTggMS41NzcgMS4wNThoMi4zMjdjLjg5NCAwIDEuMDQ4LS42MDQuNzUtMS4zOTQtLjUyOC0xLjM5Ny0xLjc5LTQuNTE0LTMuMTI2LTcuODczIDEuMTAzLS41MiAyLjM4LTEuMTI2IDMuMjQ0LTEuNDM1LjU3NS0uMjA2IDEuMTE3LS41MSAxLjM4NC0xLjEyNi4zNTctLjgyNy4xMTgtMS40MDUtLjEwMi0xLjc3OC0uOTI3LTEuNTczLTMuMzA3LS40MzMtNS45MjYuNjgzeiIgZmlsbC1vcGFjaXR5PSIuMzU1IiBmaWxsPSIjRkZGIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNNzAuNTQgMTVoMjMuMzc0djIzLjM5OEg3MC41NHoiLz48cGF0aCBkPSJNNzUuNDUzIDM2LjA3NGEzLjUgMy41IDAgMCAxLTIuOTUxLTUuMzgxbDcuMDUzLTExLjA2OGEzLjUgMy41IDAgMCAxIDUuOTAzIDBsNy4wNTYgMTEuMDY3YTMuNSAzLjUgMCAwIDEtMi45NSA1LjM4Mkg3NS40NTN6bTIuOTk1LTMuOTUyaDguMDM0YTEgMSAwIDAgMCAuODQtMS41NDFsLTMuOTgxLTYuMTk4YTEgMSAwIDAgMC0xLjY3OS0uMDA3bC00LjA1MSA2LjE5OGExIDEgMCAwIDAgLjgzNyAxLjU0OHoiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTEyNS4wOCAxNWgyMy4zNzR2MjMuMzk4SDEyNS4wOHoiLz48cGF0aCBkPSJNMTM1LjA4NiAyNC40OTFjLjI1LS42NDEuNDM2LS45ODguODc3LS45ODguNDUxIDAgLjY3NS41NDQuODY1IDEuMDA0LjMwMy43MzMuNjM5IDEuNzMxLjkyNiAyLjUzMS0xLjY3My44NzQtMy40ODQgMi4xMy00Ljk0NSAzLjM1OS41MDktMS4yNDUgMS41NzEtNC4wOTggMi4yNzctNS45MDZ6bTYuODg4Ljc3NmMtMS4xNzMtMy4wNS0yLjk3LTcuMTg0LTMuNTI5LTguNDc2YTUuNjMgNS42MyAwIDAgMC0uNDY2LS44NTFjLS40My0uNjA5LTEuMDA4LS45NC0xLjg2OS0uOTQtLjc1NCAwLTEuMjkuMzItMS42OTUuNzlhNC4wOCA0LjA4IDAgMCAwLS41ODguOTY5Yy0uNzQyIDEuNzg0LTUuNDcgMTMuODk4LTcuNzY0IDE5Ljg3Ni0uMzYzLjk0NC0uMjg3IDEuNTU1LjYwNSAxLjU1NWgyLjM5N2MuNzAxIDAgLjk3NC0uMzE0IDEuNjctMS4wNTggMi41NzQtMi43NTMgNS42NzYtNC45MDcgOC41NDctNi4zODIgMS4xNTcgMi44NTYgMi4zMjUgNS43ODkgMi41NjQgNi4zODIuMzQ0Ljg1NC43OSAxLjA1OCAxLjU3NyAxLjA1OGgyLjMyN2MuODk0IDAgMS4wNDgtLjYwNS43NS0xLjM5NS0uNTI4LTEuMzk2LTEuNzktNC41MTQtMy4xMjYtNy44NzIgMS4xMDMtLjUyIDIuMzgtMS4xMjcgMy4yNDUtMS40MzYuNTc0LS4yMDUgMS4xMTctLjUxIDEuMzgzLTEuMTI2LjM1Ny0uODI2LjExOC0xLjQwNS0uMTAxLTEuNzc3LS45MjgtMS41NzQtMy4zMDgtLjQzNC01LjkyNy42ODN6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDE3OS42MiAxNSkiPjxtYXNrIGlkPSJiIiBmaWxsPSIjZmZmIj48dXNlIHhsaW5rOmhyZWY9IiNhIi8+PC9tYXNrPjxwYXRoIGQ9Ik0xMS4yOTggNy40NTNsNC42OTEtNC42OTJhMi43MjcgMi43MjcgMCAwIDEgMy44NTcgMy44NTZsLTQuNjkyIDQuNjkyIDQuNjkyIDQuNjkyYTIuNzI3IDIuNzI3IDAgMCAxLTMuODU3IDMuODU2bC00LjY5MS00LjY5MS00LjY5MiA0LjY5MWEyLjcyNyAyLjcyNyAwIDAgMS0zLjg1Ny0zLjg1Nmw0LjY5Mi00LjY5Mi00LjY5Mi00LjY5MmEyLjcyNyAyLjcyNyAwIDAgMSAzLjg1Ny0zLjg1Nmw0LjY5MiA0LjY5MnoiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIiBtYXNrPSJ1cmwoI2IpIi8+PC9nPjxwYXRoIGQ9Ik0xMjUuMDggMTA4LjU5M2gyMy4zNzR2MjMuMzk4SDEyNS4wOHoiLz48cGF0aCBkPSJNMTM1LjA4NiAxMTguMDg0Yy4yNS0uNjQxLjQzNi0uOTg4Ljg3Ny0uOTg4LjQ1MSAwIC42NzUuNTQ1Ljg2NSAxLjAwNC4zMDMuNzMzLjYzOSAxLjczMS45MjYgMi41MzEtMS42NzMuODc0LTMuNDg0IDIuMTMtNC45NDUgMy4zNTkuNTA5LTEuMjQ1IDEuNTcxLTQuMDk4IDIuMjc3LTUuOTA2em02Ljg4OC43NzZjLTEuMTczLTMuMDUtMi45Ny03LjE4My0zLjUyOS04LjQ3NmE1LjYzIDUuNjMgMCAwIDAtLjQ2Ni0uODVjLS40My0uNjEtMS4wMDgtLjk0LTEuODY5LS45NC0uNzU0IDAtMS4yOS4zMi0xLjY5NS43OS0uMjQuMjk0LS40MzcuNjItLjU4OC45NjgtLjc0MiAxLjc4NC01LjQ3IDEzLjg5OC03Ljc2NCAxOS44NzYtLjM2My45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcwMSAwIC45NzQtLjMxNCAxLjY3LTEuMDU4IDIuNTc0LTIuNzUzIDUuNjc2LTQuOTA3IDguNTQ3LTYuMzgyIDEuMTU3IDIuODU2IDIuMzI1IDUuNzkgMi41NjQgNi4zODIuMzQ0Ljg1NS43OSAxLjA1OCAxLjU3NyAxLjA1OGgyLjMyN2MuODk0IDAgMS4wNDgtLjYwNS43NS0xLjM5NS0uNTI4LTEuMzk2LTEuNzktNC41MTQtMy4xMjYtNy44NzIgMS4xMDMtLjUyIDIuMzgtMS4xMjYgMy4yNDUtMS40MzYuNTc0LS4yMDUgMS4xMTctLjUxIDEuMzgzLTEuMTI2LjM1Ny0uODI2LjExOC0xLjQwNS0uMTAxLTEuNzc3LS45MjgtMS41NzMtMy4zMDgtLjQzNC01LjkyNy42ODN6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik0xNzkuNjIgMTA4LjU5M2gyMy4zNzR2MjMuMzk4SDE3OS42MnoiLz48cGF0aCBkPSJNMTg0LjUzMyAxMjkuNjY3YTMuNSAzLjUgMCAwIDEtMi45NTEtNS4zODFsNy4wNTQtMTEuMDY3YTMuNSAzLjUgMCAwIDEgNS45MDItLjAwMWw3LjA1NyAxMS4wNjdhMy41IDMuNSAwIDAgMS0yLjk1MiA1LjM4MmgtMTQuMTF6bTIuOTk1LTMuOTUyaDguMDM0YTEgMSAwIDAgMCAuODQxLTEuNTRsLTMuOTgyLTYuMmExIDEgMCAwIDAtMS42NzktLjAwNmwtNC4wNSA2LjE5OWExIDEgMCAwIDAgLjgzNiAxLjU0N3oiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PC9nPjwvc3ZnPg==") repeat; }

[data-vce="fading-media"] > .youtube-preview, [data-vce="fading-media"] > [data-vce="image"] { position: absolute; inset: 0px; z-index: 100; width: 100%; height: 100%; }

[data-vce="fade-image-switcher"] img.switch { position: absolute; inset: 0px; width: 100%; height: 100%; opacity: 0; transition: opacity 2s ease-in 0s; }

[data-vce="fade-image-switcher"] img.switch.show { opacity: 1; }

[data-vce="toggle-content"] { overflow-y: hidden; }

[data-vce="toggle-content"] .height-toggle { display: none; position: absolute; bottom: 0px; left: 0px; right: 0px; text-align: center; height: 100px; padding-top: 80px; line-height: 1; background: linear-gradient(0deg, rgb(255, 255, 255), rgb(255, 255, 255) 25%, rgba(255, 255, 255, 0)); z-index: 1; }

[data-vce="toggle-content"] .open-label { display: none; }

[data-vce="toggle-content"].need-toggle { position: relative; }

[data-vce="toggle-content"].open { overflow-y: auto; padding-bottom: 40px; }

[data-vce="toggle-content"].open .open-label { display: block; }

[data-vce="toggle-content"].open .closed-label { display: none; }

[data-vce="toggle-content"].open .height-toggle { background: none; height: 40px; padding-top: 10px; }

[data-vce="toggle-content"].need-toggle .height-toggle { display: block; }

.btn-progress { position: relative; }

.btn-progress::before { display: block; content: ""; position: absolute; inset: 0px; z-index: 10; height: 100%; width: 0px; pointer-events: none; will-change: width; background: rgb(0, 0, 0); opacity: 0.3; transition: width 1s ease-in 0s; }

.btn-progress.community-color::before { opacity: 0.5; background: currentcolor; }

.btn-progress.step-request-start::before { width: 70%; }

.btn-progress.step-request-done::before { transition-timing-function: linear; transition-duration: 0.3s; width: 100%; }

[data-vce="btn-load-comments"] i.fa-circle-o-notch { display: none; }

[data-vce="btn-load-comments"].loading i.fa-caret-down { display: none; }

[data-vce="btn-load-comments"].loading i.fa-circle-o-notch { display: inline-block; }

[data-vce="btn-load-comments"].loading .caption { display: none; }

[data-vce="btn-load-comments"].read-more-comments i.fa-circle-o-notch { font-size: 18px; }

[data-true-form="btn-load-comments"] i.fa-circle-o-notch { display: none; }

.follow-btn { margin: 1em; border-radius: 2em; line-height: 36px; text-align: center; background: rgb(49, 146, 255); color: rgb(255, 255, 255); user-select: none; }

.follow-btn .follow-icon { width: 18px; height: 18px; display: inline-block; vertical-align: middle; }

.follow-btn:hover { color: rgb(255, 255, 255); background: rgb(66, 132, 227); }

.level-badge { display: inline-block; width: 24px; height: 24px; vertical-align: middle; }

.level-badge-1 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 25% 0px / 500% 400%; }

.level-badge-2 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 75% 33.3333% / 500% 400%; }

.level-badge-3 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 0px 33.3333% / 500% 400%; }

.level-badge-4 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 25% 33.3333% / 500% 400%; }

.level-badge-5 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 50% 0px / 500% 400%; }

.level-badge-6 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 50% 33.3333% / 500% 400%; }

.level-badge-7 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 0px 66.6667% / 500% 400%; }

.level-badge-8 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 25% 66.6667% / 500% 400%; }

.level-badge-9 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 50% 66.6667% / 500% 400%; }

.level-badge-10 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 75% 0px / 500% 400%; }

.level-badge-11 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 0px 0px / 500% 400%; }

.level-badge-12 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 75% 66.6667% / 500% 400%; }

.level-badge-13 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 0px 100% / 500% 400%; }

.level-badge-14 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 25% 100% / 500% 400%; }

.level-badge-15 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 50% 100% / 500% 400%; }

.level-badge-16 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 75% 100% / 500% 400%; }

.level-badge-17 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 100% 0px / 500% 400%; }

.level-badge-18 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 100% 33.3333% / 500% 400%; }

.level-badge-19 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 100% 66.6667% / 500% 400%; }

.level-badge-20 { background: url("https://aminoapps.com/static/dist/99d4930ac2441caedbc7b5ae86ff4e07.png") 100% 100% / 500% 400%; }

.influencer-badge { width: 25px; display: inline-flex; vertical-align: middle; }

.influencer-badge::before { width: 100%; display: block; content: ""; padding-top: 76.7857%; background: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTY4IiBoZWlnaHQ9IjEyOSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+PGRlZnM+PHBhdGggZD0iTTE1MC42NSAyNC40M2MtNS41Ny01LjE1LTEzLjI3LTcuODctMjIuMjUtNy44N2gtMjQuOTFBNy41NSA3LjU1IDAgMCAwIDk3LjkxIDE5YTcuNTcgNy41NyAwIDAgMC01LjU4LTIuNDdoLTEzLjRhNy40MiA3LjQyIDAgMCAwLTMgLjYxIDcuNTYgNy41NiAwIDAgMC0zLS42MUg1OC41NGE3LjU5IDcuNTkgMCAwIDAtNy4xIDQuOTRMNDIuNjIgNDUuM2wtOC44NC0yMy43OWE3LjU1IDcuNTUgMCAwIDAtNy4xLTQuOTNoLTE0LjhhNy41OCA3LjU4IDAgMCAwLTcgMTAuMzlsMjQuNjYgNjEuMzdhNy41NiA3LjU2IDAgMCAwIDcgNC43NWgxMS44M2E3LjU4IDcuNTggMCAwIDAgNy00Ljc1bDE2LTM5Ljc5djM2LjUzYTcuNTcgNy41NyAwIDAgMCA3LjU3IDcuNTdoMTMuNGE3LjU1IDcuNTUgMCAwIDAgNS41OC0yLjQ3IDcuNTcgNy41NyAwIDAgMCA1LjU4IDIuNDdoMTMuNDFhNy41NyA3LjU3IDAgMCAwIDcuNTgtNy41N1Y3NC4zNmgyLjYyYzguNzcgMCAxNi40NC0yLjQ2IDIyLjItNy4xIDYuNTUtNS4yOSAxMC0xMi44NiAxMC0yMS44OXYtLjE4YTI3Ljc0IDI3Ljc0IDAgMCAwLTguNjYtMjAuNzZ6bS0yMC4wNyAyMXYuMTdjMCAuNDUgMCAxLjY1LTMuMDUgMS42NWgtMy4wNXYtMy40NGgyLjc4YzIuMTYgMCAzLjA2LjUxIDMuMTYuNjQuMTM1LjMxOS4xOS42NjUuMTYgMS4wMXYtLjAzeiIgaWQ9ImIiLz48ZmlsdGVyIHg9Ii04LjQlIiB5PSItMTAuNCUiIHdpZHRoPSIxMTYuOCUiIGhlaWdodD0iMTM0JSIgZmlsdGVyVW5pdHM9Im9iamVjdEJvdW5kaW5nQm94IiBpZD0iYSI+PGZlT2Zmc2V0IGR5PSI1IiBpbj0iU291cmNlQWxwaGEiIHJlc3VsdD0ic2hhZG93T2Zmc2V0T3V0ZXIxIi8+PGZlR2F1c3NpYW5CbHVyIHN0ZERldmlhdGlvbj0iMy41IiBpbj0ic2hhZG93T2Zmc2V0T3V0ZXIxIiByZXN1bHQ9InNoYWRvd0JsdXJPdXRlcjEiLz48ZmVDb2xvck1hdHJpeCB2YWx1ZXM9IjAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAuMzggMCIgaW49InNoYWRvd0JsdXJPdXRlcjEiLz48L2ZpbHRlcj48L2RlZnM+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMyA1NC4zM2wyNy41Ny01Mi45QTIuNjYgMi42NiAwIDAgMSAzMi44OCAwaDEwMS44NWMuOTkyIDAgMS45MDEuNTUgMi4zNiAxLjQzbDI3LjU5IDUyLjg3YTIuNjYgMi42NiAwIDAgMS0uNTkgMy4yMUw4NS42IDEyNy42OWEyLjY1IDIuNjUgMCAwIDEtMy41NSAwTDMuNTQgNTcuNTRBMi42NiAyLjY2IDAgMCAxIDMgNTQuMzN6IiBmaWxsPSIjRTIwOUJCIi8+PGcgZmlsbC1ydWxlPSJub256ZXJvIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyKSI+PHVzZSBmaWxsPSIjMDAwIiBmaWx0ZXI9InVybCgjYSkiIHhsaW5rOmhyZWY9IiNiIi8+PHVzZSBmaWxsPSIjRkY0OEU4IiB4bGluazpocmVmPSIjYiIvPjwvZz48cGF0aCBmaWxsPSIjRkZGIiBkPSJNNjAuNTQgMjQuMTRMNDQuNjIgNjcuMDVsLTE1Ljk0LTQyLjloLTE0LjhsMjQuNjUgNjEuMzdoMTEuODRMNzUgMjQuMTR6bTIwLjM5IDB2NjAuOTRoMTMuNFYyNC4xNHoiLz48cGF0aCBkPSJNMTMwLjQgMjQuMTNoLTI0LjkxdjYwLjk0aDEzLjQxVjY2Ljc5aDEwLjJjMTMuNjcgMCAyNC42NC03LjMzIDI0LjY0LTIxLjQydi0uMThjMC0xMi40NS04LjgxLTIxLjA2LTIzLjM0LTIxLjA2em05Ljc1IDIxLjQ5YzAgNS4yMi0zLjkxIDkuMjMtMTAuNjIgOS4yM2gtMTAuNjJWMzYuMjRoMTAuMzZjNi43MSAwIDEwLjg5IDMuMjIgMTAuODkgOS4yM2wtLjAxLjE1eiIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PC9nPjwvc3ZnPg==") 50% center / contain no-repeat; }

.live-member-list { position: fixed; z-index: 498; cursor: pointer; height: 40px; bottom: 0px; padding: 4px; font-size: 24px; margin-left: -16px; display: none; user-select: none; }

.chromeless .live-member-list { display: none; }

.live-member-list.active, .live-member-list > .content { display: flex; -webkit-box-align: center; align-items: center; }

.live-member-list .avatars, .live-member-list .member-counter { float: left; }

.live-member-list .avatars { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: reverse; flex-flow: row-reverse nowrap; -webkit-box-align: center; align-items: center; position: relative; z-index: 50; transition: all 0.4s ease 0s; padding-right: 0.5em; }

.live-member-list .avatars .dead { transition: opacity 0.4s ease 0s; opacity: 0; }

.live-member-list .avatars img.avatar { height: 1.2em; width: 1.2em; margin-right: -0.4em; border-radius: 50%; border: 1px solid rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px; background: rgb(255, 255, 255); z-index: 50; }

.live-member-list .avatars .newcoming { position: absolute; z-index: 1000; top: 1px; left: 0px; height: 1.2em; line-height: 1; white-space: nowrap; transition: all 0.2s cubic-bezier(0, 0, 0, 1.2) 0s; }

.live-member-list .avatars .newcoming img.avatar { position: relative; z-index: 50; border-color: rgb(126, 211, 33); }

.live-member-list .avatars .newcoming .message { position: absolute; display: inline-block; left: 1.5em; top: 1px; border-radius: 1.2em; box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px; min-width: 100px; text-align: center; font-size: 0.5em; background-color: rgb(126, 211, 33); color: rgb(255, 255, 255); padding: 7px 1em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: all 0.4s ease 0s; }

.live-member-list .avatars .newcoming .nickname { display: inline-block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 220px; line-height: 1.15; color: inherit; }

.live-member-list .avatars .newcoming .nickname, .live-member-list .avatars .newcoming .online { vertical-align: bottom; }

.live-member-list .avatars .newcoming.bigger { right: 0.5em; transition: all 0s ease 0s; }

.live-member-list .avatars .newcoming.bigger .message { transition: all 0.8s ease 0s; opacity: 0; }

.live-member-list .avatars .newcoming.bigger img.avatar { transition: all 0.4s ease 0s, transform 0.2s ease 0s, -webkit-transform 0.2s ease 0s; box-shadow: rgba(255, 255, 0, 0.25) 0px 2px 4px; transform: scale(1.15); filter: brightness(1.5); }

.live-member-list .avatars .newcoming.fading img.avatar { box-shadow: rgba(255, 255, 0, 0) 0px 2px 4px; transform: none; filter: none; }

.live-member-list .member-counter { white-space: nowrap; user-select: none; max-width: calc(100vw - 78px); color: rgb(255, 255, 255); background: rgba(0, 0, 0, 0.8); box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 7px; border-radius: 26px; margin-left: -20px; line-height: 26px; overflow: hidden; padding-left: 24px; padding-right: 10px; font-size: 14px; word-spacing: -1px; letter-spacing: -0.1px; }

.live-member-list .member-counter.overflowing { line-height: 20px; max-height: 40px; white-space: normal; word-break: break-all; transform: scale(0.8); transform-origin: left top; }

.live-member-list .member-counter > span { display: inline; vertical-align: middle; }

.live-member-list .member-counter .online-mark { margin-left: 4px; margin-right: 2px; }

.live-member-list .member-counter .online-mark::before { content: ""; display: inline-block; width: 3px; height: 3px; border-radius: 50%; border: 3px solid rgb(126, 211, 33); vertical-align: 0.1em; }

.live-member-list .member-counter .num { display: inline-block; height: 1em; margin-right: 0.25em; text-align: center; position: relative; overflow: hidden; transform: translate(3px, 2px); line-height: 2.6; }

.live-member-list .member-counter .num .digit { position: relative; display: inline-block; text-indent: 0px; letter-spacing: 22px; width: 10px; overflow: hidden; }

.live-member-list .member-counter .num .digit::after { display: block; content: "0123456789?"; line-height: 16px; font-size: 16px; white-space: normal; overflow-wrap: break-word; word-break: break-all; width: 1em; position: absolute; right: 0px; left: 0px; text-align: center; top: 0px; transition: all 1s ease 0s; }

.live-member-list .member-counter .num .digit.removing { opacity: 0; transition: all 0.5s ease 0s; }

.live-member-list .member-counter .num .digit-1::after { top: -1em; }

.live-member-list .member-counter .num .digit-2::after { top: -2em; }

.live-member-list .member-counter .num .digit-3::after { top: -3em; }

.live-member-list .member-counter .num .digit-4::after { top: -4em; }

.live-member-list .member-counter .num .digit-5::after { top: -5em; }

.live-member-list .member-counter .num .digit-6::after { top: -6em; }

.live-member-list .member-counter .num .digit-7::after { top: -7em; }

.live-member-list .member-counter .num .digit-8::after { top: -8em; }

.live-member-list .member-counter .num .digit-9::after { top: -9em; }

.live-member-list .member-counter .num .digit-10::after { top: -10em; }

.live-member-list .member-counter .num .digit { width: 9px; }

.live-member-list .member-counter .num .digit::after { font-size: 14px; line-height: 14px; }

.live-member-list .member-counter .online-mark { margin-left: 2px; margin-right: 0px; }

.live-member-list .member-counter.overflowing { line-height: 16px; max-height: 32px; overflow: hidden; overflow-wrap: break-word; transform: scale(0.9); transform-origin: center center; padding-left: 14px; padding-right: 2px; }

.community-card { position: relative; display: block; font-size: 16px; height: 7.5em; width: 5em; margin-top: 0.25em; }

.community-card .community-icon { position: absolute; z-index: 10; top: -0.25em; left: -0.25em; width: 2.4em; height: 2.4em; border-radius: 0.25em; }

.community-card .name { position: absolute; z-index: 10; bottom: 0.5em; left: 0.5em; right: 0px; color: rgb(255, 255, 255); font-size: 1em; line-height: 1.1; text-shadow: rgba(0, 0, 0, 0.7) 0px 0px 2px; overflow-wrap: break-word; text-align: left; overflow: hidden; }

.community-card .background { object-fit: cover; position: absolute; inset: 0px; box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 2px; border-radius: 0.25em; overflow: hidden; height: 7.5em; width: 5em; }

article.album { position: relative; }

article.album > .album-cover { right: 0px; bottom: 0px; z-index: 100; }

article.album > .album-cover, article.album > .content { position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; }

article.album > .content { z-index: 110; display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; transition: all 0.4s ease 0s; background: rgba(0, 0, 0, 0.5); padding: 0.5em; color: rgb(255, 255, 255); font-size: 16px; }

article.album > .content .title { margin-top: auto; margin-bottom: 2px; max-height: 2.8em; overflow: hidden; font-weight: 700; font-size: large; line-height: 1.4; }

article.album > .content .count { font-size: small; }

article.album > .album-cover.loading + .content { background-color: rgba(0, 0, 0, 0.25); }

.post-vip-mask { background-image: linear-gradient(-180deg, rgba(255, 255, 255, 0) 4%, rgb(255, 255, 255) 75%); -webkit-box-flex: 1; flex-grow: 1; display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; -webkit-box-pack: end; justify-content: flex-end; position: absolute; inset: 0px; z-index: 100; }

.post-vip-mask > .lock-icon { fill: rgb(223, 28, 152); margin: 0px auto; }

.post-vip-mask > .post-vip-tip { text-align: center; width: 255px; hyphens: auto; word-break: break-word; font-size: 16px; color: rgb(48, 48, 48); margin: 13px auto 0px; }

.post-vip-mask > .btn-vip { margin: 30px auto 0px; }

.need-hidden-post .post-full-content { position: relative; max-height: 470px; min-height: 230px; overflow: hidden; margin-bottom: 70px; }

.need-hidden-post .post-full-content .img-cover, .need-hidden-post .post-full-content .post-img { filter: blur(6px); }

.fans-only-icon { background: rgb(223, 28, 152); width: 28px; height: 28px; border-radius: 0px 0px 0px 10px; text-align: center; padding: 4px 0px; position: absolute; top: 0px; right: 0px; z-index: 6; cursor: pointer; }

.fans-only-icon > .fans-only-img { width: 22px; height: 17px; }

.fans-only-icon > .hover-hint { border-radius: 5px; width: 220px; display: block; position: absolute; background: rgba(0, 0, 0, 0.7); color: rgb(255, 255, 255); right: 0px; font-weight: 700; font-size: 14px; bottom: -7px; transform: translateY(100%); padding: 10px; text-align: left; hyphens: auto; opacity: 0; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 7px; pointer-events: none; transition: all 0.2s ease-in-out 0s; }

.fans-only-icon > .hover-hint::after { position: absolute; content: " "; display: block; width: 8px; height: 8px; background: linear-gradient(45deg, transparent, transparent 50%, rgba(0, 0, 0, 0.7) 0px, rgba(0, 0, 0, 0.7)); top: -4px; right: 8px; transform: rotate(-45deg); }

.fans-only-icon:hover > .hover-hint { opacity: 1; }

.simple-list { overflow: hidden; }

.simple-list article.post { position: relative; margin-bottom: 1em; contain: content; height: 140px; background: rgba(0, 0, 0, 0.9); }

.simple-list article.post .cover { position: absolute; inset: 0px; z-index: 150; width: 100%; height: 100%; overflow: hidden; }

.simple-list article.post .cover > .cover-img { width: 100%; height: 100%; }

.simple-list article.post.need-hidden-post .cover .img-cover, .simple-list article.post.need-hidden-post .cover > .cover-img { filter: blur(4px); }

.simple-list article.post .overlay { position: absolute; inset: 0px; z-index: 200; width: 100%; height: 100%; transition: all 0.4s ease 0s; }

.simple-list article.post .fans-only-icon { z-index: 200; }

.simple-list article.post .cover-img.loading + .overlay { background-color: rgba(0, 0, 0, 0.25); }

.simple-list article.post > .content { position: absolute; inset: 0px; z-index: 160; width: 100%; height: 100%; display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; -webkit-box-pack: end; justify-content: flex-end; color: rgb(255, 255, 255); padding: 1em 1em 0px; background: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.7)); }

.simple-list article.post section.desc h3.title { margin-bottom: 4px; font-size: medium; line-height: 18px; max-height: 54px; overflow: hidden; overflow-wrap: break-word; }

.simple-list article.post footer.actions { display: flex; padding-bottom: 10px; font-size: medium; }

.simple-list article.post footer.actions > .action { margin-right: 1em; }

section.comment-list { padding-bottom: 1em; font-size: 14px; }

section.comment-list h3.title { margin-bottom: 14px; }

section.comment-list article.comment { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; padding: 16px 0px; border-bottom: 1px solid rgb(228, 228, 228); }

section.comment-list article.comment:last-of-type { border-bottom-width: 0px; }

.phone_night section.comment-list article.comment { border-top: 1px solid rgb(255, 255, 255); }

section.comment-list article.comment > .content { -webkit-box-flex: 1; flex: 1 1 100%; display: flex; transition: background-color 2s ease 1s; }

section.comment-list article.comment.replying > .content { box-shadow: -8px 0 #fff,-10px 0 var(--community-color); }

section.comment-list article.comment .avatar-aside { -webkit-box-flex: 0; flex: 0 0 36px; height: 36px; margin-right: 0.25em; }

section.comment-list article.comment .main { -webkit-box-flex: 1; flex: 1 0 0px; overflow: hidden; }

section.comment-list article.comment .main .pretty-date { margin-left: 3px; margin-right: 1em; font-size: 12px; }

section.comment-list article.comment .main .pretty-date:first-child { margin-left: 0px; }

section.comment-list article.comment .main .nickname, section.comment-list article.comment .main .pretty-date { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

section.comment-list article.comment .main > .info { display: flex; -webkit-box-align: center; align-items: center; }

section.comment-list article.comment .main > .info .action-menu { margin-left: auto; color: rgb(155, 155, 155); }

section.comment-list article.comment .main > .bottom-info { padding: 3px 0px 0px; }

section.comment-list article.comment .main .label-author { line-height: 14px; }

section.comment-list article.comment .main .action-menu:not(.open) { visibility: hidden; }

section.comment-list article.comment .main:hover .action-menu { visibility: visible; }

section.comment-list article.comment .reply, section.comment-list article.comment .vote { padding: 0px 14px 0px 0px; border-left: 1px solid transparent; color: rgb(138, 138, 138); }

section.comment-list article.comment .reply > .amino-icon, section.comment-list article.comment .vote > .amino-icon { font-weight: 500; }

section.comment-list article.comment .reply .label, section.comment-list article.comment .reply .num, section.comment-list article.comment .vote .label, section.comment-list article.comment .vote .num { font-size: 12px; margin-left: 3px; }

section.comment-list article.comment .reply .num, section.comment-list article.comment .reply i.amino-icon-heart, section.comment-list article.comment .vote .num, section.comment-list article.comment .vote i.amino-icon-heart { color: rgb(229, 26, 74); font-weight: 700; }

section.comment-list article.comment .reply[data-vce="btn-popup"] i.amino-icon-heart, section.comment-list article.comment .reply[data-vote-value="0"] i.amino-icon-heart, section.comment-list article.comment .reply i.amino-icon-heart-o, section.comment-list article.comment .vote[data-vce="btn-popup"] i.amino-icon-heart, section.comment-list article.comment .vote[data-vote-value="0"] i.amino-icon-heart, section.comment-list article.comment .vote i.amino-icon-heart-o { display: none; }

section.comment-list article.comment .reply[data-vce="btn-popup"] .amino-icon-heart-o, section.comment-list article.comment .reply[data-vote-value="0"] .amino-icon-heart-o, section.comment-list article.comment .vote[data-vce="btn-popup"] .amino-icon-heart-o, section.comment-list article.comment .vote[data-vote-value="0"] .amino-icon-heart-o { display: inline-block; }

section.comment-list article.comment .reply[data-vce="btn-popup"] .num, section.comment-list article.comment .reply[data-vote-value="0"] .num, section.comment-list article.comment .vote[data-vce="btn-popup"] .num, section.comment-list article.comment .vote[data-vote-value="0"] .num { color: rgb(138, 138, 138); font-weight: 400; }

section.comment-list article.comment .vote { padding-bottom: 2px; }

section.comment-list article.comment .reply:hover .label { text-decoration: underline; }

section.comment-list article.comment .sub-comments { -webkit-box-flex: 1; flex: 1 1 600px; margin-top: 10px; margin-left: 36px; overflow: hidden; }

section.comment-list article.comment .sub-comments article.comment.sub { border-bottom: none; padding: 0px 0px 16px; }

section.comment-list article.comment .sub-comments article.comment.sub:last-child { padding: 0px; }

section.comment-list article.comment .sub-comments article.comment.sub > .content { overflow: hidden; margin-left: 8px; }

section.comment-list article.comment .sub-comments .read-more { color: rgb(0, 145, 255); margin-bottom: 8px; }

section.comment-list article.comment .sub-comments .comment-input-bar { margin-left: 8px; }

section.comment-list article.comment .nickname { font-weight: 700; color: rgb(0, 138, 249); padding: 3px 0px 0px; line-height: 14px; }

section.comment-list article.comment .pretty-date { color: rgb(189, 189, 189); }

section.comment-list article.comment .comment-text p { margin-bottom: 0px; word-break: break-word; }

section.comment-list article.comment .comment-sticker { background: none; width: 80px; margin: 10px 0px; }

section.comment-list .empty-content { height: 200px; min-height: auto; color: rgb(155, 155, 155); }

section.comment-list .avatar { font-size: 36px; border-width: 1px; object-fit: cover; }

section.comment-list .read-more-comments { display: block; line-height: 36px; border: 1px solid; border-radius: 8px; margin: 10px auto 0px; text-align: center; width: 240px; cursor: pointer; }

section.comment-list .height-toggle { display: none; }

section.comment-list .level-badge { margin-top: -2px; width: 19px; height: 19px; }

section.comment-list .influencer-badge { margin-top: -2px; width: 22px !important; }

section.comment-list article.comment [data-vce="toggle-content"] { overflow: hidden; max-height: 85px; }

section.comment-list article.comment [data-vce="toggle-content"].overflowing { max-height: 80px; position: relative; padding-bottom: 20px; z-index: 0; }

section.comment-list article.comment [data-vce="toggle-content"].overflowing .height-toggle { display: block; }

section.comment-list article.comment [data-vce="toggle-content"].logged-in { max-height: 140px; }

section.comment-list article.comment [data-vce="toggle-content"].logged-in.overflowing { max-height: 120px; }

section.comment-list article.comment [data-vce="toggle-content"] .height-toggle { position: absolute; bottom: 0px; left: 0px; right: 0px; padding-top: 20px; height: auto; background: linear-gradient(0deg, rgb(255, 255, 255), rgb(255, 255, 255) 60%, rgba(255, 255, 255, 0)); color: rgb(0, 138, 249); font-size: 12px; z-index: 1; font-weight: 500; padding-bottom: 4px; text-align: left; transition: opacity 0.5s ease 2s; }

section.comment-list article.comment [data-vce="toggle-content"].open { padding-bottom: 0px; }

section.comment-list article.comment [data-vce="toggle-content"].open .height-toggle { display: none; }

section.comment-list article.comment.highlight > .content { background-color: rgba(255, 255, 0, 0.4); box-shadow: rgba(255, 255, 0, 0.4) 0px 0px 4px; transition: all 0ms ease 0s; }

section.comment-list article.comment.highlight [data-vce="toggle-content"] .height-toggle { opacity: 0; transition: all 0ms ease 0s; }

section.comment-list .read-more { background: rgb(244, 244, 244); font-size: 12px; line-height: 15px; font-weight: 500; }

section.comment-list .read-more:hover { background: rgb(228, 228, 228); }

section.comment-list .read-more > a.pointer { display: block; padding: 7px; }

section.comment-list .load-comment-indicator { font-size: 56px; text-align: center; color: rgba(0, 0, 0, 0.25); padding-bottom: 25px; position: absolute; top: 50%; left: 0px; right: 0px; visibility: hidden; opacity: 0; transition: opacity 0.2s ease 0s; }

section.comment-list.loading { position: relative; }

section.comment-list.loading .load-comment-indicator { visibility: visible; opacity: 1; }

section.comment-list.loading .read-more-comments, section.comment-list.loading article.comment { visibility: hidden; }

section.live-comment { position: absolute; bottom: 0px; left: 0px; right: 0px; }

section.live-comment > .content { display: none; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; position: fixed; z-index: 497; bottom: 0px; transition-duration: 0.2s; transition-property: height, opacity; background: linear-gradient(0deg, rgba(0, 0, 0, 0.4), transparent); }

section.live-comment > .content.init { display: flex; opacity: 1; }

section.live-comment > .content ul.comments { position: absolute; bottom: 36px; left: 0px; opacity: 1; transition: transform 0.8s ease 0s, opacity 0.2s ease 0s, -webkit-transform 0.8s ease 0s; }

[data-vce="live-comment"].empty-member section.live-comment > .content ul.comments { bottom: 6px; }

[data-vce="live-comment"].state-commentarea section.live-comment > .content ul.comments, [data-vce="live-comment"].state-endcap section.live-comment > .content ul.comments, [data-vce="live-comment"].state-hide section.live-comment > .content ul.comments { opacity: 0; pointer-events: none; }

section.live-comment > .content ul.comments.newcoming { transform: translateY(38px); }

section.live-comment > .content ul.comments.newcoming .comment:last-child { opacity: 0; pointer-events: none; }

section.live-comment > .content ul.comments .comment { display: flex; -webkit-box-align: center; align-items: center; margin-bottom: 4px; transition: all 0.8s ease 0s; }

section.live-comment > .content ul.comments .comment.dying { position: absolute; top: -38px; opacity: 0; }

section.live-comment > .content ul.comments .message { display: flex; max-width: calc(100vw - 65px); border-radius: 5px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 7px; padding: 2px 8px; line-height: 21px; font-size: 14px; }

section.live-comment > .content ul.comments .message > .content { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; -webkit-box-flex: 0; flex: 0 1 auto; }

section.live-comment > .content ul.comments .message .media { display: inline-block; -webkit-box-flex: 0; flex: 0 0 21px; width: 21px; height: 21px; margin-left: 2px; }

section.live-comment .live-member-list { position: absolute; background: none; padding-bottom: 0px; right: auto; left: 0px; margin-left: auto; padding-left: 0px; bottom: 6px; }

section.live-comment .live-member-list .member-counter { max-width: calc(100vw - 120px); }

section.live-comment .counters { -webkit-box-ordinal-group: 21; order: 20; position: static; margin: 0px auto 6px 12px; z-index: 550; display: flex; -webkit-box-align: start; align-items: start; text-align: center; transition: all 0.2s ease 0s; }

section.live-comment .counters .comment-counter, section.live-comment .counters .vote-counter { width: 67px; border: 0px; border-radius: 18px; color: rgb(255, 255, 255); padding: 0px 5px; background: rgba(0, 0, 0, 0.4); }

section.live-comment .counters .comment-counter:hover, section.live-comment .counters .vote-counter:hover { background: rgba(0, 0, 0, 0.6); }

section.live-comment .counters .comment-counter i.amino-icon, section.live-comment .counters .vote-counter i.amino-icon { display: block; width: 30px; height: 30px; line-height: 30px; font-size: 16.5px; text-align: center; vertical-align: middle; }

section.live-comment .counters .comment-counter .num, section.live-comment .counters .vote-counter .num { display: block; font-size: small; font-weight: 500; line-height: 1em; }

.not-mobile section.live-comment .counters .comment-counter { display: none; }

section.live-comment .counters .comment-counter i.amino-icon { font-size: 18px; }

section.live-comment .counters .vote-counter { color: rgb(229, 26, 74); }

section.live-comment .counters .vote-counter[data-vce="btn-popup"] { color: rgb(255, 255, 255); }

.not-mobile section.live-comment .counters .vote-counter { background: rgb(255, 255, 255); color: rgb(229, 26, 74); }

.not-mobile section.live-comment .counters .vote-counter .num { font-weight: 700; }

.not-mobile section.live-comment .counters .vote-counter i.amino-icon-heart-o { display: none; }

.not-mobile section.live-comment .counters .vote-counter[data-vce="btn-popup"], .not-mobile section.live-comment .counters .vote-counter[data-vote-value="0"] { color: rgb(155, 155, 155); font-weight: 400; }

.not-mobile section.live-comment .counters .vote-counter[data-vce="btn-popup"] i.amino-icon-heart-o, .not-mobile section.live-comment .counters .vote-counter[data-vote-value="0"] i.amino-icon-heart-o { display: inline-block; }

.not-mobile section.live-comment .counters .vote-counter[data-vce="btn-popup"] i.amino-icon-heart, .not-mobile section.live-comment .counters .vote-counter[data-vote-value="0"] i.amino-icon-heart { display: none; }

.not-mobile section.live-comment .counters .vote-counter:hover { background: rgb(233, 232, 239); }

[data-vce="live-comment"].state-commentinput section.live-comment .counters { display: none; }

section.live-comment .state-switch { position: absolute; right: 12px; bottom: 0px; z-index: 600; color: rgb(255, 255, 255); font-size: 18px; text-shadow: rgba(0, 0, 0, 0.5) 0px 0px 5px; padding: 20px 8px 9px 20px; transition: all 0.3s ease 0s; }

section.live-comment .state-switch .switch-off { display: block; }

section.live-comment .state-switch .switch-on { display: none; }

[data-vce="live-comment"].state-commentarea section.live-comment .state-switch { opacity: 0.4; pointer-events: none; }

[data-vce="live-comment"].state-hide section.live-comment .state-switch .switch-off { display: none; }

[data-vce="live-comment"].state-hide section.live-comment .state-switch .switch-on { display: block; }

[data-vce="live-comment"].state-commentinput section.live-comment .state-switch { opacity: 0; pointer-events: none; }

[data-vce="live-comment"].state-endcap section.live-comment .content { height: 0px; }

[data-vce="live-comment"].state-endcap section.live-comment .comment-input-bar, [data-vce="live-comment"].state-endcap section.live-comment .counters, [data-vce="live-comment"].state-endcap section.live-comment .state-switch { opacity: 0; pointer-events: none; }

[data-vce="live-comment"].state-endcap section.live-comment .live-member-list { bottom: 12px; }

section.live-comment .upper { position: relative; -webkit-box-ordinal-group: 11; order: 10; transition-duration: 0.2s; transition-property: height; height: 132px; margin: 0px 12px 8px; border-bottom: 1px solid rgba(255, 255, 255, 0.3); }

[data-vce="live-comment"].state-commentarea section.live-comment .upper { height: 58px; }

[data-vce="live-comment"].state-hide section.live-comment .upper { height: 48px; }

section.community-content > .main-page { background: none; }

.main-page section.main-page-section > .title { font-size: 18px; position: relative; padding-left: 28px; line-height: 1.4; margin-top: 0px; }

.main-page section.main-page-section > .title::before { content: ""; position: absolute; top: 0.1em; left: 0px; display: block; height: 1.2em; width: 8px; border-left: 8px solid; }

.main-page article.post.main-post { position: relative; background-color: rgb(255, 255, 255); overflow: hidden; }

.main-page article.post.main-post > .post-full-content > section.info, .main-page article.post.main-post > section.info { margin: 1em 0px; }

.main-page article.post.main-post .rich-content a { color: rgb(0, 145, 255); }

.main-page article.post.main-post section.quiz-body { text-align: center; }

.main-page article.post.main-post section.quiz-body .btn.start-quiz { margin: 1em auto; border-radius: 1.5em; font-size: x-large; color: rgb(255, 255, 255); background: rgb(29, 218, 143); }

.main-page article.post.main-post section.quiz-body .btn.start-quiz:active, .main-page article.post.main-post section.quiz-body .btn.start-quiz:hover { background: rgb(23, 173, 113); }

.main-page article.post.main-post section.quiz-body .btn.start-quiz i.fa { margin-right: 0.25em; }

.main-page article.post.main-post > .post-full-content > section.content { padding: 0.5em 0px 0px; overflow-wrap: break-word; overflow: hidden; }

.main-page article.post.main-post > .post-full-content > section.content .post-content-toggle.open .height-toggle { display: none; }

.main-page article.post.main-post > .post-full-content > section.content p { min-height: 25px; }

.main-page article.post.main-post > .post-full-content > section.content .image-container, .main-page article.post.main-post > .post-full-content > section.content .video-container { margin: 24px auto; }

.main-page article.post.main-post > .post-full-content > section.content .video-caption { margin: -24px 0px 24px; }

.main-page article.post.main-post > .post-full-content > section.counters { display: none; -webkit-box-align: center; align-items: center; margin: 1em 22px 0.5em; }

.main-page article.post.main-post.need-hidden-post .post-full-content { position: relative; max-height: 470px; min-height: 230px; overflow: hidden; margin-bottom: 70px; }

.main-page article.post.main-post.need-hidden-post .post-full-content .img-cover, .main-page article.post.main-post.need-hidden-post .post-full-content .post-img { filter: blur(6px); }

.main-page article.post.main-post.need-hidden-post .post-full-content .poll-item .img-cover { filter: blur(2px); }

.main-page article.post.main-post.need-hidden-post section.share { padding-bottom: 30px; }

.main-page header.title { padding: 30px 0px 10px; }

.main-page header.title > .title { font-size: x-large; font-weight: 700; padding-left: 28px; padding-right: 28px; overflow: hidden; }

.main-page section.info { display: flex; -webkit-box-align: center; align-items: center; }

.main-page section.info .avatar { font-size: 40px; -webkit-box-flex: 0; flex: 0 0 auto; }

.main-page section.info .nickname { width: 100%; font-weight: 700; }

.main-page section.info .pretty-date { margin-top: 5px; color: rgb(155, 155, 155); white-space: nowrap; font-size: small; }

.phone_night .main-page section.info .pretty-date { color: rgb(233, 232, 239); }

.main-page section.info .pretty-date i.fa { color: rgb(29, 218, 143); font-size: inherit; }

.main-page section.info section.counters { display: flex; margin-left: auto; }

.main-page header.item-header .jumbotron { position: relative; z-index: 5; -webkit-box-flex: 0; flex: 0 0 100%; height: 200px; margin-bottom: -48px; }

.main-page header.item-header .jumbotron::after { display: block; content: " "; position: absolute; inset: 0px; z-index: 6; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); }

.main-page header.item-header .jumbotron > .img-cover { position: absolute; inset: 0px; z-index: 5; width: 100%; height: 100%; }

.main-page header.item-header .page-wiki-item { position: relative; }

.main-page header.item-header .fans-only-icon { width: 16px; height: 16px; padding: 0px; border-top-right-radius: 5px; z-index: 11; }

.main-page header.item-header .fans-only-icon .hover-hint { right: auto; left: -5px; }

.main-page header.item-header .fans-only-icon .hover-hint::after { right: auto; }

.main-page header.item-header .fans-only-icon > .fans-only-img { width: 12px; height: 9px; margin-top: -4px; }

.main-page header.item-header .item-card { position: relative; z-index: 10; -webkit-box-flex: 0; flex: 0 0 94px; border-width: 2px 2px 20px; border-style: solid; border-color: rgb(255, 255, 255); border-image: initial; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 8px; border-radius: 5px; width: 94px; height: 112px; margin-left: 22px; margin-bottom: 11px; background-color: rgb(233, 232, 239); }

.main-page header.item-header .item-curated { border-color: rgb(255, 192, 0); background-color: rgb(255, 255, 255); }

.main-page header.item-header > div.title { position: relative; z-index: 10; display: flex; text-align: left; }

.main-page header.item-header > div.title h3.text { margin: 0px 0px 0px 1rem; font-size: 180%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; color: rgb(255, 255, 255); line-height: 48px; text-shadow: rgb(0, 0, 0) 0px 0px 1px; }

.main-page header.item-header > div.title .authors { display: flex; -webkit-box-align: end; align-items: flex-end; height: 48px; margin-left: 1rem; color: rgb(155, 155, 155); }

.main-page header.item-header > div.title .authors > .avatars { -webkit-box-flex: 0; flex: 0 1 0%; display: flex; -webkit-box-align: center; align-items: center; margin-right: 0.5rem; font-size: 40px; }

.main-page header.item-header > div.title .authors > .avatars > .author { height: 40px; margin-right: -0.4em; }

.main-page header.item-header > div.title .authors > .avatars > .author:last-child { margin-right: 0px; }

.main-page header.item-header > div.title .authors .label::after { content: ":"; }

.main-page header.item-header > div.title .authors .names { display: inline-flex; -webkit-box-align: baseline; align-items: baseline; width: 100%; white-space: nowrap; overflow: hidden; }

.main-page header.item-header > div.title section.counters { display: flex; -webkit-box-align: center; align-items: center; margin-left: auto; margin-right: 22px; padding-top: 60px; }

.main-page section.item-about { overflow: hidden; line-height: 1.5; }

.main-page section.item-about > h3.label { margin: 0.5em 0px; }

.main-page section.item-about > .content { padding: 0.5rem 0px; }

.main-page section.item-about table[data-vce="rich-content"] { border-collapse: collapse; }

.main-page section.item-about td.label { padding: 0px; font-weight: 700; vertical-align: top; }

.main-page section.item-about hr { width: 80vw; max-width: 400px; margin: 1rem auto; border-top-color: rgb(233, 232, 239); }

.main-page section.page-snippet { margin: 0.5em 0px 1em; }

.main-page section.page-snippet > .frame { border: 1px solid rgb(198, 198, 198); overflow: hidden; border-radius: 2px; }

.main-page section.page-snippet > .frame h3.title { padding: 0px 1em; }

.main-page section.page-snippet > .frame > .content { display: flex; -webkit-box-align: center; align-items: center; padding: 1em; line-height: 1.5; }

.main-page section.page-snippet > .frame .body { line-height: 24px; overflow: hidden; overflow-wrap: break-word; }

.main-page section.page-snippet > .frame .btn-read { -webkit-box-flex: 1; flex: 1 0 auto; background: rgb(255, 255, 255); color: rgb(155, 155, 155); border: 1px solid rgb(198, 198, 198); text-align: center; }

.main-page section.page-snippet .cover { width: 100%; max-height: 400px; position: relative; }

.main-page section.page-snippet .cover::before { display: block; content: ""; width: 100%; padding-top: 62.5%; }

.main-page section.page-snippet .cover > .content { position: absolute; inset: 0px; width: 100%; height: 100%; }

.main-page section.page-snippet .cover .youtube-preview { overflow: hidden; }

.main-page section.page-snippet .source { margin-top: 0.5rem; line-height: 18px; font-size: small; color: rgb(65, 69, 73); }

.main-page section.page-snippet .source > .favicon { vertical-align: text-top; width: 18px; height: 18px; background: rgb(255, 255, 255); }

.main-page section.blog-like, .main-page section.item-gallery, .main-page section.item-linked, .main-page section.more-posts, .main-page section.pollopt { overflow: hidden; margin-top: 1em; padding: 0px; }

.main-page section.blog-like > .content, .main-page section.item-gallery > .content, .main-page section.item-linked > .content, .main-page section.more-posts > .content, .main-page section.pollopt > .content { margin: 5px 28px; }

.main-page section.item-gallery [data-vce="carousel"] { margin: 0px 0.5em; }

.main-page section.comment-list { margin-top: 30px; }

.main-page section.comment-list > .title { font-size: 18px; position: relative; padding-left: 28px; line-height: 1.4; margin-top: 0px; }

.main-page section.comment-list > .title::before { content: ""; position: absolute; top: 0.1em; left: 0px; display: block; height: 1.2em; width: 8px; border-left: 8px solid; }

.main-page section.item-linked > .content { margin-left: 25px; }

.main-page section.item-linked .linked-item { width: 100px; border-radius: 0.5em; border: 1px solid rgb(233, 232, 239); background-color: rgb(233, 232, 239); position: relative; overflow: unset; }

.main-page section.item-linked .linked-item.system { border-color: rgb(255, 192, 0); background-color: rgb(255, 192, 0); }

.main-page section.item-linked .linked-item .preview-cover { width: 100px; height: 100px; }

.main-page section.item-linked .linked-item .label { margin: 0.2em 0px; overflow: hidden; text-overflow: ellipsis; height: 1.25em; line-height: 1.25em; text-align: center; font-size: 80%; }

.main-page section.item-linked .linked-item .fans-only-icon { width: 16px; height: 16px; padding: 0px; border-top-right-radius: 5px; }

.main-page section.item-linked .linked-item .fans-only-icon .hover-hint { right: auto; left: -5px; }

.main-page section.item-linked .linked-item .fans-only-icon .hover-hint::after { right: auto; }

.main-page section.item-linked .linked-item .fans-only-icon > .fans-only-img { width: 12px; height: 9px; margin-top: -4px; }

.main-page section.item-linked .carousel-item { width: 100px; }

.main-page section.item-linked .carousel-cover { width: 98px; height: 98px; }

.main-page .recommend-item { position: relative; }

.main-page .recommend-item .fans-only-icon { z-index: 101; }

.main-page .recommend-item .fans-only-icon > .hover-hint { font-size: 12px; }

.main-page section.recommend { display: flex; -webkit-box-pack: start; justify-content: flex-start; }

.main-page section.recommend article.post.recommend-item { background: rgb(255, 255, 255); }

.main-page section.recommend article.post.recommend-item .cover { position: relative; height: 90px; }

.main-page section.recommend article.post.recommend-item .cover.item { height: 135px; }

.main-page section.recommend article.post.recommend-item .cover .cover-img { height: 100%; width: 100%; }

.main-page section.recommend article.post.recommend-item .cover .overlay { position: absolute; inset: 0px; z-index: 100; width: 100%; height: 100%; }

.main-page section.recommend article.post.recommend-item > .content { display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; -webkit-box-flex: 1; flex: 1 1 auto; font-size: small; padding: 1rem; }

.main-page section.recommend article.post.recommend-item > .content > .pretty-date { display: none; color: rgb(155, 155, 155); font-size: small; margin-top: auto; }

.main-page section.recommend article.post.recommend-item > .content > section.info { display: flex; margin-top: auto; }

.main-page section.recommend article.post.recommend-item > .content h3.title { line-height: 22px; max-height: 44px; overflow: hidden; overflow-wrap: break-word; margin: 0.5em 0px; font-size: medium; }

.main-page section.recommend article.post.recommend-item > .content .reason { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; color: rgb(155, 155, 155); }

.main-page section.recommend article.post.recommend-item.need-hidden-post .img-cover { filter: blur(6px); }

.main-page section.recommend .recommend-app { display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; justify-content: space-around; color: rgb(255, 255, 255); padding: 0.75em 1em; }

.main-page section.recommend .recommend-app .promotion { line-height: 1.5; font-size: large; font-weight: 700; white-space: pre-wrap; hyphens: auto; }

.main-page section.recommend .recommend-app .btn { background-color: rgb(255, 255, 255); box-shadow: rgb(198, 198, 198) 0px -3px inset, rgb(198, 198, 198) 0px 2px; -webkit-box-flex: 0; flex: 0 0 auto; display: flex; text-align: center; -webkit-box-pack: center; justify-content: center; font-size: large; padding: 0.75em 0.5em; }

.main-page section.recommend .recommend-app .btn:active { box-shadow: none; }

.main-page section.recommend .recommend-app:nth-child(n+4) { display: none; }

.main-page section.next-post { display: flex; -webkit-box-pack: center; justify-content: center; contain: content; opacity: 0; padding-top: 1.5em; padding-bottom: 1.5em; }

.main-page section.next-post.loading { opacity: 1; }

.main-page section.next-post i.fa { contain: content; }

.main-page section.next-post i.fa.white { display: block; color: rgb(255, 255, 255); text-shadow: rgba(0, 0, 0, 0.5) 0px 0px 3px; }

.main-page section.next-post i.fa.community-color { display: none; }

.main-page .post-divider { display: none; margin-bottom: 20px; border-top: 1px solid rgb(233, 232, 239); }

.main-page .post-divider.wiki { border-top: none; }

.main-page .vote-counter { color: rgb(252, 47, 127); }

.main-page .comment-counter { color: rgb(14, 224, 180); }

.main-page .comment-counter, .main-page .vote-counter { display: flex; -webkit-box-align: center; align-items: center; width: 80px; margin-left: 1rem; border-radius: 1rem; border: 1px solid; padding: 0px 0.7rem; line-height: 2rem; white-space: nowrap; }

.main-page .comment-counter:first-child, .main-page .vote-counter:first-child { margin-left: 0px; }

.main-page .comment-counter .amino-icon, .main-page .vote-counter .amino-icon { font-size: 20px; }

.main-page .comment-counter .num, .main-page .vote-counter .num { -webkit-box-flex: 1; flex: 1 0 auto; text-align: center; }

.main-page article.post.main-post > .post-full-content > section.content p, .main-page article.post.main-post > .post-full-content > section.info, .main-page article.post.main-post > section.info, .main-page section.comment-list > .content, .main-page section.item-about, .main-page section.page-snippet, .main-page section.repost-desc { padding-left: 28px; padding-right: 28px; }

.main-page section.recommend .recommend-app, .main-page section.recommend article.post.recommend-item { display: flex; -webkit-box-flex: 0; flex: 0 0 32%; margin-right: 2%; }

.main-page .object-status-alert { background-color: rgb(208, 2, 27); color: rgb(255, 255, 255); font-size: 20px; text-align: center; padding: 12px; }

.main-page article.post.main-post.blocked-indicator { min-height: 80vh; max-height: calc(100vh - 250px); }

.main-page section.repost-desc { margin: 5px 5px 1em; font-size: small; }

.main-page section.repost-desc > .content { position: relative; border-radius: 5px; background: rgb(233, 232, 239); padding: 10px; line-height: 1.5; }

.main-page section.repost-desc > .content p:last-child { margin-bottom: 0px; }

.main-page section.repost-desc .reposter { margin-bottom: 5px; }

.main-page section.repost-desc .reposter i.fa { color: rgb(0, 145, 255); }

.main-page section.repost-desc .reposter .nickname { max-width: 230px; }

.main-page section.pollopt .voting .poll-item { cursor: pointer; }

.main-page section.pollopt .poll-item { display: flex; -webkit-box-align: center; align-items: center; margin-top: 12px; }

.main-page section.pollopt .poll-item:first-child { margin-top: 0px; }

.main-page section.pollopt .poll-item .poll-media-placeholder { background: rgb(74, 144, 226); font-size: 18px; color: rgb(255, 255, 255); text-align: center; display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; }

.main-page section.pollopt .item-cover { width: 40px; height: 40px; margin-left: 0px; margin-right: 12px; border-radius: 3px; flex-shrink: 0; }

.main-page section.pollopt .poll-item.voted-item > .label .bar { background-color: rgb(29, 218, 143); }

.main-page section.pollopt .poll-item > .label { position: relative; margin: 0px; -webkit-box-flex: 0; flex: 0 1 100%; overflow: hidden; text-align: center; border-radius: 3px; background-color: rgb(74, 74, 74); color: rgb(255, 255, 255); line-height: 40px; padding: 0px 0.5em; }

.main-page section.pollopt .poll-item > .label .bar { position: absolute; z-index: 40; left: 0px; top: 0px; bottom: 0px; background-color: rgb(74, 144, 226); background-image: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.2)); }

.main-page section.pollopt .poll-item > .label .title { position: relative; z-index: 50; display: flex; -webkit-box-pack: justify; justify-content: space-between; }

.main-page section.pollopt .poll-item > .label .title > .content { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; height: 40px; -webkit-box-flex: 10; flex-grow: 10; flex-basis: 0px; }

.main-page section.pollopt .poll-item > .label .partition { text-align: right; }

.main-page section.pollopt .voting .bar { width: 100%; }

.main-page section.pollopt .voted .label { text-align: left; }

.main-page section.pollopt .voting-end .bar { width: 0px; }

.main-page section.pollopt .voting-progress .bar { transition: width 0.5s ease-out 0s; }

.main-page section.pollopt ul.poll-options { width: 355px; font-size: 14px; }

.main-page section.pollopt .deeplink { margin: 1em auto; text-align: center; font-size: large; }

.main-page section.pollopt .deeplink > .btn { min-width: 120px; }

.main-page section.pollopt .main-poll-content { display: flex; }

.main-page section.pollopt .poll-btn { display: block; border-radius: 20px; min-width: 160px; height: 40px; padding: 11px 37px; margin-top: 20px; font-size: 14px; }

.main-page section.pollopt .youtube-preview { position: relative; }

.main-page section.pollopt .youtube-preview .amino-video-play { width: 28px; height: 28px; margin-left: -14px; margin-top: -14px; border-color: transparent; background: transparent; }

.main-page section.pollopt .youtube-preview .amino-video-play .play-icon-img { width: 14px; height: 24px; margin-left: 1.4px; }

.main-page section.pollopt .youtube-preview .fa-youtube { display: none; }

.main-page section.pollopt ul.voter-list { overflow: hidden; margin-left: 9px; }

.main-page section.pollopt ul.voter-list.hide { display: none; }

.main-page section.pollopt ul.voter-list .voters { height: 40px; margin-top: 12px; white-space: nowrap; }

.main-page section.pollopt ul.voter-list .voters:first-child { margin-top: 0px; }

.main-page section.pollopt ul.voter-list .voter { height: 40px; width: 40px; border-radius: 50%; text-align: center; margin-left: 10px; display: block; float: left; overflow: hidden; }

.main-page section.pollopt ul.voter-list .voter:nth-child(n+4):nth-last-child(n+2) { display: none; }

.main-page section.pollopt ul.voter-list .voter.placeholder { background: rgb(228, 228, 228); color: rgb(255, 255, 255); line-height: 40px; font-size: 20px; }

.main-page section.pollopt ul.voter-list .voter > .avatar { width: 100%; height: 100%; }

.main-page section.pollopt small.poll-info { margin-top: 15px; display: block; }

.main-page section.pollopt .voted .view-result, .main-page section.pollopt .voting .change-vote { display: none; }

.main-page section.share { margin-top: 6px; }

.main-page section.share:last-child { margin-bottom: 1em; }

.main-page section.share h3.label { font-size: 16px; margin: 0px 0px 0.75em; text-align: center; }

.main-page section.share h3.label::after { content: ":"; }

.main-page section.share .item .amino-icon { font-size: 1.75em; }

.main-page section.blog-like { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; -webkit-box-align: center; align-items: center; margin-top: 30px; }

.main-page section.blog-like > .title { -webkit-box-flex: 0; flex: 0 0 100%; margin-bottom: 10px; }

.main-page section.blog-like > .content { -webkit-box-flex: 1; flex: 1 0 0px; height: 40px; }

.main-page section.blog-like .user-list { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; justify-content: left; padding: 0px; }

.main-page section.blog-like .user-list.loading { contain: content; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; }

.main-page section.blog-like .user-list.loading .more-votes, .main-page section.blog-like .user-list.loading .vote-icon { display: none; }

.main-page section.blog-like .user-list .vote-icon { line-height: 40px; }

.main-page section.blog-like .user-bubble { margin-right: 8px; position: relative; width: 40px; height: 40px; }

.main-page section.blog-like .user-bubble .level-badge { position: absolute; right: 0px; bottom: 0px; }

.main-page section.blog-like .avatar { font-size: 40px; }

.main-page section.blog-like .more-votes, .main-page section.blog-like .vote-icon { border-radius: 50%; text-align: center; font-size: 20px; line-height: 36px; width: 40px; height: 40px; color: rgb(255, 255, 255); background: rgb(228, 228, 228); }

.main-page section.blog-like .more-votes { border: 1px solid; }

.main-page section.blog-like .vote-icon { background: rgb(243, 77, 92); color: rgb(255, 255, 255); font-size: 18px; margin-right: 8px; }

.main-page section.blog-like > .vote-counter { display: none; -webkit-box-flex: 0; flex: 0 0 auto; height: 40px; border-radius: 20px; border: none; margin-left: 30px; margin-right: -10px; width: 90px; font-size: 14px; padding: 0px 14px; color: rgb(229, 26, 74); font-weight: 700; background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.25) 0px 1px 7px; }

.main-page section.blog-like > .vote-counter:hover { background-color: rgb(233, 232, 239); }

.main-page section.blog-like > .vote-counter i.amino-icon { margin-right: 14px; font-size: 16px; }

.main-page section.blog-like > .vote-counter i.amino-icon-heart-o { display: none; }

.main-page section.blog-like > .vote-counter i.amino-icon-heart { display: inline-block; }

.main-page section.blog-like > .vote-counter .label { display: none; }

.main-page section.blog-like > .vote-counter[data-vce="btn-popup"], .main-page section.blog-like > .vote-counter[data-vote-value="0"] { color: rgb(96, 96, 96); font-weight: 400; }

.main-page section.blog-like > .vote-counter[data-vce="btn-popup"] i.amino-icon-heart-o, .main-page section.blog-like > .vote-counter[data-vote-value="0"] i.amino-icon-heart-o { display: inline-block; }

.main-page section.blog-like > .vote-counter[data-vce="btn-popup"] i.amino-icon-heart, .main-page section.blog-like > .vote-counter[data-vote-value="0"] i.amino-icon-heart { display: none; }

.main-page section.blog-like > .vote-counter[data-vce="btn-popup"] .label, .main-page section.blog-like > .vote-counter[data-vote-value="0"] .label { display: inline; }

.main-page section.blog-like > .vote-counter[data-vce="btn-popup"] .num, .main-page section.blog-like > .vote-counter[data-vote-value="0"] .num, .main-page section.recommend-new { display: none; }

.main-page section.recommend-new + .blog-like { margin-top: 20px; }

.main-page section.recommend-new .recommend-app { display: flex; flex-wrap: wrap; margin: 0px 4px 14px; color: rgb(255, 255, 255); padding: 18px 30px; position: relative; border-radius: 5px; overflow: hidden; z-index: 0; }

.main-page section.recommend-new .recommend-app > .img-cover { width: 40px; height: 40px; margin-top: -0.25em; margin-right: 10px; border-radius: 8px; -webkit-box-flex: 0; flex: 0 0 auto; }

.main-page section.recommend-new .recommend-app > .promotion { -webkit-box-flex: 1; flex: 1 0 200px; line-height: 1.2; margin-top: 0.25em; margin-bottom: 21px; font-size: 16px; font-weight: 700; }

.main-page section.recommend-new .recommend-app > .btn { width: 100%; background-color: rgb(255, 255, 255); box-shadow: rgb(198, 198, 198) 0px -3px inset, rgb(198, 198, 198) 0px 2px; -webkit-box-flex: 0; flex: 0 0 auto; display: flex; text-align: center; -webkit-box-pack: center; justify-content: center; font-size: large; padding: 0.75em 0.5em; }

.main-page section.recommend-new .recommend-app > .btn:active { box-shadow: none; }

.main-page section.recommend-new .recommend-app > .backdrop-img { background-color: inherit; }

.main-page section.recommend-new .recommend-app > .backdrop-img::after { background-color: inherit; opacity: 0.88; }

.main-page section.recommend-new article.post.recommend-item { -webkit-box-flex: 1; flex: 1 0 139px; margin: 0px 4px; overflow: hidden; }

.main-page section.recommend-new article.post.recommend-item .fans-only-icon { width: 21px; height: 21px; padding: 0px; }

.main-page section.recommend-new article.post.recommend-item .fans-only-icon > .fans-only-img { width: 16px; height: 13px; }

.main-page section.recommend-new article.post.recommend-item .fans-only-icon .hover-hint { max-width: 150px; }

.main-page section.recommend-new article.post.recommend-item .cover { position: relative; z-index: 0; width: 100%; }

.main-page section.recommend-new article.post.recommend-item .cover > .cover-img { width: 100%; height: 100px; }

.main-page section.recommend-new article.post.recommend-item .cover .amino-video-play { width: 36px; height: 36px; margin-left: -18px; margin-top: -18px; }

.main-page section.recommend-new article.post.recommend-item .cover .amino-video-play .play-icon-img { width: 14px; height: 32px; margin-left: 1.8px; }

.main-page section.recommend-new article.post.recommend-item .block { position: relative; }

.main-page section.recommend-new article.post.recommend-item .post-counters { position: absolute; color: rgb(255, 255, 255); bottom: 0px; height: 30px; left: 0px; right: 0px; z-index: 1; display: flex; -webkit-box-align: end; align-items: flex-end; background: linear-gradient(transparent, rgba(0, 0, 0, 0.5)); font-size: 13px; }

.main-page section.recommend-new article.post.recommend-item .post-counters .counter { margin: 7px 4px 5px 10px; }

.main-page section.recommend-new article.post.recommend-item .post-counters .num { vertical-align: text-bottom; }

.main-page section.recommend-new article.post.recommend-item .overlay { position: absolute; inset: 0px; z-index: 100; width: 100%; height: 100%; }

.main-page section.recommend-new article.post.recommend-item > .content { padding: 0.5rem 0px; }

.main-page section.recommend-new article.post.recommend-item > .content > .pretty-date { color: rgb(155, 155, 155); font-size: small; margin-top: auto; }

.main-page section.recommend-new article.post.recommend-item > .content > section.info { display: flex; margin-top: auto; }

.main-page section.recommend-new article.post.recommend-item > .content h3.title { line-height: 20px; max-height: 40px; overflow: hidden; overflow-wrap: break-word; margin: 0.25em 0px 0.75em; font-size: 14px; }

.main-page section.recommend-new article.post.recommend-item > .content .reason { display: block; font-size: 12px; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; color: rgb(155, 155, 155); }

.main-page section.recommend-new article.post.recommend-item > .content .reason > .amino-icon { vertical-align: text-top; }

.main-page .recommend-new .backdrop-img { position: absolute; inset: 0px; overflow: hidden; z-index: -1; }

.main-page .recommend-new .backdrop-img > .img-cover { height: 100%; width: 100%; }

.main-page .recommend-new .backdrop-img::after { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; content: " "; background: rgba(0, 0, 0, 0.6); }

.main-page .comment-like-share { display: none; padding: 0px 14px; margin-top: 14px; position: relative; z-index: 0; }

.main-page .collapse-counter { -webkit-box-flex: 1; flex: 1 0 auto; height: 40px; padding: 9px 0px; line-height: 22px; border-radius: 20px; border: 1px solid; display: flex; font-size: 14px; user-select: none; }

.main-page .collapse-counter.community-bg { color: rgb(255, 255, 255); }

.main-page .collapse-counter > .counter-btn { -webkit-box-flex: 1; flex: 1 0 50%; text-align: center; }

.main-page .collapse-counter > .vote-number { border-right: 1px solid; }

.main-page .collapse-share { -webkit-box-flex: 0; flex: 0 0 40px; height: 40px; line-height: 38px; border: 1px solid; border-radius: 50%; text-align: center; margin-left: 8px; }

.main-page .collapse-share.collapse .share { left: 100%; opacity: 0; }

.main-page .collapse-share.collapse .amino-icon-x { display: none; }

.main-page .collapse-share.collapse .amino-icon-share { display: inline; }

.main-page .collapse-share.collapse::after { opacity: 0; pointer-events: none; }

.main-page .collapse-share .amino-icon { line-height: 38px; font-size: 18px; }

.main-page .collapse-share .amino-icon-x { display: inline; }

.main-page .collapse-share .amino-icon-share { display: none; }

.main-page .collapse-share section.share { margin-top: 0px; margin-bottom: 0px; font-size: 14px; position: absolute; inset: 0px 54px 0px 0px; line-height: 1; text-align: right; transition: all 0.5s ease 0s; max-width: 500px; overflow: hidden; z-index: 2; }

.main-page .collapse-share section.share .share-icons { display: block; float: right; }

.main-page .collapse-share section.share li.item { border: none; float: left; display: block; height: 40px; padding: 0px; width: 40px; text-align: center; }

.main-page .collapse-share::after { position: absolute; inset: 0px 59px 0px 0px; height: 100%; content: " "; z-index: 1; width: auto; background: rgb(255, 255, 255); opacity: 0.9; transition: all 0.2s linear 0s; }

.main-page .collapse-share.community-bg { color: rgb(255, 255, 255); }

.main-page article.post > .counters, .main-page article.post > .item-header .counters, .main-page article.post > section.info .counters { display: none; }

.main-page .main-post .extra-items > .image-container { margin-bottom: 1em; }

.main-page article.post.main-post .topic-item a { color: rgb(255, 255, 255); }

.main-page.global { max-width: 766px; margin: auto; }

.main-page.global section.blog-like:last-child { margin-bottom: 30px; }

.main-page .story-cover { position: relative; }

.main-page .story-cover .image-container { overflow: hidden; width: 39.375vh; max-width: 196.875px; border-radius: 3.5px; }

.main-page .story-cover .amino-video-play { width: 56px; height: 56px; margin-left: -28px; margin-top: -28px; cursor: pointer; }

.main-page .story-cover .amino-video-play .play-icon-img { width: 22px; height: 52px; margin-left: 2.8px; }

.fixed_get_amino_app { position: fixed; z-index: 499; text-align: center; bottom: 70px; left: 0px; right: 0px; }

.fixed_get_amino_app .link { cursor: pointer; text-align: center; border-radius: 40px; color: rgb(255, 255, 255); font-weight: 700; font-size: 14px; padding: 12px 30px; display: inline-block; box-shadow: rgba(0, 0, 0, 0.35) 0px 3px 7px; }

.nav-search-container .nav-search-input { outline: none; border: none; margin: 0px; display: block; box-shadow: none; }

.nav-search-container .clear-button { position: absolute; padding: 7px; user-select: none; }

.nav-search-container .clear-button > .amino-icon { color: rgb(255, 255, 255); line-height: 17px; width: 17px; height: 17px; border-radius: 50%; display: block; font-size: 10px; text-align: center; background: rgba(26, 26, 26, 0.2); cursor: pointer; transition: opacity 0.2s ease-in-out 0s; }

.global-dropdown-container { font-family: "Helvetica Neue", Helvetica, "\\30D2ラギノ角ゴPro W3", "Hiragino Kaku Gothic Pro", "\\30E1イリオ", Meiryo, "ＭＳ  Ｐゴシック", arial, sans-serif; text-transform: none; }

.global-dropdown-container.amino-logo-animation > .mask-container { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); }

.nav-search-container { padding: 10px 0px 10px 10px; }

.nav-search-container .amino-icon-search { font-size: 30px; line-height: 30px; cursor: pointer; }

.nav-search-container .empty-history { color: rgba(255, 255, 255, 0.5); font-style: italic; margin: 20px 0px -2px 12px; font-size: 14px; }

.nav-search-container .nav-search-input { background: rgb(235, 238, 240); -webkit-box-flex: 1; flex: 1 0 auto; padding: 0px 30px 0px 15px; margin-top: 20px; height: 38px; line-height: 38px; border-radius: 8px; }

.nav-search-container.active .search-dropdown-container, .nav-search-container.active .search-input-container { visibility: visible; opacity: 1; pointer-events: all; }

.nav-search-container .aminos-list { margin-top: 10px; }

.nav-search-container .main-explore .section .children.aminos-list { padding: 0px 20px; }

.nav-search-container .main-explore .section .children.aminos-list .community { min-width: 280px; }

.nav-search-container .empty { padding: 20px; color: rgba(255, 255, 255, 0.5); font-style: italic; text-align: center; }

.search-input-container { position: fixed; visibility: hidden; opacity: 0; top: 0px; height: 78px; left: 0px; right: 0px; background: rgb(255, 255, 255); padding: 0px 12px; display: flex; border-bottom: 1px solid rgb(216, 216, 216); }

.search-input-container .cancel-search { color: rgb(29, 218, 143); line-height: 78px; width: 64px; text-align: right; }

.search-input-container .clear-button { position: absolute; top: 23px; right: 81px; }

.global-dropdown-container { position: fixed; inset: 78px 0px 0px; background: rgb(255, 255, 255); visibility: hidden; opacity: 0; color: rgb(51, 51, 51); }

.global-dropdown-container > .scroller { height: 100%; overflow-y: overlay; overscroll-behavior: contain; }

.global-dropdown-container .amino-suggestions { padding-bottom: 20px; margin-top: 3px; }

.global-dropdown-container .suggestion { color: rgb(102, 102, 102); line-height: 34px; }

.global-dropdown-container .suggestion > .block { padding-left: 20px; }

.global-dropdown-container .suggestion .amino-icon-clock { color: rgb(225, 228, 230); margin-right: 5px; }

.global-dropdown-container .suggestion .block:active { background: rgb(240, 240, 240); }

.global-dropdown-container .history-section .amino-suggestions { border-bottom: 1px solid rgb(216, 216, 216); }

.global-dropdown-container .global-dropdown .dropdown-head { font-weight: 700; display: block; line-height: 30px; margin: 20px 12px 0px; font-size: 18px; }

.dark-theme .global-dropdown-container { background: rgb(4, 2, 38); color: rgb(255, 255, 255); }

.dark-theme .global-dropdown-container .amino-card .name, .dark-theme .global-dropdown-container .dropdown-head, .dark-theme .global-dropdown-container .dropdown-head .dropdown-head-link, .dark-theme .search-dropdown-container .amino-suggestions .suggestion > .block { color: rgb(255, 255, 255); }

.dark-theme .search-dropdown-container .amino-suggestions .amino-icon-clock { color: rgba(218, 220, 251, 0.6); }

.dark-theme .global-dropdown-container .history-section .amino-suggestions, .dark-theme .search-input-container { border-bottom-color: rgba(218, 220, 251, 0.7); }

.dark-theme .search-input-container { background: rgb(4, 2, 38); }

.dark-theme .search-input-container .cancel-search { color: rgb(14, 224, 180); }

.dark-theme .search-input-container .nav-search-input { background: rgba(218, 220, 251, 0.2); color: rgb(255, 255, 255); }

.dark-theme .search-input-container .nav-search-input::-webkit-input-placeholder { color: rgba(218, 220, 251, 0.5); }

.dark-theme .search-input-container .nav-search-input::placeholder { color: rgba(218, 220, 251, 0.5); }

.main-explore .section { width: 100%; color: rgb(65, 69, 73); }

.main-explore .section > .header { text-align: center; font-size: large; }

.main-explore .section > .header .title { color: rgb(245, 246, 253); }

.main-explore .section > .info { display: flex; -webkit-box-pack: justify; justify-content: space-between; padding: 0px 1rem; line-height: 3rem; }

.main-explore .section > .info h3.label { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin: 0px; }

.main-explore .section > .info a.more { white-space: nowrap; color: rgb(252, 47, 127); font-weight: 700; font-size: small; }

.main-explore .section > .children { display: flex; padding: 0px 0.5rem; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; }

.main-explore .section > .footer { margin: 0.25em 0px 3em; text-align: center; }

.main-explore .section > .footer .more { font-size: 14px; font-weight: 600; color: rgb(4, 228, 185); }

.main-explore .section > .footer .more:hover { background: rgba(4, 228, 185, 0.2); }

.main-explore .section > .footer .more i { font-size: 10px; }

.main-explore .section .community { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-flex: 10; flex: 10 10 30%; min-width: 300px; overflow: hidden; margin: 0.25rem; border-radius: 0.5rem; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 4px; background: rgb(255, 255, 255); }

.main-explore .section .community.placeholder { visibility: hidden; }

.main-explore .section .community h4.name { font-size: large; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin: 0px; }

.main-explore .section .community .desc { overflow: hidden; }

.main-explore .section .community img.logo { -webkit-box-flex: 0; flex: 0 0 68px; width: 68px; height: 68px; border-radius: 15.368px; margin: 1em; }

.main-explore .section .community .member-count { color: rgb(155, 155, 155); font-size: small; line-height: 1.4; }

.main-explore .section .community p.tagline { font-size: small; margin: 0.5em 0px; line-height: 1.1; max-height: 2.2em; overflow: hidden; }

.main-explore .section .community p.tagline img.emoji { height: 1.1em; width: 1.1em; margin: 0px; vertical-align: top; }

.main-explore .section .community i.fa { align-self: flex-end; margin: 0px 0.5rem 0.5rem auto; padding-left: 0.5rem; font-size: 150%; color: rgb(14, 224, 180); }

.dark-theme .main-explore .section .community { background: rgba(255, 255, 255, 0.1); }

.dark-theme .main-explore .section .community .desc { color: rgb(255, 255, 255); }

.dark-theme .main-explore .section .community .member-count { color: rgb(218, 220, 251); }

.dark-theme .main-explore .section .community i.fa { color: rgba(218, 220, 251, 0.95); }

.dark-theme .main-explore .section > .info h3.label { color: rgb(255, 255, 255); }

.dark-theme .main-explore .section > .info a.more { color: rgb(14, 224, 180); }

.locale-picker { margin: 20px 0px 5px; position: relative; line-height: 26px; }

.locale-picker i.flag-icon { font-size: 24px; border-radius: 50%; }

.locale-picker > .content { display: flex; -webkit-box-pack: justify; justify-content: space-between; -webkit-box-align: center; align-items: center; width: 100%; }

.locale-picker h3.title { display: block; color: rgb(29, 218, 143); font-size: 1rem; font-weight: 400; margin: 0px 0px 0px 0.5rem; line-height: 45px; }

.locale-picker .locales { display: none; position: absolute; top: 50px; left: 50%; transform: translateX(-50%); border-radius: 0.5em; box-shadow: rgba(0, 0, 0, 0.5) 0px 0px 2px; padding: 0.5rem 0px; border: 1px solid rgb(47, 45, 80); background: rgb(30, 28, 60); color: rgb(255, 255, 255); }

.locale-picker .locales::after { width: 13px; height: 13px; transform: rotate(45deg); content: ""; display: block; position: absolute; top: 0px; left: 50%; margin-left: -7px; margin-top: -7px; background: rgb(30, 28, 60); border-width: 1px; border-style: solid; border-color: rgb(47, 45, 80) transparent transparent rgb(47, 45, 80); border-image: initial; }

.locale-picker .locales .locale { display: flex; -webkit-box-align: center; align-items: center; padding: 0.5em 1em; min-width: 150px; }

.locale-picker .locales .locale.active { background: rgb(47, 45, 80); }

.locale-picker .locales .locale.pointer:hover { background: rgba(47, 45, 80, 0.33); }

.locale-picker .locales .locale .desc { margin-left: 10px; }

.locale-picker .locales .label { line-height: 1.2; text-transform: capitalize; opacity: 1; }

.locale-picker .locales .label.english { font-weight: 400; font-size: small; opacity: 0.7; }

.locale-picker .mobile-locales { opacity: 0; position: absolute; inset: 0px; }

.locale-picker .current { position: relative; display: flex; -webkit-box-align: center; align-items: center; color: rgb(108, 225, 181); font-weight: 700; border-radius: 8px; height: 36px; padding: 0px 10px; font-size: 14px; margin-left: 10px; cursor: pointer; }

.locale-picker .current > .label { margin: 0px 5px 0px 10px; text-transform: capitalize; }

.locale-picker .current i.caret { font-size: 17px; }

.locale-picker .current i.caret::before { content: ""; }

.locale-picker .current.open i.caret::before { content: ""; }

.locale-picker .current.open .locales { display: block; }

.explore-header { margin-bottom: 50px; }

.is-mobile .explore-header { margin-bottom: 25px; }

.explore-header .explore-tabs { margin-top: -51px; text-align: center; }

.is-mobile .explore-header .explore-tabs { border-bottom: 1px solid rgba(218, 220, 251, 0.7); margin: 10px 0px 20px; text-align: left; }

.explore-header .explore-tabs .tab-item { user-select: none; font-size: 18px; color: rgba(218, 220, 251, 0.7); padding: 10px 0px; margin: 0px 22px; display: inline-block; position: relative; cursor: pointer; }

.is-mobile .explore-header .explore-tabs .tab-item { font-size: 16px; margin: 0px 10px; padding: 5px 0px; }

.explore-header .explore-tabs .tab-item.active { color: rgb(255, 255, 255); font-weight: 700; }

.explore-header .explore-tabs .tab-item.active::after { content: " "; display: block; position: absolute; bottom: -3px; right: 0px; left: 0px; height: 3px; border-radius: 10px; background: rgb(255, 255, 255); }

.amino-logo-animation .mask-container, .amino-logo-animation svg.amino-logo-svg { width: 120px; height: 34px; }

.amino-logo-animation .logo-mask { position: absolute; width: 100%; height: 100%; overflow: hidden; fill: rgb(233, 232, 239); }

.amino-logo-animation .logo-mask svg { position: absolute; }

.amino-logo-animation .logo-mask.fg { fill: rgb(29, 218, 143); animation: 4s linear 0s infinite normal none running logo-slide-fg, svg-slide-fg; }

.amino-logo-animation .logo-mask.fg > svg { animation: 4s linear 0s infinite normal none running svg-slide-fg; }

.amino-logo-animation .logo-mask.bg { animation: 4s linear 0s infinite normal none running logo-slide-bg, svg-slide-bg; }

.dark-theme .amino-logo-animation .logo-mask.bg { fill: rgba(255, 255, 255, 0.25); }

.amino-logo-animation .logo-mask.bg > svg { animation: 4s linear 0s infinite normal none running svg-slide-bg; }

@-webkit-keyframes logo-slide-fg { 
  0%, 5% { width: 0px; }
  35% { width: 100%; }
  65% { width: 100%; }
  65.1% { width: 100%; }
  95%, 100% { width: 0px; }
}

@keyframes logo-slide-fg { 
  0%, 5% { width: 0px; }
  35% { width: 100%; }
  65% { width: 100%; }
  65.1% { width: 100%; }
  95%, 100% { width: 0px; }
}

@-webkit-keyframes logo-slide-bg { 
  0%, 5% { width: 100%; }
  35% { width: 0px; }
  65% { width: 0px; }
  65.1% { width: 0px; }
  95%, 100% { width: 100%; }
}

@keyframes logo-slide-bg { 
  0%, 5% { width: 100%; }
  35% { width: 0px; }
  65% { width: 0px; }
  65.1% { width: 0px; }
  95%, 100% { width: 100%; }
}

@-webkit-keyframes svg-slide-fg { 
  0%, 5% { left: 0px; right: auto; }
  35% { left: 0px; right: auto; }
  65% { left: 0px; right: auto; }
  65.1% { right: 0px; left: auto; }
  95%, 100% { right: 0px; left: auto; }
}

@keyframes svg-slide-fg { 
  0%, 5% { left: 0px; right: auto; }
  35% { left: 0px; right: auto; }
  65% { left: 0px; right: auto; }
  65.1% { right: 0px; left: auto; }
  95%, 100% { right: 0px; left: auto; }
}

@-webkit-keyframes svg-slide-bg { 
  0%, 5% { right: 0px; left: auto; }
  35% { right: 0px; left: auto; }
  65% { right: 0px; left: auto; }
  65.1% { left: 0px; right: auto; }
  95%, 100% { left: 0px; right: auto; }
}

@keyframes svg-slide-bg { 
  0%, 5% { right: 0px; left: auto; }
  35% { right: 0px; left: auto; }
  65% { right: 0px; left: auto; }
  65.1% { left: 0px; right: auto; }
  95%, 100% { left: 0px; right: auto; }
}

.community-bg { background-color: rgb(34, 25, 94); }

.community-bg-dark { background-color: rgb(12, 9, 34); }

.community-color, .community-color:active, .community-color:hover, .community-color:link, .community-color:visited { color: rgb(34, 25, 94); }

.community-color-dark, .community-color-dark:active, .community-color-dark:hover, .community-color-dark:link, .community-color-dark:visited { color: rgb(12, 9, 34); }

@media (min-width: 1207px) {
  .main-page .nickname, .main-page section.recommend article.post.recommend-item .nickname, section.comment-list .nickname { max-width: 360px; }
  .home-section-nav .hide-on-mobile, .mob_no_backtop .back-top { display: block; }
  html[amp] .community-sidebar > .content { position: absolute; inset: 50px 0px 0px; }
  .community-sidebar > .hide-on-pc { display: none; }
  .community-sidebar .global-nav > ul.content > li.nav-item.nav-download { display: block; }
  .community-sidebar .global-nav { display: none; }
  .community-aside > .content { max-width: 768px; }
  .community-content { max-width: 768px; width: 768px; }
  .community-livelayer-padding { display: none; }
  .main-page section.pollopt .voting .poll-item .label:hover .bar { background: rgb(58, 115, 183); }
  .locale-picker > .content, .main-explore .section { max-width: 1140px; margin-left: auto; margin-right: auto; }
  .locale-picker h3.title { display: none; }
}

@media (min-width: 641px) {
  .main-page .object-status-alert, .main-page article.post.main-post { border-radius: 5px; overflow: hidden; box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 4px; }
  .container-fixed-bg > .content { background-color: rgba(0, 0, 0, 0.5); }
  .community-content .community-main, .community-content > .content { border-radius: 5px; background: rgb(255, 255, 255); overflow: hidden; }
  .community-content { margin: 0px auto; min-width: 576px; }
  section.live-comment > .content ul.comments { bottom: 46px; }
  section.live-comment > .content ul.comments .message { max-width: 526px; padding: 3px 12px; line-height: 24px; border-radius: 15px; }
  section.live-comment .counters { margin-left: 30px; margin-bottom: 10px; }
  section.live-comment .counters .comment-counter, section.live-comment .counters .vote-counter { width: 80px; padding: 0px 10px; }
  section.live-comment .counters .comment-counter i.amino-icon, section.live-comment .counters .vote-counter i.amino-icon { width: 28px; height: 36px; line-height: 36px; }
  section.live-comment .counters .comment-counter i.amino-icon { font-size: 18px; }
  section.live-comment .state-switch { right: 20px; padding-bottom: 19px; }
  section.live-comment .upper { margin-left: 30px; margin-right: 30px; }
  section.live-comment .avatar { font-size: 30px; width: 1.2em; height: 1.2em; }
  .main-page article.post.main-post > .post-full-content > section.content .height-toggle { display: none; }
  .main-page section.item-about td.label { min-width: 150px; }
  .main-page section.page-snippet > .frame .body { -webkit-box-flex: 10; flex: 10 1 auto; margin-right: 1em; }
  .main-page section.page-snippet > .frame .btn-read { margin-left: auto; }
  .main-page section.recommend { margin: -22px 22px -22px 0px; padding: 22px 0px 22px 22px; overflow: hidden; }
  .main-page .object-status-alert, .main-page article.post.main-post, .main-page section.next-post { margin: 22px; }
  .main-page section.recommend .recommend-app, .main-page section.recommend article.post.recommend-item { -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column; }
  .main-page section.blog-like .user-list .vote-icon { display: none; }
}

@media (max-width: 640px) {
  .main-page section.recommend-new article.post.recommend-item .overlay, .main-page section.recommend article.post.recommend-item .cover .overlay, .simple-list article.post .overlay { padding-left: 8%; }
  .main-page section.recommend-new article.post.recommend-item .overlay .counter, .main-page section.recommend article.post.recommend-item .cover .overlay .counter, .simple-list article.post .overlay .counter { font-size: 0.8em; }
  .container-fixed-bg, .fixed-bg { background-size: 0px 0px; }
  .container-fixed-bg::before, .fixed-bg::before { background-image: inherit; }
  .container-fixed-bg::after, .container-fixed-bg::before, .fixed-bg::before { display: block; content: " "; position: fixed; inset: 0px; background-size: cover; }
  .container-fixed-bg::after { background-color: rgba(0, 0, 0, 0.5); }
  .global-bg { display: none; }
  .phone_night .community-aside > .content > .title { color: rgb(233, 232, 239); }
  .live-member-list { background: none; padding: 12px; height: auto; left: 0px; margin-left: 0px; }
  section.comment-list .empty-padding { height: 40px; }
  section.live-comment .counters .num { margin-left: -8px; }
  [data-vce="live-comment"].state-endcap section.live-comment .live-member-list { bottom: 27px; }
  section.live-comment .upper { height: 94px; }
  section.live-comment .avatar { font-size: 25px; }
  .main-page section.main-page-section > .title { padding-left: 18px; }
  .main-page article.post.main-post > .post-full-content > section.info, .main-page article.post.main-post > section.info { margin: 0.5em 0px; }
  .main-page article.post.main-post > .post-full-content > section.content .post-content-toggle.overflowing { margin-bottom: 30px; }
  .main-page article.post.main-post > .post-full-content > section.content .post-content-toggle.open { padding-bottom: 0px; margin-bottom: 0px; }
  .main-page article.post.main-post > .post-full-content > section.content .post-content-toggle.overflowing { max-height: 150vh; padding-bottom: 2px; }
  .main-page article.post.main-post > .post-full-content > section.content .post-content-toggle.overflowing .height-toggle { bottom: -2px; }
  .main-page article.post.main-post > .post-full-content > section.counters { display: flex; }
  .main-page header.title { padding: 10px 0px 5px; }
  .main-page header.title > .title { padding-left: 18px; }
  .main-page header.item-header .item-card { margin-left: 14px; }
  .main-page header.item-header > div.title h3.text { font-size: 135%; }
  .main-page header.item-header > div.title section.counters { display: none; }
  .main-page section.item-about td.label { min-width: 30vw; }
  .main-page section.page-snippet > .frame > .content { -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; }
  .main-page section.page-snippet > .frame .body { -webkit-box-flex: 0; flex: 0 0 100%; margin-bottom: 0.75em; }
  .main-page section.page-snippet .cover { max-height: 50vh; }
  .main-page section.blog-like > .content, .main-page section.item-gallery > .content, .main-page section.item-linked > .content, .main-page section.more-posts > .content, .main-page section.pollopt > .content { margin: 5px 14px; }
  .main-page section.comment-list > .title { padding-left: 18px; }
  .main-page section.item-linked > .content { margin-left: 11px; }
  .main-page section.more-posts .simple-list { padding: 0px 14px; }
  .main-page section.recommend { -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; justify-content: stretch; display: none; }
  .main-page section.recommend article.post.recommend-item { height: 32vw; min-height: 120px; }
  .main-page section.recommend article.post.recommend-item .cover, .main-page section.recommend article.post.recommend-item .cover.item { height: 100%; }
  .main-page section.recommend article.post.recommend-item .cover .cover-img { width: 37.5vw; height: 100%; }
  .main-page section.recommend article.post.recommend-item > .content > .pretty-date { display: block; }
  .main-page section.recommend article.post.recommend-item > .content > section.info { display: none; }
  .main-page section.recommend .recommend-app { padding: 0.75em 2em 1.25em; margin-bottom: 1em; }
  .main-page section.recommend .recommend-app .promotion { font-size: medium; margin-top: 0.5em; }
  .main-page section.next-post i.fa.white { display: none; }
  .main-page .post-divider, .main-page section.next-post i.fa.community-color { display: block; }
  .main-page .comment-counter, .main-page .vote-counter { margin-left: 0.5rem; }
  .main-page article.post.main-post > .post-full-content > section.content p, .main-page article.post.main-post > .post-full-content > section.info, .main-page article.post.main-post > section.info, .main-page section.comment-list > .content, .main-page section.item-about, .main-page section.page-snippet, .main-page section.repost-desc { padding-left: 14px; padding-right: 14px; }
  .main-page section.recommend .recommend-app, .main-page section.recommend article.post.recommend-item { -webkit-box-flex: 1; flex: 1 1 100%; margin: 5vw 4vw 0px; }
  .main-page section.share.hide-phone { display: none; }
  .main-page section.recommend-new { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; padding: 0px 10px; margin-top: 20px; }
  .main-page section.recommend-new article.post.recommend-item > .content > section.info { display: none; }
  .main-page .comment-like-share { display: flex; }
  .main-page .comment-like-share ~ .blog-like, .main-page .comment-like-share ~ .comment-list > .content { transition: all 0.5s ease-in-out 0s; max-height: 2000px; }
  .main-page .comment-like-share + .blog-like + .comment-list, .main-page .comment-like-share ~ .blog-like { margin-top: 13px; }
  .main-page .comment-like-share ~ .comment-list > .content article.comment { border-top-width: 1px; }
  .main-page .comment-like-share ~ .blog-like > h3.title, .main-page .comment-like-share ~ .comment-list > h3.title { display: none; }
  .main-page .comment-like-share.collapse ~ .comment-list { padding-bottom: 0px; }
  .main-page .comment-like-share.collapse ~ .blog-like, .main-page .comment-like-share.collapse ~ .comment-list > .content { max-height: 0px; padding-top: 0px; padding-bottom: 0px; opacity: 0; overflow: hidden; margin-top: 0px; }
}

@media (max-width: 1490px) {
  .ad-block-banner-container { display: none; }
}

@media (min-width: 641px) and (max-width: 1206px) {
  .full-content .community-content { margin: 0px; max-width: none; }
}

@media (max-width: 1206px) {
  .chromeless .community-content { padding-bottom: 0px; }
  .community-livelayer-padding { padding-bottom: 54px; -webkit-box-ordinal-group: 2; order: 1; }
  .main-explore .section > .header { font-size: small; }
  .locale-picker > .content { padding: 0px 0.5rem; }
  .locale-picker .locales { left: auto; right: 0px; transform: none; }
  .locale-picker .locales::after { left: auto; right: 50px; }
  .locale-picker .current { margin-left: auto; -webkit-box-ordinal-group: 21; order: 20; }
}

@media only screen and (-webkit-min-device-pixel-ratio: 2), not all, only screen and (min-resolution: 2dppx), only screen and (min-resolution: 192dpi) {
  .level-badge-1 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 25% 0px / 500% 400%; }
  .level-badge-2 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 75% 33.3333% / 500% 400%; }
  .level-badge-3 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 0px 33.3333% / 500% 400%; }
  .level-badge-4 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 25% 33.3333% / 500% 400%; }
  .level-badge-5 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 50% 0px / 500% 400%; }
  .level-badge-6 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 50% 33.3333% / 500% 400%; }
  .level-badge-7 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 0px 66.6667% / 500% 400%; }
  .level-badge-8 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 25% 66.6667% / 500% 400%; }
  .level-badge-9 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 50% 66.6667% / 500% 400%; }
  .level-badge-10 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 75% 0px / 500% 400%; }
  .level-badge-11 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 0px 0px / 500% 400%; }
  .level-badge-12 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 75% 66.6667% / 500% 400%; }
  .level-badge-13 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 0px 100% / 500% 400%; }
  .level-badge-14 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 25% 100% / 500% 400%; }
  .level-badge-15 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 50% 100% / 500% 400%; }
  .level-badge-16 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 75% 100% / 500% 400%; }
  .level-badge-17 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 100% 0px / 500% 400%; }
  .level-badge-18 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 100% 33.3333% / 500% 400%; }
  .level-badge-19 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 100% 66.6667% / 500% 400%; }
  .level-badge-20 { background: url("https://aminoapps.com/static/dist/d81859983fddca94bf05e66faf8f417d.png") 100% 100% / 500% 400%; }
}


.recommendation-sidebar section.author-aside .avatar { border-radius: 50%; border: 1px solid rgba(0, 0, 0, 0.1); box-shadow: rgba(255, 255, 255, 0.5) 0px 0px 0.5px; margin-right: 0.5rem; width: 1em; height: 1em; display: block; }

.recommendation-sidebar section.author-aside .nickname { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; display: inline-flex; max-width: 240px; line-height: 24px; color: rgb(0, 145, 255); }

.recommendation-sidebar section.author-aside .nickname > .level-badge { -webkit-box-flex: 0; flex: 0 0 auto; margin-left: 0.25em; }

.recommendation-sidebar section.author-aside .nickname > .influencer-badge { -webkit-box-flex: 0; flex: 0 0 auto; margin-left: 0.25em; width: 24px; }

.recommendation-sidebar section.author-aside .nickname > .label-author { -webkit-box-flex: 0; flex: 0 0 auto; display: inline-block; margin-left: 0.25em; border: 1px solid rgb(255, 255, 255); border-radius: 5px; padding: 0px 7px; font-size: 12px; color: rgb(255, 255, 255); background-color: rgb(0, 145, 255); }

.recommendation-sidebar section.author-aside .nickname > .content { -webkit-box-flex: 0; flex: 0 1 auto; overflow: hidden; text-overflow: ellipsis; }

.post-list section.info .external-source-name { line-height: 20px; }

.post-list section.info .external-source-name i.fa { margin-right: 2px; font-size: larger; }

.post-list section.info .external-source-name i.fa-rss { color: rgb(255, 136, 0); }

.post-list section.info .external-source-name i.fa-reddit-alien { color: rgb(244, 78, 63); }

.post-list section.info .external-source-name i.fa-youtube-play { color: rgb(240, 0, 27); }

.recommendation-sidebar .ad-block > h3.label, .recommendation-sidebar section.author-aside > h3.label, .recommendation-sidebar section.gallery > h3.label, .recommendation-sidebar section.leader-pick > h3.label, .recommendation-sidebar section.popular > h3.label { position: relative; margin: 0px; line-height: 1.4; padding-left: 18px; }

.recommendation-sidebar .ad-block > h3.label::before, .recommendation-sidebar section.author-aside > h3.label::before, .recommendation-sidebar section.gallery > h3.label::before, .recommendation-sidebar section.leader-pick > h3.label::before, .recommendation-sidebar section.popular > h3.label::before { content: ""; position: absolute; top: 0.1em; left: 0px; display: block; height: 1.2em; width: 8px; border-left: 8px solid; color: inherit; }

.main-about .info .heat-gauge, section.main-download .choice-download .app-guide .heat-gauge { display: flex; position: relative; box-sizing: content-box; font-size: 1rem; width: 8em; border: 1px solid rgba(255, 255, 255, 0.6); border-radius: 4px; overflow: hidden; }

.main-about .info .heat-gauge > .gauge, section.main-download .choice-download .app-guide .heat-gauge > .gauge { position: relative; z-index: 100; display: inline-block; box-sizing: border-box; border-left: 1px solid rgba(255, 255, 255, 0.6); width: 1em; height: 1em; }

.main-about .info .heat-gauge > .gauge:first-child, section.main-download .choice-download .app-guide .heat-gauge > .gauge:first-child { border-left: none; }

.main-about .info .heat-gauge > .heat, section.main-download .choice-download .app-guide .heat-gauge > .heat { position: absolute; inset: 0px; z-index: 10; height: 100%; width: 0px; overflow: hidden; }

.main-about .info .heat-gauge > .heat::before, section.main-download .choice-download .app-guide .heat-gauge > .heat::before { content: " "; position: absolute; inset: 0px; z-index: 10; height: 100%; width: 8em; background: linear-gradient(90deg, rgb(83, 189, 171), rgb(255, 111, 0)); }

.main-about .info .heat-gauge > .heat.heat-1, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-1 { width: 1em; }

.main-about .info .heat-gauge > .heat.heat-2, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-2 { width: 2em; }

.main-about .info .heat-gauge > .heat.heat-3, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-3 { width: 3em; }

.main-about .info .heat-gauge > .heat.heat-4, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-4 { width: 4em; }

.main-about .info .heat-gauge > .heat.heat-5, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-5 { width: 5em; }

.main-about .info .heat-gauge > .heat.heat-6, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-6 { width: 6em; }

.main-about .info .heat-gauge > .heat.heat-7, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-7 { width: 7em; }

.main-about .info .heat-gauge > .heat.heat-8, section.main-download .choice-download .app-guide .heat-gauge > .heat.heat-8 { width: 8em; }

.global-header > .site-bg .nav-link > .user-icon { margin-right: 35px; }

section.site-content { min-height: 50vh; width: 100%; padding-bottom: 3em; }

section.site-content .breadcrumb { display: flex; -webkit-box-align: center; align-items: center; height: 45px; color: rgb(14, 224, 180); background: none; }

section.site-content .breadcrumb > .content { width: 100%; padding-left: 15px; }

body.site-body { display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column; background: rgb(247, 249, 250); }

body.site-body.dark-theme { background-color: rgb(0, 0, 58); }

body.site-body .global-body { -webkit-box-flex: 1; flex: 1 0 auto; display: block; width: 100%; }

.site-header { color: rgb(218, 220, 251); display: flex; }

.site-header::after { display: block; content: " "; height: 50px; }

.site-header > .content { position: fixed; height: 50px; }

.site-header .svg-icon { fill: rgb(218, 220, 251); }

.site-header.scroll-top > .content { background-color: transparent; }

.site-header.scroll-top .amino-logo, .site-header.scroll-top .btn-download, .site-header.scroll-top .search-input-container { opacity: 0; pointer-events: none; }

.site-header > .content { z-index: 500; left: 0px; right: 0px; top: 0px; transition: all 0.2s ease 0s; display: flex; -webkit-box-align: center; align-items: center; background-color: rgb(4, 2, 38); padding: 0px 0.5rem; }

.site-header > .content a.menu-icon { font-size: 24px; display: block; margin-top: -2px; }

.site-header > .content .amino-logo { margin: 0px 0.5rem; padding: 10px 0px; transition: all 0.2s ease 0s; }

.site-header > .content img.logo { margin: 0px; min-width: 63px; height: 18px; object-fit: contain; }

.site-header > .content .btn-download { font-family: Montserrat, sans-serif; margin-left: auto; transition: all 0.2s ease 0s; font-weight: 600; }

aside.site-sidebar { display: none; font-family: Montserrat, sans-serif; }

aside.site-sidebar > .content { background: rgb(34, 25, 94); color: rgb(218, 220, 251); }

aside.site-sidebar > .content.fixed { position: fixed; bottom: 0px; }

aside.site-sidebar .upper { display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; -webkit-box-align: center; align-items: center; padding: 64px 0px 30px; }

aside.site-sidebar .upper img.logo { width: 109px; height: 109px; border-radius: 18px; }

aside.site-sidebar .upper img.amino-logo { height: 21px; margin: 29px 0px 14px; }

aside.site-sidebar .upper .btn-download { font-weight: 600; min-width: 130px; padding: 12px 0px; border-radius: 8px; }

aside.site-sidebar .site-menu { text-align: center; }

aside.site-sidebar .site-menu a.sidebar-link { line-height: 50px; }

aside.site-sidebar .site-menu a.sidebar-link.active { background: rgba(0, 0, 0, 0.2); }

aside.site-sidebar .sidebar-locale { margin-top: 0px; }

aside.site-sidebar .sidebar-locale .current { margin: auto; }

aside.site-sidebar .sidebar-locale .current > .label { font-weight: 400; }

.site-footer { color: rgb(218, 220, 251); min-height: 115px; background: rgb(4, 2, 38); }

.site-footer .container { line-height: 36px; margin-right: auto; margin-left: auto; padding-left: 15px; padding-right: 15px; padding-top: 38px; text-align: center; }

.site-footer .container > a { display: inline-block; }

.site-footer .container::before { content: " "; display: table; }

.site-footer .container::after { clear: both; }

.site-footer a { font-family: Montserrat, sans-serif; padding: 0px; margin-right: 10px; font-size: 14px; font-weight: 600; }

.site-footer a:hover { text-decoration: none; }

.site-footer .social-icons { text-align: center; clear: left; margin-top: 15px; margin-bottom: 28px; }

.site-footer .social-icons .icon { display: inline-block; height: 35px; width: 35px; margin: 0px 8px; background: url("https://aminoapps.com/static/img/social-icons/social-dark.svg") 0% 0% / auto 100%; }

.site-footer .social-icons .icon.facebook { background-position: 0px 0px; }

.site-footer .social-icons .icon.twitter { background-position: -50px 0px; }

.site-footer .social-icons .icon.instagram { background-position: -100px 0px; }

.site-footer .social-icons .icon.tumblr { background-position: -150px 0px; }

.site-footer .logo > img { width: 65px; }

.site-footer .amino-mobile { display: none; }

.download-button { border-radius: 4px; letter-spacing: -0.11px; display: inline-block; padding: 0px 5px; text-align: center; font-family: Montserrat, sans-serif; }

.download-button, .download-button:active, .download-button:focus, .download-button:hover { color: rgb(34, 25, 94); text-decoration: none; }

.download-button .button-bottom { background: rgb(12, 173, 178); box-shadow: rgba(43, 102, 79, 0.55) 0px 4px 8px; border-radius: 5px; width: 162px; height: 61px; display: inline-block; }

.download-button .home-button { background: rgb(4, 228, 185); border-radius: 5px; border: none; width: 162px; height: 55px; padding: 8px 12px; }

.download-button .home-button:hover { background: rgb(4, 218, 177); }

.download-button .home-button .background { width: 100%; height: 100%; background: 50% center / 100% no-repeat; }

.download-button .home-button .background.app-store { background-image: url("https://aminoapps.com/static/img/mobile/available-on-app-store@2x.png?v=3"); }

.download-button .home-button .background.google-play { background-image: url("https://aminoapps.com/static/img/mobile/google_play_text_transparent@2x.png?v=3"); }

.download-button.green .button-bottom { background: rgb(12, 173, 178); }

.download-button.green .home-button { background: rgb(4, 228, 185); }

.download-button.green .home-button .background.google-play { background: url("https://aminoapps.com/static/img/mobile/google_play_text_transparent@2x.png?v=3") 50% center / 100% no-repeat; }

.download-button.green .home-button:hover { background: rgb(4, 203, 165); }

.footer-locale.locale-picker { display: inline-block; margin: 0px; }

.footer-locale.locale-picker .locales { top: auto; bottom: 50px; }

.footer-locale.locale-picker .locales::after { bottom: -7px; top: auto; transform: rotate(-135deg); }

.footer-locale.locale-picker .content .current { margin: 0px; padding: 0px; }

.footer-locale.locale-picker .content .current .label { margin: 0px 5px 0px 0px; }

.overlay-bright .site-body .modal .overlay { background: rgba(4, 2, 38, 0.7); }

.chromeless .site-header { display: none; }

.dark-mode-body { background-color: rgb(4, 2, 38); }

.error-pages { margin: auto; max-width: 960px; color: rgb(255, 255, 255); padding-top: 100px; display: flex; }

.error-pages .error-info { -webkit-box-flex: 1; flex: 1 0 60%; padding-right: 30px; }

.error-pages .error-brand { -webkit-box-flex: 0; flex: 0 1 447px; }

.error-pages .error-brand img { padding-top: 130px; width: 100%; }

.error-pages h1.error-code { font-size: 120px; color: rgb(0, 240, 255); margin-top: 0px; margin-bottom: 20px; }

.error-pages a { color: rgb(12, 242, 190); }

.error-pages p { color: rgb(218, 220, 251); }

.error-pages .go-home { margin-left: 5px; font-weight: 700; vertical-align: middle; }

.error-pages .error-brand-logo { padding-top: 20px; width: 80%; float: right; }

.error-pages .go-home-section { margin-top: 78px; }

.site-content.error-container { min-height: calc(100vh - 208px); }

.main-catalog { padding-top: 0.5em; }

.main-catalog section.children { background: rgb(255, 255, 255); }

.main-catalog section.children .child { border-top: 1px solid rgb(233, 232, 239); }

.main-catalog section.children .child:first-child { border-top-color: transparent; }

.main-catalog section.children .child > .content { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row nowrap; justify-content: stretch; -webkit-box-align: center; align-items: center; }

.main-catalog section.children .child > .content .desc { -webkit-box-flex: 10; flex: 10 1 0%; overflow: hidden; }

.main-catalog section.children .child > .content .catalog-preview { width: 140px; margin-left: 2em; margin-right: 0.5em; }

.main-catalog section.children .child > .content .catalog-preview .preview-cover { opacity: 1; background-color: rgb(255, 255, 255); }

.main-catalog section.children .title { margin: 0.5em 0px; font-size: 24px; }

.main-catalog section.children .sub-categories { overflow: hidden; text-overflow: ellipsis; line-height: 1.1em; color: rgb(155, 155, 155); }

.main-catalog section.children .catalog-preview { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row nowrap; }

.main-catalog section.children .catalog-preview .preview-item { margin-left: -30%; width: 80px; overflow: hidden; border-radius: 0.5em; border: 1px solid rgb(233, 232, 239); background-color: rgb(233, 232, 239); }

.main-catalog section.children .catalog-preview .preview-item.system { border-color: rgb(255, 192, 0); background-color: rgb(255, 192, 0); }

.main-catalog section.children .catalog-preview .preview-item .preview-cover { width: 80px; height: 80px; }

.main-catalog section.children .catalog-preview .preview-item .label { margin: 0.2em 0px; overflow: hidden; text-overflow: ellipsis; height: 1.25em; line-height: 1.25em; text-align: center; font-size: 80%; }

.main-catalog section.children .catalog-preview .preview-item:first-child { margin-left: 0px; z-index: 99; transform: scale(1); }

.main-catalog section.children .catalog-preview .preview-item:nth-child(2) { z-index: 98; transform: scale(0.85); }

.main-catalog section.children .catalog-preview .preview-item:nth-child(3) { z-index: 97; transform: scale(0.7225); }

.main-catalog section.items > .content { background: rgb(255, 255, 255); display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; -webkit-box-pack: center; justify-content: center; padding: 8px; }

.main-catalog section.items > .content > .item { margin: 0.5rem; -webkit-box-flex: 1; flex: 1 0 22%; width: 100%; overflow: hidden; border-radius: 0.5em; border: 2px solid rgb(233, 232, 239); background-color: rgb(233, 232, 239); position: relative; }

.main-catalog section.items > .content > .item.system { border-color: rgb(255, 192, 0); background-color: rgb(255, 192, 0); }

.main-catalog section.items > .content > .item .preview-cover { width: 100%; height: 100%; }

.main-catalog section.items > .content > .item .label { margin: 0.2em 0px; overflow: hidden; text-overflow: ellipsis; height: 1.25em; line-height: 1.25em; text-align: center; font-size: 80%; }

.main-catalog section.items > .content > .item .fans-only-icon .hover-hint { width: 120px; font-size: 12px; }

.main-catalog section.items > .content > .item .label { line-height: 22px; height: 22px; }

.main-catalog section.items > .content > .item .preview-cover { height: auto; }

.main-catalog section.items > .content > .item.need-hidden-post .img-cover { filter: blur(6px); }

.main-catalog.main-page.user-wiki-list { background: rgb(255, 255, 255); border-radius: 5px; }

.main-catalog.main-page.user-wiki-list > header.title { padding: 15px 0px 0px; }

.main-catalog.main-page.user-wiki-list > header.title > h3.title { font-size: 18px; }

.pinned-posts > .list-item, .post-list > .list-item { padding: 11.25px 11.25px 0px; }

.community-content > .search-keyword { margin: 0px; font-size: 24px; font-weight: 500; color: rgb(138, 138, 138); text-align: center; line-height: 28px; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; padding: 20px 22px 0px; }

.community-content > .in-community { font-size: 14px; line-height: 17px; font-weight: 700; color: rgb(189, 189, 189); text-align: center; margin: 6px 0px 22px; }

.post-list > .list-item { min-height: 100%; overflow: hidden; border-bottom: 1px solid rgb(233, 232, 239); background-color: rgb(255, 255, 255); position: relative; }

.post-list > .list-item:last-of-type { border-bottom: none; }

.post-list > .paginator { -webkit-box-flex: 1; flex: 1 0 100%; }

.post-list section.info { display: flex; padding: 0.25em; }

.post-list section.info .external-source-name { margin-bottom: 2px; }

.post-list section.info .author { height: 40px; width: 40px; border-radius: 50%; overflow: hidden; margin-right: 0.5em; }

.post-list section.info .nickname { max-width: 64vw; margin: 2px 0px; color: rgb(0, 145, 255); }

.post-list section.info .curated-wiki-avatar { background: rgb(234, 200, 99); color: rgb(255, 255, 255); font-size: 24px; text-align: center; line-height: 35px; }

.post-list section.info .pretty-date { color: rgb(155, 155, 155); font-size: 85%; }

.post-list .gallery { display: flex; -webkit-box-align: stretch; align-items: stretch; place-content: stretch space-between; -webkit-box-pack: justify; padding: 0.25em; }

.post-list .gallery.video-gallery { position: relative; }

.post-list .gallery.video-gallery > .block { width: 100%; }

.post-list .gallery.story-gallery > .gallery-item { width: 100%; margin: 0px; cursor: pointer; }

.post-list .gallery > .gallery-item { margin-right: 5.625px; width: 56.5%; height: 275.625px; }

.post-list .gallery > .gallery-item:only-child { width: 100%; margin-right: 0px; }

.post-list .gallery > .side { -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; overflow: hidden; display: block; -webkit-box-flex: 0; flex: 0 1 36vw; width: 36vw; height: 100%; }

.post-list .gallery > .side > .gallery-item { height: 135px; width: 100%; }

.post-list .gallery > .side > .gallery-item:first-child { margin-bottom: 5.625px; }

.post-list section.desc { padding: 0.5em 0.25em; line-height: 1.4; }

.post-list section.desc .title { margin: 0px; text-overflow: ellipsis; line-height: 1.4em; max-height: 2.8em; overflow: hidden; overflow-wrap: break-word; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }

.post-list section.desc > .content { color: rgb(65, 69, 73); }

.post-list footer.actions { display: flex; padding: 0.25em 0.1em; }

.post-list footer.actions .action { border-radius: 10px; padding: 0.5em; margin-right: 8px; color: rgb(155, 155, 155); }

.post-list footer.actions .action i.amino-icon, .post-list footer.actions .action i.fa { font-size: 20px; }

.post-list footer.actions .action[data-vote-value] .num, .post-list footer.actions .action i.amino-icon-heart { color: rgb(229, 26, 74); font-weight: 700; }

.post-list footer.actions .action i.amino-icon-heart-o { display: none; }

.post-list footer.actions .action .num { padding-left: 3px; }

.post-list footer.actions .action[data-vce="btn-popup"] i.amino-icon-heart, .post-list footer.actions .action[data-vote-value="0"] i.amino-icon-heart { display: none; }

.post-list footer.actions .action[data-vce="btn-popup"] .amino-icon-heart-o, .post-list footer.actions .action[data-vote-value="0"] .amino-icon-heart-o { display: inline-block; }

.post-list footer.actions .action[data-vce="btn-popup"] .num, .post-list footer.actions .action[data-vote-value="0"] .num { color: rgb(155, 155, 155); font-weight: 400; }

.post-list footer.actions .share { margin-left: auto; }

.post-list .page-content { min-height: 100%; }

.post-list .post-quiz { position: relative; }

.post-list .post-quiz section.desc { white-space: nowrap; }

.post-list .post-quiz section.desc i.amino-icon { color: rgb(223, 28, 152); }

.post-list .post-quiz .quiz-start { position: absolute; left: 1em; bottom: 4em; width: auto; border: 2px solid rgb(255, 255, 255); border-radius: 1em; padding: 0px 1em; line-height: 2em; background-color: rgba(0, 0, 0, 0.5); color: rgb(255, 255, 255); white-space: nowrap; }

.post-list .post-quiz .gallery { width: 100%; }

.post-list .post-quiz .gallery .title { width: 100%; padding: 3em 0px 5em; text-align: center; color: rgb(255, 255, 255); font-weight: 700; font-size: 120%; }

.post-list .post-quiz .gallery .title.has-image { display: none; }

.post-list .post-quiz .gallery .gallery-item { width: 100%; }

.post-list .post-poll section.desc i.amino-icon { color: rgb(248, 87, 87); vertical-align: 2px; }

.post-list .post-poll section.desc i.amino-icon.ended { color: rgb(155, 155, 155); }

.post-list .post-poll .pollopt .voting .poll-item { cursor: pointer; }

.post-list .post-poll .pollopt .poll-item { display: flex; -webkit-box-align: center; align-items: center; margin-top: 12px; }

.post-list .post-poll .pollopt .poll-item:first-child { margin-top: 0px; }

.post-list .post-poll .pollopt .poll-item .poll-media-placeholder { background: rgb(74, 144, 226); font-size: 18px; color: rgb(255, 255, 255); text-align: center; display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; }

.post-list .post-poll .pollopt .item-cover { width: 40px; height: 40px; margin-left: 0.25em; margin-right: 12px; border-radius: 3px; flex-shrink: 0; }

.post-list .post-poll .pollopt .poll-item.voted-item > .label .bar { background-color: rgb(29, 218, 143); }

.post-list .post-poll .pollopt .poll-item > .label { position: relative; margin: 0px 0.25em 0px 0px; -webkit-box-flex: 0; flex: 0 1 100%; overflow: hidden; text-align: center; border-radius: 3px; background-color: rgb(74, 74, 74); color: rgb(255, 255, 255); line-height: 40px; padding: 0px 0.5em; }

.post-list .post-poll .pollopt .poll-item > .label .bar { position: absolute; z-index: 40; left: 0px; top: 0px; bottom: 0px; background-color: rgb(74, 144, 226); background-image: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.2)); }

.post-list .post-poll .pollopt .poll-item > .label .title { position: relative; z-index: 50; display: flex; -webkit-box-pack: justify; justify-content: space-between; }

.post-list .post-poll .pollopt .poll-item > .label .title > .content { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; height: 40px; -webkit-box-flex: 10; flex-grow: 10; flex-basis: 0px; }

.post-list .post-poll .pollopt .poll-item > .label .partition { text-align: right; }

.post-list .post-poll .pollopt .voting .bar { width: 100%; }

.post-list .post-poll .pollopt .voted .label { text-align: left; }

.post-list .post-poll .pollopt .voting-end .bar { width: 0px; }

.post-list .post-poll .pollopt .voting-progress .bar { transition: width 0.5s ease-out 0s; }

.post-list .post-poll .pollopt .poll-item { cursor: pointer; }

.post-list .post-poll .pollopt .fa-youtube { display: none; }

.post-list .post-poll .youtube-preview { position: relative; }

.post-list .post-poll .youtube-preview .amino-video-play { width: 16px; height: 16px; margin-left: -8px; margin-top: -8px; border-color: transparent; background: transparent; }

.post-list .post-poll .youtube-preview .amino-video-play .play-icon-img { width: 12px; height: 12px; margin-left: 0.8px; }

.post-list .post-wiki .wiki-background { display: none; }

.post-list .post-wiki .wiki-content { display: flex; -webkit-box-align: start; align-items: flex-start; }

.post-list .post-wiki .wiki-content .wiki-pics { margin: auto; }

.post-list .post-wiki .wiki-content .wiki-item { overflow: hidden; border-radius: 0.5em; border: 1px solid rgb(155, 155, 155); }

.post-list .post-wiki .wiki-content .wiki-curated { background: rgb(255, 192, 0); border-color: rgb(255, 192, 0); }

.post-list .post-wiki .wiki-content .wiki-cover { width: 200px; height: 200px; }

.post-list .post-wiki .wiki-content .label { max-width: 200px; overflow: hidden; line-height: 2; text-align: center; font-weight: 700; }

.post-list .post-wiki .wiki-content .summary { -webkit-box-flex: 10; flex: 10 1 0%; margin: 1em; overflow: hidden; max-height: 15em; width: 100%; }

.pinned-posts { padding: 10px 0px; font-size: small; }

.pinned-posts > .list-item { margin: 0.25em 0px; color: rgb(255, 255, 255); overflow: hidden; }

.pinned-posts > .list-item > .content { display: flex; text-overflow: ellipsis; height: 2em; border-radius: 1em; line-height: 2em; position: relative; }

.pinned-posts > .list-item .amino-icon-pin { margin-right: 0.5em; }

.pinned-posts > .list-item .amino-icon-rightward { margin-left: auto; margin-right: 0.3em; }

.pinned-posts i.amino-icon { font-size: 100%; vertical-align: top; width: 1.6em; height: 1.6em; margin: 0.4em 0px 0.15em 0.4em; text-align: center; }

.pinned-posts i.amino-icon::before { display: inline-block; transform: translateY(0.1rem); }

section.post-list.new-post-list .gallery .amino-video-play { width: 56px; height: 56px; margin-left: -28px; margin-top: -28px; cursor: pointer; }

section.post-list.new-post-list .gallery .amino-video-play .play-icon-img { width: 22px; height: 52px; margin-left: 2.8px; }

section.post-list.new-post-list > .list-item-placeholder { display: none; }

section.post-list.new-post-list > .more-featured-title { -webkit-box-flex: 1; flex: 1 0 100%; height: auto; box-shadow: none; background: none; font-size: 18px; margin: 0px 11px 9px -11px; border-bottom: none; }

section.post-list.new-post-list > .more-featured-title.list-item { max-width: none; }

section.post-list.new-post-list > .more-featured-title::before { content: ""; display: inline-block; width: 8px; height: 1.2em; border-left: 8px solid; vertical-align: top; margin-right: 10px; }

section.post-list.new-post-list > .more-featured-title:hover { box-shadow: none; }

section.post-list.new-post-list .list-item ~ .more-featured-title { margin-top: 29px; }

section.post-list.new-post-list .post-blog > a.block { background: rgb(255, 255, 255); }

section.post-list.new-post-list .need-hidden-post > .block .img-cover { filter: blur(6px); }

section.post-list.new-post-list .need-hidden-post > .block .poll-item .img-cover { filter: blur(2px); }

section.post-list.new-post-list .post-quiz .gallery .title.has-image { display: none; }

.empty-content .empty-prompt-indicator { text-decoration: underline; cursor: pointer; }

.main-shared-folder .folder { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; -webkit-box-pack: center; justify-content: center; padding: 1em; }

.main-shared-folder .folder .file { margin: 2px; width: 24%; min-width: 80px; }

.main-shared-folder .folder .file .amino-video-play { width: 36px; height: 36px; margin-left: -18px; margin-top: -18px; }

.main-shared-folder .folder .file .amino-video-play .play-icon-img { width: 14px; height: 32px; margin-left: 1.8px; }

.main-shared-folder .folder .file-wrapper { width: 100%; position: relative; padding-top: 100%; }

.main-shared-folder .folder .file-cover, .main-shared-folder .folder .img-cover { position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; }

.main-shared-folder .folder .label { -webkit-box-flex: 1; flex: 1 1 100%; margin: 10px 0px 10px -1em; padding-left: 1em; font-size: 18px; font-weight: 700; position: relative; }

.main-shared-folder .folder .label::before { content: ""; position: absolute; top: 0px; left: 0px; display: block; height: 1.2em; width: 8px; border-left: 8px solid; }

.main-shared-folder .folder .paginator { -webkit-box-flex: 1; flex: 1 1 100%; }

.main-shared-folder-albums { padding-top: 1em; }

.main-shared-folder-albums > .content { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; -webkit-box-pack: center; justify-content: center; background: rgb(255, 255, 255); padding: 0px 8px; }

.main-shared-folder-albums > .content > .album { -webkit-box-flex: 1; flex: 1 0 30%; min-width: 120px; margin: 0px 8px; border-radius: 0.5em; overflow: hidden; }

.main-shared-folder-albums > .content > .album.list-item { padding-top: 20.25%; margin: 8px; min-height: 146px; }

.main-about { position: relative; height: 100%; }

.main-about > .background { position: fixed; inset: 50px 0px 0px; }

.main-about > .background .background-media { position: absolute; inset: 0px; z-index: 0; width: 100%; height: 100%; }

.main-about > .content { padding-top: 1em; min-height: calc(100vh - 50px); height: 100%; display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; }

.main-about > .content > header.community-info { -webkit-box-flex: 0; flex: 0 0 auto; }

.main-about > .content > .desc { -webkit-box-flex: 1; flex: 1 0 auto; }

.main-about .info { display: flex; -webkit-box-align: start; align-items: flex-start; -webkit-box-pack: center; justify-content: center; width: 600px; margin: auto; }

.main-about .info h1.title { margin: 0px; padding: 0.5rem 0px 0.25rem; font-size: 24px; word-break: break-word; hyphens: auto; }

.main-about .info .community-icon { position: relative; -webkit-box-flex: 0; flex: 0 0 120px; margin-right: 1em; }

.main-about .info .community-icon img.logo { width: 120px; height: 120px; border-radius: 27.12px; }

.main-about .info .community-icon i.fa { position: absolute; top: 8px; left: 8px; border-radius: 50%; font-size: 20px; color: rgb(255, 255, 255); background: rgba(0, 0, 0, 0.5); padding: 3px; }

.main-about .info .heat-gauge { margin: 4px 0px; }

.main-about .info .community-language > .content { display: inline-block; margin: 4px 0px; padding: 2px 12px; background: rgba(255, 255, 255, 0.2); border-radius: 5px; }

.main-about .info .community-language, .main-about .info .member-count { color: rgba(255, 255, 255, 0.8); line-height: 1.5; font-size: smaller; }

.main-about p.tagline { margin: 1em 0px; padding: 0px 1em; text-align: center; }

.main-about .endpoint { color: rgb(255, 255, 255); text-align: center; }

.main-about .endpoint > .content { display: inline-block; margin-top: 1em; border-radius: 5px; background-color: rgba(0, 0, 0, 0.5); padding: 0.5em 1.5em; }

.main-about .endpoint > .content > span { font-size: 14px; }

.main-about .endpoint > .content > strong { font-size: 16px; }

.main-about .btn.join { display: block; box-shadow: rgb(23, 173, 113) 0px -3px inset, rgb(23, 173, 113) 0px 2px; background: rgb(29, 218, 143); width: 240px; margin: 12px auto; padding: 12px; }

.main-about .btn.join:active { box-shadow: none; }

.main-about .btn.join > .fa { float: left; }

.main-about .desc { padding: 1em; background-color: rgba(0, 0, 0, 0.4); margin-top: 1em; }

.main-about .desc > h3.title { margin: 0px 0px 1em; font-size: 150%; }

.full-content .main-about { max-width: 766px; margin: 0px auto; }

section.main-download { position: fixed; inset: 0px; color: rgb(255, 255, 255); height: 100vh; }

section.main-download h1.title { margin: 1rem 0px; }

section.main-download .amino-id { display: inline-block; padding: 0.5em 0.75em; overflow: hidden; background: rgba(255, 255, 255, 0.15); word-break: break-all; border-radius: 5px; }

section.main-download .amino-id .label { font-size: 14px; letter-spacing: -0.5px; }

section.main-download .amino-id .value { font-size: 17px; letter-spacing: 0.3px; }

section.main-download .amino-logo, section.main-download .amino-logo > img.content { height: 1.5em; filter: drop-shadow(rgba(0, 0, 0, 0.3) 0px 0px 5px); }

section.main-download .amino-logo, section.main-download .overlay { transition: all 0.4s ease-out 0s; }

section.main-download .overlay { position: absolute; z-index: -1; inset: -5vmin; filter: blur(5px); background-position: 50% center; background-size: cover; }

html.no-cssfilters section.main-download > .overlay::after { display: block; content: ""; position: absolute; inset: 0px; z-index: 11; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); }

section.main-download > .overlay.community-bg::after { display: block; content: ""; position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; background: radial-gradient(rgba(255, 255, 255, 0.75), rgba(255, 255, 255, 0)); }

section.main-download > .content { position: fixed; top: 40vh; left: 50%; transform: translate(-50%, -127px); z-index: 100; background: none; -webkit-box-flex: 0; flex: 0 0 280px; width: 280px; text-align: center; }

section.main-download > .content > .middle, section.main-download > .content > .middle-join { position: relative; border-radius: 5px; background: rgba(0, 0, 0, 0.5); padding: 0px 12px; }

section.main-download > .content > .middle-join > .overlay, section.main-download > .content > .middle > .overlay { filter: blur(20px); inset: 0px; }

html.no-cssfilters section.main-download > .content > .middle-join > .overlay, html.no-cssfilters section.main-download > .content > .middle > .overlay { display: none; }

section.main-download > .content > .middle-join > .overlay::after, section.main-download > .content > .middle > .overlay::after { display: block; content: ""; position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.2); }

section.main-download.join-now .middle, section.main-download .middle-join, section.main-download > .content .invite-guide { display: none; }

section.main-download.join-now .middle-join { display: block; }

section.main-download.join-now .middle-join > .content { display: none; }

section.main-download.join-now .middle-join > .content.active { display: block; }

section.main-download.join-now .middle-join > .content > i.fa { font-size: 72px; margin-top: 36px; }

section.main-download.join-now .middle-join > .content > .label { margin-top: 20px; font-size: 16px; font-weight: 500; letter-spacing: -0.5px; }

section.main-download.join-now .middle-join > .content input[name="invite_code"] { height: 36px; line-height: 34px; border-radius: 8px; outline: none; padding: 0px 12px; margin: 18px 0px 0px; border: none; width: 280px; }

section.main-download.join-now .middle-join > .content input[name="invite_code"]::-webkit-input-placeholder { color: rgb(189, 189, 189); }

section.main-download.join-now .middle-join > .content input[name="invite_code"]::placeholder { color: rgb(189, 189, 189); }

section.main-download.join-now .middle-join > .content input[name="invite_code"]:focus { box-shadow: rgba(0, 0, 0, 0.3) 0px 0px 5px inset; border-color: rgb(138, 140, 155); }

section.main-download.join-now .middle-join > .content input[name="invite_code"]::-webkit-input-placeholder { font-size: 14px; }

section.main-download.join-now .middle-join > .content input[name="invite_code"]::placeholder { font-size: 14px; }

section.main-download.join-now .middle-join > .content textarea[name="request_message"] { height: 100px; width: 280px; margin-top: 18px; border-radius: 10px; border: none; resize: none; outline: 0px; padding: 10px; }

section.main-download.join-now .middle-join > .content textarea[name="request_message"]::-webkit-input-placeholder { color: rgb(189, 189, 189); font-size: 14px; }

section.main-download.join-now .middle-join > .content textarea[name="request_message"]::placeholder { color: rgb(189, 189, 189); font-size: 14px; }

section.main-download.join-now .middle-join > .content .actions { margin-top: 20px; display: flex; -webkit-box-pack: justify; justify-content: space-between; }

section.main-download.join-now .middle-join > .content .actions > .btn { position: relative; height: 40px; padding: 0px 1em; border-radius: 8px; border: 1px solid; line-height: 38px; display: inline-block; width: 135px; font-size: 14px; }

section.main-download.join-now .middle-join > .content .actions > .btn:not(.community-color) { color: rgb(255, 255, 255); }

section.main-download.join-now .middle-join > .content .actions > .btn.community-bg { border-color: transparent; }

section.main-download.join-now .middle-join > .content .actions > .btn:not([disabled]):hover::before { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; content: ""; background-color: rgba(0, 0, 0, 0.05); }

section.main-download.join-now .middle-join > .content .actions > .btn.btn-cancel { background-color: transparent; }

section.main-download.join-now .middle-join > .content .sep { display: flex; -webkit-box-pack: justify; justify-content: space-between; -webkit-box-align: center; align-items: center; margin-top: 12px; }

section.main-download.join-now .middle-join > .content .sep .line { height: 1px; width: 120px; border-top: 1px solid rgba(255, 255, 255, 0.8); }

section.main-download.join-now .middle-join > .content .sep .label { color: rgb(255, 255, 255); }

section.main-download.join-now .middle-join > .content [name="request_switch"] { position: relative; height: 40px; padding: 0px 1em; border-radius: 8px; border: 1px solid; line-height: 38px; width: 280px; margin-top: 14px; font-size: 14px; }

section.main-download.join-now .middle-join > .content [name="request_switch"]:not(.community-color) { color: rgb(255, 255, 255); }

section.main-download.join-now .middle-join > .content [name="request_switch"].community-bg { border-color: transparent; }

section.main-download.join-now .middle-join > .content [name="request_switch"]:not([disabled]):hover::before { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; content: ""; background-color: rgba(0, 0, 0, 0.05); }

section.main-download.join-now .middle-join > .content .community-info { display: block; }

section.main-download.join-now .middle-join > .content { padding-bottom: 18px; }

section.main-download.join-now .card { visibility: hidden; }

section.main-download .community-icon { position: relative; margin: 0px -12px; }

section.main-download .community-icon .fa-lock { position: absolute; top: -42px; left: 50%; margin-left: -36px; background: rgba(0, 0, 0, 0.5); border-radius: 50%; width: 25px; height: 25px; text-align: center; line-height: 25px; }

section.main-download .community-icon .logo { width: 80px; height: 80px; border-radius: 18.08px; margin-top: -40px; box-shadow: rgba(0, 0, 0, 0.5) 0px 2px 4px; }

section.main-download a.community-info { position: absolute; display: inline-block; top: 10px; right: 10px; width: 20px; height: 20px; border-radius: 50%; border: 2px solid rgb(255, 255, 255); color: rgb(255, 255, 255); font-size: 12px; line-height: 16px; }

section.main-download .amino-id-and-tagline .tagline { margin: 1.25em 0px; line-height: 18px; max-height: 54px; overflow: hidden; overflow-wrap: break-word; }

section.main-download .amino-id-and-tagline .howto { display: none; margin: 1.25em 0px; font-weight: 700; }

section.main-download .btn-download-option.amino, section.main-download .btn-join { box-shadow: rgba(0, 0, 0, 0.2) 0px -5px inset; }

section.main-download .btn-download-option.amino:active, section.main-download .btn-join:active { box-shadow: none; }

section.main-download .btn-download-option, section.main-download .btn-join { position: relative; z-index: 10; width: 100%; margin-bottom: 16px; color: rgb(255, 255, 255); padding: 1rem; font-size: 20px; font-weight: 400; letter-spacing: 0.5px; text-align: center; }

section.main-download .btn-join { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; font-size: 22px; font-weight: 700; opacity: 0; pointer-events: none; line-height: 22px; padding: 14px 16px; margin-bottom: 10px; }

section.main-download .btn-download-option { background-color: rgba(255, 255, 255, 0.2); margin-bottom: 10px; text-align: center; font-size: 16px; font-weight: 700; line-height: 1em; padding: 8px 16px; }

section.main-download .btn-download-option.amino { background-color: rgb(29, 218, 143); font-weight: 700; padding: 9px 16px; }

section.main-download .btn-download-option.amino .fa-stack-text { color: rgb(29, 218, 143); }

section.main-download .fa-stack-text { color: rgb(74, 74, 74); }

section.main-download .fa-stack { transform: scale(0.7); transform-origin: left 12px; margin-right: -6px; }

section.main-download .imgbtn { margin-bottom: -2px; transform: scale(0.8); transform-origin: center top; }

section.main-download .guide { position: relative; padding-bottom: 2px; }

section.main-download .btn-block-open { display: none; }

section.main-download .choice-deeplink, section.main-download .choice-download { display: none; text-align: center; }

section.main-download .choice-download { -webkit-box-pack: justify; justify-content: space-between; padding: 8px 12px; margin: 0px -2em; }

section.main-download .choice-download .step { -webkit-box-flex: 1; flex: 1 0 0px; margin: 0px 5px; border-radius: 5px; overflow: hidden; padding: 6px 0px 0px; background: rgba(0, 0, 0, 0.3); }

section.main-download .choice-download .caption { margin-top: 2px; margin-bottom: 4px; font-weight: 700; }

section.main-download .choice-download .caption .fa-stack-text { font-size: 20px; }

section.main-download .choice-download .app-guide { position: relative; margin: 0px 18px; border-radius: 5px 5px 0px 0px; min-height: 116px; overflow: hidden; padding: 5px 7px; user-select: none; box-shadow: rgba(0, 0, 0, 0.5) 0px 2px 7px; }

section.main-download .choice-download .app-guide::after { display: block; content: ""; position: absolute; inset: 0px; z-index: 60; width: 100%; height: 100%; pointer-events: none; background-color: rgba(0, 0, 0, 0.5); }

section.main-download .choice-download .app-guide .overlay { display: block; position: absolute; inset: 0px; z-index: 1; width: 100%; height: 100%; background-image: url("https://aminoapps.com/static/dist/018d62ae060997551672764cc0674313.png"); background-size: cover; pointer-events: none; overflow: hidden; filter: none; }

section.main-download .choice-download .app-guide .search-bar { position: relative; height: 30px; margin-bottom: 12px; }

section.main-download .choice-download .app-guide .search-bar > .content { position: absolute; inset: 0px; z-index: 90; width: 100%; height: 100%; border-radius: 3px; text-align: left; text-indent: 4px; font-size: 14px; line-height: 30px; background-color: rgba(255, 255, 255, 0.2); }

section.main-download .choice-download .app-guide .search-bar > .content i.amino-icon { font-size: large; margin-right: 2px; }

section.main-download .choice-download .app-guide > .content { display: flex; position: relative; z-index: 50; }

section.main-download .choice-download .app-guide .logo { -webkit-box-flex: 0; flex: 0 0 auto; width: 50px; height: 50px; border-radius: 11.3px; margin-right: 7px; }

section.main-download .choice-download .app-guide h1.title { line-height: 18px; max-height: 36px; overflow: hidden; overflow-wrap: break-word; margin: 0px; text-align: left; font-size: 14px; letter-spacing: -0.5px; }

section.main-download .choice-download .app-guide .heat-gauge { margin: 4px 0px; font-size: 15px; }

section.main-download .choice-download .app-guide .tagline { line-height: 16px; max-height: 32px; overflow: hidden; overflow-wrap: break-word; margin: 3px -15px -5px 0px; text-align: left; font-size: 12px; transform-origin: left top; transform: scale(0.8); }

section.main-download h1.title { font-size: 1.75em; text-shadow: rgba(0, 0, 0, 0.5) 0px 0px 4px; line-height: 32px; max-height: 64px; overflow: hidden; overflow-wrap: break-word; }

section.main-download .card { display: none; -webkit-box-pack: center; justify-content: center; margin-top: 24px; }

section.main-download .card > .content { margin: auto; border-radius: 5px; -webkit-box-flex: 0; flex: 0 0 auto; width: 280px; text-align: center; color: rgb(255, 255, 255); background: rgba(0, 0, 0, 0.5); padding: 8px 0px; line-height: 1.6; }

section.main-download.inited .btn-join { opacity: 1; pointer-events: auto; }

section.main-download.inited .btn-join.state-request-sent, section.main-download.inited .btn[name^="submit"][disabled] { opacity: 0.6; }

section.main-download.active .amino-id-and-tagline .tagline { display: none; }

section.main-download.active .amino-id-and-tagline .howto { display: block; }

section.main-download.active .btn-join { display: none; }

section.main-download.focus-in > .overlay { filter: blur(25px); }

section.main-download.focus-in .footer > .amino-logo { pointer-events: none; opacity: 0; }

section.main-download.active.platform-etc > .content { width: 540px; }

section.main-download.active.platform-etc .choice-download { display: flex; }

section.main-download.active.platform-mobile .choice-deeplink, section.main-download.locked .card.locked-card { display: block; }

section.main-download.locked .card.locked-card i.fa { margin: 8px 13px; font-size: 18px; -webkit-box-flex: 0; flex: 0 0 auto; }

section.main-download.locked .card.locked-card > .content { display: flex; -webkit-box-align: center; align-items: center; font-size: small; text-align: left; font-weight: 700; }

section.main-download .block-guide { display: none; }

section.main-download.blocked.active .community-info { display: block; }

section.main-download.blocked.active .block-guide, section.main-download.blocked.active .btn-block-open, section.main-download.blocked .community-info { display: none; }

section.main-download.blocked .block-guide { display: block; padding-top: 36px; font-weight: 500; line-height: 1.2; height: 205px; }

section.main-download.blocked .block-guide i.fa { font-size: 72px; }

section.main-download.blocked .block-guide .desc { line-height: 20px; max-height: 60px; overflow: hidden; overflow-wrap: break-word; margin-top: 16px; }

section.main-download .footer { position: fixed; margin: 0px auto; left: 0px; right: 0px; bottom: 0px; text-align: center; }

section.main-download .footer .amino-logo { opacity: 0.85; margin-bottom: 5px; }

section.main-download.invite .card.invite-card { display: flex; -webkit-box-align: center; align-items: center; padding: 0px 0.25em; }

section.main-download.invite .card.invite-card i.fa { -webkit-box-flex: 0; flex: 0 0 auto; border-left: 1px solid rgba(255, 255, 255, 0.75); padding-left: 14px; margin-left: auto; line-height: 34px; }

section.main-download.invite .card.invite-card .amino-id { display: flex; background: none; overflow-wrap: normal; word-break: keep-all; padding: 0px 12px 0px 0px; }

section.main-download.invite .card.invite-card .amino-id > .remain { -webkit-box-flex: 1; flex: 1 0 0px; text-align: center; }

section.main-download.invite .card.invite-card .code, section.main-download.invite .card.invite-card .label { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; font-size: 14px; line-height: 34px; }

section.main-download.invite .card.locked-card { display: none; }

section.main-download.invite .footer { display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-flow: column nowrap; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; height: 40px; }

.community-profile-body .home-section-nav, section.main-download.invite .footer > .amino-logo { display: none; }

article.post.user-profile-page header.title > h3.title { font-size: 18px; overflow: visible; }

article.post.user-profile-page > section { margin-top: 10px; }

article.post.user-profile-page > section.user-fan-club { margin: 16px 38px 3px; }

.is-mobile article.post.user-profile-page > section.user-fan-club { margin: 11px 6px 0px; }

article.post.user-profile-page > section.user-wiki { margin-top: 20px; }

article.post.user-profile-page .user-posts .list-item { max-width: 400px; }

article.post.user-profile-page > .blocked-indicator { min-height: 360px; height: 40vh; }

.user-fan-club .container { background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 1px 4px 0px; border-radius: 5px; padding: 22px 24px; margin: auto; display: flex; -webkit-box-align: center; align-items: center; align-content: center; }

.is-mobile .user-fan-club .container { padding: 18px 22px; }

.user-fan-club .club-logo { display: block; }

.user-fan-club .club-info { -webkit-box-flex: 1; flex: 1 1 auto; padding-left: 12px; padding-right: 18px; word-break: break-word; hyphens: auto; }

.is-mobile .user-fan-club .club-info { padding-left: 11px; padding-right: 15px; }

.user-fan-club .club-info .title { font-size: 16px; color: rgb(74, 74, 74); margin: 0px; }

.user-fan-club .club-info .fans-count { margin-top: 5px; font-size: 14px; color: rgb(179, 179, 179); font-weight: 400; }

.user-fan-club .btn { margin: auto; -webkit-box-flex: 0; flex: 0 0 auto; }

.user-fan-club + .user-bio header.title { padding-top: 10px; }

.user-bio .bio-body { padding: 13px 28px; }

.user-bio .bio-body.overflowing { max-height: 250px; }

.user-bio .bio-body.overflowing.open { padding-bottom: 30px; }

.user-bio .image-container, .user-bio .video-container { margin: 24px auto; }

.user-bio .empty-content { min-height: 0px; }

.user-bio time.date { font-size: 13px; vertical-align: middle; font-weight: 400; }

.user-wiki { position: relative; }

.user-wiki .carousel-container { height: 148px; margin: 10px 28px 0px; }

.user-wiki .wiki-list { padding-bottom: 20px; }

.user-wiki .wiki-item { position: relative; margin-right: 16px; }

.user-wiki .wiki-item > .block { overflow: hidden; border-radius: 0.5em; border: 1px solid rgb(232, 232, 232); height: 128px; -webkit-box-flex: 0; flex: 0 0 100px; }

.user-wiki .wiki-item.curated > .block { border-color: rgb(255, 192, 0); background: rgb(255, 192, 0); }

.user-wiki .wiki-item.see-more .block { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; -webkit-box-pack: center; place-content: center; color: rgb(255, 255, 255); }

.user-wiki .wiki-item.see-more .block:hover { background-image: radial-gradient(rgba(255, 255, 255, 0.5) 0px, rgba(255, 255, 255, 0.2) 20%, rgba(255, 255, 255, 0) 50%); }

.user-wiki .wiki-item.see-more .block i.amino-icon { -webkit-box-flex: 0; flex: 0 0 100%; text-align: center; font-size: 32px; margin-bottom: 0.25rem; }

.user-wiki .wiki-item.see-more .block .label { font-size: 14px; }

.user-wiki .wiki-item.need-hidden-post .img-cover { filter: blur(3px); }

.user-wiki .fans-only-icon { width: 16px; height: 16px; padding: 0px; border-top-right-radius: 7px; top: 1px; right: 1px; }

.user-wiki .fans-only-icon > .fans-only-img { width: 12px; height: 9px; margin-top: -4px; }

.user-wiki .wiki-item:nth-last-child(n+3) .fans-only-icon .hover-hint { right: auto; left: -5px; }

.user-wiki .wiki-item:nth-last-child(n+3) .fans-only-icon .hover-hint::after { right: auto; }

.user-wiki .wiki-item:nth-child(-n+2) .fans-only-icon .hover-hint { right: auto; left: -5px; }

.user-wiki .wiki-item:nth-child(-n+2) .fans-only-icon .hover-hint::after { right: auto; }

.user-wiki .wiki-cover { width: 100px; height: 100px; }

.user-wiki .label { line-height: 28px; font-size: 12px; font-weight: 700; text-align: center; padding: 0px 0.4em; width: 100px; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }

.user-posts h3.title > .tab-toggle { margin-right: 0.75rem; opacity: 0.5; }

.user-posts .title > .tab-toggle.active { position: relative; opacity: 1; }

.user-posts .title > .tab-toggle.active::after { content: ""; width: 95%; position: absolute; height: 0px; border-bottom-width: 3px; border-bottom-style: solid; left: 50%; transform: translateX(-50%); bottom: -5px; }

.user-posts .list-item .post .nickname { width: auto; }

.user-posts .comment-bar { display: flex; padding: 13px 28px; cursor: pointer; }

.user-posts .comment-bar input.comment-input { display: block; height: 36px; -webkit-box-flex: 1; flex-grow: 1; margin-right: 0.5rem; outline: none; border-radius: 5px; padding-left: 0.5rem; border: 1px solid rgb(198, 198, 198); color: rgb(181, 181, 181); }

.user-posts .comment-bar input.comment-input:hover { border-color: rgb(165, 165, 165); }

.user-posts .comment-bar .btn { font-weight: 100; position: relative; }

.user-posts .comment-bar .btn:hover::after { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; content: " "; background: rgba(0, 0, 0, 0.2); }

.user-posts .comment-list { margin-top: 14px; }

.user-posts .comment-list > h3.title { display: none; }

.user-posts .comment-list > .content > article.comment:first-child { border-top: none; }

.user-posts .comment-list > .content > article.comment { display: flex; }

.user-newsfeed .user-bio, .user-newsfeed .user-canopy .counter-info, .user-newsfeed .user-canopy::before, .user-newsfeed .user-interaction, .user-newsfeed .user-ranking { display: none; }

.user-newsfeed .user-canopy::after { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; content: " "; background: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjIwIiBoZWlnaHQ9IjE0NyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+PGRlZnM+PHBhdGggaWQ9ImEiIGQ9Ik0wIDBoMjMuMzc0djIzLjM5OEgweiIvPjwvZGVmcz48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIG9wYWNpdHk9Ii40NzQiPjxwYXRoIGQ9Ik0zMC4zMjYgNzAuODU3aDYuNDIxYTIuNjM5IDIuNjM5IDAgMSAxIDAgNS4yNzhoLTYuNDJ2Ni40MmEyLjY0IDIuNjQgMCAxIDEtNS4yNzkgMHYtNi40MmgtNi40MmEyLjYzOSAyLjYzOSAwIDEgMSAwLTUuMjc4aDYuNDJ2LTYuNDIxYTIuNjM5IDIuNjM5IDAgMSAxIDUuMjc4IDB2Ni40MjF6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik0xNiAxNWgyMy4zNzR2MjMuMzk4SDE2eiIvPjxwYXRoIGQ9Ik0yNi4wMDYgMjQuNDkxYy4yNS0uNjQxLjQzNi0uOTg4Ljg3Ny0uOTg4LjQ1MSAwIC42NzUuNTQ0Ljg2NCAxLjAwNC4zMDQuNzMzLjY0IDEuNzMxLjkyNiAyLjUzMS0xLjY3Mi44NzQtMy40ODMgMi4xMy00Ljk0NCAzLjM1OS41MDktMS4yNDUgMS41NzEtNC4wOTggMi4yNzctNS45MDZ6bTYuODg4Ljc3NmMtMS4xNzQtMy4wNS0yLjk3MS03LjE4NC0zLjUyOS04LjQ3NmE1LjYzIDUuNjMgMCAwIDAtLjQ2NS0uODUxYy0uNDMxLS42MDktMS4wMS0uOTQtMS44NzEtLjk0LS43NTQgMC0xLjI5LjMyLTEuNjk0Ljc5LS4yNC4yOTQtLjQzOC42Mi0uNTg5Ljk2OS0uNzQxIDEuNzg0LTUuNDY5IDEzLjg5OC03Ljc2MyAxOS44NzYtLjM2My45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcgMCAuOTc0LS4zMTQgMS42Ny0xLjA1OCAyLjU3NC0yLjc1MyA1LjY3NS00LjkwNyA4LjU0Ny02LjM4MiAxLjE1NyAyLjg1NiAyLjMyNSA1Ljc4OSAyLjU2NCA2LjM4Mi4zNDQuODU0Ljc5IDEuMDU4IDEuNTc3IDEuMDU4aDIuMzI3Yy44OTQgMCAxLjA0OC0uNjA1Ljc1LTEuMzk1LS41MjgtMS4zOTYtMS43OS00LjUxNC0zLjEyNi03Ljg3MiAxLjEwMy0uNTIgMi4zOC0xLjEyNyAzLjI0NC0xLjQzNi41NzUtLjIwNSAxLjExNy0uNTEgMS4zODQtMS4xMjYuMzU3LS44MjYuMTE4LTEuNDA1LS4xMDItMS43NzctLjkyNy0xLjU3NC0zLjMwNy0uNDM0LTUuOTI2LjY4M3oiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTEyNS4wOCA2MS43OTdoMjMuMzc0djIzLjM5OEgxMjUuMDh6Ii8+PHBhdGggZD0iTTEyNi4xMjkgODAuODU1bDUuMTczLTQuNjggNS41MiA0LjY4IDUuNDUtNC42OCA1LjI0NSA0LjY4bS0yMS4zODgtOC41NzlsNS4xNzMtNC42OCA1LjUyIDQuNjggNS40NS00LjY4IDUuMjQ1IDQuNjgiIHN0cm9rZS1vcGFjaXR5PSIuMzYiIHN0cm9rZT0iI0ZGRiIgc3Ryb2tlLXdpZHRoPSI0IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48cGF0aCBkPSJNMTc5LjYyIDYxLjc5N2gyMy4zNzR2MjMuMzk4SDE3OS42MnoiLz48cGF0aCBkPSJNMTg5LjYyNiA3MS4yODhjLjI1LS42NDIuNDM2LS45ODkuODc4LS45ODkuNDUgMCAuNjc0LjU0NS44NjQgMS4wMDUuMzAzLjczMy42MzkgMS43My45MjYgMi41My0xLjY3My44NzQtMy40ODQgMi4xMy00Ljk0NSAzLjM2LjUxLTEuMjQ1IDEuNTcxLTQuMDk5IDIuMjc3LTUuOTA2em02Ljg4OC43NzVjLTEuMTczLTMuMDUtMi45Ny03LjE4My0zLjUyOS04LjQ3NmE1LjYzIDUuNjMgMCAwIDAtLjQ2Ni0uODVjLS40My0uNjEtMS4wMDgtLjk0LTEuODY5LS45NC0uNzU0IDAtMS4yOS4zMi0xLjY5NS43OS0uMjQuMjk0LS40MzcuNjItLjU4OC45NjgtLjc0MiAxLjc4NC01LjQ3IDEzLjg5OC03Ljc2NCAxOS44NzYtLjM2Mi45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcwMSAwIC45NzQtLjMxMyAxLjY3LTEuMDU4IDIuNTc0LTIuNzUyIDUuNjc2LTQuOTA3IDguNTQ3LTYuMzgxIDEuMTU3IDIuODU1IDIuMzI1IDUuNzg5IDIuNTY0IDYuMzgxLjM0NC44NTUuNzkgMS4wNTggMS41NzcgMS4wNThoMi4zMjdjLjg5NCAwIDEuMDQ4LS42MDQuNzUtMS4zOTQtLjUyOC0xLjM5Ny0xLjc5LTQuNTE0LTMuMTI2LTcuODczIDEuMTAzLS41MiAyLjM4LTEuMTI2IDMuMjQ1LTEuNDM1LjU3NC0uMjA2IDEuMTE3LS41MSAxLjM4My0xLjEyNi4zNTctLjgyNy4xMTgtMS40MDUtLjEwMS0xLjc3OC0uOTI4LTEuNTczLTMuMzA3LS40MzMtNS45MjcuNjgzeiIgZmlsbC1vcGFjaXR5PSIuMzU1IiBmaWxsPSIjRkZGIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNMTYgMTA4LjU5M2gyMy4zNzR2MjMuMzk4SDE2eiIvPjxwYXRoIGQ9Ik0yNi4wMDYgMTE4LjA4NGMuMjUtLjY0MS40MzYtLjk4OC44NzctLjk4OC40NTEgMCAuNjc1LjU0NS44NjQgMS4wMDQuMzA0LjczMy42NCAxLjczMS45MjYgMi41MzEtMS42NzIuODc0LTMuNDgzIDIuMTMtNC45NDQgMy4zNTkuNTA5LTEuMjQ1IDEuNTcxLTQuMDk4IDIuMjc3LTUuOTA2em02Ljg4OC43NzZjLTEuMTc0LTMuMDUtMi45NzEtNy4xODMtMy41MjktOC40NzZhNS42MyA1LjYzIDAgMCAwLS40NjYtLjg1Yy0uNDMtLjYxLTEuMDA5LS45NC0xLjg3LS45NC0uNzU0IDAtMS4yOS4zMi0xLjY5NC43OWE0LjEzIDQuMTMgMCAwIDAtLjU4OS45NjhjLS43NDEgMS43ODQtNS40NjkgMTMuODk4LTcuNzYzIDE5Ljg3Ni0uMzYzLjk0NC0uMjg3IDEuNTU1LjYwNSAxLjU1NWgyLjM5N2MuNyAwIC45NzQtLjMxNCAxLjY3LTEuMDU4IDIuNTc0LTIuNzUzIDUuNjc1LTQuOTA3IDguNTQ3LTYuMzgyIDEuMTU3IDIuODU2IDIuMzI1IDUuNzkgMi41NjQgNi4zODIuMzQ0Ljg1NS43OSAxLjA1OCAxLjU3NyAxLjA1OGgyLjMyN2MuODk0IDAgMS4wNDgtLjYwNS43NS0xLjM5NS0uNTI4LTEuMzk2LTEuNzktNC41MTQtMy4xMjYtNy44NzIgMS4xMDMtLjUyIDIuMzgtMS4xMjYgMy4yNDQtMS40MzYuNTc1LS4yMDUgMS4xMTctLjUxIDEuMzg0LTEuMTI2LjM1Ny0uODI2LjExOC0xLjQwNS0uMTAyLTEuNzc3LS45MjctMS41NzMtMy4zMDctLjQzNC01LjkyNi42ODN6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik03MC41NCAxMDguNTkzaDIzLjM3NHYyMy4zOThINzAuNTR6Ii8+PHBhdGggZD0iTTgyLjIyNyAxMzAuNDMyYy01LjU5NCAwLTEwLjEyOS00LjU0LTEwLjEyOS0xMC4xNCAwLTUuNiA0LjUzNS0xMC4xMzkgMTAuMTMtMTAuMTM5IDUuNTkzIDAgMTAuMTI4IDQuNTQgMTAuMTI4IDEwLjE0IDAgNS42LTQuNTM1IDEwLjEzOS0xMC4xMjkgMTAuMTM5em0wLTQuNjhhNS40NTcgNS40NTcgMCAwIDAgNS40NTQtNS40NiA1LjQ1NyA1LjQ1NyAwIDAgMC01LjQ1NC01LjQ2IDUuNDU3IDUuNDU3IDAgMCAwLTUuNDU0IDUuNDYgNS40NTcgNS40NTcgMCAwIDAgNS40NTQgNS40NnoiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTcwLjU0IDYxLjc5N2gyMy4zNzR2MjMuMzk4SDcwLjU0eiIvPjxwYXRoIGQ9Ik04MC41NDYgNzEuMjg4Yy4yNS0uNjQyLjQzNi0uOTg5Ljg3Ny0uOTg5LjQ1MSAwIC42NzUuNTQ1Ljg2NSAxLjAwNS4zMDMuNzMzLjYzOSAxLjczLjkyNSAyLjUzLTEuNjcyLjg3NC0zLjQ4MyAyLjEzLTQuOTQ0IDMuMzYuNTA5LTEuMjQ1IDEuNTcxLTQuMDk5IDIuMjc3LTUuOTA2em02Ljg4OC43NzVjLTEuMTc0LTMuMDUtMi45NzEtNy4xODMtMy41MjktOC40NzZhNS42MyA1LjYzIDAgMCAwLS40NjYtLjg1Yy0uNDMtLjYxLTEuMDA5LS45NC0xLjg3LS45NC0uNzUzIDAtMS4yOS4zMi0xLjY5NC43OS0uMjQuMjk0LS40MzcuNjItLjU4OC45NjgtLjc0MiAxLjc4NC01LjQ3IDEzLjg5OC03Ljc2NCAxOS44NzYtLjM2My45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcwMSAwIC45NzQtLjMxMyAxLjY3LTEuMDU4IDIuNTc0LTIuNzUyIDUuNjc2LTQuOTA3IDguNTQ3LTYuMzgxIDEuMTU3IDIuODU1IDIuMzI1IDUuNzg5IDIuNTY0IDYuMzgxLjM0NC44NTUuNzkgMS4wNTggMS41NzcgMS4wNThoMi4zMjdjLjg5NCAwIDEuMDQ4LS42MDQuNzUtMS4zOTQtLjUyOC0xLjM5Ny0xLjc5LTQuNTE0LTMuMTI2LTcuODczIDEuMTAzLS41MiAyLjM4LTEuMTI2IDMuMjQ0LTEuNDM1LjU3NS0uMjA2IDEuMTE3LS41MSAxLjM4NC0xLjEyNi4zNTctLjgyNy4xMTgtMS40MDUtLjEwMi0xLjc3OC0uOTI3LTEuNTczLTMuMzA3LS40MzMtNS45MjYuNjgzeiIgZmlsbC1vcGFjaXR5PSIuMzU1IiBmaWxsPSIjRkZGIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNNzAuNTQgMTVoMjMuMzc0djIzLjM5OEg3MC41NHoiLz48cGF0aCBkPSJNNzUuNDUzIDM2LjA3NGEzLjUgMy41IDAgMCAxLTIuOTUxLTUuMzgxbDcuMDUzLTExLjA2OGEzLjUgMy41IDAgMCAxIDUuOTAzIDBsNy4wNTYgMTEuMDY3YTMuNSAzLjUgMCAwIDEtMi45NSA1LjM4Mkg3NS40NTN6bTIuOTk1LTMuOTUyaDguMDM0YTEgMSAwIDAgMCAuODQtMS41NDFsLTMuOTgxLTYuMTk4YTEgMSAwIDAgMC0xLjY3OS0uMDA3bC00LjA1MSA2LjE5OGExIDEgMCAwIDAgLjgzNyAxLjU0OHoiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTEyNS4wOCAxNWgyMy4zNzR2MjMuMzk4SDEyNS4wOHoiLz48cGF0aCBkPSJNMTM1LjA4NiAyNC40OTFjLjI1LS42NDEuNDM2LS45ODguODc3LS45ODguNDUxIDAgLjY3NS41NDQuODY1IDEuMDA0LjMwMy43MzMuNjM5IDEuNzMxLjkyNiAyLjUzMS0xLjY3My44NzQtMy40ODQgMi4xMy00Ljk0NSAzLjM1OS41MDktMS4yNDUgMS41NzEtNC4wOTggMi4yNzctNS45MDZ6bTYuODg4Ljc3NmMtMS4xNzMtMy4wNS0yLjk3LTcuMTg0LTMuNTI5LTguNDc2YTUuNjMgNS42MyAwIDAgMC0uNDY2LS44NTFjLS40My0uNjA5LTEuMDA4LS45NC0xLjg2OS0uOTQtLjc1NCAwLTEuMjkuMzItMS42OTUuNzlhNC4wOCA0LjA4IDAgMCAwLS41ODguOTY5Yy0uNzQyIDEuNzg0LTUuNDcgMTMuODk4LTcuNzY0IDE5Ljg3Ni0uMzYzLjk0NC0uMjg3IDEuNTU1LjYwNSAxLjU1NWgyLjM5N2MuNzAxIDAgLjk3NC0uMzE0IDEuNjctMS4wNTggMi41NzQtMi43NTMgNS42NzYtNC45MDcgOC41NDctNi4zODIgMS4xNTcgMi44NTYgMi4zMjUgNS43ODkgMi41NjQgNi4zODIuMzQ0Ljg1NC43OSAxLjA1OCAxLjU3NyAxLjA1OGgyLjMyN2MuODk0IDAgMS4wNDgtLjYwNS43NS0xLjM5NS0uNTI4LTEuMzk2LTEuNzktNC41MTQtMy4xMjYtNy44NzIgMS4xMDMtLjUyIDIuMzgtMS4xMjcgMy4yNDUtMS40MzYuNTc0LS4yMDUgMS4xMTctLjUxIDEuMzgzLTEuMTI2LjM1Ny0uODI2LjExOC0xLjQwNS0uMTAxLTEuNzc3LS45MjgtMS41NzQtMy4zMDgtLjQzNC01LjkyNy42ODN6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDE3OS42MiAxNSkiPjxtYXNrIGlkPSJiIiBmaWxsPSIjZmZmIj48dXNlIHhsaW5rOmhyZWY9IiNhIi8+PC9tYXNrPjxwYXRoIGQ9Ik0xMS4yOTggNy40NTNsNC42OTEtNC42OTJhMi43MjcgMi43MjcgMCAwIDEgMy44NTcgMy44NTZsLTQuNjkyIDQuNjkyIDQuNjkyIDQuNjkyYTIuNzI3IDIuNzI3IDAgMCAxLTMuODU3IDMuODU2bC00LjY5MS00LjY5MS00LjY5MiA0LjY5MWEyLjcyNyAyLjcyNyAwIDAgMS0zLjg1Ny0zLjg1Nmw0LjY5Mi00LjY5Mi00LjY5Mi00LjY5MmEyLjcyNyAyLjcyNyAwIDAgMSAzLjg1Ny0zLjg1Nmw0LjY5MiA0LjY5MnoiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIiBtYXNrPSJ1cmwoI2IpIi8+PC9nPjxwYXRoIGQ9Ik0xMjUuMDggMTA4LjU5M2gyMy4zNzR2MjMuMzk4SDEyNS4wOHoiLz48cGF0aCBkPSJNMTM1LjA4NiAxMTguMDg0Yy4yNS0uNjQxLjQzNi0uOTg4Ljg3Ny0uOTg4LjQ1MSAwIC42NzUuNTQ1Ljg2NSAxLjAwNC4zMDMuNzMzLjYzOSAxLjczMS45MjYgMi41MzEtMS42NzMuODc0LTMuNDg0IDIuMTMtNC45NDUgMy4zNTkuNTA5LTEuMjQ1IDEuNTcxLTQuMDk4IDIuMjc3LTUuOTA2em02Ljg4OC43NzZjLTEuMTczLTMuMDUtMi45Ny03LjE4My0zLjUyOS04LjQ3NmE1LjYzIDUuNjMgMCAwIDAtLjQ2Ni0uODVjLS40My0uNjEtMS4wMDgtLjk0LTEuODY5LS45NC0uNzU0IDAtMS4yOS4zMi0xLjY5NS43OS0uMjQuMjk0LS40MzcuNjItLjU4OC45NjgtLjc0MiAxLjc4NC01LjQ3IDEzLjg5OC03Ljc2NCAxOS44NzYtLjM2My45NDQtLjI4NyAxLjU1NS42MDUgMS41NTVoMi4zOTdjLjcwMSAwIC45NzQtLjMxNCAxLjY3LTEuMDU4IDIuNTc0LTIuNzUzIDUuNjc2LTQuOTA3IDguNTQ3LTYuMzgyIDEuMTU3IDIuODU2IDIuMzI1IDUuNzkgMi41NjQgNi4zODIuMzQ0Ljg1NS43OSAxLjA1OCAxLjU3NyAxLjA1OGgyLjMyN2MuODk0IDAgMS4wNDgtLjYwNS43NS0xLjM5NS0uNTI4LTEuMzk2LTEuNzktNC41MTQtMy4xMjYtNy44NzIgMS4xMDMtLjUyIDIuMzgtMS4xMjYgMy4yNDUtMS40MzYuNTc0LS4yMDUgMS4xMTctLjUxIDEuMzgzLTEuMTI2LjM1Ny0uODI2LjExOC0xLjQwNS0uMTAxLTEuNzc3LS45MjgtMS41NzMtMy4zMDgtLjQzNC01LjkyNy42ODN6IiBmaWxsLW9wYWNpdHk9Ii4zNTUiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik0xNzkuNjIgMTA4LjU5M2gyMy4zNzR2MjMuMzk4SDE3OS42MnoiLz48cGF0aCBkPSJNMTg0LjUzMyAxMjkuNjY3YTMuNSAzLjUgMCAwIDEtMi45NTEtNS4zODFsNy4wNTQtMTEuMDY3YTMuNSAzLjUgMCAwIDEgNS45MDItLjAwMWw3LjA1NyAxMS4wNjdhMy41IDMuNSAwIDAgMS0yLjk1MiA1LjM4MmgtMTQuMTF6bTIuOTk1LTMuOTUyaDguMDM0YTEgMSAwIDAgMCAuODQxLTEuNTRsLTMuOTgyLTYuMmExIDEgMCAwIDAtMS42NzktLjAwNmwtNC4wNSA2LjE5OWExIDEgMCAwIDAgLjgzNiAxLjU0N3oiIGZpbGwtb3BhY2l0eT0iLjM1NSIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJub256ZXJvIi8+PC9nPjwvc3ZnPg==") repeat; }

.user-newsfeed .user-profile { top: 50%; margin-top: -68px; }

.user-newsfeed .user-posts .tab-toggles .tab-toggle { border: none; }

.user-newsfeed .user-posts .tab-toggles .tab-toggle:nth-child(2) { display: none; }

.global-post-page .community-color { color: rgb(255, 255, 255); }

.dark-theme .main-page article.post.main-post { background-color: rgb(4, 2, 38); color: rgb(255, 255, 255); }

.dark-theme .main-page article.post.main-post section.info .nickname { display: flex; }

.dark-theme .main-page article.post.main-post .nickname, .dark-theme .main-page article.post.main-post .rich-content a { color: rgb(14, 224, 180); }

.dark-theme .main-page article.post.main-post .topic-item a { color: rgb(255, 255, 255); }

.dark-theme .main-page article.post.main-post section.blog-like .avatar { background: transparent; border: 1px solid transparent; box-shadow: none; }

.dark-theme .main-page article.post.main-post section.blog-like .avatar[src*="dark-user-icon-placeholder"] { border-color: rgb(255, 255, 255); }

.dark-theme .comment-input-bar textarea[name="content"] { background: rgb(48, 47, 81); border: transparent; color: rgb(255, 255, 255); }

.dark-theme .comment-input-bar textarea[name="content"]::-webkit-input-placeholder { color: rgba(218, 220, 251, 0.5); }

.dark-theme .comment-input-bar textarea[name="content"]::placeholder { color: rgba(218, 220, 251, 0.5); }

.dark-theme .comment-input-bar .btn-send { color: rgb(255, 255, 255); background: rgba(255, 255, 255, 0.15); }

.dark-theme .comment-input-bar .btn-send:disabled { color: rgba(255, 255, 255, 0.4); }

.dark-theme.not-mobile section.live-comment .counters .vote-counter, .dark-theme section.live-comment > .content ul.comments .message { background: rgb(48, 47, 81); }

.dark-theme.not-mobile section.live-comment .counters .vote-counter[data-vce="btn-popup"], .dark-theme.not-mobile section.live-comment .counters .vote-counter[data-vote-value="0"] { color: rgba(255, 255, 255, 0.7); }

.dark-theme.not-mobile section.live-comment .counters .vote-counter:hover { background: rgb(58, 56, 97); }

.dark-theme .main-page section.blog-like > .vote-counter { background: rgb(48, 47, 81); }

.dark-theme .main-page section.blog-like > .vote-counter:hover { background: rgb(58, 56, 97); }

.dark-theme .share-icons.with-color > li.item { background: rgb(134, 134, 166); border-color: transparent; color: rgb(4, 2, 38); }

.dark-theme .main-page .collapse-share::after { background: rgb(4, 2, 38); }

.dark-theme .main-page section.blog-like .more-votes { background: rgb(134, 134, 166); border-color: transparent; }

.dark-theme .main-page section.blog-like > .vote-counter[data-vce="btn-popup"], .dark-theme .main-page section.blog-like > .vote-counter[data-vote-value="0"] { color: rgba(255, 255, 255, 0.7); }

.dark-theme section.comment-list article.comment { border-bottom-color: rgba(255, 255, 255, 0.15); }

.dark-theme section.comment-list article.comment .reply, .dark-theme section.comment-list article.comment .vote { color: rgb(255, 255, 255); }

.dark-theme .main-page .nickname > .label-author, .dark-theme section.comment-list .nickname > .label-author { border-color: rgb(0, 145, 255); }

.dark-theme section.comment-list .read-more { background: rgba(255, 255, 255, 0.15); }

.dark-theme section.comment-list article.comment [data-vce="toggle-content"] .height-toggle { color: rgb(14, 224, 180); background: linear-gradient(0deg, rgb(4, 2, 38), rgb(4, 2, 38) 60%, rgba(4, 2, 38, 0)); }

.dark-theme section.comment-list .read-more-comments { color: rgb(14, 224, 180); }

.dark-theme .main-page .chat-link .btn { background: rgb(14, 224, 180); color: rgb(4, 2, 38); box-shadow: rgb(12, 173, 178) 0px 4px 0px; }

.dark-theme .main-page .chat-link .btn:active { box-shadow: none; }

.influencer-fan-club-conversion-page { max-width: 626px; }

.influencer-fan-club-conversion-page .community-bg { background-color: rgb(223, 28, 152); }

.influencer-fan-club-conversion-page .community-bg-dark { background-color: rgb(155, 19, 106); }

.influencer-fan-club-conversion-page .community-color, .influencer-fan-club-conversion-page .community-color:active, .influencer-fan-club-conversion-page .community-color:hover, .influencer-fan-club-conversion-page .community-color:link, .influencer-fan-club-conversion-page .community-color:visited { color: rgb(228, 36, 158); }

.influencer-fan-club-conversion-page .community-color-dark, .influencer-fan-club-conversion-page .community-color-dark:active, .influencer-fan-club-conversion-page .community-color-dark:hover, .influencer-fan-club-conversion-page .community-color-dark:link, .influencer-fan-club-conversion-page .community-color-dark:visited { color: rgb(155, 19, 106); }

.main-page .influencer-fan-club-conversion-page.post.main-post:first-of-type { margin: 0px auto; }

.influencer-fan-club-conversion-page .btn-vip { z-index: 100; position: relative; padding: 18px 63px; transform: translateX(-50%); left: 50%; font-size: 20px; box-shadow: rgba(239, 149, 206, 0.8) 0px 2px 10px 0px; white-space: nowrap; }

.is-mobile .influencer-fan-club-conversion-page .btn-vip { bottom: 14px; padding: 15px 64px; font-size: 17px; position: fixed; }

.influencer-fan-club-conversion-page .btn-vip:active { transform: translateX(-50%); }

.influencer-fan-club-conversion-page .user-canopy { color: rgb(255, 255, 255); height: auto; box-shadow: rgba(0, 0, 0, 0.5) 0px 3px 10px 0px; border-radius: 100% / 0px 0px 28% 28%; font-size: 17px; padding: 50px 33px 33px; margin: 0px -33px; }

.influencer-fan-club-conversion-page .user-canopy.community-bg { background-color: transparent; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy { font-size: 14px; padding: 70px 33px 18px; }

.influencer-fan-club-conversion-page .user-canopy::after { background-image: linear-gradient(-180deg, transparent, rgba(0, 0, 0, 0.6) 99%); position: absolute; inset: 60% 0px 0px; content: " "; z-index: 1; }

.influencer-fan-club-conversion-page .user-canopy .user-header { right: 33px; left: 33px; }

.influencer-fan-club-conversion-page .user-canopy .link { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }

.influencer-fan-club-conversion-page .user-canopy .user-name { margin-left: 60px; margin-right: 60px; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .user-name { margin: 5px 30px; font-size: 24px; }

.influencer-fan-club-conversion-page .user-canopy .user-profile { margin-top: -8px; }

.influencer-fan-club-conversion-page .user-canopy .user-profile a { cursor: default; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .user-profile { font-size: 24px; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .user-profile .user-link { width: 65px; height: 65px; }

.influencer-fan-club-conversion-page .user-canopy .site-logo { z-index: 100; position: relative; width: 4.2em; display: block; margin: -40px auto 30px; opacity: 0.6; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .site-logo { margin: -60px auto 50px; }

.influencer-fan-club-conversion-page .user-canopy .fan-club-identity-img { z-index: 100; display: block; position: relative; margin: 7px auto 20px; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .fan-club-identity-img { margin: 15px auto; height: 42px; }

.influencer-fan-club-conversion-page .user-canopy .fan-club-features { font-size: 1em; z-index: 100; position: relative; display: flex; max-width: 80%; justify-content: space-around; text-align: center; margin: 35px auto 41px; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .fan-club-features { margin: 34px auto 29px; }

.influencer-fan-club-conversion-page .user-canopy .fan-club-features .feature-item { width: 8em; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .fan-club-features .feature-item { width: 6em; }

.influencer-fan-club-conversion-page .user-canopy .fan-club-features img { width: 4.4em; margin: 3px auto 7px; }

.influencer-fan-club-conversion-page .user-canopy .club-closed-msg { position: relative; z-index: 100; text-align: center; margin-bottom: 10px; }

.influencer-fan-club-conversion-page .user-canopy .fans-info { z-index: 100; margin-top: 8px; position: relative; display: flex; font-size: 21px; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; }

.is-mobile .influencer-fan-club-conversion-page .user-canopy .fans-info { color: rgb(179, 179, 179); }

.influencer-fan-club-conversion-page .user-canopy .fans-info .avatar-list { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-orient: horizontal; -webkit-box-direction: reverse; flex-direction: row-reverse; }

.influencer-fan-club-conversion-page .user-canopy .fans-info .avatar-list img { width: 1.2em; height: 1.2em; margin-right: -0.2em; border-radius: 50%; border: 1px solid rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px; }

.influencer-fan-club-conversion-page .user-canopy .fans-info .more-dots { line-height: 1.2em; margin-left: -1.1em; font-size: 0.75em; padding-left: 0.2em; }

.influencer-fan-club-conversion-page .user-canopy .fans-info .total-num { font-size: 0.75em; margin-left: 0.7em; }

.influencer-fan-club-conversion-page section.post-list.list-all-items-loaded .list-bottom-text { display: block; }

.influencer-fan-club-conversion-page section.post-list .list-bottom-text { text-align: center; font-size: 14px; display: none; margin: -31px auto 23px; color: rgb(173, 174, 187); }

.is-mobile .influencer-fan-club-conversion-page section.post-list .list-bottom-text { margin: 19px auto 87px; }

.main-page header.chat-header { position: relative; height: 320px; margin-bottom: 115px; }

.main-page header.chat-header .overlay { position: absolute; inset: 0px; z-index: 0; width: 100%; height: 100%; pointer-events: none; }

.main-page header.chat-header .overlay::after { display: block; content: ""; position: absolute; inset: 0px; z-index: 0; width: 100%; height: 100%; background: radial-gradient(rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.75)); }

.main-page header.chat-header > .content { position: relative; z-index: 10; display: flex; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; }

.main-page header.chat-header h1.title { margin: 0px; text-align: center; color: rgb(255, 255, 255); text-shadow: rgb(0, 0, 0) 0px 0px 5px; font-weight: 500; }

.main-page header.chat-header .orgranizer { position: absolute; z-index: 10; left: 0px; right: 0px; top: calc(100% - 50px); text-align: center; }

.main-page header.chat-header .orgranizer .avatar { border: 2px solid rgb(255, 255, 255); border-radius: 50%; margin: auto; overflow: hidden; width: 100px; height: 100px; box-shadow: rgba(0, 0, 0, 0.7) 2px 2px 2px; }

.main-page header.chat-header .orgranizer .nickname { font-size: x-large; line-height: 1.8; font-weight: 700; }

.main-page header.chat-header .orgranizer .muted { font-size: 14px; }

.dark-theme .main-page header.chat-header .orgranizer .muted { color: rgb(255, 255, 255); }

.main-page .chat-link { margin: 1em auto; text-align: center; }

.main-page .chat-link .btn { font-size: 16px; line-height: 19px; font-weight: 700; padding: 11px 18px; position: relative; }

.chat-main-page .chat-members { margin-bottom: 60px; }

.user-canopy { padding-top: 50px; padding-bottom: 16px; overflow: hidden; position: relative; z-index: 0; height: 350px; }

.user-canopy .user-header { inset: 0px; z-index: 0; position: absolute; }

.user-canopy .blocked-spacer { height: 40px; }

.user-canopy .user-interaction { position: relative; margin-top: 20px; z-index: 100; overflow: hidden; text-align: center; }

.user-canopy .user-interaction .action-btn, .user-canopy .user-interaction .follow-btn { display: inline-block; padding: 0px 12px; min-width: 120px; margin: 0px; }

.user-canopy .user-interaction .action-btn { border: 1px solid; text-align: center; color: rgb(255, 255, 255); position: relative; line-height: 34px; border-radius: 18px; margin-left: 10px; background: rgba(0, 0, 0, 0.5); }

.user-canopy .user-interaction .action-btn:hover { background: rgba(0, 0, 0, 0.7); }

.user-canopy .user-interaction .action-btn > .chat-icon { width: 18px; height: 18px; vertical-align: text-top; }

.user-canopy .user-interaction .action-btn .fa-spin { display: none; }

.user-canopy .user-interaction .action-btn.loading .fa-spin { display: inline-block; }

.user-canopy .user-interaction .action-btn.loading .normal-text { display: none; }

.user-canopy .user-profile { position: relative; left: 50%; transform: translateX(-50%); text-align: center; z-index: 100; max-width: 100%; }

.user-canopy .user-profile .influencer-badge { width: 29px; }

.user-canopy .team-amino-badge { background: rgb(29, 218, 143); position: absolute; width: 64px; height: 20px; padding: 0px 10px; border-radius: 10px; left: 50%; margin-left: -32px; margin-top: -20px; line-height: 16px; }

.user-canopy .user-link { width: 90px; height: 90px; border-radius: 50%; border: 4px solid rgb(255, 255, 255); overflow: hidden; display: inline-block; }

.user-canopy .user-avatar { width: 100%; height: 100%; background: rgba(0, 0, 0, 0.2); }

.user-canopy .link { color: rgb(255, 255, 255); display: block; }

.user-canopy .user-name { margin: 0.5rem 10px; font-size: 25px; }

.user-canopy .user-name-truncate { max-width: calc(100% - 40px); display: inline-block; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }

.user-canopy .user-name-truncate + .influencer-badge { vertical-align: text-top; }

.user-canopy .user-ranking { margin-top: 1rem; position: relative; text-align: center; }

.user-canopy .level-badge { position: absolute; left: 50%; margin-left: -62.5px; top: -3px; z-index: 1; }

.user-canopy .reputation-bar { color: rgb(255, 255, 255); display: inline-block; width: 125px; padding-left: 1.5rem; padding-right: 0.5rem; height: 16px; font-size: 10px; line-height: 14px; border: 1px solid rgb(255, 255, 255); border-radius: 12px; position: relative; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }

.user-canopy .reputation-bar::after { position: absolute; inset: 0px; width: 100%; height: 100%; content: " "; background: rgba(0, 0, 0, 0.5); z-index: -2; }

.user-canopy .rank-progress { background: linear-gradient(rgb(0, 199, 255), rgb(0, 149, 255)); display: block; position: absolute; height: 100%; top: 0px; left: 0px; z-index: -1; }

.user-canopy .counter-info { position: relative; width: 290px; height: 45px; left: 50%; margin-left: -145px; margin-top: 20px; display: flex; color: rgb(255, 255, 255); z-index: 100; }

.user-canopy .counter-info .counter { -webkit-box-flex: 1; flex-grow: 1; text-align: center; }

.user-canopy .counter-info .number { font-size: 24px; font-weight: 700; }

.user-canopy .counter-info .label { font-size: 12px; margin-top: 0.25em; opacity: 0.6; }

.user-canopy .counter-info-backdrop { top: auto; height: 100px; background: linear-gradient(transparent, rgba(0, 0, 0, 0.6)); }

.user-canopy .counter-info-backdrop, .user-canopy::before { position: absolute; left: 0px; right: 0px; bottom: 0px; width: 100%; content: " "; z-index: 1; }

.user-canopy::before { top: 0px; height: 100%; background: rgba(0, 0, 0, 0.5); }

.recommendation-sidebar section.author-aside .info { display: flex; -webkit-box-align: center; align-items: center; padding: 0px 12px; margin: 0.75em 0px 1.25em; }

.recommendation-sidebar section.author-aside .info > a.block { margin-right: 0.5rem; width: 40px; height: 40px; font-size: 40px; -webkit-box-flex: 0; flex: 0 0 auto; }

.recommendation-sidebar section.author-aside .info .nickname { font-weight: 700; }

.recommendation-sidebar section.author-aside .info .pretty-date { color: rgb(155, 155, 155); font-size: small; line-height: 1.2; }

.recommendation-sidebar section.author-aside .counters { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: justify; justify-content: space-between; padding: 0px 24px; color: rgb(96, 96, 96); }

.recommendation-sidebar section.author-aside .counters .counter { text-align: center; margin: 0px 2px; }

.recommendation-sidebar section.author-aside .counters .num { font-weight: 700; font-size: 18px; line-height: 1.5; }

.recommendation-sidebar section.author-aside .counters h5.label { margin: 0px; line-height: 1.5; font-weight: 400; font-size: 12px; color: rgb(155, 155, 155); }

.recommendation-sidebar section.leader-pick > [data-vce="carousel"] { height: 176px; }

.recommendation-sidebar section.leader-pick .carousel-item { width: 80px; height: auto; margin-right: 1em; }

.recommendation-sidebar section.leader-pick .carousel-item > .name { line-height: 15px; max-height: 30px; overflow: hidden; overflow-wrap: break-word; margin-top: 0.5rem; font-size: small; font-weight: 700; }

.recommendation-sidebar section.gallery .carousel-item { overflow: hidden; border-radius: 5px; width: 130px; height: 130px; margin: 0px 10px 10px 0px; }

.recommendation-sidebar section.gallery .carousel-item .title { font-size: medium; }

.recommendation-sidebar section.gallery .carousel-item .like { font-size: small; }

.recommendation-sidebar section.gallery .more-icon { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; -webkit-box-pack: center; place-content: center; color: rgb(255, 255, 255); }

.recommendation-sidebar section.gallery .more-icon i.amino-icon { -webkit-box-flex: 0; flex: 0 0 100%; text-align: center; font-size: 32px; margin-bottom: 0.25rem; }

.recommendation-sidebar section.gallery .more-icon:hover { background-image: radial-gradient(rgba(255, 255, 255, 0.5) 0px, rgba(255, 255, 255, 0.2) 20%, rgba(255, 255, 255, 0) 50%); }

.recommendation-sidebar .ad-block, .recommendation-sidebar section.author-aside, .recommendation-sidebar section.gallery, .recommendation-sidebar section.leader-pick, .recommendation-sidebar section.popular { border-radius: 5px; overflow: hidden; margin-bottom: 22px; box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 4px; background-color: rgb(255, 255, 255); }

.recommendation-sidebar .ad-block > h3.label, .recommendation-sidebar section.author-aside > h3.label, .recommendation-sidebar section.gallery > h3.label, .recommendation-sidebar section.leader-pick > h3.label, .recommendation-sidebar section.popular > h3.label { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; font-size: large; font-weight: 700; }

.recommendation-sidebar .ad-block > h3.label.with-margin, .recommendation-sidebar section.author-aside > h3.label.with-margin, .recommendation-sidebar section.gallery > h3.label.with-margin, .recommendation-sidebar section.leader-pick > h3.label.with-margin, .recommendation-sidebar section.popular > h3.label.with-margin { margin: 0.75em 0px; }

.recommendation-sidebar .ad-block article.post, .recommendation-sidebar section.author-aside article.post, .recommendation-sidebar section.gallery article.post, .recommendation-sidebar section.leader-pick article.post, .recommendation-sidebar section.popular article.post { margin-bottom: 1px; }

.recommendation-sidebar .ad-block a.more, .recommendation-sidebar section.author-aside a.more, .recommendation-sidebar section.gallery a.more, .recommendation-sidebar section.leader-pick a.more, .recommendation-sidebar section.popular a.more { padding: 0.75em 0px; text-align: center; }

.recommendation-sidebar .ad-block .scroll-container, .recommendation-sidebar section.author-aside .scroll-container, .recommendation-sidebar section.gallery .scroll-container, .recommendation-sidebar section.leader-pick .scroll-container, .recommendation-sidebar section.popular .scroll-container { left: 0.75em; right: 0.75em; width: auto; }

[data-vce="tab"] .tab-pane { display: none; }

[data-vce="tab"] .tab-pane.active { display: block; }

@media (min-width: 1207px) {
  .recommendation-sidebar section.author-aside .nickname { max-width: 360px; }
  section.site-content .breadcrumb > .content { max-width: 1140px; margin-left: auto; margin-right: auto; }
  .post-list .gallery > .side { display: none; }
  .post-list .post-poll .pollopt .voting .poll-item .label:hover .bar { background: rgb(58, 115, 183); }
}

@media (max-width: 480px) {
  .site-footer .container { padding-top: 15px; }
}

@media (min-width: 768px) {
  .site-footer .container { width: 750px; }
}

@media (min-width: 992px) {
  .site-footer .container { width: 970px; }
}

@media (min-width: 1200px) {
  .site-footer .container { width: 1120px; }
}

@media (min-width: 768px) and (max-width: 992px) {
  .site-footer .social-icons { padding-top: 0px; padding-bottom: 20px; }
}

@media only screen and (max-width: 767px) {
  .site-footer .amino-mobile { display: block; text-align: center; margin-bottom: 28px; }
  .site-footer { min-height: 194px; position: relative; }
  .site-footer .container { text-align: center; }
  .site-footer a { font-weight: 600; }
  .site-footer .social-icons { text-align: center; padding-top: 0px; }
  .site-footer .social-icons .icon { line-height: 40px; padding: 0px 10px; }
}

@media only screen and (max-width: 480px) {
  .site-footer .logo { padding-bottom: 15px; }
  .site-footer .container > a { float: none; display: block; line-height: 30px; }
}

@media only screen and (max-width: 360px) {
  .site-footer { position: relative; }
}

@media (min-width: 1206px) {
  section.global-body { max-width: 1186px; }
  .home-section-nav .home-fixed-container { max-width: 577px; }
  .global-header > .content .container { max-width: 1186px; }
  section.post-list.new-post-list > .list-item { max-width: 280px; }
}

@media (min-width: 1493px) {
  section.global-body { max-width: 1483px; }
  .home-section-nav .home-fixed-container { max-width: 873px; }
  .global-header > .content .container { max-width: 1483px; }
}

@media (min-width: 641px) and (max-width: 1206px) {
  .error-pages { max-width: 600px; }
  .site-content.error-container { min-height: calc(100vh - 113px); }
  .post-list .gallery > .gallery-item { width: 361.6px; height: 470.4px; }
  .post-list .gallery > .side > .gallery-item { height: 230.4px; }
  .post-list .gallery > .side > .gallery-item:first-child { margin-bottom: 9.6px; }
  .pinned-posts { padding-bottom: 0px; }
}

@media (max-width: 640px) {
  .site-content.error-container { min-height: calc(100vh - 246px); }
  .error-pages { padding-top: 40px; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; margin: auto 25px; }
  .error-pages h1.error-code { font-size: 100px; margin-bottom: 20px; }
  .error-pages h1 { font-size: 24px; }
  .error-pages .go-home-section { margin-top: 48px; }
  .error-pages .error-brand { text-align: right; -webkit-box-flex: 0; flex: 0 1 auto; }
  .error-pages .error-brand img { padding-top: 10px; width: 80%; }
  .main-catalog section.children .child { padding: 1em; }
  .pinned-posts > .list-item, .post-list > .list-item { padding: 3vw 3vw 0px; }
  .community-content > .search-keyword { padding: 20px 3vw 0px; }
  .post-list .gallery > .gallery-item { margin-right: 1.5vw; width: 56.5vw; height: 73.5vw; }
  .post-list .gallery > .side > .gallery-item { height: 36vw; }
  .post-list .gallery > .side > .gallery-item:first-child { margin-bottom: 1.5vw; }
  .post-list section.desc > .content { max-height: 2.8em; overflow: hidden; }
  .pinned-posts > .list-item > .content { margin-top: -2vw; }
  .main-shared-folder .folder .file { -webkit-box-flex: 1; flex: 1 0 auto; }
  .main-shared-folder-albums > .content > .album { -webkit-box-flex: 1; flex-grow: 1; }
  .main-about .btn.join { display: none; }
  section.main-download .btn-download-option, section.main-download .btn-join { margin-bottom: 12px; }
  section.main-download.blocked .btn-block-open { display: block; padding: 14px 0px; font-size: 20px; }
  .user-bio .bio-body { padding-left: 14px; padding-right: 14px; }
  .user-wiki .carousel-container { margin: 10px 20px 0px; }
  .user-posts section.post-list.new-post-list { padding-left: 3px; padding-right: 3px; }
  .user-posts .comment-bar { padding-left: 14px; padding-right: 14px; }
  .main-page header.chat-header { height: 220px; }
  .user-canopy .counter-info .number { font-size: 20px; }
}

@media (min-width: 641px) {
  .main-catalog section.children .child { margin: 0px 1em; padding: 1.5em 0.5em; }
  .main-shared-folder-albums > .content { padding: 10px 8px; }
  section.main-download > .content { top: 50%; transform: translate(-50%, -170px); width: 340px; }
  section.main-download > .content > .middle, section.main-download > .content > .middle-join { padding: 0px 2em 12px; }
  section.main-download .community-icon { margin: 0px -2em; }
  section.main-download .amino-id-and-tagline .howto { font-size: 18px; }
  section.main-download .card > .content { width: 340px; }
  section.main-download .footer .amino-logo { margin-bottom: 22px; }
  section.main-download.invite .footer { bottom: 0px; }
}

@media (max-width: 1206px) {
  .main-catalog section.children .sub-categories { height: 2.2em; }
  .main-about .info { width: 300px; }
}

<svg width="370" height="70" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><circle fill="#4A4A6C" cx="35" cy="35" r="35"/><circle fill="#4A4A6C" cx="135" cy="35" r="35"/><circle fill="#4A4A6C" cx="235" cy="35" r="35"/><circle fill="#4A4A6C" cx="335" cy="35" r="35"/><path d="M338.323 46.662A3.667 3.667 0 0 1 336.846 45c-.277-.646-.184-1.938-.184-4.154v-9.97h8.861v-6.922h-8.861V15h-5.447c-.277 2.03-.646 3.692-1.292 4.985-.646 1.292-1.477 2.4-2.585 3.323-1.107.923-2.769 1.661-4.338 2.123v5.446h5.17v13.57c0 1.753.184 3.138.553 4.06.37.924 1.015 1.847 1.939 2.678.923.83 2.123 1.477 3.415 1.938 1.385.462 2.4.646 4.154.646 1.569 0 2.954-.184 4.338-.461 1.293-.277 2.77-.831 4.431-1.662v-6.092c-1.938 1.292-3.877 1.938-5.815 1.938-1.016 0-2.031-.277-2.862-.83zM39.06 25.138c0-1.719.091-2.624 2.63-2.624h3.356V16h-5.35c-6.439 0-7.89 3.257-7.89 8.595v3.89H27V35h4.806v19h7.255V35h5.26l.725-6.514H39.06v-3.348zM155.38 20.032a16.105 16.105 0 0 1-5.111 1.97c-1.487-1.595-3.532-2.533-5.855-2.533-4.46 0-7.992 3.566-7.992 8.07 0 .656.093 1.219.186 1.876-6.69-.375-12.545-3.566-16.541-8.445-.65 1.22-1.115 2.534-1.115 4.035 0 2.815 1.393 5.254 3.53 6.662-1.3 0-2.508-.376-3.623-1.032v.093c0 3.941 2.787 7.131 6.412 7.882a7.85 7.85 0 0 1-2.138.281c-.557 0-1.022-.093-1.487-.187 1.023 3.19 3.996 5.536 7.435 5.63-2.695 2.157-6.226 3.47-9.944 3.47-.65 0-1.3 0-1.951-.093 3.531 2.252 7.713 3.66 12.267 3.66 14.682 0 22.767-12.292 22.767-22.894v-1.033c1.58-1.125 2.881-2.533 3.996-4.128-1.394.657-2.974 1.032-4.553 1.314 1.858-1.126 3.16-2.721 3.717-4.598zM246.829 16.086c-.086 0-.172-.086-.172-.086h-23.4c-.771.257-1.543.429-2.228.771-2.229 1.115-3.6 2.915-3.943 5.4 0 .086-.086.172-.086.172v23.4c.257.771.429 1.543.771 2.228 1.115 2.229 2.915 3.6 5.4 3.943.086 0 .172.086.172.086h23.4c.771-.257 1.543-.429 2.228-.771 2.229-1.115 3.6-2.915 3.943-5.4 0-.086.086-.172.086-.172v-23.4c-.257-.771-.429-1.543-.771-2.228-1.115-2.229-2.915-3.515-5.4-3.943zm1.885 15.685v13.543c0 1.543-.943 2.486-2.485 2.486h-22.715c-1.628 0-2.485-1.2-2.485-2.486V31.257h3c-.943 4.972.514 9.086 4.714 11.914 3.771 2.486 7.886 2.572 11.743.172 4.457-2.743 6-6.943 5.057-12.086h3c.171.257.171.429.171.514zM235 27.057c3.771 0 6.857 3.172 6.857 6.943 0 3.857-3.171 6.943-7.028 6.857-3.772 0-6.858-3.257-6.858-6.943 0-3.857 3.086-6.857 7.029-6.857zm9.086-6.857h1.2c.6 0 1.2 0 1.8.171 1.028.258 1.628 1.115 1.714 2.143v2.4c0 1.286-.943 2.229-2.229 2.315h-2.485c-1.2 0-2.229-1.029-2.229-2.229v-2.4c-.086-1.371.943-2.4 2.229-2.4z" fill="#040226"/></g></svg>


@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gTD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3g3D_vx3rCubqg.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gbD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gfD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gnD_vx3rCs.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gTD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3g3D_vx3rCubqg.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gbD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gfD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gnD_vx3rCs.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }



.modal .community-sidebar > .content, .modal aside.site-sidebar > .content { padding-bottom: 1em; }

.modal .community-sidebar, .modal aside.site-sidebar { display: block; z-index: 5010; }

.modal .community-sidebar > .content, .modal aside.site-sidebar > .content { z-index: 5010; inset: 0px 15% 0px 0px; min-width: 250px; overflow-y: scroll; padding-bottom: 100px; box-shadow: rgba(0, 0, 0, 0.5) 0px 0px 10px 1px; transition: transform 0.4s ease 0s, -webkit-transform 0.4s ease 0s; transform: translateX(-100%); }

.modal-transition .modal .community-sidebar > .content, .modal-transition .modal aside.site-sidebar > .content, .modal .modal-transition .community-sidebar > .content, .modal .modal-transition aside.site-sidebar > .content { transform: translateX(0px); }

.modal { display: none; }

.modal-open .modal { display: block; }

.modal-open .modal .overlay { opacity: 0; transition: all 0.2s ease 0s; }

.modal-open .modal .sidebar > .content { transform: translateX(-100%); transition: all 0.2s ease 0s; }

.modal-open .modal .popup { opacity: 0; transform: translateY(-75%); transition: all 0.2s ease 0s; }

.modal-transition .modal .overlay { opacity: 1; transition: all 0.4s ease 0s; }

.modal-transition .modal .overlay.community-bg { opacity: 0.9; }

.modal-transition .modal .sidebar > .content { opacity: 1; transform: translateX(0px); transition: all 0.4s ease 0s; }

.modal-transition .modal .popup { opacity: 1; transform: translateY(-50%); transition: all 0.4s ease 0s; }

.dark-theme .modal .btn.community-bg { background: rgb(246, 22, 60); }

.dark-theme .modal .btn.btn-cancel { background: transparent; color: rgb(255, 255, 255); }

.modal .overlay { position: fixed; z-index: 5000; inset: 0px; height: 100vh; }

.modal .overlay:not(.community-bg) { background-color: rgba(0, 0, 0, 0.6); }

.overlay-bright .modal .overlay { background-color: rgba(255, 255, 255, 0.8); }

.modal .popup { position: fixed; z-index: 5010; top: 50%; left: 0px; right: 0px; margin: auto; }

.modal .popup.dialog { width: 300px; border-radius: 5px; overflow: hidden; box-shadow: rgba(0, 0, 0, 0.25) 1px 2px 10px; background-color: rgb(255, 255, 255); text-align: center; }

.dark-theme .modal .popup.dialog { background: rgb(30, 28, 60); }

.modal .popup.small { height: 200px; }

.modal .popup .btn { width: 75%; font-size: 20px; margin: 0.5em 0px; }

.modal .popup .close.north-east { position: absolute; top: 0.5em; right: 0.5em; color: rgb(155, 155, 155); width: 2em; height: 2em; background: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTcuOTQgNS44ODZMMS43MS4xNWMtLjIwOC0uMi0uNTgxLS4yLS44MyAwTC4xNTYuOTUyYy0uMjA4LjItLjIwOC41NjEgMCAuODAxTDUuNzM2IDhsLTUuNTggNi4xNjJjLS4yMDguMi0uMjA4LjU2IDAgLjgwMWwuNzI0Ljg4N2MuMjA3LjIuNTguMi44MyAwbDYuMjMtNS43MzYgNi4yMyA1LjczNmMuMjUuMi42MjMuMi44MyAwbC43MjQtLjg4N2MuMjA4LS4yNC4yMDgtLjYgMC0uODAxTDEwLjE0MyA4bDUuNTgxLTYuMjQ3Yy4yMDgtLjI0LjIwOC0uNiAwLS44TDE1IC4xNWMtLjI0OS0uMi0uNjIyLS4yLS44MyAwTDcuOTQgNS44ODZ6IiBmaWxsPSIjOUI5QjlCIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=") 50% center / 1em 1em no-repeat; }

.modal .popup .close.underwater { position: absolute; bottom: -60px; left: 0px; right: 0px; margin: auto; width: 40px; height: 40px; background: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzUiIGhlaWdodD0iMzUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48Y2lyY2xlIHN0cm9rZT0iI0ZGRiIgc3Ryb2tlLXdpZHRoPSIyIiBjeD0iMTcuNSIgY3k9IjE3LjUiIHI9IjE2LjUiLz48cGF0aCBkPSJNMTcuOTQgMTUuODg2bC02LjIzLTUuNzM2Yy0uMjA4LS4yLS41ODEtLjItLjgzIDBsLS43MjQuODAyYy0uMjA4LjItLjIwOC41NjEgMCAuODAxTDE1LjczNiAxOGwtNS41OCA2LjE2MmMtLjIwOC4yLS4yMDguNTYgMCAuODAxbC43MjQuODg3Yy4yMDcuMi41OC4yLjgzIDBsNi4yMy01LjczNiA2LjIzIDUuNzM2Yy4yNS4yLjYyMy4yLjgzIDBsLjcyNC0uODg3Yy4yMDgtLjI0LjIwOC0uNiAwLS44MDFMMjAuMTQzIDE4bDUuNTgxLTYuMjQ3Yy4yMDgtLjI0LjIwOC0uNiAwLS44TDI1IDEwLjE1Yy0uMjQ5LS4yLS42MjItLjItLjgzIDBsLTYuMjMgNS43MzZ6IiBmaWxsPSIjRkZGIi8+PC9nPjwvc3ZnPg==") 50% center / contain; }

.modal .popup .close.corner { position: fixed; top: 0px; right: 0px; border-radius: 50%; padding: 0.4em; color: rgb(255, 255, 255); }

.modal .popup > .content { padding: 1em; }

.modal .popup > .content .card { color: rgb(255, 255, 255); padding: 0.75em; border-radius: 5px; background-color: rgba(0, 0, 0, 0.15); }

.modal .popup .popup-title { margin-top: 0px; }

.modal .popup .join-popup { padding-top: 40px; }

.modal .popup .join-popup img.logo { position: absolute; top: -40px; left: 0px; right: 0px; margin: auto; box-shadow: rgba(0, 0, 0, 0.5) 0px 1px 2px; width: 80px; height: 80px; border-radius: 18.08px; overflow: hidden; }

.modal .popup .copy-link-popup .copy-input { display: flex; -webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row nowrap; margin-bottom: 1em; border: 1px solid rgb(155, 155, 155); }

.modal .popup .copy-link-popup .copy-input input { -webkit-box-flex: 1; flex: 1 1 0%; background: rgb(233, 232, 239); border: none; border-radius: 0px; padding: 1em; min-width: 0px; }

.modal .popup .copy-link-popup .copy-input button.btn-copy { -webkit-box-flex: 0; flex: 0 1 50px; width: 50px; height: 50px; border-style: solid; border-color: rgb(155, 155, 155); border-image: initial; border-width: 0px 0px 0px 1px; background: rgb(255, 255, 255); padding: 0px; }

.modal .popup .copy-link-popup .copy-input button.btn-copy:active { background: rgb(233, 232, 239); }

.modal .popup .copy-link-popup i.fa { margin: 17px; }

.modal .popup .strip { height: 5px; }

.dark-theme .modal .popup .strip { display: none; }

.modal .popup .message-box-popup { padding: 0px 24px; }

.modal .popup .message-box-popup .message { color: rgb(65, 69, 73); }

.dark-theme .modal .popup .message-box-popup .message { color: rgb(255, 255, 255); }

.modal .popup .message-box-popup.alert .message { text-align: center; }

.modal .popup .message-box-popup.prompt .message { text-align: center; font-weight: 700; }

.modal .popup .message-box-popup .message { margin-top: 30px; text-align: left; }

.modal .popup .message-box-popup .input { height: 36px; line-height: 34px; border-radius: 8px; outline: none; border: 1px solid rgb(184, 184, 184); padding: 0px 12px; margin: 22px 0px 0px; width: 100%; }

.modal .popup .message-box-popup .input::-webkit-input-placeholder { color: rgb(189, 189, 189); }

.modal .popup .message-box-popup .input::placeholder { color: rgb(189, 189, 189); }

.modal .popup .message-box-popup .input:focus { box-shadow: rgba(0, 0, 0, 0.3) 0px 0px 5px inset; border-color: rgb(138, 140, 155); }

.modal .popup .message-box-popup .actions { display: flex; -webkit-box-pack: center; justify-content: center; margin-top: 22px; margin-bottom: 14px; }

.modal .popup .message-box-popup .actions .btn { position: relative; height: 40px; padding: 0px 1em; border-radius: 8px; border: 1px solid; line-height: 38px; -webkit-box-flex: 1; flex: 1 0 90px; max-width: 120px; font-size: 14px; box-shadow: none; }

.modal .popup .message-box-popup .actions .btn:not(.community-color) { color: rgb(255, 255, 255); }

.modal .popup .message-box-popup .actions .btn.community-bg { border-color: transparent; }

.modal .popup .message-box-popup .actions .btn:not([disabled]):hover::before { position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; content: ""; background-color: rgba(0, 0, 0, 0.05); }

.modal .popup .message-box-popup .actions .btn:active { transform: none; }

.modal .popup .message-box-popup .actions .btn-cancel { margin-right: auto; }

.modal .popup .message-box-popup .actions .btn-cancel:not(:hover) { background: rgb(255, 255, 255); }

.dark-theme .modal .popup .message-box-popup .actions .btn-cancel:not(:hover) { background: transparent; }

.dark-theme .modal .popup .message-box-popup .actions .btn-cancel:hover { background: rgba(255, 255, 255, 0.1); }

.modal .popup .message-box-popup .actions .btn-cancel::before { display: none; }

.modal .popup .message-box-popup.initiate-single-chat-prompt .actions { margin-top: 14px; }

.modal .swipe-indicator { position: fixed; z-index: 5020; top: 50%; margin-top: -1.5em; width: 3em; height: 3em; border-radius: 50%; box-shadow: rgba(0, 0, 0, 0.75) 0px 0px 5px; text-align: center; color: rgb(255, 255, 255); background: rgba(0, 0, 0, 0.5); opacity: 0; transition: transform 0.25s ease 0s, opacity 0.5s ease 0s, -webkit-transform 0.25s ease 0s; }

.modal .swipe-indicator-left.swiped, .modal .swipe-indicator-left.swiping, .modal .swipe-indicator-right.swiped, .modal .swipe-indicator-right.swiping { opacity: 1; transition: transform 0.5s ease 0s, opacity 0.5s ease 0s, -webkit-transform 0.5s ease 0s; }

.modal .swipe-indicator-left { right: 0px; transform: translateX(100%); }

.modal .swipe-indicator-left.swiping { transform: translateX(20%); }

.modal .swipe-indicator-left.swiped { transform: translateX(-50%); }

.modal .swipe-indicator-right { left: 0px; transform: translateX(-100%); }

.modal .swipe-indicator-right.swiping { transform: translateX(-20%); }

.modal .swipe-indicator-right.swiped { transform: translateX(50%); }

.modal .swipe-indicator.swiping-failed i.fa::before { content: ""; color: red; }

.head-only .modal .community-sidebar { display: block; }

.modal .community-sidebar > .content { height: 100vh; }

.modal .community-sidebar .sidebar-section { margin-left: 0px; margin-right: auto; }

.modal .community-sidebar .sidebar-section.community-info { margin-left: auto; }

.modal .highlight-following { font-size: 18px; font-weight: 700; text-shadow: rgba(0, 0, 0, 0.3) 0px 0px 2px; }

.modal .highlight-following .emoji { height: 36px; width: 36px; }

.grecaptcha-badge { opacity: 0; }

.modal .login-dialog .create-account-area .choose-method-head { display: flex; flex-wrap: wrap; -webkit-box-pack: center; justify-content: center; padding-top: 120px; }

.modal .login-dialog .create-account-area .choose-method-head p { width: 100%; font-family: Montserrat; font-weight: 600; font-size: 22px; margin: 10px 0px; }

.modal .login-dialog .create-account-area .choose-method-head .choose-method-divider { margin: 30px 0px 15px; border: 1px solid rgba(0, 0, 0, 0.2); width: 53px; }

.modal .login-dialog .create-account-area h2 { font-family: Montserrat; font-weight: 600; color: rgb(60, 194, 129); font-size: 40px; margin: 0px; }

.modal .login-dialog .create-account-area img.choose-method-logo { height: 44px; }

.modal .login-dialog .create-account-area .head-img { margin-top: 60px; }

.modal .login-dialog .create-account-area .verify-code .popup-title { margin-top: 166px; }

.modal .login-dialog .create-account-area .create-profile .popup-title { margin-top: 126px; }

.modal .login-dialog .create-account-area .two-factor-auth .popup-title { margin-top: 120px; }

.modal .login-dialog .create-account-area .two-factor-auth-email .head-img-phone { display: none; }

.modal .login-dialog .create-account-area .two-factor-auth-email .single-method .verify-email-tip { display: block; margin: 30px 0px; }

.modal .login-dialog .create-account-area .two-factor-auth-phone .head-img-email { display: none; }

.modal .login-dialog .create-account-area .two-factor-auth-phone .single-method .verify-phone-tip { display: block; margin: 30px 0px; }

.modal .login-dialog .create-account-area .two-factor-auth .single-method .step-button-group button { margin: 5px; }

.head-img { margin-top: 60px; }

.head-img.head-delete-account { margin-top: 15px; }

.tip-text { font-family: Montserrat; text-align: center; font-size: 32px; font-weight: 700; color: rgb(0, 0, 0); margin: 20px 0px 30px; }

.tip-text.small { font-size: 18px; font-weight: 100; margin: 0px 0px 10px; }

.tip-text.small.grey { color: rgba(0, 0, 0, 0.6); }

.tip-text.small.identity, .tip-text.small strong { font-weight: 700; }

.login-buttons { display: flex; -webkit-box-pack: center; justify-content: center; -webkit-box-align: baseline; align-items: baseline; }

.login-buttons a { margin-right: 10px; line-height: 36px; color: rgb(29, 218, 143); border: 1px solid rgb(29, 218, 143); background-color: rgb(255, 255, 255); border-radius: 18px; min-width: 248px; }

.login-dialog { width: 770px; height: 600px; border-radius: 20px; overflow: hidden; font-size: 12px; text-align: center; box-shadow: rgba(0, 0, 0, 0.15) 0px 20px 40px 3px, rgba(0, 0, 0, 0.1) 0px 10px 40px 8px, rgba(0, 0, 0, 0.2) 0px 10px 15px -10px; background: rgb(255, 255, 255); color: rgb(127, 127, 127); }

.login-dialog > .content { border-radius: 20px; background: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzMwIiBoZWlnaHQ9IjI0MCIgdmlld0JveD0iMCAwIDMzMCAyNDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgb3BhY2l0eT0iLjgiIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMTQwLjI3MS0zLjkwM2MtOS4xMDUgMC0xNi41MTIgNy40NjYtMTYuNTEyIDE2LjY0MyAwIDkuMTc2IDcuNDA3IDE2LjY0MiAxNi41MTIgMTYuNjQyIDkuMTA0IDAgMTYuNTExLTcuNDY2IDE2LjUxMS0xNi42NDIgMC05LjE3Ny03LjQwNy0xNi42NDMtMTYuNTExLTE2LjY0M3ptMCAzOS4xNTljLTEyLjMxOCAwLTIyLjMzOS0xMC4xLTIyLjMzOS0yMi41MTYgMC0xMi40MTUgMTAuMDIxLTIyLjUxNiAyMi4zMzktMjIuNTE2IDEyLjMxOCAwIDIyLjMzOSAxMC4xIDIyLjMzOSAyMi41MTYgMCAxMi40MTUtMTAuMDIxIDIyLjUxNi0yMi4zMzkgMjIuNTE2eiIgZmlsbD0iI0E3NjRFQiIvPjxwYXRoIGQ9Ik0xOS4yNTUgMjE4LjAzMWMtNC45MSAwLTguOTA0IDQuMDI2LTguOTA0IDguOTc0IDAgNC45NDkgMy45OTUgOC45NzUgOC45MDQgOC45NzUgNC45MSAwIDguOTA0LTQuMDI2IDguOTA0LTguOTc1IDAtNC45NDgtMy45OTQtOC45NzQtOC45MDQtOC45NzR6bTAgMjEuMTE2Yy02LjY0MiAwLTEyLjA0Ni01LjQ0Ny0xMi4wNDYtMTIuMTQyIDAtNi42OTUgNS40MDQtMTIuMTQyIDEyLjA0Ni0xMi4xNDIgNi42NDMgMCAxMi4wNDcgNS40NDcgMTIuMDQ3IDEyLjE0MiAwIDYuNjk1LTUuNDA0IDEyLjE0Mi0xMi4wNDcgMTIuMTQyeiIgZmlsbD0iIzU3MzJEOSIvPjxwYXRoIGQ9Ik0tMTMuNTgzIDY3LjM1OWw4LjktMS4zMi0yLjM1NS0xOC4yODhMOS43OSA0NC45MTQgNy40NTcgMjkuMTA5bDE3Ljg1LTIuNjQ1LTIuNTU2LTE3LjMyNiAyMC40MDQtMy4wMjMgMS41NTQgMTAuNTI3LTkuODg3IDEuNDY2IDIuNTU3IDE3LjMyNS0xNy44NSAyLjY0NSAyLjMwMiAxNS41OTctMTcuMDE2IDIuODcgMi4zODIgMTguNDkyLTE5LjIyNyAyLjg1LTEuNTUzLTEwLjUyOHoiIGZpbGw9IiM3QjU3QTMiLz48cGF0aCBkPSJNLTI3LjExNCAxODIuMzM4bDUuODg3IDIuMzY0IDQuOTMzLTExLjk5MSAxMS4yNSA0LjI1OCA0LjA4My0xMC40NjggMTEuODA2IDQuNzQgNC40NzUtMTEuNDc1IDEzLjQ5NyA1LjQxOC0yLjcyIDYuOTczLTYuNTM5LTIuNjI1LTQuNDc1IDExLjQ3Ni0xMS44MDctNC43NDEtNC4wMjggMTAuMzMxLTExLjM3Ni00LjMwNi00Ljk4OCAxMi4xMjUtMTIuNzE4LTUuMTA2IDIuNzItNi45NzN6IiBmaWxsPSIjQTc2NEVCIi8+PHBhdGggZD0iTTEyNi45OTQgODUuNjMzYy03LjYyNyAwLTEzLjgzMiA2LjQ3NS0xMy44MzIgMTQuNDMzIDAgNy45NTkgNi4yMDUgMTQuNDM0IDEzLjgzMiAxNC40MzQgNy42MjcgMCAxMy44MzItNi40NzUgMTMuODMyLTE0LjQzNCAwLTcuOTU4LTYuMjA1LTE0LjQzMy0xMy44MzItMTQuNDMzem0wIDMzLjk2MWMtMTAuMzE5IDAtMTguNzE0LTguNzYtMTguNzE0LTE5LjUyNyAwLTEwLjc2OCA4LjM5NS0xOS41MjggMTguNzE0LTE5LjUyOCAxMC4zMTggMCAxOC43MTMgOC43NiAxOC43MTMgMTkuNTI4IDAgMTAuNzY3LTguMzk1IDE5LjUyNy0xOC43MTMgMTkuNTI3eiIgZmlsbD0iIzQzQzJEMCIvPjxwYXRoIGQ9Ik0xNy4yNTcgODQuNjIxYy05LjM1IDAtMTYuOTU1IDcuNjktMTYuOTU1IDE3LjE0IDAgOS40NTEgNy42MDYgMTcuMTQgMTYuOTU1IDE3LjE0IDkuMzQ5IDAgMTYuOTU1LTcuNjg5IDE2Ljk1NS0xNy4xNCAwLTkuNDUtNy42MDYtMTcuMTQtMTYuOTU1LTE3LjE0em0wIDQwLjMyOGMtMTIuNjQ5IDAtMjIuOTQtMTAuNDAyLTIyLjk0LTIzLjE4OSAwLTEyLjc4NiAxMC4yOTEtMjMuMTg5IDIyLjk0LTIzLjE4OSAxMi42NDggMCAyMi45MzkgMTAuNDAzIDIyLjkzOSAyMy4xODkgMCAxMi43ODctMTAuMjkgMjMuMTg5LTIyLjk0IDIzLjE4OXoiIGZpbGw9IiNFRTQzNTgiLz48cGF0aCBkPSJNNTguNzggMTAuMzYyYzAgMy4wMzMtMi40MzIgNS40OTItNS40MzMgNS40OTItMyAwLTUuNDMzLTIuNDU5LTUuNDMzLTUuNDkyczIuNDMzLTUuNDkyIDUuNDMzLTUuNDkyIDUuNDMzIDIuNDU5IDUuNDMzIDUuNDkyeiIgZmlsbD0iIzU3MzJEOSIvPjxwYXRoIGQ9Ik00Ny45MTQgNDguMTk2Yy02LjY2OCAwLTEyLjA3My01LjQ2NC0xMi4wNzMtMTIuMjA0czUuNDA1LTEyLjIwNSAxMi4wNzMtMTIuMjA1IDEyLjA3MyA1LjQ2NCAxMi4wNzMgMTIuMjA1YzAgNi43NC01LjQwNSAxMi4yMDQtMTIuMDczIDEyLjIwNHoiIGZpbGw9IiNFRTQzNTgiLz48cGF0aCBkPSJNMTEzLjMxMiAzNC42MDJsLTguNzU2LjM4LS4zODctOC4xODgtMTQuNDEuNjI1LS42OTgtMTQuNzgyLTEyLjk3My41NjItLjk1LTE0LjEyLTE1LjM1Mi4zODQtLjc1My0xNS45MjMgOC43NTYtLjM4LjM0OSA3LjM3MSAxNS4xODEtLjM4Ljk0MSAxMy45NjUgMTMuMTQ0LS41Ny43IDE0Ljc4MyAxNC40MDktLjYyNS43OTkgMTYuODk4eiIgZmlsbD0iIzQzQzJEMCIvPjxwYXRoIGQ9Ik0xMTQuMzE3IDUxLjQ0OWMwIDUuMzkyLTQuMzI1IDkuNzY0LTkuNjU5IDkuNzY0LTUuMzM0IDAtOS42NTgtNC4zNzItOS42NTgtOS43NjQgMC01LjM5MiA0LjMyNC05Ljc2NCA5LjY1OC05Ljc2NHM5LjY1OSA0LjM3MiA5LjY1OSA5Ljc2NHoiIGZpbGw9IiM3QjU3QTMiLz48cGF0aCBkPSJNMTcyLjI2OCA3NC40MzdjMCAyLjY5Ni0yLjE2MiA0Ljg4Mi00LjgyOSA0Ljg4MnMtNC44MjktMi4xODYtNC44MjktNC44ODJjMC0yLjY5NiAyLjE2Mi00Ljg4MiA0LjgyOS00Ljg4MnM0LjgyOSAyLjE4NiA0LjgyOSA0Ljg4MnoiIGZpbGw9IiNGNkIzQzciLz48cGF0aCBkPSJNMTMxLjIxOS00Ljg5M2MwIDQuNzE4LTMuNzgzIDguNTQzLTguNDUxIDguNTQzLTQuNjY3IDAtOC40NTEtMy44MjUtOC40NTEtOC41NDMgMC00LjcxOSAzLjc4NC04LjU0NCA4LjQ1MS04LjU0NCA0LjY2OCAwIDguNDUxIDMuODI1IDguNDUxIDguNTQ0em04Ni4wNjkgNDMuMDMzYzAgNC43MTktMy43ODQgOC41NDQtOC40NTEgOC41NDQtNC42NjggMC04LjQ1Mi0zLjgyNS04LjQ1Mi04LjU0MyAwLTQuNzE5IDMuNzg0LTguNTQ0IDguNDUyLTguNTQ0IDQuNjY3IDAgOC40NTEgMy44MjUgOC40NTEgOC41NDR6IiBmaWxsPSIjRUU0MzU4Ii8+PHBhdGggZD0iTTIwMi40NTIgMjAuMTI2YzAgMy4wMzQtMi40MzMgNS40OTItNS40MzMgNS40OTItMy4wMDEgMC01LjQzMy0yLjQ1OC01LjQzMy01LjQ5MiAwLTMuMDMzIDIuNDMyLTUuNDkyIDUuNDMzLTUuNDkyIDMgMCA1LjQzMyAyLjQ2IDUuNDMzIDUuNDkyek02Ny4yMzEgOTUuNzk1YzAgMy4wMzQtMi40MzIgNS40OTItNS40MzMgNS40OTItMyAwLTUuNDMzLTIuNDU5LTUuNDMzLTUuNDkyczIuNDMzLTUuNDkyIDUuNDMzLTUuNDkyIDUuNDMzIDIuNDYgNS40MzMgNS40OTJ6TTIyNi45MjMgNy44NzJjLjE1Ni0uMjgzLjItLjYyLjExMy0uOTQ0YTEuMjM2IDEuMjM2IDAgMCAwLS41NzEtLjc0OSAxLjE3OCAxLjE3OCAwIDAgMC0uOTE5LS4xMTYgMS4yMTMgMS4yMTMgMCAwIDAtLjg4IDEuMTY0Yy40OS40My45OTguODQgMS41MjQgMS4yMzJsLjAwNC0uMDAxYy4zMTQtLjA5LjU3My0uMzAyLjcyOS0uNTg2ek0yMjUuMjYuMDc0YTEuMTk1IDEuMTk1IDAgMCAwLS45MTgtLjExNCAxLjIwNiAxLjIwNiAwIDAgMC0uNzI3LjU3NSAxLjIyOSAxLjIyOSAwIDAgMCAuNDU3IDEuNjYzYy4yNzYuMTU4LjYwMy4yMDIuOTE3LjExNC4zMTMtLjA4OC41NzEtLjI5Ny43MjctLjU3NWExLjIyOSAxLjIyOSAwIDAgMC0uNDU2LTEuNjYzem01Ljc2NSAxLjAxN2ExLjIgMS4yIDAgMCAwIC43MjgtLjU3NSAxLjIzIDEuMjMgMCAwIDAtLjQ1Ny0xLjY2MiAxLjE5MiAxLjE5MiAwIDAgMC0uOTE3LS4xMTQgMS4yMDggMS4yMDggMCAwIDAtLjcyOC41NzUgMS4yMyAxLjIzIDAgMCAwIC40NTcgMS42NjNjLjI3My4xNTYuNjAxLjIwMi45MTcuMTEzem0xLjQ3OCAzLjg2NGExLjE5IDEuMTkgMCAwIDAtLjkxNi0uMTEzIDEuMjA0IDEuMjA0IDAgMCAwLS43MjguNTc1IDEuMjMgMS4yMyAwIDAgMC0uMTEzLjkyNyAxLjIwOSAxLjIwOSAwIDAgMCAxLjQ4Ni44NDljLjMxNi0uMDg5LjU3NC0uMjk4LjcyOC0uNTc1LjE1NS0uMjc3LjItLjYwOC4xMTMtLjkyN2ExLjIxNiAxLjIxNiAwIDAgMC0uNTctLjczNnptMS43NzcgNS44ODVjLS4wODgtLjQxNC0uMjk2LS43NTItLjU3MS0uOTU1YS45NjMuOTYzIDAgMCAwLS45Mi0uMTQ4Yy0uMzE3LjExNS0uNTc1LjM4Ny0uNzMuNzQ3YTEuOTUzIDEuOTUzIDAgMCAwLS4xNS42NjhjLjcyMi4zNjYgMS40NjEuNjg5IDIuMjE3Ljk2OC4wMTMtLjAyNi4wMjktLjA1LjA0MS0uMDc3LjE1Ni0uMzYuMjAxLS43OS4xMTMtMS4yMDN6bTQuMzM3IDEuNTA2YTEuMzk3IDEuMzk3IDAgMCAwLTEuMTc3LS4xNjIgMS41MTIgMS41MTIgMCAwIDAtLjcwMS40NzhjLjc5NS4xMiAxLjYuMjA5IDIuNDE0LjI2NGExLjYzNSAxLjYzNSAwIDAgMC0uNTM2LS41OHptLTEuMjg0LTYuMTdhMS4yMDQgMS4yMDQgMCAwIDAtMS42NDUuNDYyIDEuMjI2IDEuMjI2IDAgMCAwIC40NTcgMS42NjNjLjI3NC4xNTYuNjAyLjIwMS45MTcuMTEzYTEuMjI3IDEuMjI3IDAgMCAwIC4yNzEtMi4yMzh6bS0uNzUxLTEuOTk5YTEuMjI4IDEuMjI4IDAgMCAwLS40NTctMS42NjIgMS4yMDIgMS4yMDIgMCAwIDAtMS42NDQuNDYyIDEuMjI4IDEuMjI4IDAgMCAwIC40NTcgMS42NjJjLjI3NS4xNTguNjAyLjIwMi45MTcuMTE0LjMxNC0uMDg5LjU3Mi0uMjk3LjcyNy0uNTc2em01LjMwOS41NzZhMS4yMjUgMS4yMjUgMCAwIDAgLjI3MS0yLjIzOCAxLjE5MyAxLjE5MyAwIDAgMC0uOTE3LS4xMTQgMS4yMDcgMS4yMDcgMCAwIDAtLjcyOC41NzUgMS4yMyAxLjIzIDAgMCAwIC40NTcgMS42NjNjLjI3NC4xNTcuNjAxLjIwMi45MTcuMTE0em0xLjQ3OCAxLjQyM2ExLjE5MSAxLjE5MSAwIDAgMC0uOTE3LS4xMTMgMS4yMjYgMS4yMjYgMCAwIDAtLjI3MSAyLjIzOCAxLjIwNSAxLjIwNSAwIDAgMCAxLjY0NS0uNDYyYy4xNTUtLjI3Ny4yLS42MDkuMTEzLS45MjdhMS4yMTUgMS4yMTUgMCAwIDAtLjU3LS43MzZ6bTEuMzA3IDQuODYxYTEuNTYyIDEuNTYyIDAgMCAwLS45OS0uMDk4IDEuMjkgMS4yOSAwIDAgMC0uNzg2LjUuOTY3Ljk2NyAwIDAgMC0uMTI1LjI2NiAzNC4zNCAzNC4zNCAwIDAgMCAyLjQxNS0uMjM0IDEuMTk4IDEuMTk4IDAgMCAwLS41MTQtLjQzNHptNC4wOTItMS42NjdhMS4yMzYgMS4yMzYgMCAwIDAtLjU2OS0uNzUgMS4xNzMgMS4xNzMgMCAwIDAtLjkxNy0uMTE2Yy0uMzE2LjA5LS41NzMuMzA0LS43MjguNTg2LS4xNTUuMjgzLS4yLjYyLS4xMTIuOTQ0LjA4Ny4zMjUuMjk0LjU5LjU2OS43NS4wOTEuMDUzLjE4OS4wODguMjkuMTE1LjQxMS0uMTE5LjgxOC0uMjQ3IDEuMjE5LS4zODdhMS4yNzUgMS4yNzUgMCAwIDAgLjI0OC0xLjE0M3ptLTEuNzc3LTUuNjM1YTEuMTkzIDEuMTkzIDAgMCAwLS45MTctLjExMyAxLjIwNyAxLjIwNyAwIDAgMC0uNzI4LjU3NSAxLjIzMSAxLjIzMSAwIDAgMCAuNDU3IDEuNjYzIDEuMjA1IDEuMjA1IDAgMCAwIDEuNjQ1LS40NjIgMS4yMjcgMS4yMjcgMCAwIDAtLjQ1Ny0xLjY2M3ptLjQ1Ny0zLjIxOWExLjIyOCAxLjIyOCAwIDAgMC0uNDU3LTEuNjYzIDEuMjAzIDEuMjAzIDAgMCAwLTEuNjQ0LjQ2MiAxLjIyOCAxLjIyOCAwIDAgMCAuNDU2IDEuNjYzIDEuMTk1IDEuMTk1IDAgMCAwIDEuNjQ1LS40NjJ6bTIuODk0LjU3NWMuMzE2LS4wODguNTczLS4yOTguNzI4LS41NzVhMS4yMjYgMS4yMjYgMCAwIDAtLjQ1Ny0xLjY2MiAxLjE5IDEuMTkgMCAwIDAtLjkxNy0uMTE0IDEuMjA1IDEuMjA1IDAgMCAwLS43MjguNTc1IDEuMjMgMS4yMyAwIDAgMCAuNDU3IDEuNjYzYy4yNzQuMTU2LjYwMS4yMDIuOTE3LjExM3ptMS40NzkgMi42NDRhMS4xOTQgMS4xOTQgMCAwIDAtLjkxNy0uMTEzIDEuMjA1IDEuMjA1IDAgMCAwLS43MjguNTc1IDEuMjI2IDEuMjI2IDAgMCAwIC40NTcgMS42NjNjLjI3NC4xNTYuNjAxLjIwMi45MTcuMTEzLjMxNS0uMDg5LjU3Mi0uMjk4LjcyOC0uNTc1YTEuMjMgMS4yMyAwIDAgMC0uNDU3LTEuNjYzem0xLjA5MSAzLjU0NWMtLjE4NS4wODgtLjMzNy4yOTctLjQyOS41NzQtLjAyLjA2LS4wMzUuMTI0LS4wNDkuMTkuMjcxLS4yNDguNTM3LS41MS43OTctLjc4NGEuNDI0LjQyNCAwIDAgMC0uMzE5LjAyem0zLjczOC00Ljc2NWExLjIwNCAxLjIwNCAwIDAgMC0xLjY0NS40NjIgMS4yMjcgMS4yMjcgMCAwIDAgLjQ1NyAxLjY2MiAxLjIwNSAxLjIwNSAwIDAgMCAxLjY0NS0uNDYyIDEuMjMyIDEuMjMyIDAgMCAwLS40NTctMS42NjJ6IiBmaWxsPSIjN0I1N0EzIi8+PC9nPjwvc3ZnPg==") no-repeat, url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzM4IiBoZWlnaHQ9IjIwOSIgdmlld0JveD0iMCAwIDMzOCAyMDkiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgb3BhY2l0eT0iLjgiIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMTgwLjI3MS0xNS45MDJjLTkuMTA1IDAtMTYuNTEyIDcuNDY1LTE2LjUxMiAxNi42NDIgMCA5LjE3NiA3LjQwNyAxNi42NDIgMTYuNTEyIDE2LjY0MiA5LjEwNCAwIDE2LjUxMS03LjQ2NiAxNi41MTEtMTYuNjQyIDAtOS4xNzctNy40MDctMTYuNjQyLTE2LjUxMS0xNi42NDJ6bTAgMzkuMTU4Yy0xMi4zMTggMC0yMi4zMzktMTAuMS0yMi4zMzktMjIuNTE2IDAtMTIuNDE1IDEwLjAyMS0yMi41MTYgMjIuMzM5LTIyLjUxNiAxMi4zMTggMCAyMi4zMzkgMTAuMSAyMi4zMzkgMjIuNTE2IDAgMTIuNDE1LTEwLjAyMSAyMi41MTYtMjIuMzM5IDIyLjUxNnoiIGZpbGw9IiNBNzY0RUIiLz48cGF0aCBkPSJNMjk0LjAxIDE2LjAwM2MtOS4xMDUgMC0xNi41MTIgNy40NjYtMTYuNTEyIDE2LjY0MiAwIDkuMTc3IDcuNDA3IDE2LjY0MyAxNi41MTIgMTYuNjQzIDkuMTA0IDAgMTYuNTExLTcuNDY2IDE2LjUxMS0xNi42NDMgMC05LjE3Ni03LjQwNy0xNi42NDItMTYuNTExLTE2LjY0MnptMCAzOS4xNThjLTEyLjMxOCAwLTIyLjMzOS0xMC4xLTIyLjMzOS0yMi41MTUgMC0xMi40MTYgMTAuMDIxLTIyLjUxNiAyMi4zMzktMjIuNTE2IDEyLjMxNyAwIDIyLjMzOSAxMC4xIDIyLjMzOSAyMi41MTYgMCAxMi40MTUtMTAuMDIyIDIyLjUxNS0yMi4zMzkgMjIuNTE1ek0xMC42NDYgMTEuNzg3YzAgMi4zNi0xLjg5MiA0LjI3Mi00LjIyNiA0LjI3MnMtNC4yMjYtMS45MTMtNC4yMjYtNC4yNzJjMC0yLjM2IDEuODkyLTQuMjcyIDQuMjI2LTQuMjcyczQuMjI2IDEuOTEzIDQuMjI2IDQuMjcyeiIgZmlsbD0iIzQzQzJEMCIvPjxwYXRoIGQ9Ik05OC43OC0xLjYzOGMwIDMuMDMzLTIuNDMyIDUuNDkyLTUuNDMzIDUuNDkyLTMgMC01LjQzMy0yLjQ1OS01LjQzMy01LjQ5MnMyLjQzMy01LjQ5MiA1LjQzMy01LjQ5MiA1LjQzMyAyLjQ1OSA1LjQzMyA1LjQ5MnoiIGZpbGw9IiM1NzMyRDkiLz48cGF0aCBkPSJNMzI0LjgyMyAxNDEuMDE0bC0xMi41MjktMS44NDggMS43MTUtMTEuNzExLTIwLjYxNy0zLjA0IDMuMDk2LTIxLjE0NS0xOC41NjEtMi43MzcgMi41NTYtMjAuMjc1LTIxLjg4OS0zLjYzOCAzLjMzNi0yMi43NzYgMTIuNTI5IDEuODQ3LTEuNTQ0IDEwLjU0NCAyMS42NDYgMy42LTIuNTI3IDIwLjA1IDE4LjgwOCAyLjc3My0zLjA5NyAyMS4xNDUgMjAuNjE4IDMuMDQtMy41NCAyNC4xNzF6IiBmaWxsPSIjQTc2NEVCIi8+PHBhdGggZD0iTTE1My4zMTIgMjIuNjAybC04Ljc1Ni4zOC0uMzg3LTguMTg4LTE0LjQwOS42MjUtLjY5OS0xNC43ODItMTIuOTczLjU2Mi0uOTUxLTE0LjEyLTE1LjM1MS4zODMtLjc1My0xNS45MjIgOC43NTYtLjM4LjM0OSA3LjM3MSAxNS4xODItLjM4Ljk0IDEzLjk2NSAxMy4xNDQtLjU3LjcgMTQuNzgzIDE0LjQwOS0uNjI1Ljc5OSAxNi44OTh6IiBmaWxsPSIjNDNDMkQwIi8+PHBhdGggZD0iTTE1NC4zMTcgMzkuNDQ5YzAgNS4zOTItNC4zMjUgOS43NjQtOS42NTkgOS43NjQtNS4zMzQgMC05LjY1OC00LjM3Mi05LjY1OC05Ljc2NCAwLTUuMzkyIDQuMzI0LTkuNzY0IDkuNjU4LTkuNzY0czkuNjU5IDQuMzcyIDkuNjU5IDkuNzY0eiIgZmlsbD0iIzdCNTdBMyIvPjxwYXRoIGQ9Ik0yMTIuMjY4IDYyLjQzN2MwIDIuNjk2LTIuMTYyIDQuODgyLTQuODI5IDQuODgycy00LjgyOS0yLjE4Ni00LjgyOS00Ljg4MmMwLTIuNjk2IDIuMTYyLTQuODgyIDQuODI5LTQuODgyczQuODI5IDIuMTg2IDQuODI5IDQuODgyeiIgZmlsbD0iI0Y2QjNDNyIvPjxwYXRoIGQ9Ik0yNTcuMjg4IDI2LjE0YzAgNC43MTktMy43ODQgOC41NDQtOC40NTEgOC41NDQtNC42NjggMC04LjQ1Mi0zLjgyNS04LjQ1Mi04LjU0MyAwLTQuNzE5IDMuNzg0LTguNTQ0IDguNDUyLTguNTQ0IDQuNjY3IDAgOC40NTEgMy44MjUgOC40NTEgOC41NDN6IiBmaWxsPSIjRUU0MzU4Ii8+PHBhdGggZD0iTTI0Mi40NTIgOC4xMjZjMCAzLjAzNC0yLjQzMyA1LjQ5Mi01LjQzMyA1LjQ5Mi0zLjAwMSAwLTUuNDMzLTIuNDU4LTUuNDMzLTUuNDkyIDAtMy4wMzMgMi40MzItNS40OTIgNS40MzMtNS40OTIgMyAwIDUuNDMzIDIuNDYgNS40MzMgNS40OTJ6IiBmaWxsPSIjN0I1N0EzIi8+PHBhdGggZD0iTTMzMC42MzQgMTg0LjQyYzAgNy4wNzgtNS42NzYgMTIuODE1LTEyLjY3NyAxMi44MTUtNy4wMDEgMC0xMi42NzctNS43MzctMTIuNjc3LTEyLjgxNSAwLTcuMDc3IDUuNjc2LTEyLjgxNSAxMi42NzctMTIuODE1IDcuMDAxIDAgMTIuNjc3IDUuNzM4IDEyLjY3NyAxMi44MTV6IiBmaWxsPSIjNTczMkQ5Ii8+PHBhdGggZD0iTTM2MS4zNTEgNDcuNzkxYzAgMTAuNzg1LTguNjQ4IDE5LjUyOC0xOS4zMTcgMTkuNTI4cy0xOS4zMTctOC43NDMtMTkuMzE3LTE5LjUyOGMwLTEwLjc4NSA4LjY0OC0xOS41MjcgMTkuMzE3LTE5LjUyN3MxOS4zMTcgOC43NDIgMTkuMzE3IDE5LjUyN3oiIGZpbGw9IiNFRTQzNTgiLz48cGF0aCBkPSJNMzI5LjM3OSAxMy42MThjLTUuMzM0IDAtOS42NTktNC4zNzItOS42NTktOS43NjQgMC01LjM5MiA0LjMyNS05Ljc2NCA5LjY1OS05Ljc2NCA1LjMzNCAwIDkuNjU4IDQuMzcyIDkuNjU4IDkuNzY0IDAgNS4zOTItNC4zMjQgOS43NjQtOS42NTggOS43NjR6IiBmaWxsPSIjNDNDMkQwIi8+PHBhdGggZD0iTTExNC4yMDguMjMyYTIuMDggMi4wOCAwIDAgMC0xLjc2Ni0uMjQ0IDIuMjggMi4yOCAwIDAgMC0xLjA1Mi43MjQgNDMuNTUgNDMuNTUgMCAwIDAgMy42MjIuNCAyLjQ3NyAyLjQ3NyAwIDAgMC0uODA0LS44OHoiIGZpbGw9IiNGNkIzQzciLz48cGF0aCBkPSJNMjc0LjI4LTEuMTZjLS4wODgtLjQxNC0uMjk2LS43NTItLjU3MS0uOTU1YS45NjMuOTYzIDAgMCAwLS45Mi0uMTQ4Yy0uMzE3LjExNS0uNTc1LjM4Ny0uNzMuNzQ3YTEuOTUyIDEuOTUyIDAgMCAwLS4xNS42NjhjLjcyMi4zNjYgMS40NjEuNjg5IDIuMjE3Ljk2OC4wMTMtLjAyNi4wMjktLjA1LjA0MS0uMDc3LjE1Ni0uMzYuMjAxLS43OS4xMTMtMS4yMDN6bTQuMzM3IDEuNTA2YTEuMzk3IDEuMzk3IDAgMCAwLTEuMTc3LS4xNjIgMS41MTMgMS41MTMgMCAwIDAtLjcwMS40NzhjLjc5NS4xMiAxLjYuMjA5IDIuNDE0LjI2NGExLjYzNSAxLjYzNSAwIDAgMC0uNTM2LS41OHoiIGZpbGw9IiM3QjU3QTMiLz48L2c+PC9zdmc+") 100% 0px no-repeat; }

.login-dialog > .content::after { display: block; position: absolute; bottom: 0px; left: 0px; right: 0px; content: " "; height: 327px; z-index: -1; pointer-events: none; }

.login-dialog .hide, .login-dialog .state-login .create-account-area .step-indicator, .login-dialog .state-login .delete-account-area, .login-dialog .state-login .login-signup-area, .login-dialog .state-login > .popup-title { display: none; }

.login-dialog .state-login .input-area { display: block; }

.login-dialog.state-delete-account .login-signup-area, .login-dialog.state-delete-account .popup-title { display: none; }

.login-dialog.state-delete-account .delete-account-area { display: block; }

.login-dialog .state-create-account .login-signup-area, .login-dialog .state-create-account > .popup-title { display: none; }

.login-dialog .state-account-created .account-created, .login-dialog .state-create-account .create-account-area, .login-dialog .state-signup-password .create-password { display: block; }

.login-dialog .state-account-created .create-account-area .step-indicator { display: none; }

.login-dialog .state-choose-method .choose-method, .login-dialog .state-enter-birthday .enter-birthday, .login-dialog .state-enter-email .enter-email, .login-dialog .state-enter-phone .enter-phone, .login-dialog .state-reactivate-account .reactivate-account, .login-dialog .state-verify-code .verify-code { display: block; }

.login-dialog .state-reactivate-account .create-account-area .step-indicator, .login-dialog .state-reactivate-account .login-email, .login-dialog .state-reactivate-account .login-phone { display: none; }

.login-dialog .state-reactivate-account-password .reactivate-account-password { display: block; }

.login-dialog .state-reactivate-account-password .create-account-area .step-indicator, .login-dialog .state-reactivate-account-password .login-email, .login-dialog .state-reactivate-account-password .login-phone { display: none; }

.login-dialog .state-account-reactivated .account-reactivated { display: block; }

.login-dialog .state-account-reactivated .create-account-area .step-indicator, .login-dialog .state-account-reactivated .login-email, .login-dialog .state-account-reactivated .login-phone { display: none; }

.login-dialog .account-reactivated .confirmation-text { font-size: 28px; padding: 0px 90px; margin-top: 36px; text-align: center; font-weight: 700; line-height: 32px; max-height: 64px; overflow: hidden; overflow-wrap: break-word; opacity: 0; transform: translateY(100px); }

.login-dialog .account-reactivated.start-transition .confirmation-text { transition: all 1s ease 0s; opacity: 1; transform: translateY(0px); }

.login-dialog .account-created .profile-icon { margin: 200px auto 0px; display: block; border-radius: 50%; border: 4px solid rgb(255, 255, 255); overflow: hidden; box-shadow: rgba(0, 0, 0, 0.3) 0px 2px 15px; width: 100px; height: 100px; opacity: 0; transform: translateY(-100px); }

.login-dialog .account-created .welcome-text { font-size: 28px; padding: 0px 90px; margin-top: 36px; text-align: center; font-weight: 700; line-height: 32px; max-height: 64px; overflow: hidden; overflow-wrap: break-word; opacity: 0; transform: translateY(100px); }

.login-dialog .account-created.start-transition .profile-icon, .login-dialog .account-created.start-transition .welcome-text { transition: all 1s ease 0s; opacity: 1; transform: translateY(0px); }

.login-dialog .state-create-profile .create-profile { display: block; }

.login-dialog .state-two-factor-auth .create-account-area .step-indicator { display: none; }

.login-dialog .state-two-factor-auth .two-factor-auth-help { position: absolute; bottom: 30px; width: 400px; left: 50%; margin-left: -200px; text-align: center; }

.login-dialog .state-two-factor-auth .two-factor-auth-help a { color: rgb(15, 134, 255); display: block; }

.login-dialog .state-two-factor-auth .two-factor-auth-help { display: block; }

.login-dialog .state-two-factor-auth-alert .two-factor-auth { display: block; margin: 50px 100px; }

.login-dialog .state-two-factor-auth-alert .two-factor-auth .tip-text { margin-bottom: 80px; }

.login-dialog .state-two-factor-auth-alert .two-factor-auth-choose .single-method { display: none; }

.login-dialog .state-two-factor-auth-alert .two-factor-auth-choose .choose-method { display: block; }

.login-dialog .state-two-factor-auth-alert .choose-method .auth-btn { line-height: 17px; }

.login-dialog .state-two-factor-auth-alert .choose-method .auth-btn span { font-weight: 400; }

.login-dialog .state-two-factor-auth-alert .choose-method .auth-btn.choose-email { background: rgb(138, 140, 155); color: rgb(255, 255, 255); }

.login-dialog .state-two-factor-auth-alert .choose-method .auth-btn.choose-email:hover { background: rgb(123, 125, 139); }

.login-dialog .state-start-over-verification .start-over-verification { display: block; }

.login-dialog .state-start-over-verification .start-over-verification .step-button-group .auth-btn { float: none; width: 100%; margin-bottom: 12px; }

.login-dialog .create-password { margin: auto; }

.login-dialog .create-profile .avatar-display { width: 126px; height: 126px; margin: -10px auto 20px; cursor: pointer; }

.login-dialog .create-profile .avatar-display.rendered { border-radius: 50%; border: 4px solid rgb(255, 255, 255); overflow: hidden; box-shadow: rgba(0, 0, 0, 0.3) 0px 2px 15px; position: relative; }

.login-dialog .create-profile .avatar-display.rendered:hover::before { opacity: 1; }

.login-dialog .create-profile .avatar-display.rendered::before { opacity: 0; display: block; content: attr(data-rendered); font-weight: 700; color: rgb(255, 255, 255); text-align: center; line-height: 118px; position: absolute; inset: 0px; background: rgba(0, 0, 0, 0.6); transition: opacity 0.3s ease 0s; }

.login-dialog .create-profile .img-cover { width: 126px; height: 126px; }

.login-dialog .create-profile .avatar-input { display: none; }

.login-dialog .create-profile .profile-placeholder { margin-left: 5px; }

.login-dialog .create-profile .license-agreement { text-align: center; margin: 20px 0px; font-size: 12px; }

.login-dialog .create-profile .license-agreement .license-label { display: inline-block; line-height: 16px; cursor: pointer; user-select: none; }

.login-dialog .create-profile .license-agreement .license-label::before { content: " "; display: inline-block; border: 1px solid rgb(184, 184, 184); color: rgb(94, 203, 176); width: 16px; height: 16px; border-radius: 3px; vertical-align: middle; margin-right: 5px; position: relative; top: -1px; }

.login-dialog .create-profile .license-agreement .checkbox:checked + .license-label::before { content: ""; font-family: FontAwesome; font-weight: 100; border-color: rgb(94, 203, 176); }

.login-dialog .create-profile .license-agreement .license-label > a { text-decoration: underline; }

.login-dialog .create-profile .license-agreement > .checkbox { display: none; }

.login-dialog .create-profile .nickname-container { position: relative; }

.login-dialog .create-profile .length-notification { position: absolute; left: 50%; margin-left: 137px; top: 12px; opacity: 0; pointer-events: none; transition: opacity 0.2s ease 0s; }

.login-dialog .create-profile .length-notification.show { opacity: 1; }

.login-dialog .create-account-area .toast, .login-dialog .delete-account-area .toast { border-radius: 15px; font-size: 14px; padding: 6px 17px; bottom: 30px; }

.login-dialog .create-account-area .toast > .content, .login-dialog .delete-account-area .toast > .content { line-height: 18px; }

.login-dialog .create-account-area .account-deleted, .login-dialog .delete-account-area .account-deleted { margin-top: 70px; }

.login-dialog .create-account-area .auth-btn, .login-dialog .delete-account-area .auth-btn { min-width: 248px; text-align: center; }

.login-dialog .create-account-area .step-button-group, .login-dialog .delete-account-area .step-button-group { display: flex; -webkit-box-pack: justify; justify-content: space-between; width: 510px; margin: 48px auto; }

.login-dialog .create-account-area .step-button-group .auth-btn, .login-dialog .delete-account-area .step-button-group .auth-btn { display: block; float: left; }

.login-dialog .create-account-area .step-button-group .cancel, .login-dialog .delete-account-area .step-button-group .cancel { line-height: 36px; color: rgb(29, 218, 143); border: 1px solid rgb(29, 218, 143); background-color: rgb(255, 255, 255); }

.login-dialog .create-account-area .step-button-group .cancel:hover, .login-dialog .delete-account-area .step-button-group .cancel:hover { color: rgb(10, 192, 120); border: 1px solid rgb(10, 192, 120); }

.login-dialog .create-account-area .step-button-group .main-action.disabled:hover, .login-dialog .create-account-area .step-button-group .main-action:hover, .login-dialog .delete-account-area .step-button-group .main-action.disabled:hover, .login-dialog .delete-account-area .step-button-group .main-action:hover { background: rgb(10, 192, 120); }

.login-dialog .create-account-area .input, .login-dialog .delete-account-area .input { display: block; width: 250px; margin: auto; }

.login-dialog .create-account-area .tip-text, .login-dialog .delete-account-area .tip-text { font-family: Montserrat; text-align: center; font-size: 32px; font-weight: 700; margin: 20px 0px 30px; }

.login-dialog .create-account-area .tip-text.show-in-email, .login-dialog .delete-account-area .tip-text.show-in-email { font-size: 32px; margin: 0px 0px 20px; }

.login-dialog .create-account-area .tip-text.small, .login-dialog .delete-account-area .tip-text.small { font-size: 18px; font-weight: 100; margin: 0px 0px 10px; }

.login-dialog .create-account-area .tip-text.small > span, .login-dialog .delete-account-area .tip-text.small > span { font-weight: 600; }

.login-dialog .create-account-area .tip-text.small.identity, .login-dialog .delete-account-area .tip-text.small.identity { font-weight: 700; }

.login-dialog .create-account-area .tip-text.bellow-input, .login-dialog .delete-account-area .tip-text.bellow-input { font-size: 16px; font-weight: 100; margin-top: 10px; }

.login-dialog .create-account-area .step-indicator, .login-dialog .delete-account-area .step-indicator { display: flex; position: absolute; overflow: hidden; bottom: 0px; left: 170px; right: 170px; -webkit-box-pack: center; justify-content: center; -webkit-box-align: end; align-items: flex-end; height: 40px; }

.login-dialog .create-account-area .step-indicator > .step-item, .login-dialog .delete-account-area .step-indicator > .step-item { margin: 0px 3px; width: 40px; height: 6px; opacity: 0.7; background: rgb(29, 218, 143); float: left; }

.login-dialog .create-account-area .step-indicator > .step-item.active, .login-dialog .delete-account-area .step-indicator > .step-item.active { height: 10px; opacity: 1; }

.login-dialog .choose-method { margin-top: 50px; }

.login-dialog .choose-method p.tip-text { font-family: Montserrat; font-weight: 500; font-size: 20px; }

.login-dialog .choose-method .buttons { display: flex; -webkit-box-pack: center; justify-content: center; margin-top: 30px; }

.login-dialog .choose-method .auth-btn { font-weight: 700; }

.login-dialog .choose-method .auth-btn:hover { background: rgb(242, 242, 242); }

.login-dialog .choose-method .auth-btn.loading:hover { background: rgb(255, 255, 255); }

.login-dialog .choose-method .method-email { min-width: 200px; }

.login-dialog .choose-method .method-email:hover { background: rgb(10, 192, 120); }

.login-dialog .choose-method .method-phone { min-width: 200px; }

.login-dialog .choose-method .method-phone:hover { background: rgb(10, 192, 120); }

.login-dialog .choose-method .method-phone > .fa-spin { display: none; }

.login-dialog .choose-method .method-phone.loading { opacity: 0.5; position: relative; }

.login-dialog .choose-method .method-phone.loading > .fa-spin { display: block; font-size: 18px; position: absolute; right: 11px; top: 11px; }

.login-dialog .enter-phone .show-in-phone { margin: auto; display: flex; -webkit-box-align: end; align-items: flex-end; }

.login-dialog .enter-phone .show-in-phone .input { margin: 0px; }

.login-dialog .two-factor-auth.two-factor-auth-email .verify-phone-tip, .login-dialog .two-factor-auth.two-factor-auth-phone .verify-email-tip { display: none; }

.login-dialog .two-factor-auth .step-button-group .auth-btn { float: none; width: 100%; margin-bottom: 12px; }

.login-dialog .verify-code .resend-tip span { color: rgb(29, 218, 143); }

.login-dialog .verify-code .resend-now { color: rgb(29, 218, 143); cursor: pointer; }

.login-dialog .verify-code .resend-now:hover { text-decoration: underline; }

.login-dialog .verify-code .resend-now .amino-icon { margin-left: 5px; }

.login-dialog .verify-code .resend-container { text-align: center; margin: 20px 0px; font-size: 14px; }

.login-dialog .verify-code .step-button-group { margin-top: 0px; }

.login-dialog .verify-code-container { width: 330px; display: flex; height: 39px; -webkit-box-pack: center; justify-content: center; margin: 0px auto; border-bottom: 2px solid rgb(230, 230, 230); }

.login-dialog .verify-code-container .code-input { width: 22px; -webkit-box-flex: 0; flex: 0 0 22px; font-size: 28px; font-weight: 700; border: none; color: rgb(127, 127, 127); text-align: center; outline: none; overflow: hidden; }

.login-dialog .verify-code-container .code-input:last-child { margin-right: 0px; }

.login-dialog .verify-code-container .code-input::-webkit-input-placeholder { color: rgb(230, 230, 230); }

.login-dialog .verify-code-container .code-input::placeholder { color: rgb(230, 230, 230); }

.login-dialog .verify-code-container .code-input:nth-child(4) { margin-left: 10px; }

.login-dialog .verify-code-container.invalid { border-bottom: 2px solid red; }

.login-dialog .signin-overlay { display: none; background: rgba(255, 255, 255, 0.95); position: absolute; inset: 0px; z-index: 10; width: 100%; height: 100%; }

.login-dialog .loading-overlay > .mask-container { position: relative; }

.login-dialog .confirm-exit > .content, .login-dialog .error-overlay > .content { width: 320px; text-align: center; }

.login-dialog .confirm-exit .error-message, .login-dialog .error-overlay .error-message { text-align: center; font-weight: 700; }

.login-dialog .confirm-exit .auth-btn, .login-dialog .error-overlay .auth-btn { width: 200px; text-align: center; margin-top: 12px; }

.login-dialog .confirm-exit .hide, .login-dialog .error-overlay .hide { display: none; }

.login-dialog .confirm-exit .show, .login-dialog .error-overlay .show { display: block; margin: auto; }

.login-dialog .confirm-exit .icon-warn, .login-dialog .error-overlay .icon-warn { font-size: 40px; color: rgb(251, 144, 61); }

.login-dialog .loading .loading-overlay, .login-dialog .show-confirm-exit .confirm-exit, .login-dialog .show-error-overlay .error-overlay { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; z-index: 1010; border-radius: 20px; }

.login-dialog .show-confirm-exit .confirm-exit { z-index: 1011; }

.login-dialog .confirm-exit .error-message { font-size: 18px; }

.login-dialog .confirm-exit .auth-btn { border-color: rgb(29, 218, 143); padding: 0px; }

.login-dialog .confirm-exit .go-back { background: rgb(29, 218, 143); color: rgb(255, 255, 255); }

.login-dialog .confirm-exit .go-back:hover, .login-dialog .confirm-exit .really-close:hover { background: rgb(28, 208, 136); }

.login-dialog .login-signup-area { width: 600px; height: 100%; margin: 20px auto 0px; display: flex; flex-wrap: wrap; -webkit-box-pack: center; justify-content: center; }

.login-dialog .login-signup-area > .sub-area { width: 300px; }

.login-dialog .login-signup-area > .signup-area, .login-dialog .login-signup-area > .sub-area .login-area { display: flex; flex-wrap: wrap; -webkit-box-pack: center; justify-content: center; }

.login-dialog .login-signup-area > .signup-area { width: 300px; padding-right: 0px; align-content: flex-start; }

.login-dialog .login-signup-area .auth-btn { min-width: 200px; margin-top: 12px; font-weight: 700; display: flex; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; }

.login-dialog .login-signup-area .auth-btn .fa-mobile-phone { font-size: 25px; vertical-align: -4px; margin-right: 15px; }

.login-dialog .login-signup-area .auth-btn .fa-envelope { font-size: 18px; position: relative; left: -3px; margin-right: 9px; }

.login-dialog .login-signup-area .choose-signup-method { background-color: rgb(255, 255, 255); color: rgb(28, 208, 136); border: 1px solid rgb(28, 208, 136); }

.login-dialog .login-signup-area .choose-signup-method:hover { color: rgb(8, 178, 111); border: 1px solid rgb(8, 178, 111); }

.login-dialog .popup-title { font-size: 36px; color: rgb(127, 127, 127); text-align: center; }

.login-dialog .auth-btn { height: 36px; background: rgb(29, 218, 143); border-radius: 18px; border: 0px; padding: 0px 20px; cursor: pointer; display: inline-block; font-size: 12px; font-weight: 700; color: rgb(255, 255, 255); text-align: center; line-height: 1; }

.login-dialog .main-action { background: rgb(29, 218, 143); color: rgb(255, 255, 255); border: none; }

.login-dialog .main-action.disabled, .login-dialog .main-action[disabled] { background: rgb(29, 218, 143); border-color: rgb(29, 218, 143); }

.login-dialog .divider { line-height: 36px; text-align: center; font-size: 14px; font-weight: 700; margin: 10px; display: flex; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; }

.login-dialog .divider.btn-divider { margin: 0px 10px; }

.login-dialog .divider .line { width: 235px; border: 1px solid rgba(0, 0, 0, 0.1); }

.login-dialog .signin-email:hover, .login-dialog .signin-phone:hover { background: rgb(10, 192, 120); }

.login-dialog .area-title { font-size: 16px; margin: 18px 0px 0px; height: 38px; text-align: center; color: rgb(0, 0, 0); font-weight: 600; }

.login-dialog .third-party-button { min-width: 200px; height: 36px; line-height: 36px; padding: 0px 17px; font-size: 12px; display: flex; cursor: pointer; -webkit-box-pack: start; justify-content: flex-start; }

.login-dialog .fb-login-button { margin-bottom: 12px; background: rgb(55, 103, 184); color: rgb(255, 255, 255); border-radius: 3px; font-weight: 700; }

.login-dialog .fb-login-button > i.fa { font-size: 23px; float: left; line-height: 36px; margin-right: 15px; }

.login-dialog .fb-login-button:hover { background: rgb(43, 81, 145); }

.login-dialog .gg-login-button { border: 1px solid rgb(230, 230, 230); border-radius: 2px; font-weight: 700; }

.login-dialog .gg-login-button > svg { float: left; margin-top: 9px; margin-right: 15px; margin-left: 1px; }

.login-dialog .gg-login-button:hover { background: rgb(242, 242, 242); }

.login-dialog .input-area { font-size: 14px; }

.login-dialog .input-area .input { width: 250px; }

.login-dialog .input-area.login-email .show-in-phone, .login-dialog .input-area.login-phone .show-in-email { display: none; }

.login-dialog .area-container, .login-dialog form > .show-in-phone { display: flex; -webkit-box-pack: center; justify-content: center; }

.login-dialog .area-container { font-family: Helvetica; font-style: normal; font-weight: 400; width: 89px; border-bottom: 1px solid; margin: 0px 20px 0px 0px; -webkit-box-align: baseline; align-items: baseline; position: relative; }

.login-dialog .area-container > .area-code-input { width: 45px; padding: 0px; height: 34px; border: none; background: none; font-size: 20px; border-radius: 0px; }

.login-dialog .area-container > .area-code-input:focus { box-shadow: none; }

.login-dialog .area-container::before { content: "+"; font-size: 20px; color: rgb(0, 0, 0); }

.login-dialog .area-container > .area-list { display: none; position: absolute; top: 35px; left: 0px; width: 439px; max-height: 300px; overflow: auto; background: rgb(255, 255, 255); list-style: none; margin: 3px 0px 0px; font-size: 20px; box-shadow: rgba(0, 0, 0, 0.25) 0px 4px 4px; z-index: 1; }

.login-dialog .area-container > .area-list > .no-result { display: none; }

.login-dialog .area-container.show > .area-list { display: block; }

.login-dialog .area-list { padding: 0px; }

.login-dialog .area-list > .area-item { line-height: 36px; padding: 0px 12px; cursor: pointer; }

.login-dialog .area-list > .area-item.active { background: rgb(228, 228, 228); }

.login-dialog .third-party { width: 100%; display: flex; -webkit-box-pack: center; justify-content: center; }

.login-dialog .download-links { width: 85%; display: flex; justify-content: space-evenly; text-align: -webkit-left; margin-top: 40px; }

.login-dialog .download-links p { color: rgb(94, 94, 94); font-weight: 700; }

.login-dialog .signup-area { position: relative; text-align: center; }

.login-dialog .signup-area .link-highlight, .login-dialog .signup-area .send-icon { color: rgb(29, 218, 143); }

.login-dialog .signup-area .imgbtn { display: block; margin: 10px auto; width: 140px; }

.login-dialog .signup-area .imgbtn > img { width: 140px; }

.login-dialog .signup-area .download-invite-container + .imgbtn { margin-top: 20px; }

.login-dialog .signup-area .download-invite-container .input { width: 250px; }

.login-dialog .signup-area .invite-text { float: left; margin: 10px 0px 14px; }

.login-dialog .input { height: 36px; line-height: 34px; border-radius: 8px; outline: none; border: 1px solid rgb(184, 184, 184); padding: 0px 12px; margin: 0px; }

.login-dialog .input::-webkit-input-placeholder { color: rgb(189, 189, 189); }

.login-dialog .input::placeholder { color: rgb(189, 189, 189); }

.login-dialog .input:focus { box-shadow: rgba(0, 0, 0, 0.3) 0px 0px 5px inset; border-color: rgb(138, 140, 155); }

.login-dialog .input.invalid { border-color: rgb(233, 13, 59); }

.login-dialog .input.no-border { width: 330px; border-top: none; border-left: none; border-right: none; border-radius: 0px; font-size: 23px; text-align: center; }

.login-dialog .input.no-border.login-password { margin-top: 10px; }

.login-dialog .input.no-border:focus { box-shadow: none; border-color: rgb(230, 230, 230); }

.login-dialog .input.no-border::-webkit-input-placeholder { text-align: center; font-size: 23px; }

.login-dialog .input.no-border::placeholder { text-align: center; font-size: 23px; }

.login-dialog .birthday-input { color: rgba(0, 0, 0, 0.2); text-transform: uppercase; }

.login-dialog .form-tip { display: none; color: rgb(233, 13, 59); text-align: center; margin-top: 10px; }

.login-dialog .form-tip.show { display: block; }

.login-dialog .submit-btn { color: rgb(255, 255, 255); background: rgb(29, 218, 143); border-color: rgb(29, 218, 143); text-align: center; min-width: 248px; }

.login-dialog .submit-btn:hover { border-color: rgb(26, 195, 128); background: rgb(26, 195, 128); }

.login-dialog .submit-btn[disabled] { background: rgb(189, 189, 189); border-color: rgb(189, 189, 189); }

.login-dialog .forget-pw-tip { font-size: 12px; margin-top: 10px; display: block; }

.login-dialog .signin-back { display: block; margin-top: 28px; font-weight: 600; }

.login-dialog .signin-back:hover { color: rgb(26, 195, 128); border-color: rgb(26, 195, 128); }

.login-dialog .reenter-password .auth-btn, .login-dialog .reenter-password .input { width: 250px; }

.login-dialog .reenter-password .auth-btn { border: none; }

.login-dialog .reenter-password .auth-btn:hover, .login-dialog .reenter-password .cancel:hover { background: rgb(28, 208, 136); }

.login-dialog .g-recaptcha { position: relative; top: -140px; }

.modal .popup.login-dialog { overflow: visible; }

.modal .popup.login-dialog .popup-title { margin: 40px auto 0px; padding: 0px 90px; line-height: 41px; max-height: 82px; overflow: hidden; overflow-wrap: break-word; }

.modal .popup.login-dialog .close { color: rgb(155, 155, 155); position: absolute; top: 3px; right: 13px; width: 32px; height: 32px; font-size: 32px; padding: 0px 12px; }

.modal .lightbox { inset: 5%; }

.modal-open .modal .lightbox { transform: translateY(-5%); }

.modal-transition .modal .lightbox { transform: translateY(0px); }

.modal .lightbox-popup { width: 100%; position: absolute; top: 50%; transform: translateY(-50%); }

.modal .lightbox-item { display: none; visibility: hidden; }

.modal .lightbox-thumb { -webkit-tap-highlight-color: transparent; cursor: pointer; }

.modal .lightbox-content { display: block; margin: auto auto 20px; background-color: initial; max-height: calc(90vh - 50px); max-width: 100%; }

.modal .lightbox div.lightbox-content { height: 9999px; }

.modal .lightbox-video { width: 88vmin; height: 49.5vmin; background-size: cover; background-position: 50% center; }

.modal .lightbox .youtube-playlink { position: relative; width: 100%; height: 100%; }

.modal .lightbox .youtube-playlink > i.fa { position: absolute; top: 50%; left: 50%; margin-top: -3rem; margin-left: -3rem; width: 6rem; height: 6rem; text-align: center; border-radius: 50%; font-size: 3rem; background-color: rgba(0, 0, 0, 0.5); color: rgb(255, 255, 255); }

.modal .lightbox .youtube-playlink > i.fa::before { line-height: 6rem; }

.modal .lightbox .youtube-playlink .lightbox-content { width: 100%; }

.modal .lightbox .controls { padding: 1em; text-align: center; position: fixed; bottom: calc(-50vh + 50% + 20px); left: 50%; margin-left: -143px; }

.modal .lightbox .controls > .control { padding: 0.5em; background: none; border: none; cursor: pointer; }

.modal .lightbox .controls [disabled] { opacity: 0.5; }

.modal .call2action-popup .vip-color { color: rgb(223, 28, 152); }

.modal .call2action-popup .vip-popup-bg { background-color: rgb(223, 28, 152); }

.modal .call2action-popup .vip-popup-bg, .modal .call2action-popup .vip-popup-bg::before { background-image: url("https://aminoapps.com/static/img/FanClubPopupBg.png"); background-size: cover; }

.modal .call2action-popup .amino-intro { display: flex; margin: 20px 30px; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; }

.modal .call2action-popup .amino-intro .logo { width: 72px; height: 72px; flex-shrink: 0; margin-right: 20px; }

.modal .call2action-popup .amino-intro .amino-says { font-size: 14px; font-weight: 700; }

.modal .call2action-popup .amino-intro .amino-says .slogan { display: block; margin-top: 5px; font-weight: 400; }

.modal .call2action-popup .motivation { position: relative; z-index: 10; display: flex; -webkit-box-align: center; align-items: center; margin-bottom: calc(-0.5em + 5vw); padding: 0px 1.5em; }

.modal .call2action-popup .motivation > .avatars { -webkit-box-flex: 0; flex: 0 0 auto; }

.modal .call2action-popup .motivation > .bubble { -webkit-box-flex: 1; flex: 1 0 0px; display: flex; -webkit-box-align: center; align-items: center; position: relative; z-index: 10; margin-left: 1rem; border-radius: 5px; min-height: 60px; background: rgb(255, 255, 255); padding: 0.4rem 0.8rem; line-height: 1.4; font-weight: 700; }

.modal .call2action-popup .motivation > .bubble::after { font-size: 14px; content: " "; position: absolute; top: 50%; left: 0px; margin-top: -0.5em; margin-left: -1em; border-width: 0.5em; border-style: solid; border-color: transparent rgb(255, 255, 255) transparent transparent; }

.modal .call2action-popup .motivation > .bubble > .content { transform: scale(0.95); }

.modal .call2action-popup .motivation .avatar { font-size: 20px; border: 2px solid rgb(255, 255, 255); border-radius: 50%; width: 2em; height: 2em; margin-left: -1em; }

.modal .call2action-popup .motivation .avatar:first-child { margin-left: 0px; }

.modal .call2action-popup .motivation .avatar:first-child:last-child { font-size: 30px; }

.modal .call2action-popup > .content { position: relative; padding: 1em 1.5em; }

.modal .call2action-popup > .content::before { content: " "; display: none; position: absolute; z-index: -1; left: -5vw; right: -5vw; top: calc(-32px - 5vw); border-radius: 50%; height: calc(64px + 10vw); background-color: inherit; }

.modal .call2action-popup .fan-club-info .tagline { color: rgb(255, 255, 255); text-align: center; font-weight: 400; margin-top: 0px; }

.modal .call2action-popup .fan-club-info .fan-club-features { display: flex; justify-content: space-around; text-align: center; }

.modal .call2action-popup .fan-club-info .fan-club-features .feature-item { width: 90px; }

.modal .call2action-popup .fan-club-info .fan-club-features img { margin: 3px 0px 7px; }

.modal .call2action-popup .community-info { color: rgb(255, 255, 255); padding: 0.75em; border-radius: 5px; background-color: rgba(0, 0, 0, 0.15); }

.modal .call2action-popup .community-info .info { display: flex; -webkit-box-align: center; align-items: center; overflow: hidden; }

.modal .call2action-popup .community-info .info > .remain { -webkit-box-flex: 1; flex: 1 1 0%; overflow: hidden; }

.modal .call2action-popup .community-info .logo { width: 48px; height: 48px; border-radius: 10.848px; margin-right: 0.5em; }

.modal .call2action-popup .community-info .title { display: flex; -webkit-box-align: center; align-items: center; }

.modal .call2action-popup .community-info .member-count { margin-left: auto; font-size: small; white-space: nowrap; }

.modal .call2action-popup .community-info .name { font-size: large; line-height: 22px; max-height: 44px; overflow: hidden; overflow-wrap: break-word; }

.modal .call2action-popup .community-info .endpoint { display: flex; font-size: small; font-weight: 700; }

.modal .call2action-popup .community-info .endpoint > a.underline { white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }

.modal .call2action-popup .community-info .endpoint > i.fa-clone { margin-left: 4px; }

.modal .call2action-popup .global-info .logo { width: 72px; height: 72px; border-radius: 16.272px; margin-left: 40px; }

.modal .call2action-popup .global-info .endpoint, .modal .call2action-popup .global-info .remain { font-size: 14px; }

.modal .call2action-popup .global-info .tagline { margin: 5px 0px 0px; }

.modal .call2action-popup .buttons { display: flex; }

.modal .call2action-popup .buttons .btn:last-child { margin-left: 8px; }

.modal .call2action-popup .btn { display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; -webkit-box-flex: 1; flex: 1 1 0px; padding: 0.75em 0px; text-align: center; margin: 1.5em 0px 0.5em; }

.modal .call2action-popup .btn.btn-join { display: flex; background-color: rgb(255, 255, 255); box-shadow: rgb(198, 198, 198) 0px -5px inset; padding-bottom: 17px; }

body.is-mobile .modal .call2action-popup .btn.btn-join { display: none; }

.modal .call2action-popup .btn.btn-join:active { box-shadow: none; }

.modal .call2action-popup .btn.btn-get-app { display: none; background-color: rgb(255, 255, 255); box-shadow: rgb(198, 198, 198) 0px -3px inset, rgb(198, 198, 198) 0px 2px; }

body.is-mobile .modal .call2action-popup .btn.btn-get-app { display: flex; }

.modal .call2action-popup .btn.btn-get-app:active { box-shadow: none; }

.modal .call2action-popup .btn.btn-open-deeplink { display: none; border: 2px solid rgb(255, 255, 255); background-color: transparent; }

body.is-mobile .modal .call2action-popup .btn.btn-open-deeplink { display: flex; }

.modal .call2action-popup.get-app .btn-join { display: none; }

.modal .call2action-popup.get-app .btn-get-app, .modal .call2action-popup.get-app.btn-open-deeplink { display: flex; }

@media (min-width: 641px) {
  .modal .community-sidebar > .content, .modal aside.site-sidebar > .content { right: auto; min-width: 320px; }
  .modal .call2action-popup { width: 425px; }
  .modal .call2action-popup > .content { border-radius: 10px; }
  .modal .call2action-popup .motivation { margin-bottom: -26px; }
  .modal .call2action-popup > .content { padding: 3em 1.5em 1em; }
}

@media (max-width: 640px) {
  .modal .call2action-popup { top: auto; bottom: 0px; }
  .modal-open .modal .call2action-popup { transform: translateY(5%); }
  .modal-transition .modal .call2action-popup { transform: translateY(0px); }
  .modal .call2action-popup > .content::before { display: block; }
  .modal .call2action-popup .btn { font-size: 16px; }
}

@media screen and (max-width: 374px) {
  .modal .call2action-popup .motivation .avatar { font-size: 16px; }
}

@media (min-width: 1207px) {
  .modal .call2action-popup.get-app.btn-open-deeplink { display: none; }
}

<svg width="305" height="86" viewBox="0 0 305 86" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient x1="0%" y1="100%" x2="100%" y2="100%" id="a"><stop stop-color="#FFF" offset="0%"/><stop stop-color="#D7D7EF" offset="100%"/></linearGradient></defs><path d="M276.5 22c5.754 0 9.5-4.037 9.5-9s-3.947-9-9.5-9-9.5 4.037-9.5 9 3.813 9 9.5 9zm102.196 6.109c-14.459 0-24.608 11.16-24.608 28.318 0 4.254.417 8.09 1.32 11.578-2.293 1.953-4.448 3.278-6.533 3.278-3.128 0-4.519-1.883-4.519-5.859V47.08c0-11.369-6.881-18.971-17.517-18.971-7.368 0-12.651 2.86-16.614 7.044-.278-.488-.625-1.185-1.042-1.953-1.112-2.022-2.642-3.487-5.561-3.487h-2.294c-2.503 0-3.962 1.744-3.962 4.743v32.572c-2.711 2.372-5.7 4.255-8.273 4.255-3.128 0-4.518-1.953-4.518-5.859V34.456c0-3.07-1.182-4.743-4.032-4.743h-7.924c-2.503 0-3.962 1.744-3.962 4.743v33.48c-2.642 2.092-4.866 3.347-7.09 3.347-3.129 0-4.519-1.883-4.519-5.859V47.08c0-11.369-6.048-18.971-16.683-18.971-7.369 0-12.93 3.348-16.892 7.463-2.85-4.464-7.438-7.394-14.041-7.394-6.535 0-10.984 2.442-15.78 6.906-2.016-4.255-4.796-5.301-7.994-5.301-5.7 0-18.351 3.557-27.944 7.602-4.31-11.09-10.844-26.155-12.86-30.898-.417-.907-1.112-2.302-1.668-3.07C141.586 1.187 139.5 0 136.373 0c-2.78 0-4.727 1.186-6.186 2.86-.765.906-1.669 2.371-2.155 3.557-2.711 6.486-19.95 50.637-28.292 72.399-1.32 3.418-1.043 5.65 2.224 5.65h8.759c2.572 0 3.545-1.116 6.117-3.837 9.384-10.043 20.715-17.855 31.142-23.226 4.24 10.393 8.48 21.064 9.315 23.226 1.251 3.139 2.85 3.837 5.77 3.837h8.48c3.267 0 3.823-2.232 2.71-5.092-1.945-5.092-6.533-16.46-11.4-28.667 5.7-2.65 12.583-4.743 14.807-4.743 2.364 0 3.267 1.674 3.267 4.255v29.504c0 3.069 1.182 4.743 4.032 4.743h7.924c2.503 0 3.963-1.744 3.963-4.743V52.38c0-5.161 2.294-8.928 7.229-8.928 4.935 0 6.882 3.837 6.882 8.928v27.342c0 3.069 1.182 4.743 4.032 4.743h7.924c2.503 0 3.962-1.744 3.962-4.743V52.38c0-5.161 2.294-8.928 7.23-8.928 4.935 0 6.881 3.837 6.881 8.928v17.856c0 9.695 5.283 15.763 13.834 15.763 6.95 0 11.747-2.441 16.196-5.929 2.364 3.767 6.326 5.929 11.4 5.929 6.048 0 10.983-3.069 14.876-5.998.07 2.86 1.32 4.464 4.032 4.464h7.924c2.503 0 3.963-1.744 3.963-4.743V52.38c0-5.161 2.78-8.928 7.715-8.928 4.936 0 7.3 3.837 7.3 8.928v17.856c0 9.695 5.282 15.763 13.832 15.763 7.23 0 13.903-3.348 18.56-7.184 4.032 4.603 9.94 7.184 17.935 7.184 17.239 0 25.442-11.509 25.442-29.504.139-17.297-9.663-28.387-25.303-28.387zM124 55c1.876-4.514 5.699-14.861 8.27-21.389.904-2.361 1.599-3.611 3.197-3.611 1.668 0 2.433 1.944 3.128 3.611 1.112 2.639 2.293 6.25 3.405 9.167-6.116 3.194-12.649 7.778-18 12.222zm255 16c-6.264 0-9-5.807-9-14.588 0-8.02 3.384-13.412 9-13.412 5.904 0 9 5.462 9 13.412C388 65.331 385.696 71 379 71z" transform="translate(-99)" fill="url(#a)" fill-rule="evenodd"/></svg>


<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 511.5 144.2"><g fill="#FFF"><path d="M298 31.7c10 0 16.5-7.1 16.5-15.8C314.5 7.1 307.6 0 298 0c-9.7 0-16.5 7.1-16.5 15.8 0 8.8 6.7 15.9 16.5 15.9z"/><path d="M468.8 47.7c-24.2 0-41.3 18.6-41.3 47.2 0 7.1.7 13.5 2.2 19.3-3.9 3.2-7.5 5.4-10.9 5.4-5.2 0-7.6-3.1-7.6-9.8V79.4c0-19-11.5-31.6-29.3-31.6-12.3 0-21.3 4.8-27.9 11.7-.5-.8-1.1-2-1.8-3.2-1.9-3.4-4.4-5.9-9.4-5.9H339c-4.2 0-6.6 2.9-6.6 7.9v54.3c-4.5 4-9.6 7.1-13.8 7.1-5.2 0-7.6-3.2-7.6-9.8V58.3c0-5.2-2-7.9-6.8-7.9h-13.3c-4.2 0-6.6 2.9-6.6 7.9v55.8c-4.5 3.5-8.2 5.6-11.9 5.6-5.2 0-7.6-3.1-7.6-9.8V79.4c0-19-10.2-31.6-28-31.6-12.3 0-21.7 5.5-28.3 12.5-4.8-7.5-12.5-12.4-23.5-12.4s-18.5 4.1-26.5 11.5c-3.4-7.1-8-8.9-13.4-8.9-9.6 0-30.8 5.9-46.8 12.7-7.2-18.5-18.1-43.6-21.6-51.5-.5-1.5-1.7-3.8-2.7-5.2C71.4 2.8 67.8.8 62.6.8c-4.6 0-7.9 1.9-10.4 4.8-1.3 1.5-2.8 4-3.6 5.9-4.5 10.9-33.3 84.4-47.4 120.7-2.2 5.7-1.8 9.4 3.7 9.4h14.6c4.3 0 5.9-1.9 10.2-6.4 15.7-16.7 34.7-29.8 52.2-38.8 7.1 17.3 14.2 35.2 15.7 38.8 2.1 5.2 4.8 6.4 9.6 6.4h14.2c5.5 0 6.4-3.7 4.6-8.5-3.2-8.5-10.9-27.4-19.1-47.8 9.5-4.5 21.1-8 24.8-8 4 0 5.5 2.8 5.5 7.1v49.2c0 5.2 2 7.9 6.8 7.9h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 3.9-14.9 12.2-14.9 8.3 0 11.5 6.4 11.5 14.9v45.6c0 5.2 2 7.9 6.8 7.9h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 3.9-14.9 12.2-14.9 8.3 0 11.5 6.4 11.5 14.9v29.8c0 16.2 8.9 26.3 23.2 26.3 11.7 0 19.7-4.1 27.2-9.9 3.9 6.3 10.6 9.9 19.1 9.9 10.1 0 18.4-5.1 25-10 .1 4.8 2.2 7.4 6.8 7.4h13.3c4.2 0 6.6-2.9 6.6-7.9V88c0-8.6 4.7-14.9 12.9-14.9s12.3 6.4 12.3 14.9v29.8c0 16.2 8.9 26.3 23.2 26.3 12.1 0 23.3-5.6 31.1-12 6.8 7.7 16.7 12 30 12 28.9 0 42.7-19.2 42.7-49.2.1-28.6-16.3-47.2-42.6-47.2zM43.3 94.3c3.1-7.6 9.6-24.9 13.9-35.9 1.5-3.9 2.7-6 5.4-6 2.8 0 4.1 3.3 5.3 6.1 1.9 4.5 3.9 10.5 5.7 15.4-10.3 5.3-21.3 13-30.3 20.4zm426.2 25.2c-10.1 0-14.6-9.7-14.6-24.5 0-13.4 5.5-22.6 14.6-22.6 9.5 0 14.6 9.2 14.6 22.6 0 14.8-3.8 24.5-14.6 24.5z"/></g></svg>
g

<svg width="211" height="151" viewBox="0 0 211 151" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="7.5" cy="81.5" r="3.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<rect x="42" y="27" width="153" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="33" y="81" width="178" height="28" rx="14" fill="#B983EF" fill-opacity="0.3"/>
<rect x="14" y="109" width="170" height="26" rx="13" fill="#B983EF" fill-opacity="0.3"/>
<rect y="54" width="171" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<circle cx="155.5" cy="52.5" r="32.5" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="152.5" cy="141" rx="8.5" ry="8" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="81" cy="14" r="12" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="40" cy="98.5" rx="22" ry="22.5" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="174.5" cy="100" rx="3.5" ry="3" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<path d="M105.577 59.4126L61.6499 80.9909V134.876H149.639V80.9909L105.577 59.4126Z" fill="#300BB0"/>
<path d="M145.298 78.6249V128.86C145.298 131.056 143.501 132.853 141.304 132.853H69.8072C67.6103 132.853 65.813 131.056 65.813 128.86V66.6308C65.813 64.4345 67.6103 62.6377 69.8072 62.6377H129.113L145.298 78.6249Z" fill="white"/>
<path d="M88.581 87.7944H71.006V89.9241H88.581V87.7944Z" fill="#F2F2F2"/>
<path d="M87.6917 70.5513H70.1168V72.681H87.6917V70.5513Z" fill="#5732D9"/>
<path d="M143.302 87.7944H125.727V89.9241H143.302V87.7944Z" fill="#F2F2F2"/>
<path d="M121.333 87.7944H92.7083V89.9241H121.333V87.7944Z" fill="#F2F2F2"/>
<path d="M88.4477 94.8481H70.8727V96.9778H88.4477V94.8481Z" fill="#F2F2F2"/>
<path d="M143.169 94.8481H125.594V96.9778H143.169V94.8481Z" fill="#F2F2F2"/>
<path d="M121.2 94.8481H92.575V96.9778H121.2V94.8481Z" fill="#F2F2F2"/>
<path d="M100.697 102.835H70.8727V104.965H100.697V102.835Z" fill="#F2F2F2"/>
<path d="M143.169 102.835H125.594V104.965H143.169V102.835Z" fill="#F2F2F2"/>
<path d="M88.4477 110.822H70.8727V112.951H88.4477V110.822Z" fill="#F2F2F2"/>
<path d="M143.169 110.822H125.594V112.951H143.169V110.822Z" fill="#F2F2F2"/>
<path d="M121.2 110.822H92.575V112.951H121.2V110.822Z" fill="#F2F2F2"/>
<path d="M88.4477 118.808H70.8727V120.937H88.4477V118.808Z" fill="#F2F2F2"/>
<path d="M143.168 118.808H110.416V120.937H143.168V118.808Z" fill="#F2F2F2"/>
<path d="M103.759 118.808H92.575V120.937H103.759V118.808Z" fill="#F2F2F2"/>
<path d="M88.4477 126.794H70.8727V128.924H88.4477V126.794Z" fill="#F2F2F2"/>
<path d="M143.169 126.794H125.594V128.924H143.169V126.794Z" fill="#F2F2F2"/>
<path d="M121.2 126.794H92.575V128.924H121.2V126.794Z" fill="#F2F2F2"/>
<path d="M121.2 102.835H104.291V104.965H121.2V102.835Z" fill="#F2F2F2"/>
<path d="M129.114 74.6319V62.6377L145.299 78.6249H133.108C130.912 78.6249 129.114 76.8282 129.114 74.6319Z" fill="#E6E6E6"/>
<path d="M149.639 134.675L146.493 134.875H64.7885L61.6499 134.675L105.595 97.3774L149.639 134.675Z" fill="#663FED"/>
<path d="M61.6499 80.9907L101.719 100.666L61.6499 134.875V80.9907Z" fill="#5732D9"/>
<path d="M149.64 80.9902L109.571 100.666L149.64 134.875V80.9902Z" fill="#5732D9"/>
<path d="M61.7265 73.3024C67.6184 73.3024 72.3947 68.5273 72.3947 62.637C72.3947 56.7467 67.6184 51.9717 61.7265 51.9717C55.8345 51.9717 51.0582 56.7467 51.0582 62.637C51.0582 68.5273 55.8345 73.3024 61.7265 73.3024Z" fill="#A764EB"/>
<path d="M66.3748 67.4982C66.0652 67.7645 65.5427 68.0131 64.8064 68.2419C64.07 68.4707 63.0888 68.586 61.8619 68.586C60.9445 68.586 60.1387 68.4501 59.4455 68.1781C58.7523 67.9062 58.1707 67.5273 57.7008 67.0425C57.2308 66.5576 56.8763 65.9762 56.6371 65.2982C56.3969 64.6211 56.2769 63.8821 56.2769 63.0822C56.2769 62.2401 56.4044 61.4608 56.6605 60.7462C56.9166 60.0316 57.2871 59.4155 57.773 58.8988C58.258 58.3811 58.8508 57.976 59.5496 57.6825C60.2485 57.389 61.0402 57.2427 61.9257 57.2427C62.6301 57.2427 63.2962 57.328 63.9256 57.4987C64.555 57.6694 65.1066 57.9413 65.5821 58.3146C66.0568 58.6878 66.4329 59.1679 66.7106 59.754C66.9882 60.3411 67.1271 61.0444 67.1271 61.8659C67.1271 62.5589 67.0417 63.1694 66.871 63.6974C66.7003 64.2254 66.4817 64.668 66.2153 65.0253C65.9489 65.3826 65.6497 65.6517 65.3195 65.8337C64.9884 66.0147 64.6582 66.1056 64.3271 66.1056C63.8787 66.1056 63.5372 66.0231 63.3027 65.858C63.0682 65.693 62.9238 65.4932 62.8703 65.2579C62.6996 65.5458 62.4679 65.7511 62.1743 65.874C61.8807 65.9968 61.5477 66.0578 61.1743 66.0578C60.7578 66.0578 60.4033 65.9837 60.1097 65.8337C59.8161 65.6846 59.5759 65.4876 59.3892 65.2419C59.2026 64.9972 59.0666 64.7168 58.9812 64.4017C58.8958 64.0875 58.8536 63.7593 58.8536 63.4179C58.8536 62.9059 58.923 62.4286 59.0619 61.986C59.2007 61.5433 59.4005 61.1616 59.6622 60.8419C59.9239 60.5221 60.2382 60.2689 60.6059 60.0823C60.9736 59.8957 61.3873 59.8019 61.846 59.8019C62.2193 59.8019 62.5448 59.8844 62.8224 60.0494C63.1001 60.2145 63.2971 60.4677 63.4143 60.809L63.6226 59.9613H64.8711L64.0391 63.9131C63.9753 64.201 63.9434 64.3932 63.9434 64.4889C63.9434 64.5958 63.9837 64.6727 64.0635 64.7205C64.1432 64.7683 64.2257 64.7927 64.3111 64.7927C64.4921 64.7927 64.6788 64.7346 64.8711 64.6164C65.0634 64.4992 65.2388 64.3257 65.3992 64.0969C65.5596 63.8681 65.69 63.5802 65.7913 63.2332C65.8926 62.8872 65.9433 62.4839 65.9433 62.0253C65.9433 61.3642 65.8495 60.7987 65.6628 60.3298C65.4761 59.861 65.2069 59.4793 64.8542 59.1858C64.5025 58.8922 64.0785 58.6765 63.5823 58.5377C63.086 58.399 62.5288 58.3296 61.9097 58.3296C61.195 58.3296 60.5627 58.4655 60.013 58.7375C59.4633 59.0094 59.0047 59.3639 58.6369 59.8019C58.2692 60.2389 57.9888 60.7378 57.7965 61.2976C57.6042 61.8575 57.5085 62.4258 57.5085 63.0016C57.5085 64.4307 57.8978 65.5186 58.6763 66.265C59.4549 67.0115 60.5487 67.3847 61.9566 67.3847C62.8956 67.3847 63.7014 67.3097 64.373 67.1606C65.0456 67.0115 65.5465 66.8146 65.8776 66.5689L66.3748 67.4982ZM61.4145 64.7946C61.8947 64.7946 62.2784 64.5658 62.5664 64.1063C62.8543 63.6477 62.9988 63.0616 62.9988 62.3461C62.9988 61.9091 62.905 61.5733 62.7183 61.338C62.5317 61.1035 62.2568 60.9863 61.8938 60.9863C61.4238 60.9863 61.0271 61.1785 60.7016 61.5621C60.3761 61.9456 60.2138 62.5646 60.2138 63.4179C60.2138 63.8662 60.302 64.2076 60.4783 64.442C60.6537 64.6774 60.9661 64.7946 61.4145 64.7946Z" fill="white"/>
<path d="M144.094 68.7514L155.2 64.4911L169.921 45.2554L145.386 54.4212L144.094 68.7514Z" fill="#5E3BDB"/>
<path d="M125.628 50.6779L177.411 38.2842L160.623 84.5017L152.068 59.9403L168.855 46.2562L145.354 56.7134L125.628 50.6779Z" fill="#A764EB"/>
<path d="M94.0575 37.6689L95.0009 40.7234H98.0554L95.5842 42.6116L96.5288 45.666L94.0575 43.7778L91.5862 45.666L92.5296 42.6116L90.0583 40.7234H93.1129L94.0575 37.6689Z" fill="#A764EB"/>
<path d="M81.4461 52.4326L82.0269 54.3124H83.9068L82.386 55.4741L82.9669 57.3539L81.4461 56.1921L79.9254 57.3539L80.5062 55.4741L78.9855 54.3124H80.8653L81.4461 52.4326Z" fill="#A764EB"/>
</svg>


<svg width="211" height="151" viewBox="0 0 211 151" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="7.5" cy="81.5" r="3.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<rect x="42" y="27" width="153" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="33" y="81" width="178" height="28" rx="14" fill="#B983EF" fill-opacity="0.3"/>
<rect x="14" y="109" width="170" height="26" rx="13" fill="#B983EF" fill-opacity="0.3"/>
<rect y="54" width="171" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<circle cx="155.5" cy="52.5" r="32.5" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="152.5" cy="141" rx="8.5" ry="8" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="81" cy="14" r="12" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="40" cy="98.5" rx="22" ry="22.5" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="174.5" cy="100" rx="3.5" ry="3" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<g clip-path="url(#clip0)">
<path d="M119.989 38H100.97V134.49H119.989C123.833 134.49 126.94 131.367 126.94 127.538V44.9515C126.956 41.1227 123.833 38 119.989 38Z" fill="#5732D9"/>
<path d="M81.9515 38C78.1227 38 75 41.1227 75 44.9515V127.523C75 131.367 78.1227 134.474 81.9515 134.474H100.97V38H81.9515Z" fill="#5732D9"/>
<path d="M111.531 41.8604H90.4094V43.6022H111.531V41.8604Z" fill="white"/>
<path d="M100.97 131.791C97.8162 131.791 95.2427 129.218 95.2427 126.048C95.2427 122.878 97.8162 120.32 100.97 120.32C104.14 120.32 106.714 122.894 106.714 126.048C106.714 129.218 104.14 131.791 100.97 131.791ZM100.97 121.56C98.4909 121.56 96.4823 123.569 96.4823 126.048C96.4823 128.527 98.4909 130.536 100.97 130.536C103.45 130.536 105.458 128.527 105.458 126.048C105.474 123.569 103.45 121.56 100.97 121.56Z" fill="white"/>
<path d="M124.54 48.3208H77.0642V116.439H124.54V48.3208Z" fill="white"/>
<path d="M162.263 74.0602C162.263 86.7079 152.001 96.9705 139.353 96.9705V51.1499C152.001 51.1499 162.263 61.3968 162.263 74.0602Z" fill="#A764EB"/>
<path d="M116.443 74.0602C116.443 61.4125 126.705 51.1499 139.353 51.1499V96.9705C134.19 96.9705 129.436 95.2601 125.607 92.3884L116.443 100.203L120.836 87.5553C118.075 83.7578 116.443 79.0973 116.443 74.0602Z" fill="#A764EB"/>
<path d="M129.545 74.0599C129.545 75.6134 128.274 76.8845 126.721 76.8845C125.167 76.8845 123.896 75.6134 123.896 74.0599C123.896 72.5064 125.167 71.2354 126.721 71.2354C128.274 71.2354 129.545 72.4907 129.545 74.0599Z" fill="white"/>
<path d="M142.177 74.0599C142.177 75.6134 140.906 76.8845 139.353 76.8845C137.799 76.8845 136.528 75.6134 136.528 74.0599C136.528 72.5064 137.799 71.2354 139.353 71.2354C140.906 71.2354 142.177 72.4907 142.177 74.0599Z" fill="white"/>
<path d="M154.81 74.0599C154.81 75.6134 153.538 76.8845 151.985 76.8845C150.431 76.8845 149.16 75.6134 149.16 74.0599C149.16 72.5064 150.431 71.2354 151.985 71.2354C153.538 71.2354 154.81 72.4907 154.81 74.0599Z" fill="white"/>
</g>
<defs>
<clipPath id="clip0">
<rect width="87.2631" height="96.49" fill="white" transform="translate(75 38)"/>
</clipPath>
</defs>
</svg>

<svg width="207" height="148" viewBox="0 0 207 148" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="41.9241" y="26.3418" width="149.354" height="27.0759" rx="13.538" fill="#B983EF" fill-opacity="0.27"/>
<rect x="32.3164" y="79.6201" width="174.684" height="26.2025" rx="13.1013" fill="#B983EF" fill-opacity="0.27"/>
<rect x="13.9747" y="105.823" width="166.823" height="26.2025" rx="13.1013" fill="#B983EF" fill-opacity="0.27"/>
<rect y="53.4177" width="167.696" height="26.2025" rx="13.1013" fill="#B983EF" fill-opacity="0.27"/>
<circle cx="152.411" cy="51.234" r="31.8797" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="149.354" cy="138.139" r="7.86076" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="79.0443" cy="13.6771" r="11.7911" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="38.8671" cy="96.2151" rx="22.2722" ry="21.8354" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<g clip-path="url(#clip0)">
<path d="M120.824 129.288C120.824 130.8 109.81 132.025 96.2221 132.025C82.6344 132.025 71.6202 130.799 71.6202 129.288C71.6202 127.777 82.6344 126.552 96.2221 126.552C109.81 126.55 120.824 127.777 120.824 129.288Z" fill="black" fill-opacity="0.3"/>
<path d="M86.1219 53.1458C86.4624 52.4148 86.8787 51.541 86.3494 50.9335C85.9965 50.6061 85.6146 50.8586 85.3086 51.0181C85.9854 50.5076 86.3507 49.5048 85.9262 48.7683C85.5016 48.0317 84.1962 47.9846 83.8888 48.778C83.9329 48.4326 83.5814 48.1399 83.2367 48.1219C82.8921 48.1039 82.5682 48.2786 82.2746 48.4631C78.8904 50.5881 76.9053 54.4344 75.9542 58.332C74.5164 64.2229 75.2939 70.957 79.2846 75.5038C80.5818 76.981 84.8248 80.3002 86.7836 80.3016C89.0305 80.303 90.092 77.6759 90.9204 75.5745C91.7696 73.4218 96.5764 70.5159 94.5459 69.4465C92.82 68.5366 87.4466 68.8487 85.8131 65.2534C84.0845 61.446 84.3547 56.9436 86.1219 53.1458Z" fill="#4620C8"/>
<path d="M125.906 118.904C125.776 119.339 125.613 119.802 125.242 120.065C124.871 120.325 124.237 120.235 124.113 119.797C124.201 120.612 123.331 121.375 122.54 121.176C121.749 120.976 121.34 119.891 121.799 119.213C121.439 119.644 120.672 119.372 120.431 118.865C120.188 118.357 120.299 117.761 120.395 117.206C120.762 115.11 120.868 112.946 120.455 110.859C119.685 106.978 117.186 103.621 116.36 99.7525C116.063 98.3585 116.008 96.83 116.687 95.5802C117.749 93.6272 120.255 91.7159 122.123 92.8602C123.584 93.7562 124.913 95.4998 125.54 97.0228C127.202 101.066 127.299 107.123 127.132 111.494C127.035 114.002 126.63 116.5 125.906 118.904Z" fill="#4620C8"/>
<path d="M121.669 92.3289L108.143 80.8913L92.1528 73.3318C92.1528 73.3318 81.8913 81.65 78.259 87.7197C74.6267 93.7895 74.1525 99.1588 77.7972 104.448C81.4419 109.737 87.2826 113.706 87.2826 113.706C87.2826 113.706 93.3135 117.378 99.6132 118.49C105.914 119.603 110.558 116.917 114.512 111.056C118.467 105.19 121.669 92.3289 121.669 92.3289Z" fill="white"/>
<path d="M121.669 92.3289L117.273 88.6116C116.06 92.8074 113.7 100.132 110.984 104.159C107.031 110.022 102.385 112.706 96.0856 111.594C89.786 110.481 83.7551 106.81 83.7551 106.81C83.7551 106.81 79.1041 103.649 75.5117 99.2087C75.8563 100.977 76.6049 102.717 77.7973 104.446C81.4434 109.735 87.2826 113.705 87.2826 113.705C87.2826 113.705 93.3135 117.376 99.6132 118.489C105.914 119.601 110.558 116.916 114.512 111.054C118.467 105.19 121.669 92.3289 121.669 92.3289Z" fill="#F9F2FF"/>
<path d="M118.248 103.271C121.304 98.4652 121.674 92.3136 121.674 92.3136L108.149 80.8759L95.8513 64.6584C95.8513 64.6584 86.3907 75.2403 82.8342 81.9634C86.6678 81.1741 90.9094 81.2712 94.8257 82.3101C99.6339 83.5862 104.11 86.0857 108.127 89.097C118.147 96.6065 118.202 103.13 118.248 103.271Z" fill="#4620C8"/>
<path d="M100.852 43.155C100.852 43.155 94.2136 26.7531 109.451 24.7308C122.886 22.9484 121.89 39.2699 121.89 39.2699L100.852 43.155Z" fill="#4620C8"/>
<path d="M105.374 40.3283C105.374 40.3283 101.67 31.1765 110.172 30.0488C117.669 29.0543 117.113 38.1603 117.113 38.1603L105.374 40.3283Z" fill="#A764EB"/>
<path d="M107.013 25.2634C119.887 23.5545 119.509 38.471 119.455 39.7193L121.89 39.2699C121.89 39.2699 122.886 22.9484 109.451 24.7308C108.458 24.8625 107.556 25.0567 106.741 25.3022C106.831 25.2897 106.922 25.2759 107.013 25.2634Z" fill="#4620C8"/>
<path opacity="0.22" d="M102.985 28.7463C102.146 29.5494 101.487 30.5773 101.259 31.7049C101.153 32.2306 101.174 32.8493 101.578 33.1766C101.941 33.472 102.512 33.4096 102.911 33.1294C103.309 32.8493 103.557 32.3971 103.714 31.938C103.871 31.4788 103.951 30.9989 104.097 30.537C104.46 29.3955 105.246 28.3788 106.26 27.7366C106.466 27.6062 106.712 27.4314 106.683 27.1956C106.537 25.95 103.281 28.4634 102.985 28.7463Z" fill="white"/>
<path d="M145.718 65.8598C145.718 65.8598 162.86 61.8429 162.447 77.3031C162.085 90.9337 146.223 87.3759 146.223 87.3759L145.718 65.8598Z" fill="#512CD3"/>
<path d="M147.782 70.7978C147.782 70.7978 157.346 68.5563 157.117 77.1824C156.914 84.7877 148.064 82.8028 148.064 82.8028L147.782 70.7978Z" fill="#A764EB"/>
<path d="M162.308 74.7968C161.961 87.8573 147.381 85.1373 146.163 84.8876L146.221 87.3774C146.221 87.3774 162.083 90.9338 162.446 77.3046C162.472 76.2962 162.424 75.371 162.311 74.5208C162.312 74.6109 162.311 74.7025 162.308 74.7968Z" fill="#4620C8"/>
<path opacity="0.22" d="M159.524 70.2458C158.867 69.2846 157.963 68.469 156.892 68.0653C156.393 67.8767 155.782 67.8018 155.398 68.1513C155.052 68.4662 155.021 69.0446 155.234 69.4843C155.446 69.924 155.851 70.2416 156.277 70.4705C156.703 70.698 157.161 70.8533 157.591 71.0725C158.654 71.612 159.528 72.5525 159.999 73.6621C160.094 73.8868 160.228 74.1587 160.464 74.1684C161.708 74.2156 159.755 70.5842 159.524 70.2458Z" fill="white"/>
<path d="M144.917 90.0085C149.6 84.4145 152.874 74.3846 150.093 64.3951C147.517 55.1392 133.36 40.2145 122.755 36.7482C113.965 33.8742 103.403 37.3807 97.8197 42.0648C92.2368 46.7475 84.6055 57.1088 90.0781 66.5922C95.5507 76.0769 110.873 91.5703 120.271 97.1254C129.668 102.679 140.234 95.6025 144.917 90.0085Z" fill="white"/>
<path d="M144.953 90.0459C149.444 84.6794 152.637 75.2307 150.435 65.6503C149.983 72.0835 147.47 77.8745 144.312 81.6473C139.629 87.2413 129.063 94.318 119.665 88.7643C110.266 83.2105 94.9456 67.7157 89.4716 58.231C89.1215 57.6248 88.8265 57.0145 88.5797 56.4028C87.8739 59.7234 88.1538 63.2327 90.1126 66.6296C95.5852 76.1143 110.907 91.6077 120.306 97.1629C129.704 102.717 140.272 95.6399 144.953 90.0459Z" fill="#F9F2FF"/>
<path d="M117.43 43.0608C114.97 42.5753 112.433 42.6294 109.937 42.8583C106.774 43.1496 103.509 43.7737 100.96 45.6782C100.512 46.0125 98.5531 47.6353 98.8812 50.9753C99.0177 52.3652 99.7262 53.6524 100.705 54.6427C105.622 59.6153 110.423 58.6055 111.558 58.3531C115.073 57.5708 118.381 55.9923 121.917 55.3043C123.009 55.0921 124.092 54.8036 124.991 54.1448C126.622 52.9491 128.002 48.4662 122.582 45.1428C120.991 44.1663 119.254 43.4214 117.43 43.0608Z" fill="#4620C8"/>
<path d="M142.756 68.6602C143.228 71.1375 143.165 73.6896 142.927 76.2002C142.625 79.3807 141.992 82.6639 140.088 85.2216C139.755 85.671 138.134 87.6351 134.816 87.2925C133.436 87.1496 132.159 86.4312 131.179 85.4436C126.257 80.4765 127.279 75.6496 127.536 74.5094C128.327 70.9752 129.909 67.6518 130.606 64.0981C130.821 63.001 131.113 61.9108 131.77 61.0092C132.964 59.3724 137.426 58.002 140.707 63.4684C141.672 65.0732 142.405 66.8237 142.756 68.6602Z" fill="#4620C8"/>
<path d="M125.927 67.0139C125.286 65.4146 123.523 63.3202 123.185 63.1288C122.998 62.7875 120.925 61.0038 119.338 60.3505C118.475 59.9954 117.352 60.1937 116.69 60.8554C115.611 61.9345 116.012 62.8153 116.223 63.3659C116.69 64.5838 117.426 65.7558 117.412 67.0611C117.409 67.394 117.356 67.731 117.409 68.0597C117.444 68.272 117.538 68.4842 117.684 68.6354C117.833 68.7824 118.045 68.8781 118.254 68.9142C118.581 68.9696 118.916 68.9183 119.247 68.9169C120.544 68.91 121.706 69.6576 122.914 70.1334C123.46 70.3484 124.332 70.7576 125.41 69.6757C126.073 69.0127 126.276 67.885 125.927 67.0139Z" fill="#040226"/>
<path opacity="0.22" d="M117.742 61.3143C117.517 61.6111 117.524 62.0633 117.755 62.3532C117.991 62.6486 118.392 62.7499 118.767 62.7721C119.142 62.7943 119.525 62.7541 119.891 62.8414C120.693 63.0342 121.239 63.7874 121.987 64.1356C122.099 64.1883 122.234 64.2299 122.343 64.1703C122.452 64.1092 122.49 63.9622 122.462 63.8401C122.433 63.7181 122.353 63.6154 122.273 63.5183C121.621 62.7346 118.818 59.8842 117.742 61.3143Z" fill="white"/>
<path d="M110.822 71.8935C110.925 72.4733 111.199 73.0184 111.538 73.5094C112.083 74.2959 112.812 74.97 113.67 75.3778C114.527 75.7856 115.513 75.9159 116.395 75.6677C116.136 75.2502 116.119 74.7397 116.115 74.2584C116.111 73.8284 116.111 73.3984 116.141 72.9726C116.235 71.6646 116.62 70.3941 117.261 69.2803C116.615 69.5605 115.97 69.842 115.325 70.1222C115.049 70.2429 114.771 70.3636 114.476 70.4315C114.236 70.487 113.989 70.5078 113.743 70.5286C113.332 70.5633 112.92 70.598 112.505 70.5688C112.233 70.5508 111.963 70.505 111.697 70.4329C111.476 70.3733 111.212 70.1957 111.024 70.3594C110.702 70.6451 110.751 71.5065 110.822 71.8935Z" fill="#A764EB"/>
<path d="M113.372 72.0864C113.692 72.5122 114.131 72.8368 114.601 73.0781C114.994 73.2793 115.445 73.4291 115.854 73.3112C115.899 73.2987 115.945 73.2806 115.974 73.2446C115.996 73.2168 116.006 73.1808 116.016 73.1447C116.096 72.834 116.177 72.5233 116.225 72.2043C116.265 71.9366 116.282 71.6647 116.334 71.3998C116.478 70.6688 116.877 70.0308 117.15 69.3442C116.917 69.2942 116.712 69.4635 116.52 69.5911C115.955 69.9683 115.251 70.0474 114.585 70.1487C114.17 70.2111 112.946 70.3026 112.906 70.8547C112.874 71.2694 113.128 71.7604 113.372 72.0864Z" fill="#8440CA"/>
<path d="M118.514 78.0521C118.6 77.8981 118.533 77.74 118.403 77.6443C117.259 76.7912 116.516 75.4527 116.298 74.0476C116.06 72.5163 116.577 71.0433 117.374 69.7561C117.573 69.4343 117.789 69.1236 118.012 68.8184C118.616 68.283 119.173 67.6949 119.717 67.0999C119.975 66.8183 119.557 66.3925 119.298 66.6754C119.171 66.8141 119.043 66.9528 118.913 67.0915C118.803 67.0402 118.656 67.0471 118.576 67.1456C118.234 67.5617 117.891 67.9848 117.567 68.4217C116.939 68.9724 116.261 69.4565 115.495 69.8005C114.178 70.3913 112.681 70.3997 111.337 69.892C110.609 69.6174 109.945 69.1777 109.403 68.6173C109.136 68.3413 108.715 68.7629 108.981 69.039C110.054 70.1472 111.552 70.788 113.082 70.856C113.856 70.8907 114.637 70.77 115.362 70.4968C115.802 70.3303 116.217 70.1181 116.614 69.8726C116.319 70.4011 116.07 70.9531 115.896 71.5412C115.44 73.085 115.63 74.7536 116.387 76.1698C116.807 76.9563 117.396 77.6332 118.107 78.1644C118.238 78.2601 118.441 78.1811 118.514 78.0521Z" fill="#040226"/>
<path d="M120.297 49.2553C120.303 46.6469 118.207 44.527 115.615 44.5203C113.023 44.5137 110.916 46.6228 110.909 49.2312C110.903 51.8396 112.999 53.9595 115.591 53.9662C118.183 53.9728 120.29 51.8637 120.297 49.2553Z" fill="#232120"/>
<path d="M118.565 52.9392C116.727 54.7798 113.755 54.7715 111.926 52.9225C110.096 51.0736 110.105 48.0831 111.942 46.2425C113.78 44.4018 116.752 44.4102 118.581 46.2591C120.41 48.1094 120.403 51.0999 118.565 52.9392Z" fill="white"/>
<path d="M119.936 50.0596C119.713 50.7407 119.332 51.3801 118.792 51.9211C116.955 53.7617 113.983 53.7534 112.153 51.9044C111.126 50.8655 110.678 49.4674 110.809 48.115C110.272 49.7517 110.645 51.627 111.937 52.9336C113.766 54.7826 116.738 54.7909 118.576 52.9503C119.382 52.1444 119.836 51.1166 119.936 50.0596Z" fill="#E3FFFE"/>
<path d="M116.565 53.0367C115.366 54.2365 113.428 54.2324 112.235 53.0256C111.043 51.8189 111.047 49.8687 112.246 48.6689C113.446 47.4691 115.384 47.4732 116.576 48.68C117.769 49.8853 117.763 51.8369 116.565 53.0367Z" fill="#39B4EA"/>
<path d="M117.249 49.7063C117.216 50.4498 116.917 51.1849 116.35 51.7508C115.151 52.9506 113.213 52.9465 112.02 51.7397C111.721 51.436 111.496 51.0864 111.348 50.7133C111.31 51.5442 111.607 52.3889 112.235 53.0255C113.428 54.2323 115.366 54.2364 116.565 53.0366C117.463 52.1378 117.69 50.8187 117.249 49.7063Z" fill="#2D90B2"/>
<path d="M116.553 53.0337C115.379 54.2513 113.482 54.2466 112.312 53.0221C111.144 51.7976 111.149 49.8199 112.323 48.6C113.498 47.3824 115.394 47.387 116.565 48.6115C117.73 49.836 117.726 51.8161 116.553 53.0337Z" fill="#232120"/>
<path d="M112.824 48.8075C112.715 48.9115 112.613 49.0252 112.55 49.1626C112.486 49.2999 112.468 49.4622 112.528 49.6009C112.594 49.7534 112.745 49.8533 112.907 49.8935C113.067 49.9338 113.235 49.9199 113.399 49.8977C113.938 49.8242 114.477 49.6494 114.899 49.3054C115.005 49.2194 115.112 49.1029 115.103 48.9656C115.097 48.8851 115.053 48.8144 115.003 48.7506C114.464 48.0668 113.386 48.2707 112.824 48.8075Z" fill="white"/>
<path d="M114.406 54.0646C113.55 54.0646 112.747 53.7289 112.144 53.1186C110.902 51.8633 110.908 49.8257 112.155 48.576C112.758 47.9726 113.557 47.6411 114.406 47.6411C115.263 47.6411 116.066 47.9768 116.669 48.5871C117.911 49.8424 117.905 51.88 116.658 53.1297C116.055 53.7331 115.256 54.0646 114.406 54.0646ZM114.405 47.9033C113.625 47.9033 112.89 48.2084 112.337 48.7619C111.192 49.909 111.188 51.7801 112.326 52.9327C112.881 53.4931 113.618 53.8024 114.404 53.8024C115.184 53.8024 115.919 53.4973 116.471 52.9438C117.617 51.7967 117.623 49.9256 116.482 48.773C115.93 48.2126 115.191 47.9033 114.405 47.9033Z" fill="#288199"/>
<path d="M115.95 48.7937C115.884 48.7632 115.811 48.7396 115.738 48.7452C115.665 48.7507 115.591 48.7882 115.56 48.8548C115.518 48.9463 115.564 49.0545 115.624 49.1363C115.722 49.2723 115.852 49.3819 116.003 49.454C116.081 49.4914 116.17 49.5192 116.255 49.5067C116.342 49.4928 116.425 49.429 116.437 49.343C116.444 49.2945 116.429 49.2445 116.409 49.1988C116.328 49.0115 116.16 48.8645 115.964 48.8076L115.95 48.7937Z" fill="white"/>
<path d="M136.672 74.6934C139.262 74.5757 141.266 72.368 141.149 69.7622C141.032 67.1564 138.838 65.1393 136.249 65.257C133.659 65.3746 131.654 67.5824 131.771 70.1882C131.888 72.794 134.082 74.811 136.672 74.6934Z" fill="#232120"/>
<path d="M139.422 73.6718C137.585 75.5124 134.613 75.5041 132.784 73.6552C130.956 71.8062 130.963 68.8157 132.8 66.9751C134.638 65.1359 137.61 65.1428 139.439 66.9917C141.268 68.8421 141.26 71.8326 139.422 73.6718Z" fill="white"/>
<path d="M140.794 70.7923C140.571 71.4734 140.19 72.1128 139.65 72.6537C137.812 74.4944 134.84 74.486 133.011 72.6371C131.984 71.5982 131.536 70.2 131.667 68.8477C131.129 70.4844 131.503 72.3597 132.795 73.6663C134.624 75.5152 137.596 75.5236 139.433 73.6829C140.238 72.8771 140.692 71.8492 140.794 70.7923Z" fill="#E3FFFE"/>
<path d="M137.422 73.7692C136.224 74.969 134.284 74.9648 133.092 73.7581C131.9 72.5527 131.904 70.6011 133.103 69.4013C134.302 68.2015 136.24 68.2057 137.433 69.4124C138.627 70.6178 138.621 72.5694 137.422 73.7692Z" fill="#39B4EA"/>
<path d="M138.105 70.4387C138.072 71.1822 137.773 71.9173 137.207 72.4832C136.009 73.683 134.069 73.6789 132.877 72.4721C132.578 72.1698 132.353 71.8188 132.204 71.4457C132.167 72.2766 132.463 73.1213 133.092 73.7579C134.284 74.9647 136.222 74.9689 137.422 73.769C138.319 72.8702 138.548 71.5511 138.105 70.4387Z" fill="#2D90B2"/>
<path d="M137.585 73.996C136.324 75.2571 134.287 75.2523 133.031 73.984C131.777 72.7158 131.782 70.6674 133.043 69.4039C134.304 68.1429 136.341 68.1477 137.597 69.4159C138.851 70.6842 138.846 72.7349 137.585 73.996Z" fill="#232120"/>
<path d="M133.682 69.5401C133.573 69.6441 133.471 69.7579 133.408 69.8952C133.344 70.0325 133.326 70.1948 133.386 70.3335C133.452 70.4861 133.603 70.5859 133.765 70.6262C133.925 70.6664 134.093 70.6525 134.257 70.6303C134.796 70.5568 135.335 70.382 135.757 70.0381C135.863 69.9521 135.97 69.8355 135.961 69.6982C135.955 69.6178 135.911 69.547 135.861 69.4832C135.322 68.7994 134.243 69.0019 133.682 69.5401Z" fill="white"/>
<path d="M135.263 74.797C134.407 74.797 133.603 74.4613 133 73.851C132.399 73.2435 132.068 72.4348 132.07 71.5776C132.073 70.719 132.407 69.9146 133.011 69.3084C133.613 68.705 134.413 68.3735 135.262 68.3735C136.118 68.3735 136.921 68.7092 137.524 69.3195C138.125 69.927 138.456 70.7357 138.453 71.5929C138.45 72.4501 138.117 73.256 137.513 73.8621C136.912 74.4655 136.112 74.797 135.263 74.797ZM135.263 68.6357C134.483 68.6357 133.748 68.9408 133.195 69.4943C132.64 70.0505 132.334 70.7898 132.331 71.5776C132.33 72.3655 132.631 73.1062 133.184 73.6652C133.738 74.2255 134.476 74.5348 135.262 74.5348C136.042 74.5348 136.777 74.2297 137.329 73.6763C137.885 73.12 138.191 72.3807 138.194 71.5929C138.196 70.805 137.893 70.063 137.34 69.5054C136.786 68.945 136.049 68.6357 135.263 68.6357Z" fill="#288199"/>
<path d="M136.807 69.5262C136.741 69.4957 136.668 69.4721 136.595 69.4776C136.522 69.4832 136.447 69.5206 136.417 69.5872C136.374 69.6787 136.421 69.7869 136.48 69.8688C136.578 70.0047 136.709 70.1143 136.859 70.1864C136.938 70.2239 137.026 70.253 137.112 70.2391C137.198 70.2252 137.281 70.1614 137.294 70.0754C137.3 70.0269 137.285 69.977 137.266 69.9312C137.185 69.7439 137.016 69.5969 136.821 69.54L136.807 69.5262Z" fill="white"/>
<path d="M132.86 45.5353C133.878 46.0207 135.18 45.8252 136.012 45.0609C136.845 44.2966 137.159 43.0108 136.773 41.9456C137.748 42.7501 138.378 43.9623 138.478 45.2273C139.358 44.5699 140.48 44.2994 141.576 44.2883C142.672 44.2772 143.756 44.5061 144.822 44.7654C143.202 45.2454 141.791 46.398 140.991 47.8946C141.461 47.9099 141.926 48.0666 142.31 48.3385C141.629 48.4717 141.024 48.9544 140.74 49.591C140.467 50.2041 140.488 50.9101 140.272 51.5468C140.174 51.8325 140.019 52.1141 139.766 52.2764C139.344 52.5468 138.788 52.4178 138.318 52.2417C136.227 51.4594 134.476 49.9697 132.894 48.3871C132.405 47.8974 131.897 47.154 132.281 46.5783C132.544 46.183 133.09 46.1206 133.563 46.1151L132.86 45.5353Z" fill="white"/>
<path d="M79.8443 120.232C80.3612 121.6 80.8974 122.969 81.6074 124.169C82.3187 125.369 83.2216 126.399 84.2954 126.908C85.3665 127.416 86.5341 127.376 87.6644 127.229C88.1938 127.159 88.7479 127.055 89.1711 126.62C89.4702 126.312 89.6743 125.867 89.8452 125.414C90.7398 123.048 90.8763 120.309 90.9756 117.657C91.0376 116.002 90.5455 114.421 88.5522 113.526C87.3143 112.971 80.9953 108.785 78.7401 103.009C78.3059 101.896 75.6923 97.9521 75.5117 99.6582C75.0003 104.506 79.337 118.891 79.8443 120.232Z" fill="#4620C8"/>
<path d="M111.894 123.06C111.379 124.08 110.845 125.099 110.136 125.994C109.428 126.887 108.525 127.657 107.453 128.039C106.383 128.419 105.214 128.391 104.084 128.284C103.554 128.234 103 128.157 102.575 127.833C102.276 127.604 102.071 127.274 101.899 126.937C101.001 125.179 99.0796 120.365 99.0728 118.387C99.0714 117.795 101.16 118.256 103.152 117.587C104.39 117.171 108.74 115.247 110.688 112.293C111.308 111.351 112.048 110.501 112.687 109.57C113.23 108.778 117.001 105.864 117.019 107.14C117.055 109.546 112.4 122.062 111.894 123.06Z" fill="#4620C8"/>
<path d="M112.903 126.018C113.372 126.485 113.696 127.141 113.623 127.802C113.55 128.462 112.998 129.079 112.338 129.086C112.377 129.581 111.953 130 111.503 130.203C110.783 130.526 109.96 130.494 109.174 130.427C107.546 130.289 105.918 130.024 104.379 129.472C103.68 129.222 102.979 128.896 102.489 128.337C102.056 127.843 101.823 127.208 101.624 126.581C101.252 125.41 100.972 124.113 101.441 122.979C101.966 121.705 103.349 120.952 104.712 120.82C106.076 120.689 107.435 121.073 108.733 121.51C109.844 121.884 110.751 122.386 111.046 123.585C111.348 124.808 112.062 125.177 112.903 126.018Z" fill="#4620C8"/>
<path d="M78.2962 125.616C77.7944 126.047 77.4222 126.677 77.4443 127.34C77.4677 128.003 77.9709 128.661 78.6284 128.718C78.5526 129.209 78.9427 129.659 79.3769 129.895C80.0703 130.272 80.8933 130.302 81.6818 130.295C83.3153 130.28 84.9584 130.14 86.5354 129.707C87.2509 129.51 87.9732 129.24 88.5053 128.72C88.974 128.261 89.2538 127.645 89.4992 127.034C89.9582 125.896 90.3345 124.624 89.9527 123.456C89.524 122.146 88.202 121.291 86.8525 121.055C85.5029 120.819 84.1189 121.099 82.7914 121.436C81.6556 121.725 80.7141 122.156 80.3295 123.33C79.9352 124.528 79.1963 124.842 78.2962 125.616Z" fill="#4620C8"/>
<path d="M83.5965 53.5468C83.3815 53.802 83.0975 54.0073 82.775 54.0891C82.4524 54.171 82.0912 54.1224 81.8224 53.9241C81.595 53.7562 81.4475 53.4955 81.3634 53.225C81.3179 53.078 81.2876 52.924 81.2862 52.77C81.2821 52.3747 81.4599 51.9988 81.6818 51.6715C81.861 51.4079 82.0747 51.1597 82.3476 50.996C82.968 50.6215 83.7633 50.8975 84.0129 51.5952C84.2348 52.2166 84.0073 53.0572 83.5965 53.5468Z" fill="#A764EB"/>
<path d="M85.3486 52.702C85.2852 52.7284 85.2177 52.7492 85.1487 52.745C85.0081 52.7367 84.8868 52.6202 84.8468 52.4842C84.8069 52.3483 84.8344 52.1985 84.8965 52.0709C85.0164 51.8212 85.2645 51.6395 85.5375 51.6007C85.6753 51.5813 85.8242 51.5993 85.9372 51.6797C86.3687 51.9877 85.6312 52.5869 85.3486 52.702Z" fill="#A764EB"/>
<path d="M85.4175 49.527C85.3541 49.9625 85.1046 50.3884 84.7089 50.5756C84.5807 50.6366 84.4332 50.6713 84.2968 50.6339C84.0748 50.5728 83.937 50.3287 83.9384 50.0957C83.9397 49.864 84.0514 49.6463 84.1865 49.4576C84.334 49.2523 84.527 49.0609 84.771 48.9971C85.1266 48.9056 85.4726 49.1483 85.4175 49.527Z" fill="#A764EB"/>
<path d="M82.7805 50.0722C82.7309 50.1055 82.6771 50.136 82.6179 50.143C82.5214 50.1541 82.429 50.1 82.3587 50.0348C82.1933 49.8794 82.1133 49.6395 82.1492 49.4162C82.1781 49.2386 82.2746 49.0791 82.3821 48.9348C82.4704 48.8156 82.571 48.7004 82.7033 48.6339C82.8357 48.5673 83.0052 48.559 83.1238 48.6477C83.5911 48.9931 83.1334 49.8337 82.7805 50.0722Z" fill="#A764EB"/>
</g>
<defs>
<clipPath id="clip0">
<rect width="90.8354" height="107.43" fill="white" transform="translate(71.6202 24.5947)"/>
</clipPath>
</defs>
</svg>


<svg width="211" height="151" viewBox="0 0 211 151" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="7.5" cy="81.5" r="3.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<rect x="42" y="27" width="153" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="33" y="81" width="178" height="28" rx="14" fill="#B983EF" fill-opacity="0.3"/>
<rect x="14" y="109" width="170" height="26" rx="13" fill="#B983EF" fill-opacity="0.3"/>
<rect y="54" width="171" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<circle cx="155.5" cy="52.5" r="32.5" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="152.5" cy="141" rx="8.5" ry="8" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="81" cy="14" r="12" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="40" cy="98.5" rx="22" ry="22.5" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="174.5" cy="100" rx="3.5" ry="3" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<path d="M120.589 84.7112C119.475 65.995 108.861 52.1578 93.6654 43.6818C98.323 42.2636 103.261 41.5 108.387 41.5C134.898 41.5 156.49 59.3111 158.903 85.0504L159.03 86.4062L160.392 86.4103L172.319 86.447C172.319 86.447 172.319 86.447 172.319 86.447C173.189 86.4511 173.773 86.5788 174.127 86.7302C174.298 86.8036 174.393 86.8733 174.441 86.9179C174.486 86.9591 174.493 86.9808 174.493 86.9811C174.493 86.9816 174.503 87.0028 174.499 87.0644C174.494 87.1309 174.472 87.2482 174.396 87.4204C174.241 87.7754 173.9 88.2724 173.266 88.875L173.265 88.8754L143.771 116.915L143.77 116.916C141.476 119.102 137.68 119.088 135.399 116.878L135.398 116.877L106.241 88.7005L106.239 88.6983C105.612 88.095 105.277 87.5977 105.125 87.2429C105.052 87.0708 105.031 86.9534 105.027 86.8862C105.023 86.8254 105.032 86.8024 105.033 86.7993L105.034 86.7992L105.034 86.799C105.035 86.7959 105.044 86.773 105.089 86.7321C105.138 86.687 105.234 86.6174 105.406 86.5448C105.761 86.3951 106.346 86.2708 107.214 86.2728L119.088 86.3003L120.684 86.304L120.589 84.7112Z" fill="#663FED" stroke="white" stroke-width="3"/>
<path d="M89.4065 76.2889C90.521 95.0057 101.135 108.843 116.331 117.326C111.674 118.742 106.736 119.5 101.609 119.5C75.0973 119.5 53.5055 101.698 51.0926 75.9497L50.9655 74.5939L49.6037 74.5897L37.6768 74.553C37.6767 74.553 37.6766 74.553 37.6764 74.553C36.8072 74.549 36.2233 74.4212 35.8711 74.2701C35.7005 74.1968 35.6057 74.1273 35.558 74.0831C35.5139 74.0423 35.5068 74.0208 35.5067 74.0204L35.5066 74.0203C35.506 74.0189 35.4968 73.9969 35.5012 73.9362C35.506 73.8691 35.5283 73.7514 35.6036 73.5788C35.7587 73.2232 36.0993 72.7261 36.7315 72.1236C36.7315 72.1235 36.7316 72.1234 36.7317 72.1234L66.215 44.0951C66.2152 44.095 66.2153 44.0948 66.2155 44.0947C68.5193 41.907 72.3083 41.9211 74.5988 44.1325L103.755 72.2997L103.755 72.3C104.382 72.9057 104.718 73.4048 104.87 73.7614C104.944 73.9343 104.965 74.0526 104.969 74.1206C104.973 74.1836 104.963 74.2069 104.962 74.2095L104.962 74.2097C104.961 74.213 104.951 74.2361 104.907 74.277C104.857 74.3222 104.761 74.3918 104.589 74.4644C104.235 74.614 103.65 74.7384 102.782 74.7364L90.9085 74.6997L89.3116 74.6948L89.4065 76.2889Z" fill="#5732D9" stroke="white" stroke-width="3"/>
</svg>


<svg width="221" height="158" viewBox="0 0 221 158" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="45" y="28" width="159" height="29" rx="14.5" fill="#DCD1FF" fill-opacity="0.08"/>
<rect x="34" y="86" width="187" height="27" rx="13.5" fill="#DCD1FF" fill-opacity="0.08"/>
<rect x="15" y="113" width="177" height="28" rx="14" fill="#DCD1FF" fill-opacity="0.08"/>
<rect y="57" width="179" height="29" rx="14.5" fill="#DCD1FF" fill-opacity="0.08"/>
<circle cx="163" cy="55" r="34" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="160" cy="147.5" rx="9" ry="8.5" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="84.5" cy="14.5" r="12.5" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="41.5" cy="103" rx="23.5" ry="23" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="182.5" cy="104.5" rx="3.5" ry="2.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<path d="M109.791 141.656C80.6238 133.347 72.2078 101.115 72.1195 100.748L72 100.255V47H150V100.255L149.881 100.747C149.792 101.115 141.052 134.092 112.209 141.656L111 142L109.791 141.656Z" fill="white"/>
<path d="M110.174 138.524C110.708 138.688 111.294 138.688 111.828 138.524C136.751 130.88 145.571 103.595 146.615 100.072C146.69 99.8198 146.723 99.5629 146.723 99.3001V53.2312C146.723 51.5743 145.38 50.2312 143.723 50.2312H78.2773C76.6205 50.2312 75.2773 51.5743 75.2773 53.2312V99.3C75.2773 99.5629 75.3104 99.8198 75.3851 100.072C76.4291 103.596 85.2508 130.88 110.174 138.524Z" fill="#5732D9"/>
<path d="M111 125.129C125.863 120.903 130.437 105.419 130.437 105.419V82.7581H91.563V105.419C91.563 105.419 96.1367 120.903 111 125.129Z" fill="#A764EB"/>
<path d="M125.389 80.8661H120.334V73.9113C120.334 69.6532 116.819 66.1887 112.499 66.1887H109.501C105.181 66.1887 101.666 69.6532 101.666 73.9113V80.8661H96.6113V73.9113C96.6113 66.9048 102.394 61.2048 109.503 61.2048H112.501C119.609 61.2048 125.39 66.9048 125.39 73.9113V80.8661H125.389Z" fill="white"/>
<path d="M114.528 100.074C114.528 98.1533 112.947 96.5952 110.998 96.5952C109.05 96.5952 107.469 98.1533 107.469 100.074C107.469 101.465 108.298 102.661 109.496 103.218V112.097C109.496 112.915 110.169 113.577 110.998 113.577C111.828 113.577 112.501 112.915 112.501 112.097V103.218C113.698 102.661 114.528 101.465 114.528 100.074Z" fill="#050236"/>
<rect x="45" y="28" width="159" height="29" rx="14.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="34" y="86" width="187" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="15" y="113" width="177" height="28" rx="14" fill="#B983EF" fill-opacity="0.3"/>
<rect y="57" width="179" height="29" rx="14.5" fill="#B983EF" fill-opacity="0.3"/>
<ellipse cx="182.5" cy="104.5" rx="3.5" ry="2.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<path d="M109.791 141.656C80.6238 133.347 72.2078 101.115 72.1195 100.748L72 100.255V47H150V100.255L149.881 100.747C149.792 101.115 141.052 134.092 112.209 141.656L111 142L109.791 141.656Z" fill="white"/>
<path d="M110.174 138.524C110.708 138.688 111.294 138.688 111.828 138.524C136.751 130.88 145.571 103.595 146.615 100.072C146.69 99.8198 146.723 99.5629 146.723 99.3001V53.2312C146.723 51.5743 145.38 50.2312 143.723 50.2312H78.2773C76.6205 50.2312 75.2773 51.5743 75.2773 53.2312V99.3C75.2773 99.5629 75.3104 99.8198 75.3851 100.072C76.4291 103.596 85.2508 130.88 110.174 138.524Z" fill="#5732D9"/>
<path d="M111 125.129C125.863 120.903 130.437 105.419 130.437 105.419V82.7581H91.563V105.419C91.563 105.419 96.1367 120.903 111 125.129Z" fill="#A764EB"/>
<path d="M125.389 80.8661H120.334V73.9113C120.334 69.6532 116.819 66.1887 112.499 66.1887H109.501C105.181 66.1887 101.666 69.6532 101.666 73.9113V80.8661H96.6113V73.9113C96.6113 66.9048 102.394 61.2048 109.503 61.2048H112.501C119.609 61.2048 125.39 66.9048 125.39 73.9113V80.8661H125.389Z" fill="white"/>
<path d="M114.528 100.074C114.528 98.1533 112.947 96.5952 110.998 96.5952C109.05 96.5952 107.469 98.1533 107.469 100.074C107.469 101.465 108.298 102.661 109.496 103.218V112.097C109.496 112.915 110.169 113.577 110.998 113.577C111.828 113.577 112.501 112.915 112.501 112.097V103.218C113.698 102.661 114.528 101.465 114.528 100.074Z" fill="#050236"/>
</svg>


<svg width="213" height="152" viewBox="0 0 213 152" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="42.7642" y="27.2551" width="153.703" height="27.2699" rx="13.635" fill="#B983EF" fill-opacity="0.3"/>
<rect x="32.8477" y="81.7952" width="179.734" height="27.2699" rx="13.635" fill="#B983EF" fill-opacity="0.3"/>
<rect x="14.2549" y="109.065" width="171.057" height="26.6502" rx="13.3251" fill="#B983EF" fill-opacity="0.3"/>
<rect y="54.5251" width="172.297" height="27.2699" rx="13.635" fill="#B983EF" fill-opacity="0.3"/>
<circle cx="156.863" cy="52.7272" r="32.9093" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="153.719" cy="141.928" r="8.07209" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="81.5001" cy="13.93" r="12.0855" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="39.9752" cy="98.8387" r="22.6217" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="175.401" cy="100.394" r="3.10465" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<path d="M65.6995 104.616C65.6995 106.218 64.3935 107.517 62.7841 107.517H58.6947C57.0853 107.517 55.7793 106.218 55.7793 104.616C55.7793 103.015 57.0853 101.715 58.6947 101.715H62.7841C64.3935 101.715 65.6995 103.015 65.6995 104.616Z" fill="black"/>
<path d="M69.6704 119.634C69.6704 121.997 67.7444 123.927 65.3567 123.927C62.9822 123.927 61.043 122.01 61.043 119.634V89.5988C61.043 87.2359 62.969 85.3062 65.3567 85.3062C67.7312 85.3062 69.6704 87.2228 69.6704 89.5988V119.634Z" fill="#5732D9"/>
<path d="M158.041 104.616C158.041 106.218 156.735 107.517 155.126 107.517H151.036C149.427 107.517 148.121 106.218 148.121 104.616C148.121 103.015 149.427 101.715 151.036 101.715H155.126C156.735 101.715 158.041 103.015 158.041 104.616Z" fill="black"/>
<path d="M152.778 119.634C152.778 121.997 150.852 123.927 148.465 123.927C146.09 123.927 144.151 122.01 144.151 119.634V89.5988C144.151 87.2359 146.077 85.3062 148.465 85.3062C150.839 85.3062 152.778 87.2228 152.778 89.5988V119.634Z" fill="#5732D9"/>
<path d="M109.047 70.4065C109.047 71.5748 108.084 72.5331 106.91 72.5331C105.736 72.5331 104.773 71.5748 104.773 70.4065V41.1718C104.773 40.0035 105.736 39.0452 106.91 39.0452C108.084 39.0452 109.047 39.9903 109.047 41.1718V70.4065Z" fill="white"/>
<path d="M106.91 43.9548C109.825 43.9548 112.187 41.6039 112.187 38.7038C112.187 35.8038 109.825 33.4529 106.91 33.4529C103.996 33.4529 101.634 35.8038 101.634 38.7038C101.634 41.6039 103.996 43.9548 106.91 43.9548Z" fill="white"/>
<path d="M122.411 75.723C122.411 84.2427 115.472 91.1346 106.91 91.1346C98.349 91.1346 91.4233 84.2427 91.4233 75.723C91.4233 67.2033 98.3622 60.2983 106.924 60.2983C115.485 60.2983 122.411 67.2033 122.411 75.723Z" fill="#663FED"/>
<path d="M147.778 120.828C147.778 129.046 141.077 135.715 132.819 135.715H81.0014C72.7434 135.715 66.042 129.046 66.042 120.828V88.4038C66.042 80.186 72.7434 73.5173 81.0014 73.5173H132.819C141.077 73.5173 147.778 80.186 147.778 88.4038V120.828Z" fill="#A764EB"/>
<path d="M130.418 119.306C130.418 122.089 128.149 124.36 125.339 124.36H88.4816C85.685 124.36 83.4028 122.102 83.4028 119.306C83.4028 116.523 85.6718 114.251 88.4816 114.251H125.353C128.149 114.251 130.418 116.509 130.418 119.306Z" fill="black"/>
<path d="M98.3094 99.6542C98.3094 104.354 94.4838 108.161 89.7611 108.161C85.0385 108.161 81.2129 104.354 81.2129 99.6542C81.2129 94.9546 85.0385 91.1477 89.7611 91.1477C94.4838 91.1477 98.3094 94.9546 98.3094 99.6542Z" fill="white"/>
<path d="M93.5212 99.6545C93.5212 101.715 91.8327 103.396 89.7616 103.396C87.6905 103.396 86.002 101.715 86.002 99.6545C86.002 97.5935 87.6905 95.9132 89.7616 95.9132C91.8327 95.9 93.5212 97.5803 93.5212 99.6545Z" fill="black"/>
<path d="M132.608 99.6542C132.608 104.354 128.783 108.161 124.06 108.161C119.337 108.161 115.512 104.354 115.512 99.6542C115.512 94.9546 119.337 91.1477 124.06 91.1477C128.783 91.1477 132.608 94.9546 132.608 99.6542Z" fill="white"/>
<path d="M127.82 99.6545C127.82 101.715 126.131 103.396 124.06 103.396C121.989 103.396 120.3 101.715 120.3 99.6545C120.3 97.5935 121.989 95.9132 124.06 95.9132C126.131 95.9 127.82 97.5803 127.82 99.6545Z" fill="black"/>
<path d="M131.737 85.0038C131.737 86.3953 130.603 87.5243 129.191 87.5243H84.92C83.5217 87.5243 82.374 86.3953 82.374 85.0038C82.374 83.6123 83.5085 82.4702 84.92 82.4702H129.205C130.603 82.4702 131.737 83.5992 131.737 85.0038Z" fill="#663FED"/>
</svg>


<svg width="126" height="126" viewBox="0 0 126 126" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="63" cy="63" r="61" stroke="#7C78B7" stroke-width="4" stroke-dasharray="5 5"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M81.4315 55.5119C81.3711 54.9723 80.921 54.5222 80.4313 54.5118L66.054 53.8632L65.4055 39.486C65.3951 38.9963 64.945 38.5463 64.4053 38.4858L62.5722 38.5726C62.0825 38.5622 61.6512 38.9936 61.6137 39.5312L60.8681 53.7363L46.7642 54.3806C46.2745 54.3702 45.8432 54.8016 45.8057 55.3392L45.6176 57.2735C45.628 57.7632 46.0781 58.2133 46.6178 58.2737L60.9952 58.9222L61.6437 73.2994C61.7041 73.8391 62.1542 74.2892 62.6439 74.2996L64.5782 74.1115C65.1158 74.074 65.5472 73.6427 65.5368 73.153L66.181 59.0491L80.3862 58.3036C80.9238 58.266 81.3552 57.8347 81.3447 57.345L81.4315 55.5119Z" fill="#8480BB"/>
<path d="M37.4688 97H38.875V92.9766H41.7188C43.8359 92.9766 45.3359 91.4844 45.3359 89.3438V89.3281C45.3359 87.1875 43.8359 85.7266 41.7188 85.7266H37.4688V97ZM41.3594 86.9766C42.9688 86.9766 43.8984 87.8594 43.8984 89.3438V89.3594C43.8984 90.8438 42.9688 91.7266 41.3594 91.7266H38.875V86.9766H41.3594ZM47.6406 97H49.0469V91.8672H55.2344V97H56.6406V85.7266H55.2344V90.6016H49.0469V85.7266H47.6406V97ZM64.25 97.2656C67.4688 97.2656 69.4219 94.9609 69.4219 91.3672V91.3516C69.4219 87.7422 67.4531 85.4609 64.25 85.4609C61.0625 85.4609 59.0781 87.7344 59.0781 91.3516V91.3672C59.0781 94.9688 61.0156 97.2656 64.25 97.2656ZM64.25 95.9688C61.9062 95.9688 60.5156 94.1562 60.5156 91.3672V91.3516C60.5156 88.5391 61.9531 86.7578 64.25 86.7578C66.5547 86.7578 67.9844 88.5391 67.9844 91.3516V91.3672C67.9844 94.1562 66.5625 95.9688 64.25 95.9688ZM74.3203 97H75.7266V86.9922H79.3594V85.7266H70.6875V86.9922H74.3203V97ZM85.7969 97.2656C89.0156 97.2656 90.9688 94.9609 90.9688 91.3672V91.3516C90.9688 87.7422 89 85.4609 85.7969 85.4609C82.6094 85.4609 80.625 87.7344 80.625 91.3516V91.3672C80.625 94.9688 82.5625 97.2656 85.7969 97.2656ZM85.7969 95.9688C83.4531 95.9688 82.0625 94.1562 82.0625 91.3672V91.3516C82.0625 88.5391 83.5 86.7578 85.7969 86.7578C88.1016 86.7578 89.5312 88.5391 89.5312 91.3516V91.3672C89.5312 94.1562 88.1094 95.9688 85.7969 95.9688Z" fill="#8480BB"/>
</svg>


<svg width="221" height="158" viewBox="0 0 221 158" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="45" y="28" width="159" height="29" rx="14.5" fill="#DCD1FF" fill-opacity="0.08"/>
<rect x="34" y="86" width="187" height="27" rx="13.5" fill="#DCD1FF" fill-opacity="0.08"/>
<rect x="15" y="113" width="177" height="28" rx="14" fill="#DCD1FF" fill-opacity="0.08"/>
<rect y="57" width="179" height="29" rx="14.5" fill="#DCD1FF" fill-opacity="0.08"/>
<circle cx="163" cy="55" r="34" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="160" cy="147.5" rx="9" ry="8.5" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="84.5" cy="14.5" r="12.5" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="41.5" cy="103" rx="23.5" ry="23" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="182.5" cy="104.5" rx="3.5" ry="2.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<rect x="45" y="28" width="159" height="29" rx="14.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="34" y="86" width="187" height="27" rx="13.5" fill="#B983EF" fill-opacity="0.3"/>
<rect x="15" y="113" width="177" height="28" rx="14" fill="#B983EF" fill-opacity="0.3"/>
<rect y="57" width="179" height="29" rx="14.5" fill="#B983EF" fill-opacity="0.3"/>
<ellipse cx="182.5" cy="104.5" rx="3.5" ry="2.5" stroke="#F300FC" stroke-opacity="0.4" stroke-width="2.88" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="136" cy="73" r="32" fill="#A764EB"/>
<rect x="117.241" y="71.998" width="5.51724" height="23.1724" rx="2.75862" transform="rotate(-45 117.241 71.998)" fill="white"/>
<path d="M135.577 86.4327C134.5 87.51 132.753 87.51 131.676 86.4327C130.599 85.3554 130.599 83.6087 131.676 82.5314L151.962 62.2447C153.04 61.1674 154.786 61.1674 155.864 62.2447C156.941 63.322 156.941 65.0687 155.864 66.146L135.577 86.4327Z" fill="white"/>
<circle cx="97" cy="129" r="20" fill="#A764EB"/>
<rect x="85.2754" y="128.374" width="3.44828" height="14.4828" rx="1.72414" transform="rotate(-45 85.2754 128.374)" fill="white"/>
<path d="M96.7357 137.396C96.0624 138.069 94.9708 138.069 94.2975 137.396C93.6241 136.722 93.6241 135.631 94.2975 134.957L106.977 122.278C107.65 121.605 108.742 121.605 109.415 122.278C110.088 122.951 110.088 124.043 109.415 124.716L96.7357 137.396Z" fill="white"/>
<circle cx="73.5" cy="60.5" r="13.5" fill="#A764EB"/>
<rect x="65.5859" y="60.0776" width="2.32759" height="9.77586" rx="1.16379" transform="rotate(-45 65.5859 60.0776)" fill="white"/>
<path d="M73.3215 66.1668C72.867 66.6213 72.1301 66.6213 71.6756 66.1668C71.2211 65.7123 71.2211 64.9755 71.6756 64.521L80.234 55.9625C80.6885 55.508 81.4254 55.508 81.8799 55.9625C82.3344 56.417 82.3344 57.1539 81.8799 57.6084L73.3215 66.1668Z" fill="white"/>
</svg>


<svg width="207" height="148" viewBox="0 0 207 148" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="41.924" y="26.4558" width="149.354" height="27.0759" rx="13.538" fill="#B983EF" fill-opacity="0.27"/>
<rect x="32.3165" y="79.7341" width="174.684" height="26.2025" rx="13.1013" fill="#B983EF" fill-opacity="0.27"/>
<rect x="13.9747" y="105.937" width="166.823" height="26.2025" rx="13.1013" fill="#B983EF" fill-opacity="0.27"/>
<rect y="53.5317" width="167.696" height="26.2025" rx="13.1013" fill="#B983EF" fill-opacity="0.27"/>
<circle cx="152.411" cy="51.348" r="31.8797" stroke="#35326C" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="149.354" cy="138.253" r="7.86076" stroke="#270B9F" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<circle cx="79.0443" cy="13.7911" r="11.7911" stroke="#2C287B" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<ellipse cx="38.8671" cy="96.3291" rx="22.2722" ry="21.8354" stroke="#3F2264" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 10"/>
<path d="M103.195 128.382C131.721 128.382 154.846 125.998 154.846 123.058C154.846 120.117 131.721 117.734 103.195 117.734C74.6698 117.734 51.5452 120.117 51.5452 123.058C51.5452 125.998 74.6698 128.382 103.195 128.382Z" fill="#02000D" fill-opacity="0.1"/>
<path d="M123.722 79.0979L103.414 76.5876L83.1068 79.0979C83.1068 79.0979 78.2508 92.8079 78.4713 100.532C78.6918 108.256 81.5617 113.469 88.4038 116.172C95.246 118.876 103.414 119.069 103.414 119.069C103.414 119.069 111.581 118.876 118.425 116.172C125.269 113.469 128.137 108.256 128.358 100.532C128.58 92.8079 123.722 79.0979 123.722 79.0979Z" fill="white"/>
<path d="M123.722 79.098L117.121 78.2815C118.542 82.8531 120.783 90.9784 120.632 96.2834C120.411 104.008 117.541 109.22 110.699 111.924C103.857 114.627 95.6886 114.821 95.6886 114.821C95.6886 114.821 89.1835 114.667 82.9214 112.713C84.3563 114.133 86.1667 115.289 88.4038 116.172C95.2459 118.876 103.414 119.069 103.414 119.069C103.414 119.069 111.581 118.876 118.425 116.172C125.269 113.469 128.137 108.256 128.357 100.532C128.58 92.8079 123.722 79.098 123.722 79.098Z" fill="#F9F2FF"/>
<path d="M127.173 91.9961C127.173 85.424 123.679 78.3773 123.679 78.3773L103.411 76.5701L83.1036 79.2226C83.1036 79.2226 79.911 86.2645 79.3677 93.4374C82.621 90.2784 86.8235 87.7218 91.2928 86.2837C96.7815 84.5196 102.702 84.1489 108.494 84.5611C122.939 85.5902 127.042 91.8875 127.173 91.9961Z" fill="#3A3734"/>
<path d="M139.635 107.31C142.641 111.446 145.978 111.74 147.627 114.461C149.081 116.859 148.788 119.333 147.019 121.404C145.632 123.029 145.429 123.641 143.493 123.655C140.024 123.681 134.687 122.692 131.277 121.928C126.995 120.969 122.728 119.913 118.463 118.857C117.252 118.556 115.843 118.059 115.435 116.657C114.946 114.972 116.247 113.368 117.412 112.264C120.932 108.926 124.216 105.813 127.736 102.475C130.687 99.6741 134.062 99.6389 139.635 107.31Z" fill="#5732D9"/>
<path d="M149.301 121.714C152.499 118.298 153.74 112.288 153.895 110.303C153.933 109.819 154.072 108.902 153.635 108.301C153.202 107.707 152.51 107.576 152.043 107.713C152.195 107.079 151.974 106.393 151.562 105.888C151.15 105.384 150.562 105.046 149.947 104.831C149.349 104.62 148.702 104.516 148.079 104.626C147.456 104.736 146.858 105.08 146.524 105.618C145.624 104.714 144.058 104.799 142.994 105.503C141.932 106.208 141.278 107.381 140.77 108.551C139.543 111.374 138.926 114.461 138.974 117.539C138.995 118.907 139.159 120.319 139.843 121.506C140.404 122.481 141.494 123.427 142.67 123.477C143.117 123.494 146.732 124.458 149.301 121.714Z" fill="#4620C8"/>
<path d="M150.225 113.1C150.301 114.282 149.929 115.445 149.486 116.545C149.189 117.286 148.855 118.018 148.424 118.691C147.927 119.466 147.272 120.18 146.417 120.519C145.562 120.859 144.483 120.744 143.863 120.065C143.472 119.637 143.307 119.054 143.186 118.486C142.807 116.713 142.743 114.872 142.999 113.076C143.076 112.537 143.183 111.996 143.43 111.511C143.851 110.69 144.662 110.101 145.556 109.87C147.853 109.274 150.068 110.689 150.225 113.1Z" fill="#A764EB"/>
<path d="M149.531 106.962C149.542 107.291 149.432 107.614 149.304 107.918C149.184 108.201 149.042 108.485 148.815 108.693C148.588 108.901 148.258 109.019 147.965 108.923C147.706 108.838 147.519 108.602 147.435 108.343C147.35 108.086 147.353 107.806 147.374 107.536C147.412 107.049 147.519 106.536 147.853 106.178C148.576 105.403 149.499 106.05 149.531 106.962Z" fill="#A764EB"/>
<path d="M152.163 110.794C151.981 111.07 151.672 111.31 151.348 111.251C151.08 111.203 150.88 110.955 150.817 110.69C150.755 110.425 150.806 110.147 150.883 109.885C150.974 109.578 151.113 109.27 151.366 109.075C152.524 108.181 152.564 110.182 152.163 110.794Z" fill="#A764EB"/>
<path d="M145.105 108.675C145.036 108.955 144.913 109.254 144.651 109.372C144.408 109.484 144.108 109.396 143.908 109.218C143.709 109.041 143.592 108.787 143.506 108.535C143.355 108.092 143.283 107.605 143.416 107.156C143.571 106.63 144.236 105.94 144.801 106.347C145.41 106.785 145.255 108.065 145.105 108.675Z" fill="#A764EB"/>
<path d="M69.5136 107.996C66.4871 112.115 63.1475 112.392 61.4841 115.104C60.0173 117.494 60.2969 119.969 62.053 122.05C63.4304 123.681 63.6317 124.295 65.5684 124.32C69.0374 124.365 74.3791 123.405 77.7938 122.658C82.081 121.722 86.3522 120.69 90.6233 119.656C91.8361 119.362 93.2487 118.873 93.6641 117.472C94.1611 115.791 92.87 114.18 91.7115 113.068C88.2089 109.711 84.9428 106.58 81.4402 103.223C78.5017 100.408 75.127 100.355 69.5136 107.996Z" fill="#5732D9"/>
<path d="M59.7711 122.348C56.5929 118.916 55.3833 112.899 55.2395 110.912C55.2044 110.428 55.0701 109.511 55.5112 108.912C55.9474 108.319 56.6409 108.193 57.1043 108.333C56.9572 107.699 57.1794 107.013 57.5948 106.512C58.0103 106.01 58.5999 105.674 59.2151 105.462C59.8143 105.256 60.4614 105.154 61.0846 105.267C61.7078 105.38 62.3038 105.727 62.633 106.269C63.5374 105.369 65.1033 105.462 66.1627 106.173C67.2221 106.884 67.8693 108.059 68.371 109.231C69.5822 112.061 70.183 115.152 70.1191 118.229C70.0903 119.597 69.9178 121.009 69.2291 122.192C68.6634 123.163 67.5689 124.103 66.3912 124.146C65.9438 124.162 62.3246 125.105 59.7711 122.348Z" fill="#4620C8"/>
<path d="M58.8939 113.728C58.8108 114.909 59.1768 116.075 59.613 117.176C59.907 117.919 60.2362 118.653 60.6628 119.327C61.155 120.104 61.8069 120.821 62.6602 121.166C63.5134 121.511 64.592 121.401 65.2168 120.725C65.6099 120.299 65.7777 119.717 65.9023 119.15C66.2906 117.378 66.3641 115.537 66.118 113.739C66.0445 113.201 65.939 112.657 65.6946 112.173C65.2791 111.35 64.469 110.756 63.5774 110.519C61.2844 109.917 59.0617 111.317 58.8939 113.728Z" fill="#A764EB"/>
<path d="M59.6194 107.595C59.605 107.924 59.7152 108.247 59.8415 108.552C59.9597 108.837 60.1003 109.121 60.3256 109.329C60.5525 109.538 60.8817 109.658 61.1741 109.564C61.433 109.481 61.6215 109.244 61.7078 108.987C61.7941 108.73 61.7925 108.451 61.7733 108.18C61.7382 107.692 61.6343 107.18 61.302 106.82C60.5829 106.04 59.6561 106.683 59.6194 107.595Z" fill="#A764EB"/>
<path d="M56.9669 111.412C57.1474 111.689 57.4542 111.932 57.7802 111.874C58.0486 111.826 58.25 111.582 58.3139 111.317C58.3778 111.051 58.3283 110.773 58.2516 110.511C58.1621 110.204 58.0247 109.894 57.7722 109.698C56.6201 108.797 56.569 110.797 56.9669 111.412Z" fill="#A764EB"/>
<path d="M64.0359 109.332C64.103 109.612 64.2245 109.91 64.4849 110.032C64.7278 110.145 65.0282 110.059 65.2296 109.883C65.4309 109.706 65.5491 109.455 65.6354 109.201C65.7888 108.758 65.8623 108.273 65.7329 107.824C65.5795 107.296 64.9196 106.604 64.3523 107.007C63.7419 107.438 63.8889 108.72 64.0359 109.332Z" fill="#A764EB"/>
<path d="M73.684 103.265C76.0824 111.598 80.0228 120.094 87.3827 124.68C88.1082 125.132 88.9279 125.555 89.7764 125.455C90.6265 125.352 91.4222 124.488 91.1362 123.681C91.4398 124.723 92.5839 125.444 93.6545 125.269C94.7251 125.095 95.5799 124.049 95.5384 122.965C95.1613 123.959 97.1331 124.311 97.5709 123.342C98.0087 122.374 97.3919 121.283 96.8215 120.385C94.6404 116.956 92.7964 113.242 92.0374 109.249C91.2768 105.256 91.6795 100.943 93.7408 97.4405C96.4236 92.8833 101.834 89.5741 102.146 84.2946C102.349 80.8687 100.123 77.6298 97.2002 75.829C94.2776 74.0282 90.7671 73.4481 87.3396 73.2692C80.988 72.9368 76.1511 73.9882 73.4986 79.9899C70.2341 87.3706 71.5268 95.7691 73.684 103.265Z" fill="#4620C8"/>
<path d="M133.703 102.931C131.363 111.281 127.484 119.804 120.157 124.443C119.435 124.9 118.618 125.33 117.768 125.236C116.918 125.14 116.116 124.28 116.396 123.472C116.099 124.515 114.961 125.244 113.889 125.078C112.816 124.911 111.954 123.87 111.989 122.786C112.372 123.777 110.404 124.143 109.959 123.178C109.515 122.213 110.124 121.116 110.688 120.215C112.845 116.77 114.662 113.044 115.394 109.046C116.126 105.048 115.694 100.737 113.606 97.2486C110.891 92.7106 105.457 89.4397 105.107 84.1635C104.88 80.7392 107.083 77.4843 109.991 75.6627C112.901 73.8411 116.409 73.2371 119.834 73.0326C126.183 72.6555 131.028 73.6717 133.723 79.6542C137.039 87.0125 135.805 95.419 133.703 102.931Z" fill="#4620C8"/>
<path d="M102.304 92.0106C105.512 91.4433 108.973 92.0297 111.632 93.9121C112.915 94.8197 114.195 96.0756 115.761 95.951C117.538 95.8088 118.657 93.9296 119.007 92.1831C119.885 87.8113 117.739 83.1454 114.199 80.437C110.658 77.7286 105.942 76.8386 101.518 77.3946C98.4593 77.7797 95.3882 78.8775 93.2182 81.065C90.9572 83.3436 89.8994 86.549 89.2778 89.6984C88.7122 92.565 90.1694 95.9717 93.656 95.5483C95.0095 95.3837 96.2207 94.4138 97.3839 93.7858C98.9323 92.9533 100.569 92.3174 102.304 92.0106Z" fill="#4620C8"/>
<path d="M72.2651 47.1541C72.2651 47.1541 55.4201 35.6428 68.8664 23.9527C80.7195 13.6463 90.1327 29.9639 90.1327 29.9639L72.2651 47.1541Z" fill="#5732D9"/>
<path d="M74.8393 41.5445C74.8393 41.5445 65.4405 35.1226 72.9426 28.5984C79.5563 22.8476 84.8086 31.9523 84.8086 31.9523L74.8393 41.5445Z" fill="#A764EB"/>
<path d="M66.8483 26.0224C78.2077 16.1459 87.3237 30.7171 88.0651 31.9506L90.1328 29.9613C90.1328 29.9613 80.7196 13.6436 68.8664 23.95C67.9892 24.7122 67.2413 25.4744 66.6102 26.2334C66.6885 26.1631 66.7668 26.0943 66.8483 26.0224Z" fill="#4620C8"/>
<path opacity="0.22" d="M65.1673 31.9458C64.8669 33.2545 64.8828 34.6638 65.3798 35.8926C65.6115 36.4647 66.0253 37.0463 66.623 37.1022C67.1614 37.1534 67.676 36.7283 67.8821 36.2042C68.0898 35.6801 68.0419 35.0873 67.9013 34.5456C67.7607 34.0039 67.5337 33.4926 67.3819 32.9541C67.0064 31.6246 67.1199 30.1466 67.6919 28.8795C67.807 28.6238 67.9348 28.2978 67.7575 28.0885C66.8243 26.9876 65.2743 31.484 65.1673 31.9458Z" fill="white"/>
<path d="M130.07 40.2676C130.07 40.2676 144.087 25.444 153.518 40.56C161.832 53.8865 144.236 60.6168 144.236 60.6168L130.07 40.2676Z" fill="#5732D9"/>
<path d="M135.205 43.6905C135.205 43.6905 143.026 35.4198 148.286 43.8535C152.925 51.2901 143.108 55.0436 143.108 55.0436L135.205 43.6905Z" fill="#A764EB"/>
<path d="M151.789 38.24C159.756 51.0104 143.932 57.7231 142.596 58.26L144.236 60.6153C144.236 60.6153 161.83 53.8866 153.518 40.5586C152.903 39.5727 152.267 38.7146 151.618 37.97C151.676 38.0595 151.732 38.1489 151.789 38.24Z" fill="#4620C8"/>
<path opacity="0.22" d="M146.204 35.6481C144.958 35.1448 143.566 34.9387 142.274 35.2359C141.671 35.3749 141.034 35.6913 140.883 36.2729C140.749 36.797 141.088 37.3706 141.572 37.6583C142.056 37.9459 142.651 37.9922 143.207 37.9379C143.763 37.8852 144.305 37.7398 144.861 37.6758C146.232 37.5145 147.675 37.858 148.836 38.6234C149.071 38.7784 149.373 38.9542 149.606 38.8119C150.84 38.0641 146.644 35.8271 146.204 35.6481Z" fill="white"/>
<path d="M144.648 63.9788C145.618 55.6091 142.408 43.8805 133.369 36.0604C124.994 28.8156 101.821 23.5346 89.3658 26.9876C79.0402 29.851 71.0603 39.9753 68.6395 48.0462C66.2187 56.1172 65.4293 70.952 76.7488 76.5623C88.0683 82.1725 112.73 87.2586 125.346 86.5826C137.962 85.9067 143.678 72.3486 144.648 63.9788Z" fill="white"/>
<path d="M144.706 63.9918C145.636 55.9624 142.716 44.8426 134.497 37.0481C138.149 43.518 139.401 50.6893 138.747 56.3331C137.777 64.7028 132.061 78.261 119.445 78.9353C106.829 79.6112 82.1673 74.5251 70.8478 68.9149C70.124 68.557 69.4512 68.1591 68.8233 67.7292C70.2518 71.3708 72.7525 74.5634 76.8063 76.5736C88.1258 82.1838 112.788 87.2699 125.403 86.594C138.02 85.9181 143.737 72.3615 144.706 63.9918Z" fill="#F9F2FF"/>
<path d="M88.2313 36.4568C85.5436 37.5641 83.1276 39.2387 80.8586 41.0555C77.9872 43.3581 75.226 46.0457 73.9733 49.5068C73.7528 50.114 72.8915 52.9263 75.3315 55.9255C76.3462 57.1735 77.8498 57.9564 79.4253 58.2824C87.3397 59.9139 91.3392 55.8728 92.2756 54.9045C95.1757 51.9036 97.3713 48.27 100.351 45.3491C101.272 44.4463 102.136 43.4763 102.587 42.2683C103.403 40.0776 101.887 34.8861 94.535 35.1609C92.3746 35.2424 90.2239 35.6371 88.2313 36.4568Z" fill="#4620C8"/>
<path d="M128.987 44.8503C131.02 46.9276 132.579 49.4203 133.945 51.9849C135.676 55.2334 137.151 58.7935 136.937 62.4671C136.898 63.1126 136.582 66.0352 133.156 67.828C131.731 68.5742 130.04 68.7005 128.465 68.3777C120.549 66.7542 118.468 61.4636 117.99 60.2029C116.509 56.3008 115.926 52.0968 114.341 48.2363C113.852 47.0442 113.44 45.8107 113.504 44.5228C113.619 42.1866 117.059 38.0161 123.706 41.1688C125.66 42.0987 127.48 43.3115 128.987 44.8503Z" fill="#4620C8"/>
<path d="M111.672 54.0353C110.036 52.9104 107 52.0251 106.553 52.0571C106.155 51.8494 103.017 51.4627 101.069 51.8494C100.008 52.0603 99.049 52.9679 98.8301 54.0273C98.4721 55.7546 99.4197 56.3442 99.9742 56.7373C101.2 57.6082 102.657 58.2649 103.474 59.5256C103.683 59.8484 103.844 60.2047 104.106 60.4876C104.274 60.6681 104.499 60.8135 104.737 60.8663C104.976 60.9126 105.241 60.8679 105.466 60.7688C105.818 60.6138 106.108 60.3501 106.428 60.136C107.678 59.3003 109.275 59.2748 110.746 58.96C111.41 58.8178 112.514 58.6516 112.869 56.9227C113.085 55.8633 112.562 54.6489 111.672 54.0353Z" fill="#040226"/>
<path opacity="0.22" d="M100.136 53.7954C100.108 54.2252 100.401 54.6534 100.81 54.7845C101.225 54.9171 101.678 54.7589 102.055 54.54C102.432 54.3211 102.775 54.0382 103.184 53.888C104.082 53.5589 105.089 53.9344 106.035 53.7906C106.177 53.7698 106.334 53.7234 106.401 53.5956C106.468 53.4678 106.411 53.3016 106.305 53.2025C106.2 53.1035 106.056 53.0571 105.918 53.0156C104.789 52.6784 100.268 51.7325 100.136 53.7954Z" fill="white"/>
<path d="M95.5691 45.2485C96.4983 42.3908 94.9349 39.3211 92.0772 38.392C89.2196 37.4628 86.1498 39.0262 85.2207 41.8839C84.2916 44.7415 85.855 47.8113 88.7126 48.7404C91.5703 49.6695 94.64 48.1061 95.5691 45.2485Z" fill="#232120"/>
<path d="M95.6087 45.2091C96.2076 42.2646 94.3061 39.3921 91.3616 38.7933C88.4171 38.1944 85.5447 40.0959 84.9458 43.0404C84.3469 45.9848 86.2484 48.8573 89.1929 49.4562C92.1374 50.0551 95.0098 48.1536 95.6087 45.2091Z" fill="white"/>
<path d="M95.1039 41.5796C95.3196 42.3769 95.3595 43.235 95.1806 44.0995C94.5734 47.0428 91.6956 48.9363 88.7523 48.3291C87.1 47.9887 85.777 46.9309 85.0435 45.5488C85.5645 47.4662 87.1176 49.0274 89.1965 49.4572C92.1398 50.0644 95.0176 48.1709 95.6248 45.2276C95.8916 43.9365 95.6775 42.6582 95.1039 41.5796Z" fill="#E3FFFE"/>
<path d="M94.4288 44.4496C93.8939 47.0859 91.3574 48.7823 88.7678 48.2384C86.1747 47.6946 84.5062 45.1159 85.0411 42.4831C85.576 39.8468 88.1125 38.1504 90.7021 38.6942C93.2952 39.2345 94.9638 41.8132 94.4288 44.4496Z" fill="#232120"/>
<path d="M85.8063 42.1831C85.7555 42.4063 85.7196 42.6379 85.7534 42.8632C85.7872 43.0884 85.9014 43.3116 86.0937 43.4358C86.3051 43.5727 86.5862 43.5727 86.825 43.4885C87.0638 43.4043 87.2667 43.2464 87.457 43.08C88.0847 42.5326 88.6257 41.8567 88.8773 41.0651C88.9407 40.865 88.9787 40.6292 88.8519 40.4629C88.7779 40.3661 88.6617 40.3134 88.5454 40.2755C87.2794 39.8628 86.0726 41.0293 85.8063 42.1831Z" fill="white"/>
<path d="M89.8769 39.4405C89.7644 39.4595 89.6497 39.4951 89.5567 39.5711C89.4658 39.6471 89.4009 39.773 89.4182 39.8989C89.4398 40.0699 89.5956 40.1792 89.7449 40.2409C89.9895 40.3407 90.2578 40.374 90.5153 40.3336C90.6516 40.3122 90.7901 40.2694 90.8918 40.1673C90.9936 40.0652 91.0477 39.8965 90.9892 39.7588C90.9568 39.6828 90.894 39.6257 90.8291 39.5806C90.5608 39.3906 90.2145 39.3407 89.9116 39.4452L89.8769 39.4405Z" fill="white"/>
<path d="M129.065 51.2423C128.458 54.1856 125.58 56.0792 122.637 55.472C119.694 54.8648 117.8 51.9869 118.408 49.0436C119.015 46.1003 121.893 44.2068 124.836 44.814C127.779 45.4212 129.673 48.299 129.065 51.2423Z" fill="#232120"/>
<path d="M128.238 53.5756C129.827 51.0251 129.047 47.6696 126.497 46.0809C123.946 44.4922 120.591 45.272 119.002 47.8225C117.413 50.373 118.193 53.7286 120.743 55.3172C123.294 56.9059 126.65 56.1262 128.238 53.5756Z" fill="white"/>
<path d="M128.445 48.155C128.661 48.9524 128.701 49.8104 128.522 50.6749C127.915 53.6182 125.037 55.5117 122.094 54.9045C120.442 54.5642 119.119 53.5064 118.385 52.1242C118.906 54.0417 120.459 55.6028 122.538 56.0326C125.481 56.6398 128.359 54.7463 128.966 51.803C129.233 50.5119 129.019 49.2352 128.445 48.155Z" fill="#E3FFFE"/>
<path d="M128.138 51.2889C127.567 54.0549 124.862 55.8347 122.099 55.2641C119.333 54.6935 117.554 51.9917 118.124 49.2257C118.695 46.4597 121.4 44.6799 124.162 45.2505C126.928 45.8211 128.708 48.5267 128.138 51.2889Z" fill="#232120"/>
<path d="M119.515 48.5446C119.47 48.7465 119.437 48.9561 119.468 49.1599C119.498 49.3637 119.601 49.5657 119.774 49.678C119.964 49.8019 120.217 49.8019 120.432 49.7257C120.647 49.6495 120.83 49.5066 121.001 49.3561C121.566 48.8608 122.053 48.2493 122.279 47.5331C122.336 47.3521 122.37 47.1387 122.256 46.9882C122.19 46.9006 122.085 46.853 121.98 46.8187C120.843 46.4453 119.755 47.5007 119.515 48.5446Z" fill="white"/>
<path d="M123.067 46.1435C122.966 46.1593 122.863 46.189 122.779 46.2524C122.697 46.3157 122.638 46.4206 122.654 46.5255C122.674 46.6681 122.814 46.7591 122.947 46.8106C123.167 46.8937 123.409 46.9214 123.641 46.8878C123.764 46.8699 123.889 46.8343 123.98 46.7492C124.072 46.6641 124.121 46.5236 124.068 46.4088C124.039 46.3454 123.982 46.2979 123.924 46.2603C123.682 46.1019 123.37 46.0604 123.097 46.1475L123.067 46.1435Z" fill="white"/>
<path d="M104.72 28.9657C106.013 28.7804 107.147 27.7593 107.467 26.4938C107.786 25.2267 107.273 23.7902 106.222 23.0136C107.674 23.1638 109.055 23.926 109.956 25.0749C110.389 23.8796 111.3 22.9033 112.353 22.1923C113.406 21.4796 114.6 21.0066 115.795 20.5752C114.534 22.0724 113.903 24.0826 114.08 26.032C114.544 25.746 115.093 25.599 115.638 25.6149C115.063 26.179 114.787 27.0291 114.918 27.8232C115.044 28.587 115.512 29.2518 115.709 30.0012C115.797 30.3383 115.825 30.7074 115.683 31.0254C115.447 31.5559 114.828 31.786 114.263 31.917C111.744 32.5019 109.105 32.1919 106.569 31.6837C105.786 31.5272 104.821 31.1373 104.825 30.3383C104.829 29.7902 105.316 29.3812 105.77 29.0728L104.72 28.9657Z" fill="white"/>
<path d="M97.4985 69.9106C99.7159 63.7582 109.748 65.3763 110.443 71.8522" stroke="#2500A2"/>
<line x1="105.114" y1="60.7268" x2="104.467" y2="65.9047" stroke="#2500A2"/>
</svg>


@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gTD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3g3D_vx3rCubqg.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gbD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gfD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 500; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_ZpC3gnD_vx3rCs.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gTD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3g3D_vx3rCubqg.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gbD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gfD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 600; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_bZF3gnD_vx3rCs.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 700; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_dJE3gTD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 700; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_dJE3g3D_vx3rCubqg.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 700; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_dJE3gbD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 700; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_dJE3gfD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 700; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_dJE3gnD_vx3rCs.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 900; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_epG3gTD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 900; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_epG3g3D_vx3rCubqg.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 900; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_epG3gbD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 900; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_epG3gfD_vx3rCubqg.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Montserrat; font-style: normal; font-weight: 900; font-display: swap; src: url("https://fonts.gstatic.com/s/montserrat/v18/JTURjIg1_i6t8kCHKm45_epG3gnD_vx3rCs.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }


@font-face { font-family: amino-icon; src: url("https://aminoapps.com/static/dist/fonts/amino-icon.44287601e.eot?#iefix&v=1.0") format("embedded-opentype"), url("data:application/font-woff2;base64,bW9kdWxlLmV4cG9ydHMgPSBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyArICJmb250cy9hbWluby1pY29uLmRjNjMwYTg2NC53b2ZmMiI7") format("woff2"), url("https://aminoapps.com/static/dist/fonts/amino-icon.0e4baf457.woff") format("woff"), url("https://aminoapps.com/static/dist/fonts/amino-icon.356b05c8b.ttf") format("truetype"), url("data:image/svg+xml;base64,bW9kdWxlLmV4cG9ydHMgPSBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyArICJmb250cy9hbWluby1pY29uLmY4ZDM4MDQ2Mi5zdmciOw==#fontawesomeregular") format("svg"); font-weight: 400; font-style: normal; font-display: block; }

.amino-icon { display: inline-block; font-style: normal; font-variant: normal; font-weight: normal; font-stretch: normal; line-height: 1; font-family: amino-icon; font-size: inherit; text-rendering: auto; -webkit-font-smoothing: antialiased; }

.amino-icon-rightward::before { content: ""; }

.amino-icon-leftward::before { content: ""; }

.amino-icon-comment-plus::before { content: ""; }

.amino-icon-menu::before { content: ""; }

.amino-icon-bookmark::before { content: ""; }

.amino-icon-warn::before { content: ""; }

.amino-icon-slider-h::before { content: ""; }

.amino-icon-comment-fat::before { content: ""; }

.amino-icon-book-with-bookmark::before { content: ""; }

.amino-icon-mail::before { content: ""; }

.amino-icon-clipboard::before { content: ""; }

.amino-icon-heart::before { content: ""; }

.amino-icon-users::before { content: ""; }

.amino-icon-users2::before { content: ""; }

.amino-icon-user-plus::before { content: ""; }

.amino-icon-user-star::before { content: ""; }

.amino-icon-user-check::before { content: ""; }

.amino-icon-user-triple::before { content: ""; }

.amino-icon-home::before { content: ""; }

.amino-icon-poi::before { content: ""; }

.amino-icon-search::before { content: ""; }

.amino-icon-qa::before { content: ""; }

.amino-icon-splat::before { content: ""; }

.amino-icon-at::before { content: ""; }

.amino-icon-comment::before { content: ""; }

.amino-icon-pin::before { content: ""; }

.amino-icon-find::before { content: ""; }

.amino-icon-question-rev::before { content: ""; }

.amino-icon-user-rev::before { content: ""; }

.amino-icon-hide::before { content: ""; }

.amino-icon-mute::before { content: ""; }

.amino-icon-uni49::before { content: ""; }

.amino-icon-clock::before { content: ""; }

.amino-icon-user::before { content: ""; }

.amino-icon-chatroom::before { content: ""; }

.amino-icon-alert::before { content: ""; }

.amino-icon-unlock::before { content: ""; }

.amino-icon-download::before { content: ""; }

.amino-icon-poll::before { content: ""; }

.amino-icon-close-rev::before { content: ""; }

.amino-icon-plus-rev::before { content: ""; }

.amino-icon-camera::before { content: ""; }

.amino-icon-android::before { content: ""; }

.amino-icon-apple::before { content: ""; }

.amino-icon-power::before { content: ""; }

.amino-icon-global::before { content: ""; }

.amino-icon-scope::before { content: ""; }

.amino-icon-wiki::before { content: ""; }

.amino-icon-wiki-plus::before { content: ""; }

.amino-icon-compose::before { content: ""; }

.amino-icon-headline::before { content: ""; }

.amino-icon-favs::before { content: ""; }

.amino-icon-lists::before { content: ""; }

.amino-icon-feed::before { content: ""; }

.amino-icon-comments::before { content: ""; }

.amino-icon-grid::before { content: ""; }

.amino-icon-create::before { content: ""; }

.amino-icon-compass::before { content: ""; }

.amino-icon-slider-v::before { content: ""; }

.amino-icon-dash::before { content: ""; }

.amino-icon-signal::before { content: ""; }

.amino-icon-twitter::before { content: ""; }

.amino-icon-t::before { content: ""; }

.amino-icon-f::before { content: ""; }

.amino-icon-instagram::before { content: ""; }

.amino-icon-cog::before { content: ""; }

.amino-icon-flag::before { content: ""; }

.amino-icon-upward::before { content: ""; }

.amino-icon-lock::before { content: ""; }

.amino-icon-upload::before { content: ""; }

.amino-icon-crown::before { content: ""; }

.amino-icon-check::before { content: ""; }

.amino-icon-sound::before { content: ""; }

.amino-icon-share::before { content: ""; }

.amino-icon-download::before { content: ""; }

.amino-icon-x::before { content: ""; }

.amino-icon-star::before { content: ""; }

.amino-icon-comment-splat::before { content: ""; }

.amino-icon-reload::before { content: ""; }

.amino-icon-write::before { content: ""; }

.amino-icon-link::before { content: ""; }

.amino-icon-plus::before { content: ""; }

.amino-icon-minus-rev::before { content: ""; }

.amino-icon-quiz::before { content: ""; }

.amino-icon-folder::before { content: ""; }

.amino-icon-heart-o::before { content: ""; }

.amino-icon-info::before { content: ""; }

.amino-icon-call-app::before { content: ""; }

.amino-icon-show-comment::before { content: ""; }

.amino-icon-hide-comment::before { content: ""; }

.amino-icon-send::before { content: ""; }

.amino-icon-comment-splat-o::before { content: ""; }

@font-face { font-family: FontAwesome; src: url("https://wa1.narvii.com/static/fontawesome/fontawesome-webfont.eot?#iefix&v=4.7.0") format("embedded-opentype"), url("https://wa1.narvii.com/static/fontawesome/fontawesome-webfont.woff2?v=4.7.0") format("woff2"), url("https://wa1.narvii.com/static/fontawesome/fontawesome-webfont.woff?v=4.7.0") format("woff"), url("https://wa1.narvii.com/static/fontawesome/fontawesome-webfont.ttf?v=4.7.0") format("truetype"), url("https://wa1.narvii.com/static/fontawesome/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular") format("svg"); font-weight: 400; font-style: normal; }

.fa { display: inline-block; font-style: normal; font-variant: normal; font-weight: normal; font-stretch: normal; line-height: 1; font-family: FontAwesome; font-size: inherit; text-rendering: auto; -webkit-font-smoothing: antialiased; }

.fa-lg { font-size: 1.33333em; line-height: 0.75em; vertical-align: -15%; }

.fa-2x { font-size: 2em; }

.fa-3x { font-size: 3em; }

.fa-4x { font-size: 4em; }

.fa-5x { font-size: 5em; }

.fa-fw { width: 1.28571em; text-align: center; }

.fa-ul { padding-left: 0px; margin-left: 2.14286em; list-style-type: none; }

.fa-ul > li { position: relative; }

.fa-li { position: absolute; left: -2.14286em; width: 2.14286em; top: 0.14286em; text-align: center; }

.fa-li.fa-lg { left: -1.85714em; }

.fa-border { padding: 0.2em 0.25em 0.15em; border: 0.08em solid rgb(238, 238, 238); border-radius: 0.1em; }

.fa-pull-left { float: left; }

.fa-pull-right { float: right; }

.fa.fa-pull-left { margin-right: 0.3em; }

.fa.fa-pull-right { margin-left: 0.3em; }

.pull-right { float: right; }

.pull-left { float: left; }

.fa.pull-left { margin-right: 0.3em; }

.fa.pull-right { margin-left: 0.3em; }

.fa-spin { animation: 2s linear 0s infinite normal none running fa-spin; }

.fa-pulse { animation: 1s steps(8) 0s infinite normal none running fa-spin; }

@-webkit-keyframes fa-spin { 
  0% { transform: rotate(0deg); }
  100% { transform: rotate(359deg); }
}

@keyframes fa-spin { 
  0% { transform: rotate(0deg); }
  100% { transform: rotate(359deg); }
}

.fa-rotate-90 { transform: rotate(90deg); }

.fa-rotate-180 { transform: rotate(180deg); }

.fa-rotate-270 { transform: rotate(270deg); }

.fa-flip-horizontal { transform: scaleX(-1); }

.fa-flip-vertical { transform: scaleY(-1); }

:root .fa-flip-horizontal, :root .fa-flip-vertical, :root .fa-rotate-90, :root .fa-rotate-180, :root .fa-rotate-270 { filter: none; }

.fa-stack { position: relative; display: inline-block; width: 2em; height: 2em; line-height: 2em; vertical-align: middle; }

.fa-stack-1x, .fa-stack-2x { position: absolute; left: 0px; width: 100%; text-align: center; }

.fa-stack-1x { line-height: inherit; }

.fa-stack-2x { font-size: 2em; }

.fa-inverse { color: rgb(255, 255, 255); }

.fa-glass::before { content: ""; }

.fa-music::before { content: ""; }

.fa-search::before { content: ""; }

.fa-envelope-o::before { content: ""; }

.fa-heart::before { content: ""; }

.fa-star::before { content: ""; }

.fa-star-o::before { content: ""; }

.fa-user::before { content: ""; }

.fa-film::before { content: ""; }

.fa-th-large::before { content: ""; }

.fa-th::before { content: ""; }

.fa-th-list::before { content: ""; }

.fa-check::before { content: ""; }

.fa-close::before, .fa-remove::before, .fa-times::before { content: ""; }

.fa-search-plus::before { content: ""; }

.fa-search-minus::before { content: ""; }

.fa-power-off::before { content: ""; }

.fa-signal::before { content: ""; }

.fa-cog::before, .fa-gear::before { content: ""; }

.fa-trash-o::before { content: ""; }

.fa-home::before { content: ""; }

.fa-file-o::before { content: ""; }

.fa-clock-o::before { content: ""; }

.fa-road::before { content: ""; }

.fa-download::before { content: ""; }

.fa-arrow-circle-o-down::before { content: ""; }

.fa-arrow-circle-o-up::before { content: ""; }

.fa-inbox::before { content: ""; }

.fa-play-circle-o::before { content: ""; }

.fa-repeat::before, .fa-rotate-right::before { content: ""; }

.fa-refresh::before { content: ""; }

.fa-list-alt::before { content: ""; }

.fa-lock::before { content: ""; }

.fa-flag::before { content: ""; }

.fa-headphones::before { content: ""; }

.fa-volume-off::before { content: ""; }

.fa-volume-down::before { content: ""; }

.fa-volume-up::before { content: ""; }

.fa-qrcode::before { content: ""; }

.fa-barcode::before { content: ""; }

.fa-tag::before { content: ""; }

.fa-tags::before { content: ""; }

.fa-book::before { content: ""; }

.fa-bookmark::before { content: ""; }

.fa-print::before { content: ""; }

.fa-camera::before { content: ""; }

.fa-font::before { content: ""; }

.fa-bold::before { content: ""; }

.fa-italic::before { content: ""; }

.fa-text-height::before { content: ""; }

.fa-text-width::before { content: ""; }

.fa-align-left::before { content: ""; }

.fa-align-center::before { content: ""; }

.fa-align-right::before { content: ""; }

.fa-align-justify::before { content: ""; }

.fa-list::before { content: ""; }

.fa-dedent::before, .fa-outdent::before { content: ""; }

.fa-indent::before { content: ""; }

.fa-video-camera::before { content: ""; }

.fa-image::before, .fa-photo::before, .fa-picture-o::before { content: ""; }

.fa-pencil::before { content: ""; }

.fa-map-marker::before { content: ""; }

.fa-adjust::before { content: ""; }

.fa-tint::before { content: ""; }

.fa-edit::before, .fa-pencil-square-o::before { content: ""; }

.fa-share-square-o::before { content: ""; }

.fa-check-square-o::before { content: ""; }

.fa-arrows::before { content: ""; }

.fa-step-backward::before { content: ""; }

.fa-fast-backward::before { content: ""; }

.fa-backward::before { content: ""; }

.fa-play::before { content: ""; }

.fa-pause::before { content: ""; }

.fa-stop::before { content: ""; }

.fa-forward::before { content: ""; }

.fa-fast-forward::before { content: ""; }

.fa-step-forward::before { content: ""; }

.fa-eject::before { content: ""; }

.fa-chevron-left::before { content: ""; }

.fa-chevron-right::before { content: ""; }

.fa-plus-circle::before { content: ""; }

.fa-minus-circle::before { content: ""; }

.fa-times-circle::before { content: ""; }

.fa-check-circle::before { content: ""; }

.fa-question-circle::before { content: ""; }

.fa-info-circle::before { content: ""; }

.fa-crosshairs::before { content: ""; }

.fa-times-circle-o::before { content: ""; }

.fa-check-circle-o::before { content: ""; }

.fa-ban::before { content: ""; }

.fa-arrow-left::before { content: ""; }

.fa-arrow-right::before { content: ""; }

.fa-arrow-up::before { content: ""; }

.fa-arrow-down::before { content: ""; }

.fa-mail-forward::before, .fa-share::before { content: ""; }

.fa-expand::before { content: ""; }

.fa-compress::before { content: ""; }

.fa-plus::before { content: ""; }

.fa-minus::before { content: ""; }

.fa-asterisk::before { content: ""; }

.fa-exclamation-circle::before { content: ""; }

.fa-gift::before { content: ""; }

.fa-leaf::before { content: ""; }

.fa-fire::before { content: ""; }

.fa-eye::before { content: ""; }

.fa-eye-slash::before { content: ""; }

.fa-exclamation-triangle::before, .fa-warning::before { content: ""; }

.fa-plane::before { content: ""; }

.fa-calendar::before { content: ""; }

.fa-random::before { content: ""; }

.fa-comment::before { content: ""; }

.fa-magnet::before { content: ""; }

.fa-chevron-up::before { content: ""; }

.fa-chevron-down::before { content: ""; }

.fa-retweet::before { content: ""; }

.fa-shopping-cart::before { content: ""; }

.fa-folder::before { content: ""; }

.fa-folder-open::before { content: ""; }

.fa-arrows-v::before { content: ""; }

.fa-arrows-h::before { content: ""; }

.fa-bar-chart-o::before, .fa-bar-chart::before { content: ""; }

.fa-twitter-square::before { content: ""; }

.fa-facebook-square::before { content: ""; }

.fa-camera-retro::before { content: ""; }

.fa-key::before { content: ""; }

.fa-cogs::before, .fa-gears::before { content: ""; }

.fa-comments::before { content: ""; }

.fa-thumbs-o-up::before { content: ""; }

.fa-thumbs-o-down::before { content: ""; }

.fa-star-half::before { content: ""; }

.fa-heart-o::before { content: ""; }

.fa-sign-out::before { content: ""; }

.fa-linkedin-square::before { content: ""; }

.fa-thumb-tack::before { content: ""; }

.fa-external-link::before { content: ""; }

.fa-sign-in::before { content: ""; }

.fa-trophy::before { content: ""; }

.fa-github-square::before { content: ""; }

.fa-upload::before { content: ""; }

.fa-lemon-o::before { content: ""; }

.fa-phone::before { content: ""; }

.fa-square-o::before { content: ""; }

.fa-bookmark-o::before { content: ""; }

.fa-phone-square::before { content: ""; }

.fa-twitter::before { content: ""; }

.fa-facebook-f::before, .fa-facebook::before { content: ""; }

.fa-github::before { content: ""; }

.fa-unlock::before { content: ""; }

.fa-credit-card::before { content: ""; }

.fa-feed::before, .fa-rss::before { content: ""; }

.fa-hdd-o::before { content: ""; }

.fa-bullhorn::before { content: ""; }

.fa-bell::before { content: ""; }

.fa-certificate::before { content: ""; }

.fa-hand-o-right::before { content: ""; }

.fa-hand-o-left::before { content: ""; }

.fa-hand-o-up::before { content: ""; }

.fa-hand-o-down::before { content: ""; }

.fa-arrow-circle-left::before { content: ""; }

.fa-arrow-circle-right::before { content: ""; }

.fa-arrow-circle-up::before { content: ""; }

.fa-arrow-circle-down::before { content: ""; }

.fa-globe::before { content: ""; }

.fa-wrench::before { content: ""; }

.fa-tasks::before { content: ""; }

.fa-filter::before { content: ""; }

.fa-briefcase::before { content: ""; }

.fa-arrows-alt::before { content: ""; }

.fa-group::before, .fa-users::before { content: ""; }

.fa-chain::before, .fa-link::before { content: ""; }

.fa-cloud::before { content: ""; }

.fa-flask::before { content: ""; }

.fa-cut::before, .fa-scissors::before { content: ""; }

.fa-copy::before, .fa-files-o::before { content: ""; }

.fa-paperclip::before { content: ""; }

.fa-floppy-o::before, .fa-save::before { content: ""; }

.fa-square::before { content: ""; }

.fa-bars::before, .fa-navicon::before, .fa-reorder::before { content: ""; }

.fa-list-ul::before { content: ""; }

.fa-list-ol::before { content: ""; }

.fa-strikethrough::before { content: ""; }

.fa-underline::before { content: ""; }

.fa-table::before { content: ""; }

.fa-magic::before { content: ""; }

.fa-truck::before { content: ""; }

.fa-pinterest::before { content: ""; }

.fa-pinterest-square::before { content: ""; }

.fa-google-plus-square::before { content: ""; }

.fa-google-plus::before { content: ""; }

.fa-money::before { content: ""; }

.fa-caret-down::before { content: ""; }

.fa-caret-up::before { content: ""; }

.fa-caret-left::before { content: ""; }

.fa-caret-right::before { content: ""; }

.fa-columns::before { content: ""; }

.fa-sort::before, .fa-unsorted::before { content: ""; }

.fa-sort-desc::before, .fa-sort-down::before { content: ""; }

.fa-sort-asc::before, .fa-sort-up::before { content: ""; }

.fa-envelope::before { content: ""; }

.fa-linkedin::before { content: ""; }

.fa-rotate-left::before, .fa-undo::before { content: ""; }

.fa-gavel::before, .fa-legal::before { content: ""; }

.fa-dashboard::before, .fa-tachometer::before { content: ""; }

.fa-comment-o::before { content: ""; }

.fa-comments-o::before { content: ""; }

.fa-bolt::before, .fa-flash::before { content: ""; }

.fa-sitemap::before { content: ""; }

.fa-umbrella::before { content: ""; }

.fa-clipboard::before, .fa-paste::before { content: ""; }

.fa-lightbulb-o::before { content: ""; }

.fa-exchange::before { content: ""; }

.fa-cloud-download::before { content: ""; }

.fa-cloud-upload::before { content: ""; }

.fa-user-md::before { content: ""; }

.fa-stethoscope::before { content: ""; }

.fa-suitcase::before { content: ""; }

.fa-bell-o::before { content: ""; }

.fa-coffee::before { content: ""; }

.fa-cutlery::before { content: ""; }

.fa-file-text-o::before { content: ""; }

.fa-building-o::before { content: ""; }

.fa-hospital-o::before { content: ""; }

.fa-ambulance::before { content: ""; }

.fa-medkit::before { content: ""; }

.fa-fighter-jet::before { content: ""; }

.fa-beer::before { content: ""; }

.fa-h-square::before { content: ""; }

.fa-plus-square::before { content: ""; }

.fa-angle-double-left::before { content: ""; }

.fa-angle-double-right::before { content: ""; }

.fa-angle-double-up::before { content: ""; }

.fa-angle-double-down::before { content: ""; }

.fa-angle-left::before { content: ""; }

.fa-angle-right::before { content: ""; }

.fa-angle-up::before { content: ""; }

.fa-angle-down::before { content: ""; }

.fa-desktop::before { content: ""; }

.fa-laptop::before { content: ""; }

.fa-tablet::before { content: ""; }

.fa-mobile-phone::before, .fa-mobile::before { content: ""; }

.fa-circle-o::before { content: ""; }

.fa-quote-left::before { content: ""; }

.fa-quote-right::before { content: ""; }

.fa-spinner::before { content: ""; }

.fa-circle::before { content: ""; }

.fa-mail-reply::before, .fa-reply::before { content: ""; }

.fa-github-alt::before { content: ""; }

.fa-folder-o::before { content: ""; }

.fa-folder-open-o::before { content: ""; }

.fa-smile-o::before { content: ""; }

.fa-frown-o::before { content: ""; }

.fa-meh-o::before { content: ""; }

.fa-gamepad::before { content: ""; }

.fa-keyboard-o::before { content: ""; }

.fa-flag-o::before { content: ""; }

.fa-flag-checkered::before { content: ""; }

.fa-terminal::before { content: ""; }

.fa-code::before { content: ""; }

.fa-mail-reply-all::before, .fa-reply-all::before { content: ""; }

.fa-star-half-empty::before, .fa-star-half-full::before, .fa-star-half-o::before { content: ""; }

.fa-location-arrow::before { content: ""; }

.fa-crop::before { content: ""; }

.fa-code-fork::before { content: ""; }

.fa-chain-broken::before, .fa-unlink::before { content: ""; }

.fa-question::before { content: ""; }

.fa-info::before { content: ""; }

.fa-exclamation::before { content: ""; }

.fa-superscript::before { content: ""; }

.fa-subscript::before { content: ""; }

.fa-eraser::before { content: ""; }

.fa-puzzle-piece::before { content: ""; }

.fa-microphone::before { content: ""; }

.fa-microphone-slash::before { content: ""; }

.fa-shield::before { content: ""; }

.fa-calendar-o::before { content: ""; }

.fa-fire-extinguisher::before { content: ""; }

.fa-rocket::before { content: ""; }

.fa-maxcdn::before { content: ""; }

.fa-chevron-circle-left::before { content: ""; }

.fa-chevron-circle-right::before { content: ""; }

.fa-chevron-circle-up::before { content: ""; }

.fa-chevron-circle-down::before { content: ""; }

.fa-html5::before { content: ""; }

.fa-css3::before { content: ""; }

.fa-anchor::before { content: ""; }

.fa-unlock-alt::before { content: ""; }

.fa-bullseye::before { content: ""; }

.fa-ellipsis-h::before { content: ""; }

.fa-ellipsis-v::before { content: ""; }

.fa-rss-square::before { content: ""; }

.fa-play-circle::before { content: ""; }

.fa-ticket::before { content: ""; }

.fa-minus-square::before { content: ""; }

.fa-minus-square-o::before { content: ""; }

.fa-level-up::before { content: ""; }

.fa-level-down::before { content: ""; }

.fa-check-square::before { content: ""; }

.fa-pencil-square::before { content: ""; }

.fa-external-link-square::before { content: ""; }

.fa-share-square::before { content: ""; }

.fa-compass::before { content: ""; }

.fa-caret-square-o-down::before, .fa-toggle-down::before { content: ""; }

.fa-caret-square-o-up::before, .fa-toggle-up::before { content: ""; }

.fa-caret-square-o-right::before, .fa-toggle-right::before { content: ""; }

.fa-eur::before, .fa-euro::before { content: ""; }

.fa-gbp::before { content: ""; }

.fa-dollar::before, .fa-usd::before { content: ""; }

.fa-inr::before, .fa-rupee::before { content: ""; }

.fa-cny::before, .fa-jpy::before, .fa-rmb::before, .fa-yen::before { content: ""; }

.fa-rouble::before, .fa-rub::before, .fa-ruble::before { content: ""; }

.fa-krw::before, .fa-won::before { content: ""; }

.fa-bitcoin::before, .fa-btc::before { content: ""; }

.fa-file::before { content: ""; }

.fa-file-text::before { content: ""; }

.fa-sort-alpha-asc::before { content: ""; }

.fa-sort-alpha-desc::before { content: ""; }

.fa-sort-amount-asc::before { content: ""; }

.fa-sort-amount-desc::before { content: ""; }

.fa-sort-numeric-asc::before { content: ""; }

.fa-sort-numeric-desc::before { content: ""; }

.fa-thumbs-up::before { content: ""; }

.fa-thumbs-down::before { content: ""; }

.fa-youtube-square::before { content: ""; }

.fa-youtube::before { content: ""; }

.fa-xing::before { content: ""; }

.fa-xing-square::before { content: ""; }

.fa-youtube-play::before { content: ""; }

.fa-dropbox::before { content: ""; }

.fa-stack-overflow::before { content: ""; }

.fa-instagram::before { content: ""; }

.fa-flickr::before { content: ""; }

.fa-adn::before { content: ""; }

.fa-bitbucket::before { content: ""; }

.fa-bitbucket-square::before { content: ""; }

.fa-tumblr::before { content: ""; }

.fa-tumblr-square::before { content: ""; }

.fa-long-arrow-down::before { content: ""; }

.fa-long-arrow-up::before { content: ""; }

.fa-long-arrow-left::before { content: ""; }

.fa-long-arrow-right::before { content: ""; }

.fa-apple::before { content: ""; }

.fa-windows::before { content: ""; }

.fa-android::before { content: ""; }

.fa-linux::before { content: ""; }

.fa-dribbble::before { content: ""; }

.fa-skype::before { content: ""; }

.fa-foursquare::before { content: ""; }

.fa-trello::before { content: ""; }

.fa-female::before { content: ""; }

.fa-male::before { content: ""; }

.fa-gittip::before, .fa-gratipay::before { content: ""; }

.fa-sun-o::before { content: ""; }

.fa-moon-o::before { content: ""; }

.fa-archive::before { content: ""; }

.fa-bug::before { content: ""; }

.fa-vk::before { content: ""; }

.fa-weibo::before { content: ""; }

.fa-renren::before { content: ""; }

.fa-pagelines::before { content: ""; }

.fa-stack-exchange::before { content: ""; }

.fa-arrow-circle-o-right::before { content: ""; }

.fa-arrow-circle-o-left::before { content: ""; }

.fa-caret-square-o-left::before, .fa-toggle-left::before { content: ""; }

.fa-dot-circle-o::before { content: ""; }

.fa-wheelchair::before { content: ""; }

.fa-vimeo-square::before { content: ""; }

.fa-try::before, .fa-turkish-lira::before { content: ""; }

.fa-plus-square-o::before { content: ""; }

.fa-space-shuttle::before { content: ""; }

.fa-slack::before { content: ""; }

.fa-envelope-square::before { content: ""; }

.fa-wordpress::before { content: ""; }

.fa-openid::before { content: ""; }

.fa-bank::before, .fa-institution::before, .fa-university::before { content: ""; }

.fa-graduation-cap::before, .fa-mortar-board::before { content: ""; }

.fa-yahoo::before { content: ""; }

.fa-google::before { content: ""; }

.fa-reddit::before { content: ""; }

.fa-reddit-square::before { content: ""; }

.fa-stumbleupon-circle::before { content: ""; }

.fa-stumbleupon::before { content: ""; }

.fa-delicious::before { content: ""; }

.fa-digg::before { content: ""; }

.fa-pied-piper-pp::before { content: ""; }

.fa-pied-piper-alt::before { content: ""; }

.fa-drupal::before { content: ""; }

.fa-joomla::before { content: ""; }

.fa-language::before { content: ""; }

.fa-fax::before { content: ""; }

.fa-building::before { content: ""; }

.fa-child::before { content: ""; }

.fa-paw::before { content: ""; }

.fa-spoon::before { content: ""; }

.fa-cube::before { content: ""; }

.fa-cubes::before { content: ""; }

.fa-behance::before { content: ""; }

.fa-behance-square::before { content: ""; }

.fa-steam::before { content: ""; }

.fa-steam-square::before { content: ""; }

.fa-recycle::before { content: ""; }

.fa-automobile::before, .fa-car::before { content: ""; }

.fa-cab::before, .fa-taxi::before { content: ""; }

.fa-tree::before { content: ""; }

.fa-spotify::before { content: ""; }

.fa-deviantart::before { content: ""; }

.fa-soundcloud::before { content: ""; }

.fa-database::before { content: ""; }

.fa-file-pdf-o::before { content: ""; }

.fa-file-word-o::before { content: ""; }

.fa-file-excel-o::before { content: ""; }

.fa-file-powerpoint-o::before { content: ""; }

.fa-file-image-o::before, .fa-file-photo-o::before, .fa-file-picture-o::before { content: ""; }

.fa-file-archive-o::before, .fa-file-zip-o::before { content: ""; }

.fa-file-audio-o::before, .fa-file-sound-o::before { content: ""; }

.fa-file-movie-o::before, .fa-file-video-o::before { content: ""; }

.fa-file-code-o::before { content: ""; }

.fa-vine::before { content: ""; }

.fa-codepen::before { content: ""; }

.fa-jsfiddle::before { content: ""; }

.fa-life-bouy::before, .fa-life-buoy::before, .fa-life-ring::before, .fa-life-saver::before, .fa-support::before { content: ""; }

.fa-circle-o-notch::before { content: ""; }

.fa-ra::before, .fa-rebel::before, .fa-resistance::before { content: ""; }

.fa-empire::before, .fa-ge::before { content: ""; }

.fa-git-square::before { content: ""; }

.fa-git::before { content: ""; }

.fa-hacker-news::before, .fa-y-combinator-square::before, .fa-yc-square::before { content: ""; }

.fa-tencent-weibo::before { content: ""; }

.fa-qq::before { content: ""; }

.fa-wechat::before, .fa-weixin::before { content: ""; }

.fa-paper-plane::before, .fa-send::before { content: ""; }

.fa-paper-plane-o::before, .fa-send-o::before { content: ""; }

.fa-history::before { content: ""; }

.fa-circle-thin::before { content: ""; }

.fa-header::before { content: ""; }

.fa-paragraph::before { content: ""; }

.fa-sliders::before { content: ""; }

.fa-share-alt::before { content: ""; }

.fa-share-alt-square::before { content: ""; }

.fa-bomb::before { content: ""; }

.fa-futbol-o::before, .fa-soccer-ball-o::before { content: ""; }

.fa-tty::before { content: ""; }

.fa-binoculars::before { content: ""; }

.fa-plug::before { content: ""; }

.fa-slideshare::before { content: ""; }

.fa-twitch::before { content: ""; }

.fa-yelp::before { content: ""; }

.fa-newspaper-o::before { content: ""; }

.fa-wifi::before { content: ""; }

.fa-calculator::before { content: ""; }

.fa-paypal::before { content: ""; }

.fa-google-wallet::before { content: ""; }

.fa-cc-visa::before { content: ""; }

.fa-cc-mastercard::before { content: ""; }

.fa-cc-discover::before { content: ""; }

.fa-cc-amex::before { content: ""; }

.fa-cc-paypal::before { content: ""; }

.fa-cc-stripe::before { content: ""; }

.fa-bell-slash::before { content: ""; }

.fa-bell-slash-o::before { content: ""; }

.fa-trash::before { content: ""; }

.fa-copyright::before { content: ""; }

.fa-at::before { content: ""; }

.fa-eyedropper::before { content: ""; }

.fa-paint-brush::before { content: ""; }

.fa-birthday-cake::before { content: ""; }

.fa-area-chart::before { content: ""; }

.fa-pie-chart::before { content: ""; }

.fa-line-chart::before { content: ""; }

.fa-lastfm::before { content: ""; }

.fa-lastfm-square::before { content: ""; }

.fa-toggle-off::before { content: ""; }

.fa-toggle-on::before { content: ""; }

.fa-bicycle::before { content: ""; }

.fa-bus::before { content: ""; }

.fa-ioxhost::before { content: ""; }

.fa-angellist::before { content: ""; }

.fa-cc::before { content: ""; }

.fa-ils::before, .fa-shekel::before, .fa-sheqel::before { content: ""; }

.fa-meanpath::before { content: ""; }

.fa-buysellads::before { content: ""; }

.fa-connectdevelop::before { content: ""; }

.fa-dashcube::before { content: ""; }

.fa-forumbee::before { content: ""; }

.fa-leanpub::before { content: ""; }

.fa-sellsy::before { content: ""; }

.fa-shirtsinbulk::before { content: ""; }

.fa-simplybuilt::before { content: ""; }

.fa-skyatlas::before { content: ""; }

.fa-cart-plus::before { content: ""; }

.fa-cart-arrow-down::before { content: ""; }

.fa-diamond::before { content: ""; }

.fa-ship::before { content: ""; }

.fa-user-secret::before { content: ""; }

.fa-motorcycle::before { content: ""; }

.fa-street-view::before { content: ""; }

.fa-heartbeat::before { content: ""; }

.fa-venus::before { content: ""; }

.fa-mars::before { content: ""; }

.fa-mercury::before { content: ""; }

.fa-intersex::before, .fa-transgender::before { content: ""; }

.fa-transgender-alt::before { content: ""; }

.fa-venus-double::before { content: ""; }

.fa-mars-double::before { content: ""; }

.fa-venus-mars::before { content: ""; }

.fa-mars-stroke::before { content: ""; }

.fa-mars-stroke-v::before { content: ""; }

.fa-mars-stroke-h::before { content: ""; }

.fa-neuter::before { content: ""; }

.fa-genderless::before { content: ""; }

.fa-facebook-official::before { content: ""; }

.fa-pinterest-p::before { content: ""; }

.fa-whatsapp::before { content: ""; }

.fa-server::before { content: ""; }

.fa-user-plus::before { content: ""; }

.fa-user-times::before { content: ""; }

.fa-bed::before, .fa-hotel::before { content: ""; }

.fa-viacoin::before { content: ""; }

.fa-train::before { content: ""; }

.fa-subway::before { content: ""; }

.fa-medium::before { content: ""; }

.fa-y-combinator::before, .fa-yc::before { content: ""; }

.fa-optin-monster::before { content: ""; }

.fa-opencart::before { content: ""; }

.fa-expeditedssl::before { content: ""; }

.fa-battery-4::before, .fa-battery-full::before, .fa-battery::before { content: ""; }

.fa-battery-3::before, .fa-battery-three-quarters::before { content: ""; }

.fa-battery-2::before, .fa-battery-half::before { content: ""; }

.fa-battery-1::before, .fa-battery-quarter::before { content: ""; }

.fa-battery-0::before, .fa-battery-empty::before { content: ""; }

.fa-mouse-pointer::before { content: ""; }

.fa-i-cursor::before { content: ""; }

.fa-object-group::before { content: ""; }

.fa-object-ungroup::before { content: ""; }

.fa-sticky-note::before { content: ""; }

.fa-sticky-note-o::before { content: ""; }

.fa-cc-jcb::before { content: ""; }

.fa-cc-diners-club::before { content: ""; }

.fa-clone::before { content: ""; }

.fa-balance-scale::before { content: ""; }

.fa-hourglass-o::before { content: ""; }

.fa-hourglass-1::before, .fa-hourglass-start::before { content: ""; }

.fa-hourglass-2::before, .fa-hourglass-half::before { content: ""; }

.fa-hourglass-3::before, .fa-hourglass-end::before { content: ""; }

.fa-hourglass::before { content: ""; }

.fa-hand-grab-o::before, .fa-hand-rock-o::before { content: ""; }

.fa-hand-paper-o::before, .fa-hand-stop-o::before { content: ""; }

.fa-hand-scissors-o::before { content: ""; }

.fa-hand-lizard-o::before { content: ""; }

.fa-hand-spock-o::before { content: ""; }

.fa-hand-pointer-o::before { content: ""; }

.fa-hand-peace-o::before { content: ""; }

.fa-trademark::before { content: ""; }

.fa-registered::before { content: ""; }

.fa-creative-commons::before { content: ""; }

.fa-gg::before { content: ""; }

.fa-gg-circle::before { content: ""; }

.fa-tripadvisor::before { content: ""; }

.fa-odnoklassniki::before { content: ""; }

.fa-odnoklassniki-square::before { content: ""; }

.fa-get-pocket::before { content: ""; }

.fa-wikipedia-w::before { content: ""; }

.fa-safari::before { content: ""; }

.fa-chrome::before { content: ""; }

.fa-firefox::before { content: ""; }

.fa-opera::before { content: ""; }

.fa-internet-explorer::before { content: ""; }

.fa-television::before, .fa-tv::before { content: ""; }

.fa-contao::before { content: ""; }

.fa-500px::before { content: ""; }

.fa-amazon::before { content: ""; }

.fa-calendar-plus-o::before { content: ""; }

.fa-calendar-minus-o::before { content: ""; }

.fa-calendar-times-o::before { content: ""; }

.fa-calendar-check-o::before { content: ""; }

.fa-industry::before { content: ""; }

.fa-map-pin::before { content: ""; }

.fa-map-signs::before { content: ""; }

.fa-map-o::before { content: ""; }

.fa-map::before { content: ""; }

.fa-commenting::before { content: ""; }

.fa-commenting-o::before { content: ""; }

.fa-houzz::before { content: ""; }

.fa-vimeo::before { content: ""; }

.fa-black-tie::before { content: ""; }

.fa-fonticons::before { content: ""; }

.fa-reddit-alien::before { content: ""; }

.fa-edge::before { content: ""; }

.fa-credit-card-alt::before { content: ""; }

.fa-codiepie::before { content: ""; }

.fa-modx::before { content: ""; }

.fa-fort-awesome::before { content: ""; }

.fa-usb::before { content: ""; }

.fa-product-hunt::before { content: ""; }

.fa-mixcloud::before { content: ""; }

.fa-scribd::before { content: ""; }

.fa-pause-circle::before { content: ""; }

.fa-pause-circle-o::before { content: ""; }

.fa-stop-circle::before { content: ""; }

.fa-stop-circle-o::before { content: ""; }

.fa-shopping-bag::before { content: ""; }

.fa-shopping-basket::before { content: ""; }

.fa-hashtag::before { content: ""; }

.fa-bluetooth::before { content: ""; }

.fa-bluetooth-b::before { content: ""; }

.fa-percent::before { content: ""; }

.fa-gitlab::before { content: ""; }

.fa-wpbeginner::before { content: ""; }

.fa-wpforms::before { content: ""; }

.fa-envira::before { content: ""; }

.fa-universal-access::before { content: ""; }

.fa-wheelchair-alt::before { content: ""; }

.fa-question-circle-o::before { content: ""; }

.fa-blind::before { content: ""; }

.fa-audio-description::before { content: ""; }

.fa-volume-control-phone::before { content: ""; }

.fa-braille::before { content: ""; }

.fa-assistive-listening-systems::before { content: ""; }

.fa-american-sign-language-interpreting::before, .fa-asl-interpreting::before { content: ""; }

.fa-deaf::before, .fa-deafness::before, .fa-hard-of-hearing::before { content: ""; }

.fa-glide::before { content: ""; }

.fa-glide-g::before { content: ""; }

.fa-sign-language::before, .fa-signing::before { content: ""; }

.fa-low-vision::before { content: ""; }

.fa-viadeo::before { content: ""; }

.fa-viadeo-square::before { content: ""; }

.fa-snapchat::before { content: ""; }

.fa-snapchat-ghost::before { content: ""; }

.fa-snapchat-square::before { content: ""; }

.fa-pied-piper::before { content: ""; }

.fa-first-order::before { content: ""; }

.fa-yoast::before { content: ""; }

.fa-themeisle::before { content: ""; }

.fa-google-plus-circle::before, .fa-google-plus-official::before { content: ""; }

.fa-fa::before, .fa-font-awesome::before { content: ""; }

.fa-handshake-o::before { content: ""; }

.fa-envelope-open::before { content: ""; }

.fa-envelope-open-o::before { content: ""; }

.fa-linode::before { content: ""; }

.fa-address-book::before { content: ""; }

.fa-address-book-o::before { content: ""; }

.fa-address-card::before, .fa-vcard::before { content: ""; }

.fa-address-card-o::before, .fa-vcard-o::before { content: ""; }

.fa-user-circle::before { content: ""; }

.fa-user-circle-o::before { content: ""; }

.fa-user-o::before { content: ""; }

.fa-id-badge::before { content: ""; }

.fa-drivers-license::before, .fa-id-card::before { content: ""; }

.fa-drivers-license-o::before, .fa-id-card-o::before { content: ""; }

.fa-quora::before { content: ""; }

.fa-free-code-camp::before { content: ""; }

.fa-telegram::before { content: ""; }

.fa-thermometer-4::before, .fa-thermometer-full::before, .fa-thermometer::before { content: ""; }

.fa-thermometer-3::before, .fa-thermometer-three-quarters::before { content: ""; }

.fa-thermometer-2::before, .fa-thermometer-half::before { content: ""; }

.fa-thermometer-1::before, .fa-thermometer-quarter::before { content: ""; }

.fa-thermometer-0::before, .fa-thermometer-empty::before { content: ""; }

.fa-shower::before { content: ""; }

.fa-bath::before, .fa-bathtub::before, .fa-s15::before { content: ""; }

.fa-podcast::before { content: ""; }

.fa-window-maximize::before { content: ""; }

.fa-window-minimize::before { content: ""; }

.fa-window-restore::before { content: ""; }

.fa-times-rectangle::before, .fa-window-close::before { content: ""; }

.fa-times-rectangle-o::before, .fa-window-close-o::before { content: ""; }

.fa-bandcamp::before { content: ""; }

.fa-grav::before { content: ""; }

.fa-etsy::before { content: ""; }

.fa-imdb::before { content: ""; }

.fa-ravelry::before { content: ""; }

.fa-eercast::before { content: ""; }

.fa-microchip::before { content: ""; }

.fa-snowflake-o::before { content: ""; }

.fa-superpowers::before { content: ""; }

.fa-wpexplorer::before { content: ""; }

.fa-meetup::before { content: ""; }

.sr-only { position: absolute; width: 1px; height: 1px; padding: 0px; margin: -1px; overflow: hidden; clip: rect(0px, 0px, 0px, 0px); border: 0px; }

.sr-only-focusable:active, .sr-only-focusable:focus { position: static; width: auto; height: auto; margin: 0px; overflow: visible; clip: auto; }

<link rel="stylesheet" type="text/css" href="https://www.gstatic.com/recaptcha/releases/rPvs0Nyx3sANE-ZHUN-0nM85/styles__ltr.css">

<div id="rc-anchor-alert" class="rc-anchor-alert"></div>

<div class="rc-anchor rc-anchor-invisible rc-anchor-light  rc-anchor-invisible-hover"><div id="recaptcha-accessible-status" class="rc-anchor-aria-status" aria-hidden="true">Recaptcha requires verification. </div><div class="rc-anchor-error-msg-container" style="display:none"><span class="rc-anchor-error-msg" aria-hidden="true"></span></div><div class="rc-anchor-normal-footer"><div class="rc-anchor-logo-large" role="presentation"><div class="rc-anchor-logo-img rc-anchor-logo-img-large"></div></div><div class="rc-anchor-pt"><a href="https://www.google.com/intl/en/policies/privacy/" target="_blank">Privacy</a><span aria-hidden="true" role="presentation"> - </span><a href="https://www.google.com/intl/en/policies/terms/" target="_blank">Terms</a></div></div><div class="rc-anchor-invisible-text"><span>protected by <strong>reCAPTCHA</strong></span><div class="rc-anchor-pt"><a href="https://www.google.com/intl/en/policies/privacy/" target="_blank" style="">Privacy</a><span aria-hidden="true" role="presentation"> - </span><a href="https://www.google.com/intl/en/policies/terms/" target="_blank" style="">Terms</a></div></div></div><iframe style="display: none;"></iframe><iframe style="display: none;"></iframe></body></html>

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu72xKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu5mxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu7mxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+1F00-1FFF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4WxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+370-3FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu7WxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu7GxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; src: local("Roboto Regular"), local("Roboto-Regular"), local("sans-serif"), url("//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxKKTU1Kg.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fCRc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fABc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fCBc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+1F00-1FFF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fBxc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+370-3FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fCxc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fChc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fBBc4AMP6lQ.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfCRc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfABc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfCBc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+1F00-1FFF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfBxc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+370-3FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfCxc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfChc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+100-24F, U+259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 900; src: local("Roboto Black"), local("Roboto-Black"), local("sans-serif-black"), url("//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfBBc4AMP6lQ.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }


.goog-inline-block { position: relative; display: inline-block; }

* html .goog-inline-block { display: inline; }

:first-child + html .goog-inline-block { display: inline; }

.recaptcha-checkbox { border: none; font-size: 1px; height: 28px; margin: 4px; width: 28px; overflow: visible; outline: 0px; vertical-align: text-bottom; }

.recaptcha-checkbox-border { border-radius: 2px; background-color: rgb(255, 255, 255); border: 2px solid rgb(193, 193, 193); font-size: 1px; height: 24px; position: absolute; width: 24px; z-index: 1; }

.recaptcha-checkbox-borderAnimation { background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAANICAYAAABZl8i8AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAABIAAAASABGyWs+AAAACXZwQWcAAABUAAADSAC4K4y8AAA4oElEQVR42u2dCZRV1ZX3q5iE4IQIiKQQCKBt0JLEIUZwCCk7pBNFiRMajZrIl9aOLZ8sY4CWdkDbT2McooaAEmNixFhpaYE2dCiLScWiQHCgoGQoGQuhGArKKl7V+c5/n33fO/V4w733nVuheXuv9V/rrnvP2Xud3zvTPee+ewsKxMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExP4OdtlT6ztAbRWvvLy8A3QkwxzH6tBGMMexIo+nCgraaf2E1U6A5g60o9a9rI7S5N1APQaSzl1MTExMTExMTExMTExMTExMTExMTExMTExMTExMTOwIsMueWl8EtVW88vLyIqit4qmCguOgtoT5AKuojWA+wCpqA5i9tP6d1UuA5g70K1oPsL4iTd4N1DMh6dzFxMTExMTExMTExMTExMTExMTExMTExMTExMTExMT+l9tlT63/stbtrC9HHa+8vPzLWrezIo+nCgq6a41hdW8LoAD5COv2NgAKkI+wbm8DoHhf0yOsnwjQ3IHeaQG9U5p87kAHa01kDZZOXkxMTExMTExMTExMTExMTExMTExMTExMTExMTEysLe2yp9afoTWWdUbU8crLy8/QGsuKPJ4qKOirdRWrb1vAfDJJZ0QM88kknREhTLwR5wmtJ1lPRPpmHK6VT/5q3g4SAx0bIVDUyidXr15NYqBjIwT6YwI5cqSRgfpjARoe6E8J4vjxRgboT6XJhwf6Dau5e/qGDEq5Qb3I+mriRTINERMTExMTExMTExMTExMTExMTExMTExMTEzss7LKn1neB2ipeeXl5F+hIBHma1mStF1g4Pi1CkKdpTdZ6gYXjyOKpgoLeWndoPcPCce8oYU63YHqaHgVUhjndgulpehRQNbgiree0XkgSzhVFAZRq5pQ3t7+w+0CMhGOvpkYAlGrmhx9++EJTUxMJx15NjQDozwngN7/5gnr/fSMcG6g/j6LPJHgAqZQi4diqqV0c95kEDyC9eDi2amoXhzCP0ppO8DZsiMejYwMU144SoP6BHk3gCgtfUHv2JIDiGOcM1KOlyQeD+giB++lPX1AHDxrh2MB8RAal4EDPjg9Exx1nlBiYzpZpUzio39R6ygKJ42/KxD43qO14CgW1k9s4MTExMTExMTExMTExMTExMTExMTGxw894C+Q2rQdZt7XBFshtWg+ybot4C6Sn1hX8xZo7+bhnFCA78NdpStMI1zo4BNmBv05Tmka41sEhyEJ+C85rWqVJeo2vFboESjBHPb2+9Om/fV66pHo/Ccc450F1CJRgLliwoLSqqqp0x44dJBzjnAfVIdAxcYDf/napevxxIxwnwI5x2cwJXMX6A6VKqVbCOQvqaY6aOYHbuXPnIfFwzoJ6mgOYeE/T6wTtN785JB6dM0Bfd/IeJ+4nqTYeEoyFawz0NgdA0U9SbUwXD9cY6G0OgN5MwK66Km08umag3uwCKAYfauLpAuIaA33QAVAMPtTE08XDNQb6oAOg9xOsV15JDxTXDND7BWh2oA8TrFmz0gPFNQP0YWny2YHeQbDuuis9UFwzQO+QQSk70KEEq0uXUlVRcShMnMM1A3SoTJv8QZ1AwI4+ulQ9+GCpWrbMCMc4Z2BOkIm9f6Bf0pqcYlLvCde+JLeewe+WhvP3PKeyJvK5wgIxMTExMTExMTExMTExMTExMbHD2y57an03rRKtG1g47hZVvPLy8m5aJVo3sHAcWTxVUNBB6wytb7Nw3CEKkD20JmjN1ypL0ny+1sMhyB5aE7Tma5UlaT5f6+EQJBaYb9V6U6ssSW/ytS+5gnkar8qXXa41fuaWsmfnf07C8eUJsE73lDyAy5cvL1uzZg0JxxZYV3tKJ2v9Lg6wd+8y9Z3vGOE4ARZpTnZRMwnmna9sLlu3o7FMKdVKOIdrFtQeOdZMgrls2bKy+vr6Q+LhHK5ZUHvkAPMYrd8TsKKiMjVrVplqaUnEwzHO4ZqBirTH5AJ0ggezoan5kMJ5wjUL6oQcgE7wYMZisbTxcM2COiEHoD8jUKecUqa2bEkbj64hjYH6s1wGoPlo0qlqZqqaenmiT+0WcgCiPjNVzUxVU60+tVsImHhxyzyCpP1ki0dpDNB5oV7owiM49ZNZg7GQlmtpSQigJV6f6Tee1aeWhAB6MQE680zf8SitgXpxGKCYFtHg4zcg0jLQ60MAxbSIBh+/8ZCWgV4fAugYgnPbbf6BIq0BOqatgd7QxkBvCAH0RoLzz//sHyjSGqA3SpM/FOhIgnPJJf6BIq0BOlIGpUOB9iI4HTqUqU8/zQ4TaZDWAO0l06bUUB8hQCNGlKmDB9PDxDWkMTDDv2UsDyb2p2jNIVC4M0o1F8U5XDMwkfYUufXMDPU8rf8mYF27lqlrry1TjzxihGOcMzCR5jxZHPEHFd9EfjrFwoinpyP5RnLS8t31bbx8d30bLN+dpvVDrbu1/i8fR/Z0oZiYmJiYmJiYmJiYmJhYVKbv1wu1LuD31s/Sepc1i8/hmrN/m+n79UKtC/i99bO03mXN4nO45vTfbfqefYDWWK3nrb8kPs/nBriEOVDrZa3KLEKagQ5gDtR6Wasyi5BmoAOQPbT+n1ZlFiFNj1xhnqf1DoBd/dyGyt+W76z84LOGys/3xUg4xjlcY6hIe14OMM/TegfAFi1aVFldXV1ZV1dX+cUXX5BwjHO4xlCR9rwcYA7W+h8CVlhYqS6/vFJNn16ptH8SjnEO1wxUpB2cS80kmL94fWvlrvpYpVIqpXANaSyoA0PWTIK5YsWKysbGxrTxcA1pLKgDQ8A8SWs+gTrttEql/aWLR9eQxkBFnpPC9JkvezAPxlrSB2MhjQX15SB9KveZL3swW1qyx0MaC+rLQftUDeVZAjRkSKXavTtrPEqDtAbqs0GBXuA180w1M1VNtZr/BQGAXuA180w1M1VNtZr/BQFgnkVgOnasVFVVvuNRWuQxUM8KAhQjN/WPvoOxkIeBTg4AFCM39Y9B4yEPA50cAOjPCcottwSOR3kM0J8HAYrpEA06QQMiDwOdFQAopkM06ASNhzwMdFYAoKUEZc6c4ECRxwAtDQIUc0wayYMGRB4G+m4AoJhj0kgeNB7yMNB3AwBdTFA2bAgOFHkM0MUCNAH0PYKydWtwoMhjgL4nTT4BdDZBwVwzKFDkMUBny6CUAPofBGXChOBAkccA/Q+ZNiWAlhCU7t0rVZBWgbTIY4CWBAF6RE/sNYz2Wv9JYK6+ulL5iEdpkNbARN72cuvZGurXtCoI0JgxlerAgfQwcQ1pDEzk+ZosjqSG+k9xqH36VKonnqhUn35qaiOEY5zDtQTMf5Llu8xQz9ea22qpDreXiVtMT0hzviww+4N6FL+4Gq9ne9+C+D6fu8rpx6bzyfgdeN1Z8s47MTExMTExMbHDxPQE/li+e4KOjTqensAfy3dP0LFtUUY9/+wCRQmxn/c3Ra2qJJXxtX4OIfbz/qaoVZWkMr7WzyHAY7V+xK/AWKZVxVrG53DtWBcgO2tN0vrEhjjmNxtJSWA/4bSdcwDZWWuS1ic2xMWLF5OSwH7CaTvnALKd1i1ayy2I6bSc07YLC/MErb94wO77z21VS6r3VzU0NVcppUg4xjlcs8AizwkhYJ6g9RcP2MqVK6t27NhRFYvF4vFwjHO4ZoFFnhNCNuupcWCnn16lHn+8Sq1aVaX27DHCMc7hWgLs1MDdAddMgnnDb2uqlm04EC9UOiEN0lpQOwesmQRzyZIlVTt37swaD2mQ1oLaOQBMLDBPJ0BdulSp556rUtYPd4hwDWmQ1kCdHmiBmZsuAdqyuylr4TwhrQV1UgCgkzyYBw4c8B0PaS2okwIAvT0OU+f3G4/SJqDeHmQAoj7TT81MVVOtPrWfzwGI+kw/NTNVTbX61H4+YOLFA6sIyu9/Hzge5TFAV/l6EQGP2NQvBg7GsvrUCT6ATvD6zLDxrD51gg+gdxGQ886rUi0tweMhD/IaqHf5AUpTIww2YQuIvN6UygdQmhphsAkbD3m9KZUPoHND185Da+lcP5N2gmGP5kGFvNaof2yWSTvBiGUaFLIIea1R/9gMMLvGR+sQ3UtcyJsY9btmAjrQm2eGDsay5qkDMwAd6M0zc41nzVMHZgA6gCAcc0zO8ciHATogn4EOIgg9euQOFD4M0EH53ORPiDfVhobwMJE30eRPyPdBaTGBmDs3PFDkNTAXy7SpoOAhgnHtteGBIq8B+pBM7AsKvhpvrkuXBoeJPInm/lW59TRQf0lA+vevUrW1/mEiLfIYmL+UxZEE0OP4/0ZVatAgs6qUDSbSIK2BibzHyfJda6in8EuuqlT79lVq7NgqtWzZoSBxDteQxsAsC/26tjxYYO7Of5BN9Ivdu1epoUONcNx6kRlpu8sWSHaweALvufgqVGut4mvnF0RhR/ImHT+Fd7rWRazT5ak7MTExMbH8Mf7W/ImsDlHH42/Nn8jqcKRAHKQ1UWue1nqtGtZ6PodrgxxCHKQ1UWue1nqtGtZ6PodrzuLpqVE3ftzmRa13tNay3uFzuNbNBcieWs9aAElXPLOBlHye0/bMAWRPrWctgKQFCxaQks9z2p45gMSHqe7VWqNVk0VrOO2XwsI8R2s5QF2uNeXN7TVvr66v2bU/VqPvcUk4xjlcuzwBFXnOCQHzHK3lHqwPP/ywZvv27TWNjY3xeDjGOVyzoCLPOSFgfoXvyw2ws86qUQ8+WKPeeadGbd5shGOcw7UE2LLAL7hmmGsA6M4/bq5ZV5soVDohDdIy1DVBoDLMNQBUUVFRs2/fvqzxkAZpGeqaIFA1kIFaKwhQnz416o03ssajNEhroCLvwCDNnGrmv7+xreaLgy3Zg7GQFnmsmtrTZzOnmrlq1aqa5uZm3/GQFnmsmtrTB0x85WsRgTn77Bqla7zfeJQWeQzURb6+/uX1mahtQWDaUK2a+qwPoM96NTMITBuqVVOf9QH0IQLSr1+Nqq0NHI/yIK+B+pCf0Zz6Qz/NPFPzt/rUQVlGc4Lhp5lnav5WnzooA8w+WusJxvz5oeNRXgMUvvpkAorpDw0yoYOx4IOBTswAdKI3AOUazxqoJmYAOo5AjBiRczzyYaCOywQUc0oauXMNCB8MdF4GoJhT0sidazz4YKDzMgB9kyBMnZo7UPgwQN/MdAdEk3Z7ahRW8GFN/jukuQOiSbs9NQor+LAm/x1SwMRDtusIwoYNuQOFDwN0XcqHb/lWkibsOQdjWZP/E1MAPdGbtLuKZ03+T0yz3VGj2rd3Fo98Gajd8xFoTyr8UUe5AwpfBmjPfGzynbQ2EoCdO3OHCR8GJnx2ytdBqZwglJbmDhQ+DNDyfJ42TSEIN9yQO1D4MECn5PPE/iyC0LFjjfr00/AwkRc+DNCz8v3W848E4pJLalQsxFiBPMhrYP5RFkfMY+GrCcgttwSDirTIY2Cu9v069jxYvsNXZzcQmO98x6x9ZoOJNEhrYG4I/PXZPFhg/ife5qhRXbvWqH/91xq1aFGNslsIjnEO15DGwFwb+u1iebAFcqrWG622Orp0qVGDBhnhuPU2CNKeKpt0maHixVeX8JN1H6fYS/qYr10SyYuxjuRtZP7/fJHWUFZR6P/Hi4mJiYlF9ihOJ63vak3xPo1ufQJ9Cl/r5HAg6qT1Xa0p9qfR+XgKX+vksox68DlD66daT2q9xHqSz53hCiT+tDCen6WvzaIqTpvrnxbG87P0tVlUxWlz+dMCpkzXaC3Qqs2iBZy2MCzMYq2lHrBbXvis9rflO2vLq+prV21qIOEY53DNAos8xSFgFmst9YC9++67tdXV1bX6zqi2rq6OhGOcwzULLPIUh4D5Zd60M8C6dKlVl19eqx56qFa9+KIRjnEO1xJgkefLQWF+iyfutTdrWADX0qJq9e1YSuEa0tycAIu83woA81s8cSdYAJculiekscAi77cCwCzmxY1adfTRtWrKlFq1Z0/6eLiGNEhroCJvcZCaSTAnv7Gtdt8XzVkL5wlpkceCWuyzZhLMVatW1R48eNB3PKRFHgtqsQ+Y/eIwhw6tVevW+Y5HaZEnAbWfnz5zqQfzYKzFfzCvkDqPBXVppj6V+8ylHsyWluDxkMeCujRTn6oBdNCaR0C+/vVatXt34HiUB3kNVPjqkAnoeK+ZB6mZqWqq1fzHZwA63mvmQWpmqppqNf/xGYD+mEB061arPvssdDzKCx8G6o8zTY1oNEd/GDoYCz6s0b9TmqkRjeZ++kw/fao1+ndK86DDCoLw61/nHI98GKAr0j3o8F1vNM80APlvisoe/b+bAuh3vdqZc+FYVi39bgqglxCAE0+sVY2NuceDD/gyUC9JBRQTdJoGuSogfDHQKSmAYoJO0yBX8eCLgU5JAXQyFf6225zFI18G6ORUQEtdNfcUzb40BdBSV809RbMvTQF0JhV+xgx3QOHLAJ2ZCihuJWnC7iogfDHQshRAcStJE3ZX8eCLgZalAFpGhZ8/3x1Q+DJAy/IXaFmZO6DwlQHokd7kZ1HhX3vNHVD4MkBn5eOg9BgV/p573AGFLwP0sXycNo2mwp96qjug8GWAjs7Hif3R/IBCrZo7N3eY8GFgwufR+Xrr+QBB+Id/qFUNOQy+yAsfBugD+bw4cjzvs9eqm26qVSHiUR7kNTDh6/h8X767WGsbAbn11mC3oUiLPAYmfFwsC8wG6nVxqFjfXLIkO0ykSayFIu91sgXSGuql/JdtA+mCC2rVE0/UqsWLa9X69UY4xjlcS2yBIM+lskmXGmoPrae0NvvYpNvMaXvINnJ2sHi3/f/hD6ngY6jVrAo+9398vbNeTExMLH0/is/5Dtb6vtaNrO/zOecPovLnfAdrfV/rRtb3+VwkX4TlDwcU81z1Yj7u6hrkAK1H+Y8IdWm0htMMcABygNaj/EeEujRaw2kGOICIt93eofU3rZ1adUnaydfuCPxW2ySQXbUe0/rcA3f1cxvq7nltS93Ds7eTcIxzFtjPOU/XECC7aj2m9bkHbtGiRXXLly+v++ijj0g4xjkL7Oecp2sIkNgF/Rn/VzMBsE+fOvW1rxnhuDXcjZynfZhaudQD9cCs7XWVGw/UxZpb6vRdQyvhHK4hjQV2aZDayrVyqQdK307W7dq1q07fpx8SD+dwDWkssEuD1FYN5ESt2XFQZ5xRp55/vk5t3XpIPDqHa0iTAIu8JwaBWQ0wN79QU7eipuHQIGmEtMjDUKv9QGWY1QCj74DqYH7jwZCHoVb7gcowKwjM0UfXqWnT6lSKH+4QIQ3SIo+BWpEVKjdzqpn/8ofNdXX7Y74LFy+kzoO8Vk3tmqWZU82sqKioa2xsDBwPeZDXqqldM8DsyI/PmOb8ySeB41GeRFcAXx0zAX3Mq5lhYNpQrZr6WAagj3k1MwxMG6pVUx/LAPReAnH88XWqqip0PMoLHwbqvZmaOg1AQZp5puZvDVQD0jR1GoCCNPNMzd8aqAakub3cRhBeeSXneOTDAN2W8raUpz00uOQcjGUNVI+mAPqoNwC5imcNVI+mAPpvBGDYMGfxyJeB+m+pJu00z8SI7SogfFnz1MKkSTvNMzFiu4oHX9Y8tTAJ6Coq/J//7A4ofBmgq5KBDvbmmammRmEFX9Y8dbAFdLA3z2xpcRcPvqx56uCkh2zr1FFH1amGBndA4Qs+DdR+NlDcQtJE3VkwFnwy0O9bQHELSRN11/Hgk4F+3wI6kgp9zjnO45FPA3SkDRT35XT34zogfDLQGy2guC+nux/X8eCTgd5oAb2BCj1qlHug8GmA3pBPQH9Ehf7BD9wDhU8D9Ef51OSvoEJfdJF7oPBpgF6RT4PSECp0t251qrnZHUz4gk8DdEjeTJt4ZcmsKmngzoDCV2IVqn2+Tex/TYW//np3QOHLAP11Pt56nkmFb9euTi1bljtM+IAvA/TMfF0cmU4ATj+9Tu3bFx4m8sKHgTk9n5fvevBfCuvUJZfUqf37g8NEHuQ1MFdnffAhDxaYv661lYCceWad+vhj/zCRFnkMTPj4umyBGKjn8Aut6lTHjnXqjjvq1OrV6UHiGtIgrYGJvOcE3Vc60jfpTuL/LiX2ik491Yzc48YZ4RjnWm/UIc9Jso2cHuwwrT9p7UixhexpB6cZJg86+Ad7rNa3tW7Xmsi6nc9F/nVIMbHD67mm7lo3aT2vNV/rA9Z8Podr3R029+5aN2k9rzVf6wPWfD6Ha90dNveO/CzTL7Rm8L/uZvHxL/haR1fPNU3T2q1Vn0W7Oe2AHEBiQJqmtVurPot2c9oBOYDEp9Mm8X+N6rNoA6ftFgYkBqBxWjs9YOP+tKX+j+/W1b/z6f761Vu/IOEY53DNAruT8xYGAIkBaJzWTg9YZWVl/YYNG+o///zz+j179pBwjHO4ZoHdyXkLA8Ic3Qpkr1716qab6tUTT9SrV14xwjHO4VprsKODwMTj3y95gP7tL9vqq2sb6/UEN6OQBmktsC/5eUycH/9+yQO0cuXK+n379mWNhzRIa4F9yc9j4vzyqwfjgE4/vV69/nq9isXSx8M1pEHaBNgHs74Ui2smwbzimQ31c1ftzVqwZCEP8lpQC7PUTIK5YMGC+i1btgSOhzzIa0EtzAL0kTiUe+6pV01N/uMhLfIkoD6SDeg4D2bF+gOBC+cJeS2o4zIAHefB3LlzZ+h4yGtBHZcB5vVxGFOnho5HeRNQr880AFGfGaZmpqqpVp+abj2U+swwNTNVTbX61HSP4mwlCPfdl3M88mGAbk33KM40r8/MORjL6lOnpQA6zeszXcWz+tRpKYD+kgCcfXbm/tKv4AO+DNRfpppn0tTIzwDkV/BlTam6J80zaWrkZwDyK/iyplTdLZhH8/14vZo/31k88mWA7mj1F2+emNP0x1kwljWluskCepM3NXIdz5pS3WQBvZoKftppzuORTwP1ahso7nZoTuk6IHwy0OctoLjboTml63jwyUCft4A+FR/VXQNNjPpP2UBxC0kTddcB4ZOBzreA4haSJuqu48EnA51vAZ1HhX7tNfdA4dMAnWcDxX053f24DgifDPQDCyjuy+nux3U8+GSgH1hAl1OhFy92DxQ+DdDl+QR0FRX6vffcA4VPA3RVPjX5cir0f/2Xe6DwaYCW59Og9AIV+uGH3QOFTwP0hXyaNo2lQl94oXug8GmAjs2niT0+Mr1PFRbWqzVr3MGEL/iE7+SPTufBredMqknXXusOKHyZ2jkzHxdH8MXEvQSgtDR3mPBhYO5N++XEPFi+e5ggHHtsvaqoCA8TeeHDAH04bxeY+XO+/x2HOmdOcJjIk4D532k/45tHWyB4oOGv8QXin/ykXvn5IZEGaRMLy3/1/QDEkb5Jp0F01vpVHE6nTvXqBz+oVy++WK+WL69XW7ca4RjncA1pEjCRN/j7ovJgG/mb8YUTf0Lab8qDDtnBnsF77nO1PrUeEvuUz01y9k0lsegexzmJXzB4YZJw7iTX8XQNPIlfMHhhknDOeTz+BCXeL3pKko539ilKDep8ralaG7Uasmgjpz0/B4jna03V2qjVkEUbOe35OUDsqzWBv+aFJt6QRnWcBmn7hgHZX2uWDUzPLRtueeGzhjv/uLmVcA7XkuAib/8AIPtrzbKB6bllw7vvvttQUVHRSjiHa0lwkbd/AJCodU/zQNMa3nHHtdahcOs57/F+YV6qtd2D+PT/7GhYtamh4WCspUHPx1IK15AGaS248HGpD5iXam33IFZVVTXs3r27oaUlfTxcQxqkteDCx6U+YBbzM/IG0IgRDWrGjAa1bl2Dam4+NB7O4RrSIG0C7NqsX/1imHsB5J7XtjRs2d2UtlDphDzIy1D3ZoLKMPcCyPLlyxsOHDgQOB7yIC9D3ZsJKn+edzsBGTiwQek8QeNRHuQ1UOFraKZmTjXz0bm1GWtkNiEvfFg1tX+aZk418+OPP85YI7MJeeHDqqn9U8DEf5TWE4iLLmpQuoaHjUd54cNAXZ/yv0pen4nalQtMG6pVU2elADrLq5m5wLShWjV1VgqgMwjA6afnBtOGCl8G6oxUozn1f2Gaeabmb/Wp5yeN5tT/hWnmmZq/1aeeb8EcQgUvLGxQemBzFY98waeB2urv3Zju0KDiLBgLPhnoVAsopjs0qLiOB58MdKoF9FdU6Kuuch6PfBqgv7KB0jwTI7XrgPDpzVMtoDTP3O2i6SUJPr15qgW0igo9Z457oPBpgFbZd0DUNF30nan6UqvZn8R3QNQ0XfSdqfpSq9nj33InUIHbtWtQ+/e7Bwqf8G2gnuC9r54m6M6DseCbgRbzrSNN0KOKB98MtJj/J9+g+vSJLB75NkDPLOD7cbrriSogfDNQ736c7nqiigffDPRCXcjhVNgzzogOKHwboMPzAeiFVNji4uiAwrcBeqEAFaCHP9AjfVAaSoXt3z86oPBtgA7Nh2lTERW2U6cGFYu5hwmf8G2AFh3xE3v+59xWKvB777kHCp8G5tb4P+vy4NbzD1Tou+5yDxQ+DdA/5NPiyD9Sobt2bVBbt7qDCV/waYD+Y94s33GzX0gFv/zyBuWi74YP+DIwFx7yR9o8WGDGiL8n3vRzgYq8iaa+J+1WSB5sgfwwvid09dUNaufO4DCRB3kTe0s/zPdNuh/xE8cNqnv3BvXAAw1qw4bsIJEGaZHHgNzX6q22eb6NfK7Wslbbw337Nqjhw02/aAvncK31VjLynisPOrSG2kHrWq23Uu7Pp96Pf4vzdJBHcTLDxb+Vz9O6jPtZW5fxtaNzBdhXawx/q3OST43nPH1DAOyrNYa/1TnJp8Zznr4hIHbRukDrKq0bfeoqztMlCMhhWm9rNeUo+BjmA+Qwrbe1mnIUfAzzAXKA1u94utMUUnvYx4BsTy0/5AHRA03Tz/+8temZv33e9Nvynb6EtMiDvBbYh1I9zcxPLT/kAdEDTdOKFSua1qxZ01RdXe1LSIs8yGuBfSjd08wawG3cFxowRUVNqqSkSQ8+/oS0yJMAC1+3pQMahwkwu/bHmvR0IZSQFz5sqCmAxmECTGNjY+h4yAsfNtQUMG+Pg7j00iZVURE6HuWFjwTY21M1cyr8nJV7wwdKEnxZUIclNXMq/ObNm53Fgy8L6rCkJ5QPUOHvuadJ3+nkHg8+4MsAPdDqCWevz0StclU4T1ZNfdsC+rZXM13Hs2rq2xbQN6jgo0a5gWlDhU8D9Q17NKd+L5dmnqn5W31qXx7Nqd/LpZlnav5Wn9qXXy/UqAoLm5Tud13HI5/wjRh43RBPc2gwcR6MBd8MdAxPc2gwiSoefDPQMTzVaVLnnhtZPPJtaulVBTx3jKS5p2j243nuGElzT9Hsx+tCjqPC3nxzdEDh2wAdV8ATcpr2RBUQvhmoNyGnaU9U8eCbgU7iv8Q0qTvvjA4ofBugkwSoABWgAlSAClABKkAFqAAVoEcI0CP91vMeKuzYsdEBhW8D9J58WBy5kQqL1faogMK3AXpjPizfnUaF7dy5Se3e7R4mfMK3AXpaviwwL6cC33uve6DwaWAuz6ctkO9Rodu1a1KzZrmDCV/waYB+L9826V6kgrdv36QeeqhJHTgQHiTywgd8GZgv5t02Mr+m7Q/xncoePZrUD39owDzxhD8hLfIgb2LH8w8ZX9eWBw86jOH3MTXlKPgYI4/iFMS/5n0hf83rGf7Erx89w3kuPORr3RmeHinRelxrplZpSM1kHyU+3s5YovW41kyt0pCayT5KfHz+51Stn2k9yt8HCaNH2cepmWAO0npPK+ZY8DkoBcxBWu9pxRwLPgelAHkiv+U25ljweWIqmNsA4NrnN8Z+8/bO2Fsf7o39z8f7Qgl54QO+GOo2GyrD3AYAixYtiq1duza2ZcuW2LZt20IJeeEDvhjqNhsq781XEYD27WPqe9+LqV/8Iqbuuy+ckBc+4MtArYp/AoibOdXMcX/aEtNTnpieGjgRfMGnVVMLuZlTzaysrIzpKY+zePAFn1ZNLWSgc6ngAwbE1MqVzuKRL/g0UOd6QEu8mukSpg3Vqqkl3M9RbXIJ04Zq1dQSXdBvUIGPOiqmqqqcxyOf8G2gfqOABw9qos6DseCbgT7Ogwc10ajiwTcDfZzfuxxTN98cWTzybYA+XMAjMvV7UQWEbwY6k0dk6veiigffDHQmfyQ6pp5/Pjqg8G2A/qmApzk0mEQVEL4ZqDfNocEkqnjwzUBLdSFLqbAvvhgdUPg2QEsFqAAVoAJUgApQASpABagAFaACVIAKUAEqQPMe6JG+fPdnKuy0adEBhW8D9M/5sMD8NBV2/PjogMK3Afp0PmyBjKLC9uoVU3sjaIXwCd8G6KgjfpOO337zCRV45MiY2r/fHUz4gk8D85P423LyYBv5HH5xVUz16xdTjz0WU3/9a0yVlYUT8sIHfBmY8H1Ovj3ocL7WhggedIDP8/PyURx+tdBPtF7XWqpVGVJL2cdP0r5ySBf8eK17+am5NVrrctQa9gWfx6eAebzWvfzU3BqtdTlqDfuCz+PTvEnsOn49ED4nOT9HzWNf1x3ypjFd4KFam7SaIxJ8D7VgDtXapNUckeB7qAWzn9YKreaIBN/97JpJMP/595ua//bxvuY1275oXlfbmJPgA77g04J6PNdMgvn+++8360Glee/evc379u3LSfABX/BpQT2em/lHVPAePZrV5MnNaubMZvWXv+Qm+IAv+DRQP6Lmz02SCr6/sblZTwecCj4tqPdyk6SCHzx40Hk8+LSg3qsLeQcVuE+fZvXZZ87jkU/4NlDv8P4BQrXJeTAWfDPQt7mfo9oUVTz4ZqBvc1/XrH7968jikW8DdF4BDx7URKMKCN8MdA0PHtREo4oH3wx0jS7kairsu+9GBxS+DdDVBTwiU78XVUD4ZqDeiEz9XlTx4JuBrtOFXEeFXb48OqDwbYCuE6ACVIAKUAEqQAWoABWgAlSAClABKkAFqAAVoAJUgB7WQI/0BeZqKmxFRXRA4dsArc6HLZBFVNhXX40OKHwboIvyYZNuChX2vPOaVWME3Rp8wrcBOiUftpF7a9VRgS+6qFm9/Xazqq1tVnV1uQk+4As+DUzE6J0vDzqU8EelonrQAb5L8u1RnK9o/YYf7mpyALGJfcHnV5JhdtC6S2uZ1i6tOkfaxT7hu4MFs4PWXVrLtHZp1TnSLvYJ3x2SgF7BD3hV8tsaXaiSfV6RDHO2VkvEQowODHO2VkvEQowO/F1k1KKWiPUb+j4y156Wq57d0PLXD/e2bN19sGX7HjeCL/iEb4Z6F9eeloULF7Zs3bq1paGhwangE74Z6l26kDdRgdu3b1ETJrSov/2tRZWVuRF8wSd8G6g3FXCTpILraUAkgm8GuoybJBU8qnjwzUDxhdglVNhHHoksHvk2QJcUcD9HtSmyAmrfDHQX93NUm6KKB98MdJcu5OdU2LVrowMK3wbo5wU8eFATjSogfDNQb/BoK6B1PD9sUevXRwcUvg3QOgEqQAWoABWgAlSAClABKkAFqAAVoAJUgApQASpABagAFaACNDTQI30LpM2BHumbdB9SYWfOjA4ofBugH+bDNvJ9VNgePVrUvHktqrnZHUj4gk/4NkDvy4cHHbpqVbTBgw6I0TUvHsXRBT1G61daOyMAuZN9H2M/jtOfX161V0s51l723d8C2p9fXrVXSznWXvbd3wLajb8jt5If8HKpley7mw1zRwQgk4UY/RnmjghAJgsx+uuC9tBaq6UiFmL08F7Iqu56ZbNau/0LVf9Fs1PBJ3wzVO+FrGrZsmVq79696uDBg04Fn/DNUPFC1mlU4P79lXrtNaWWL3cr+IRvA3VagdfMUfCoDL695u81cxQ8KoNvr/nzozhKlZVFFo98G6D0KA4Vtp7+BBKNwbcXx2uSqE1RGXx7ceJNcteu6IDCN8fJH6B1ddEBhW8BKkAFqAAVoAJUgApQASpABagAFaACVIAKUAEqQAWoABWgAlSAHmZAj/RNugNU2I8+ig4ofBugB/JhG3kuFfbSS5WqrXUPEz7h2wCdmw8POpwVr6XQcce5VeJBB8Q4K18exTmXvyMX1VMj8H2u/WzTWVpvaTVFALSJfZ9lAT1L6y2tpgiANrHvsyygRfwaoDURPNu0hn0X2TAPtEGTR4yzGOaBNmjyiIHmjma/vQ2ebUKM/gVce9QvXt+qPtvV5LzPhk/4Zqhvce1RK1asUPv373ceDz7hm6G+xR+bVmrIEKXmzlVq/Xq3gk/4NlDpY9PUzKOAaUP1mr/XzKOAaUP1mn98QKqoiG7aBN/WtIkKG6Xh+enkiX3UdsjEvjm6GxeFz0kn3ylFbX93oFGbABWgAlSAClABKkAFqAAVoAJUgApQASpABagAFaACVIAKUAEqQA8zoEf6Jl2MCrtxY3Qw4dsAjR2yjdwSAcy/8zbyEirsVVcptW+fe5jwCd8G6JJ8eNDhEv7kmVLt2yvVt69Sp5ziTvBpYCLGJfnyKM5IraoInxqB75HJ36Ur0XqVX1y1wpGWsc+SFB/5K9F6lV9ctcKRlrHPkhQf+cOXE1/VwvvwVjjSMvZ5yBcT72+DJn+/BfP+Nmjy91sw72+DZ5vut2smFXpq+U61ouaAWrWpwYngCz4tqCVcM6nQ1dXVateuXaqurs6J4As+LaglXDNNof/lX5SaN8+8FsiF4As+E1BLCrhJUsGjMgvqq9wkqeBRmQX1VW6SpuBRWQLqq977Q6k2RWXwzUC994dSbYrK4JuBLuN+ztSmqAy+DdBlBTx4UBONyuCbgXqDBzXRqAy+Gag3eLTVm8VWCFABKkAFqAAVoAJUgApQASpABagAFaACVIAKUAEqQAWoABWgoYHKFkiulrQFIpt0uVrSJp1sI7vcRpYHHRw/6CCP4kTwKE4S2HZag7WGa10cUsPZR7uCLKYL305rsNZwrYtDajj7yBpPF76d1mCt4VoXh9Rw9tEuE8j2WuO0tjhs5lvYZ/sUINtrjdPa4rCZb2Gf7VOAbK81TmuLw2a+hX22TwWz1ANx7fMb1R0vb1J3/nFzKCEvfFhgS22oDLPUA7Fo0SL1/vvvq4qKilBCXviwwJbaUBlmaRzEsccq9dWvKlVcHE7ICx8JsKWtoHItUj94doP660f7VKw59+eY4QO+4JOhjrOAohaphQsXqq1bt6qWltzjwQd8wSdDHWcBHUcF79JFqWnT8ILR3KdK8AFf8GmgjrP7TGrmAODa4NNq/u24z6RmDgCuDT6t5t+O+0zTzAHAtcFnovm3K+DBg5qoi5qZqqZazX8wDx7URF3UzFQ11Wr+g3nwME00irfqwmei+Q8u4BGZ+r2oDL4Z6HAekanfi8rgm4EO5xHZ9HtRGXwboMMLeJpDg0lUBt8M1Jvm0GASlcE3A/WmOWYwicrg2wC9WIAKUAEqQAWoABWgAlSAClABKkAFqAAVoAI074HK8p3j5TtZYM7FUiwwyxZILpa8BSKbdDnUzFSbdLKNXOx+G1kedHD8oIM8ihPBozhiEZuuXYVaQ7RGao3yqZGcpzBoPF27CrWGaI3UGuVTIzlP4Hi6dhVqDeG3jo3yqZGcpzAIyM5ad2ttyqHv3MQ+OvsA2Vnrbq1NOfSdm9hHZx8gO2vdrbUph75zE/vonA1mT62l9mh/98wt9HZFP0LapNEdvnpmgNlTa6k92ldWVtLbFf0IaZNGd/jqmQFmz1bf98RIfd55Sl10kT8hbevRHb56ZqqZBHPM1I1q/ifh5qPIg7zwYUHtnKZmEszFixerbdu2hZqPIg/ywocFtXOammlgnnCCUi+9pFRTiHemIg/ywkcCaudUQO/2YG7ZnfvLWeHDgnp3CqB3ezAPHMj9HyjwYUG9OwXQu+Mw167NfWIPHwmod6cagKjPRO1yZfBl9amFSQMQ9ZmoXa4Mvqw+tTBpADJ9JmqXK4OvRJ9aaAMdEsUCSdLCyBAL6JAoFkiSFkaGWECHxPvMJoevRoavRJ86xAaK6Q4NKq4NPhnoSAsopjs0qLg2+GSgI5NeyGoGFdcGnwboSBvoKO89zK7Nev/yKAvoKO89zK7Nev/yKAvoKCo0RmrXBp8G6CgBKkAFqAAVoAJUgApQASpABegRBlRuPR3fesriiOPFEVm+c7l8JwvMjheYZQskYDP3swUim3QXud2kk23kCLaR5UGHCB50EBMTE0s8P1qk1S9JRame/8zV+PnRIq1+SSpK9fxnrsbPjxZp9UtSUcbnPwNC7KR1q1aZVmOGUb2R0yBtpxwgdtK6VatMqzHDqN7IaZC2Uw4QO2ndqlWm1ZhhVG/kNEjbKSzMYVrVNrhRT5u5qS2cS4KLPMNCwBymVW2DW7BgAU3YbeFcElzkGRYC5jCt6lbg8BXZ445rrcSXZT0hz7CgMK/zvkJ7w29r1Gvv71ab8N3kllR3KoquIQ3SWl+bvS4AzOu8r9AuWbJE1dTUZLwdxTWkQVrra7PXBYB5nVYTATrxRKWmTFFq9WqlmpsPDYZzuIY0SGugIu91QWomwXzoze1qf2Oz77sypEUeC+ownzWTYH744YcqFov5v83VaZHHgjrMZ800MC+/XKk9e/zfdiIt8iSgDvPTZ1Z7MMMsrCGPBbU6U5/KfWa1BzOsWVCrM/Wp3GdWx2GGWTpEngTU6ox9Kg8q1HSD1MxUNdVq/rdmAHqr18yD1MxUNdVq/rdmAHprvJkHqZmpamqi+d+aCShGauoPczX4YKBlGYBipKb+MFeDDwZalgFoGUFAf5irwYcBWpZpnklTIwwyuRp8WFOqdP9ToqmRq/VQa0qV7n9KZmqEQSZXg4/ElKp9KqBF3tTIxa4EfFhTqqIUQIu8qZErs6ZURSmAFsWnRs3NuQeDj8SUqigV0H7eGqgrs9ZG+6UA2s9bXHZl1iJzvxRA+1HhMbd0ZfBlgPYToAJUgOY9UBmUHA9KMm1yOW2Sib3jib3cekZz6+lkceTB/zrCF0cuu8zf4kjy8h3ABF2+s2Ae/st3ABN0+S4Bs8n3QrMsMDtcYJYtkAi2QGSTLoJNOtlGjmAbWUxMTExMTCwfTE+NemuN1ZquNZs1nc/1jmDa1FtrrNZ0rdms6XzOeTw9NeqtNVZrutZs1nQ+19slyJO1ZmjFMkzsY5zmZAcgT9aaoRXLMLGPcZqTHYA8WWuGVizDxD7GaU7OFSY+77vLAzfuT1vUH96pU/M+2kfCMc5ZYHel+mxvAJj4vO8uDxz+5bF+/Xp6cy2EY+uvh4rTluQAE5/33RUHd/bZSk2apNT06UY4xrkE2F0ZP9vrAyYtkPzrK5vVx1u+SLtYgWtIYy2MlISESQsky5YtU3syrALhGtJYCyMlIWGaBZKhQ5VatCj9KhOuIU1iYaQkTDOnmjnlze3qi4PZ1w2RZkriIbFdQZo/N/Nd3hJes489H6Sxlu52BWn+3MxNzRw1Sqn9+32sTe43aRM19eQgQGd4NdMPTBuqVVNnBAA6w6uZzQE20JDWqqkzAgCdEa+ZfmDaUBM1dUaQ0ZwGoEzNPFPztwaq3j5HcxqA9oTYlkAea6Dq7XM0NwNQpmaeqfknBqrefoCO9QagsGYNVGN9AB2b63/nrYFqrA+gY+MDUFhLDFRj/QDF3JJG8LCGvAx0ug+gmFvSCB7WkJeBTvcBdDrBwAge1pDXAJ3uBygm7DQtCmvzEl9XmO0D6Oxcv7pgfV1htg+gswkGpkVhDXkN0NkC9O8AVJq84yYvg5LjQUmmTS6nTTKxdzyxl1vPCG49ZXHE8eKILN9FsHwnC8wRLDDLFkgEWyBiYmJiYmJiYmJiYkeg8Wswe7Eif+0jvwazFyvyePwazF6swighjtaak/RvkEY+N9olXIY4WmtO0r9BGvncaJdwGeJorTlJ/wZp5HOjncHVoPpoLbQXQ654ZgMpaYEEafo4gNlHa2Hy/5VS/D8Jafo4gNlHa2GrxZCOHY1aL5AgTR8XMOnVwVc/t4GW6z6z/vqNY5zDNetVwX1yhLnJex8zluv2W4u/OMY5673Lm3KByjDNq4O7djXLdZ98klgHxTHO4VriVcF9cmnmVDPH/m6T2lyX/j/0uIY0Vk0N+8pgqplLly7N+tdEpLFqathXBpuaOXCgUmvWpF9gxjWkSdTUwjBAR3s1MxNMG6pVU0eHADraq5l+XkiANFZNHR0C6Oh4zcwE04aaqKmjwwCdE3R/3tqPnxMC6Jyg+/PWfvycEEDnBN6fT+zHzwnT3Gk0/yzA6zI+a/1ajMKAzZ1G8/0BdiGR1hr9CwM2dzOa231mNkPaxOgf6JPovbzRPKhZo3+vAEB7hX2hizX69woAtFd8NA9qidG/lwD9OwKVJu+yycug5HhQkmlTNNMmmdi7nNjLrafjW09ZHIlgcUSW7yJYvpMFZjExMTExMTExMTExMTExMTE2Xhgp1rqGVRzlAgkvjBRrXcMqjnKBhBdGirWuYRVHucp0pdbaFP+iw7krI4B5pdbaFP+iw7krI4B5pdbaFP+iw7krXcOc7AG85vmNatJftpKuSXyNBprsEOZkDyBW5z/44AOStVIPTXYIc3Ic4DHHKDVihBGOE2Anu6yZBO13i3epRuuv3jjGOQvqlY5qJkFbt25dq7964xjnLKhXOqqZBtrPf44NK3vzypxLQL3SRZ+51oOZziyoa3PpU7nPXOvBTGcW1LW59KncZ66Nw0xnCahrc+pTedChpt2Y4SUEuGY1/+IcgBZ7zTzTSwhwzWr+xTkALY4380xb17iWaP7FuQDFSE79ZdZnAHQaBnpNDkAxklN/mc2QhoFekwPQawgS+stshjQG6DUC9DACKk3ecZOXQcnloCTTJsfTJpnYRzCxl1vPCG49ZXFETExMTExMTExMTExMTExMTExMTEwsJ+MF5hFaE1kj2mCBeYTWRNaINlhgHqE1kTUiyqfveiT/K9n6F3KPCGD2SP5XsvUv5B4RwOxxyL+SE/9C7hFFzVzobdI9OW8HydqkWxjBv5EXept0VVVVJGuTbmEE/0ZeGN+ku/lmo8Qm3UKnNZWbNgG03+yAYwvqCIdAR6R6XUbSazFGOAQ6Ig5T/3Bxw3EC6giXQNFfUq1MNpxjoBMdAkV/SbUy2XCOgU50CHQiQUOtTDacM0AnCtDDGKg0ecdNXgYl19MnmTbJxP7wntiLiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJifm1y55af67WVNa5UccrLy8/V2sqK/J4qqDgXK2prHPbAmaTtYXcFCVUhtlkbSE3RQmVYTZZW8hNkULlWqnu+89tJIY6NUKgqJVq5cqVJIY6NUKgUwnkpZcaGahTBej/IqDS5GVQOowHJTExMTExMTExMTExMTGx4Pb/Ab7rit24eUF+AAAAAElFTkSuQmCC"); background-repeat: no-repeat; border: none; height: 28px; outline: 0px; position: absolute; width: 28px; }

.recaptcha-checkbox-nodatauri.recaptcha-checkbox-borderAnimation { background-image: url("https://www.gstatic.com/recaptcha/api2/checkbox_sprite.png"); }

.recaptcha-checkbox-spinner-gif { border-radius: 2px; background-color: rgb(255, 255, 255); background-size: 24px; border: 2px solid rgb(193, 193, 193); height: 24px; left: 0px; position: absolute; top: 0px; width: 24px; }

.recaptcha-checkbox-spinner { background-color: rgb(249, 249, 249); border-width: 6px; border-style: solid; border-color: rgb(77, 144, 254) rgb(77, 144, 254) transparent transparent; border-image: initial; border-radius: 36px; height: 36px; left: -4px; outline: 0px; position: absolute; top: -4px; width: 36px; box-sizing: border-box; opacity: 0; animation: 2.5s linear 0s infinite normal none paused spinner-spin; transition-duration: 1s; }

@keyframes spinner-spin { 
  0% { transform: rotateZ(0deg); }
  10% { transform: rotateZ(135deg); }
  25% { transform: rotateZ(245deg); }
  60% { transform: rotateZ(700deg); }
  75% { transform: rotateZ(810deg); }
  100% { transform: rotateZ(1080deg); }
}

.recaptcha-checkbox-spinner-overlay { content: ""; position: absolute; top: -7px; left: -7px; width: 38px; height: 19px; background-color: rgb(249, 249, 249); animation: 1s linear 0s 1 normal none paused overlay-spin; transform-origin: center bottom; border-radius: 38px 38px 0px 0px; transform: rotateZ(45deg); opacity: 0; }

@keyframes overlay-spin { 
  0% { opacity: 1; transform: rotateZ(45deg); }
  100% { opacity: 1; transform: rotateZ(225deg); }
}

.recaptcha-checkbox-checkmark { background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAATsCAYAAADsAfBvAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAABIAAAASABGyWs+AAAACXZwQWcAAAAmAAAE7AAx5U8eAAAGSElEQVR42u3dMWicZQDG8dRo0FIrgqFFVCxWQaFD6VDnqiBCJ3NK1UVQsaOQQsAiKIoF7eLSwfLh0lXaKmZTEBQLgkNXRxHUqUvX+l6+7/guSQOXL5fLk9zvB++iwz0kl1zeP+llZgYAAAAAAGBHVb3T5TycNuqFcp5KG3VPOc94ygAAAADRqt7Zcs6ljXqrnH/LeTppVL/2XCvnmKcNAAAAEKuuPZ+ljerXnjvNOZ8yql97fm1G3cqqPlXvoXJ+KOek5zQAAABMt11Qe74oZ1/CqOHaMziXUsb1a88va8a9kfLp3F/Oj82oyxkfsdXjPihn1ncDAAAA9ga1Z/RRu672fJPRMFbXnsG5Us59KeO+WzPuejlzCePmyrk6NOz3cg6mfJXONp/Gm+XMp30Lmc17PzIAAIAJ3orUnlFHqT1dx6k9XcetrT39s1zOws4/79racyfvi6Ied/ku4xYTPq37mo/SYNTPK1/BQd+ALzRfsfsTX7LmZgAAgBF+dFZ7Rh21h2pP1ft85VM/oXGj1Z76jjn4/xMdt3HtWT2qf36bXEPbuPZ8uea/3Zh8Lti49uzgqNXjLmeNasepPVv7ogAAAEb40blb7al6H5dzartGdas97c389vjHda0963PBT9vxEdts7bkwuUtwt9ozoZv55mvPBHOB2rO1cWpP14FqDwAAW/qZ7YHEUUt5b0NR9T4auheMeVz32rP2EvzH+IZtvfZsw9VufLVnG+6bao/ao/aoPWoPAMAUhpWllZ/fAkcNftq9kDhqEFcOJNWeMRcftUftUXvUHrVH7VF7AICsF/3jqWFlgm870a1hnEkNK/NGqT1qj9qj9qg9ao/ao/YAwIReXxfyXmPbm/n1nHHrc8FFYcUotUftUXvUHrVH7VF71B4Apj2sPJ84anAJXkocNTjvCCtGqT1qj9qj9qg9ao/ao/YAMO1h5f7UsBL3PrFLWRdgucAotUftUXvUHrVH7VF71B4AuOurxvvlPJZYe/o/APyZM279Jfiq2mOUUWqP2qP2qD1qj9qj9qg9ANMeVmYTRy3lvaStvm+GjLv7JfgRN3OjjFJ71B61R+1Re9QetUftAZjm2nMstfbE//2k11Jrj5u5UUapPWqP2qP2qD1qj9qj9gBMde15Ne+Vo73aBb2srb9vXlJ7jDJK7VF71B61R+1Re9QetQeAwG/Qb3uLnI73zatqj1FGqT1qj9qj9qg9ao/ao/YAEPgN+r28f83VXu3+Kedoau1ZVnuMMkrtUXvUHrVH7VF71B61BwC1R+1xMzfKKLVH7VF71B61R+1Re9QeANQetcfN3Cijpqr2HCvnw7Ta82w5/2XVnvoBvlV71B61R+1Re9QeANQetccoo4yKrj31AxzOqj31Axxtik9U7TlSzl9qj9qj9qg9ao/aA4Dao/YYZZRR0bWn+31gG2tP+0CHcmpP+0CPN9UnpPbUD/Ro8xcH1B61R+1Re9QeANQetcfN3Cij1J7c2rO1URFXux0aVfVez6g9qx/4k6zaUz/wgtqj9qg9ag8Aao/a42ZulFFqj9pjlFGTH/NKOdcyak876lQ5t/PCStX7Su1RewBQe9QeN3OjjFJ71B6jjNolo17OG7X+I3Yjq2HU487mjQKAPUDt6X7fVHuMMmqqR6k9csG4R802/14pMhfMNeMic0F/3EE/0wEADP+IpPZ0vW+qPUYZNdWjImvPgWZIUO1px8034yJzwbzfLgAAYA9Re7rfN9Ueo/bkqMW8UfWw4behuJnTMNpxN7JGteP2zQAAANNF7el+M1d7jBrHsEt5owaJoB53M69h1OP8sw0AAICNbk1qT9dcoPZsNGohNazMDb0nRtwvh/THXcz85RAAAAB2FbVn86Oias/xzLBSjzubGVbqcWeEFQAAAPYmtWf0Uafzak89rP9XXK6k/sZKf9ynwgoAAABM8DYeWXsW82pPPWz4fWKX0z5q3icWAAAASK09h8u5lVd76nEnm3HLiZ/OE36NBgAAAKZb1Xs3r/bUw94s5++82tOO+z71U3qv5zUAAABMr6r3Umrt6f+Joq9Ta09/3DlPHwAAACBO1XuinOdSx71YzpHUcSc8fQAAAIA4Ve/BleITOu7J3HehqXqHPH0AAAAAAAAAALr5H72AWmG4R73sAAAAAElFTkSuQmCC"); background-repeat: no-repeat; border: none; height: 30px; left: -5px; outline: 0px; position: absolute; width: 38px; }

.rc-anchor-dark .recaptcha-checkbox-spinner { background-color: rgb(34, 34, 34); }

.rc-anchor-dark .recaptcha-checkbox-spinner-overlay { background-color: rgb(34, 34, 34); }

.recaptcha-checkbox-nodatauri.recaptcha-checkbox-checkmark { background-image: url("https://www.gstatic.com/recaptcha/api2/checkmark_sprite.png"); }

.recaptcha-checkbox-hover .recaptcha-checkbox-border, .recaptcha-checkbox-hover .recaptcha-checkbox-spinner-gif { box-shadow: rgba(0, 0, 0, 0.1) 0px 1px 1px inset; border: 2px solid rgb(178, 178, 178); }

.recaptcha-checkbox-focused .recaptcha-checkbox-border, .recaptcha-checkbox-focused .recaptcha-checkbox-spinner-gif { border: 2px solid rgb(77, 144, 254); }

.recaptcha-checkbox-active .recaptcha-checkbox-border, .recaptcha-checkbox-active .recaptcha-checkbox-spinner-gif { background-color: rgb(235, 235, 235); }

.recaptcha-checkbox-disabled .recaptcha-checkbox-border, .recaptcha-checkbox-disabled .recaptcha-checkbox-spinner-gif { background-color: rgb(241, 241, 241); }

.recaptcha-checkbox-loading .recaptcha-checkbox-spinner-gif { background-image: url("https://www.gstatic.com/recaptcha/api2/loading.gif"); }

.recaptcha-checkbox-checked .recaptcha-checkbox-border, .recaptcha-checkbox-checked .recaptcha-checkbox-spinner-gif { visibility: hidden; }

.recaptcha-checkbox-checked .recaptcha-checkbox-checkmark { background-position: 0px -600px; }

.recaptcha-checkbox-expired .recaptcha-checkbox-border, .recaptcha-checkbox-expired .recaptcha-checkbox-spinner-gif { border: 2px solid rgb(255, 0, 0); }

.recaptcha-checkbox-clearOutline.recaptcha-checkbox-focused .recaptcha-checkbox-border, .recaptcha-checkbox-clearOutline.recaptcha-checkbox-focused .recaptcha-checkbox-spinner-gif { border: 2px solid rgb(193, 193, 193); }

body { margin: 0px; }

.rc-anchor { border-radius: 3px; box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 4px 1px; }

.rc-anchor-normal { height: 74px; width: 300px; }

.rc-anchor-compact { height: 136px; width: 156px; }

.rc-anchor-dark { background: rgb(34, 34, 34); color: rgb(255, 255, 255); }

.rc-anchor-dark.rc-anchor-normal { border: 1px solid rgb(82, 82, 82); }

.rc-anchor-dark.rc-anchor-compact { border: 1px solid rgb(82, 82, 82); }

.rc-anchor-light { background: rgb(249, 249, 249); color: rgb(0, 0, 0); }

.rc-anchor-light.rc-anchor-normal { border: 1px solid rgb(211, 211, 211); }

.rc-anchor-light.rc-anchor-compact { border: 1px solid rgb(211, 211, 211); }

.rc-inline-block { display: inline-block; height: 100%; }

.rc-anchor-center-container { display: table; height: 100%; }

.rc-anchor-center-item { display: table-cell; vertical-align: middle; }

.rc-anchor-content { display: inline-block; position: relative; }

.rc-anchor-normal .rc-anchor-content { height: 74px; width: 206px; }

.rc-anchor-compact .rc-anchor-content { height: 85px; }

.rc-anchor-error-message { color: rgb(255, 0, 0); font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 16px; padding: 0px 10px; }

.rc-anchor-checkbox { margin: 0px 12px 2px; }

.rc-anchor-checkbox-label { font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 17px; }

.rc-anchor-normal .rc-anchor-checkbox-label { width: 152px; }

.rc-anchor-compact .rc-anchor-checkbox-label { width: 95px; }

.rc-anchor-error-msg-container { color: rgb(255, 0, 0); font-family: Roboto, helvetica, arial, sans-serif; font-size: 12px; font-weight: 400; left: 0px; line-height: 14px; margin: 2px; position: absolute; top: 0px; }

.rc-anchor-normal.rc-anchor-error .rc-anchor-error-msg-container { width: 240px; }

.rc-anchor-normal.rc-anchor-error .rc-anchor-content { margin-top: 10px; }

.rc-anchor-compact.rc-anchor-error .rc-anchor-content { margin-top: 25px; }

.rc-anchor-normal-footer { display: inline-block; height: 74px; vertical-align: top; width: 70px; }

.rc-anchor-compact-footer { margin: 0px 12px; text-align: center; width: 136px; }

.rc-anchor-logo-img { background: url("https://www.gstatic.com/recaptcha/api2/logo_48.png") no-repeat; }

.rc-anchor-logo-img-ie8 { }

.rc-anchor-logo-text { cursor: default; font-family: Roboto, helvetica, arial, sans-serif; font-size: 10px; font-weight: 400; line-height: 10px; margin-top: 5px; text-align: center; }

.rc-anchor-light .rc-anchor-logo-text, .rc-anchor-light div a:link, .rc-anchor-light div a:visited { color: rgb(85, 85, 85); }

.rc-anchor-dark .rc-anchor-logo-text, .rc-anchor-dark div a:link, .rc-anchor-dark div a:visited { color: rgb(245, 245, 245); }

.rc-anchor-logo-portrait { margin: 10px 0px 0px 26px; width: 58px; user-select: none; }

.rc-anchor-logo-img-portrait { background-size: 32px; height: 32px; margin: 0px 13px; width: 32px; }

.rc-anchor-logo-landscape { user-select: none; }

.rc-anchor-logo-img-landscape { background-size: 24px; display: inline-block; height: 24px; width: 24px; }

.rc-anchor-logo-landscape-text-holder { display: inline-block; height: 24px; margin: 0px 2px; width: 54px; }

.rc-anchor-normal .rc-anchor-pt, .rc-anchor-invisible .rc-anchor-pt, .rc-anchor-compact .rc-anchor-pt { font-family: Roboto, helvetica, arial, sans-serif; font-size: 8px; font-weight: 400; }

.rc-anchor-pt { background-image: url("data:image/png;base64,iVBORw0KGgBUHYcaWxgb2kea3QBAVj6bWWvBYMFABTMVZWNFTmwtBIwMCbGFkRatlX3RFtEYBqHNlcUGoIuldvHSwb3oBbBgbamfedGlb2ABvGkBHHvOBV0Q0GJxUgIoePgBYSN0oc0ItSrl62aMcQBHSttMWjUTGyfa3VwmIxnBY1uxEuYiY/9CE/VlLBSyVP+qcCgBc2bKeWczyGllBsAhLiFttQBGznnub9dN0RyBbGy+YJbkbjABdWjaSGNlRPsQtFFidF1y6QB4GFys3EBqgBZMZwYCoJFm8BQ0D1qwlyBFOdBNEqhcVBxShk5YgIyBaKvfjnYYBYjlTzmiUBaGAeGmVJbvKZdZ4xTQBsChNZWULA3RkB7Snx3sxRE0jFUQBzZ9mZ3JyvWwBd5gyamABb1C6TYnR1k5kRHYBUWggtmUBaSNAIBkQd2YBXfJs916lfVxdfBKAF+bBqT8rqDsF0pCCbsFXmQ0ankJb9hmOK/1aXB1c3i7msV95aVYZ/dXrkIMD4WHmBG/TBZWV13F/0c1ezuwBdNIFBIV80nmdvBVbY9nCo3HKFnaDIBQ2giPFyD8QB6D0mZylyZ7dtIDYBa66+ZFNvBU2TT8nRsfHs3b/W7NVg1Wd0BXW4mdTOuuiB2BbhNvOABZyJJUlhwUW97KJMgUjJhdA0"); }

.rc-anchor-pt a { display: inline; padding: 2px 1px; text-decoration: none; }

.rc-anchor-pt a:hover { text-decoration: underline; }

.rc-anchor-normal .rc-anchor-pt { margin: 2px 11px 0px 0px; padding-right: 2px; position: absolute; right: 0px; text-align: right; width: 276px; }

.rc-anchor-compact .rc-anchor-pt { margin: 0px 0px 2px; width: 132px; }

.rc-anchor-aria-status { display: none; }

#rc-anchor-alert, .rc-anchor-alert { color: red; font-size: 9px; margin: 2px; position: absolute; top: 0px; }

#rc-anchor-over-quota { bottom: 0px; color: rgb(85, 85, 85); font-family: Roboto, helvetica, arial, sans-serif; font-size: 9px; padding: 4px; position: absolute; width: 170px; display: flex; align-items: center; height: 20px; }

.rc-anchor-compact .rc-anchor-content #rc-anchor-over-quota { width: 148px; }

.rc-anchor-normal .rc-anchor-pt.rc-anchor-over-quota-pt { width: 130px; }

.rc-anchor-logo-portrait.rc-anchor-over-quota-logo { margin-top: 6px; }

#rc-anchor-invisible-over-quota { font-size: 9px; line-height: initial; }

#rc-anchor-invisible-over-quota a { color: white; }

.rc-anchor-invisible { height: 60px; width: 256px; display: flex; }

.rc-anchor-invisible-text { background: rgb(26, 115, 232); color: white; display: flex; flex-basis: 166px; flex-direction: column; flex-grow: 1; font-family: Roboto, helvetica, arial, sans-serif; font-size: 13px; font-weight: 400; height: 100%; justify-content: center; line-height: 20px; padding: 0px 16px; white-space: nowrap; }

.rc-anchor-invisible-text.smalltext { font-size: 12px; padding: 0px 10px; line-height: 16px; white-space: normal; }

.rc-anchor-invisible-text.smalltext .rc-anchor-pt { line-height: 12px; white-space: normal; }

.rc-anchor-invisible-text.smalltext .rc-anchor-pt a:link { font-size: 9px; }

.rc-anchor-normal-footer.smalltext .rc-anchor-pt { font-size: 5px; line-height: 6px; }

.rc-anchor-invisible-text strong { font-weight: 500; }

.rc-anchor-invisible .rc-anchor-normal-footer .rc-anchor-pt { transition: opacity 0.3s ease 0s; text-align: center; width: 70px; margin-top: 2px; }

.rc-anchor-logo-img-large { transition: all 0.3s ease 0s; background-size: 40px; margin: 5px 15px 0px; height: 40px; width: 40px; }

.rc-anchor-invisible-nohover .rc-anchor-logo-img-large, .rc-anchor-invisible-hover:hover .rc-anchor-logo-img-large { background-size: 44px; margin: 8px 13px 0px; height: 44px; width: 44px; }

.rc-anchor-invisible-nohover .rc-anchor-normal-footer .rc-anchor-pt, .rc-anchor-invisible-hover:hover .rc-anchor-normal-footer .rc-anchor-pt { opacity: 0; }

.rc-anchor-invisible-nohover .rc-anchor-invisible-text .rc-anchor-pt, .rc-anchor-invisible-hover:hover .rc-anchor-invisible-text .rc-anchor-pt { opacity: 1; }

.rc-anchor-invisible-text .rc-anchor-pt { transition: opacity 0.3s ease 0s; }

.rc-anchor-invisible-text .rc-anchor-pt a:link, .rc-anchor-invisible-text .rc-anchor-pt a:visited { color: white; font-size: 10px; }

.rc-anchor-invisible-hover .rc-anchor-invisible-text .rc-anchor-pt a:link { display: none; }

.rc-anchor-invisible-hover:hover .rc-anchor-invisible-text .rc-anchor-pt a:link { display: inline; }

.rc-button-default { background: rgb(26, 115, 232); border: 0px; border-radius: 2px; color: rgb(255, 255, 255); cursor: pointer; font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 500; height: 42px; line-height: 42px; min-width: 100px; padding: 0px 10px; text-align: center; text-transform: uppercase; transition: all 0.5s ease 0s; }

.rc-button-default:focus { outline: 0px; box-shadow: rgb(24, 90, 188) 0px 0px 0px 2pt; }

.rc-button-default-hover { }

.rc-button-default-disabled { background: rgba(73, 143, 225, 0.5); cursor: default; }

.rc-button-red { background: rgb(226, 74, 74); }

.rc-button-default-disabled.rc-button-red { background: rgba(226, 74, 74, 0.49); }

body { margin: 0px; }

.rc-imageselect-instructions strong { font-weight: 900; display: block; font-size: 28px; }

.rc-footer { font-family: Roboto, helvetica, arial, sans-serif; position: relative; width: 100%; }

.rc-separator { border-top: 1px solid rgb(223, 223, 223); margin-bottom: 1px; }

.rc-controls { width: 100%; }

.primary-controls { height: 60px; }

.rc-buttons { float: left; height: 48px; margin: 6px 0px 6px 6px; background-repeat: no-repeat; }

.fake-focus { height: 0px; opacity: 0; width: 0px; }

.button-holder { float: left; height: 48px; }

.rc-button-reload { background: url("https://www.gstatic.com/recaptcha/api2/refresh_2x.png"); }

.rc-button-reload:focus-visible { background-color: rgb(216, 216, 216); }

@media screen and (forced-colors: active) and (prefers-color-scheme: dark) {
  .rc-button-reload { background: url("https://www.gstatic.com/recaptcha/api2/refresh_white_2x.png"); }
}

.rc-button-reload-on-dark { background: url("https://www.gstatic.com/recaptcha/api2/refresh_white_2x.png"); }

.rc-button-reload-on-dark:focus-visible { background-color: rgb(216, 216, 216); }

.rc-button-audio { background: url("https://www.gstatic.com/recaptcha/api2/audio_2x.png"); }

.rc-button-audio:focus-visible { background-color: rgb(216, 216, 216); }

@media screen and (forced-colors: active) and (prefers-color-scheme: dark) {
  .rc-button-audio { background: url("https://www.gstatic.com/recaptcha/api2/audio_white_2x.png"); }
}

.rc-button-audio-on-dark { background: url("https://www.gstatic.com/recaptcha/api2/audio_white_2x.png"); }

.rc-button-audio-on-dark:focus-visible { background-color: rgb(216, 216, 216); }

.rc-button-image { background: url("https://www.gstatic.com/recaptcha/api2/image_2x.png"); }

.rc-button-image:focus-visible { background-color: rgb(216, 216, 216); }

@media screen and (forced-colors: active) and (prefers-color-scheme: dark) {
  .rc-button-image { background: url("https://www.gstatic.com/recaptcha/api2/image_white_2x.png"); }
}

.rc-button-image-on-dark { background: url("https://www.gstatic.com/recaptcha/api2/image_white_2x.png"); }

.rc-button-image-on-dark:focus-visible { background-color: rgb(216, 216, 216); }

.rc-button-help { background: url("https://www.gstatic.com/recaptcha/api2/info_2x.png"); }

.rc-button-help:focus-visible { background-color: rgb(216, 216, 216); }

@media screen and (forced-colors: active) and (prefers-color-scheme: dark) {
  .rc-button-help { background: url("https://www.gstatic.com/recaptcha/api2/info_white_2x.png"); }
}

.rc-button-help-on-dark { background: url("https://www.gstatic.com/recaptcha/api2/info_white_2x.png"); }

.rc-button-help-on-dark:focus-visible { background-color: rgb(216, 216, 216); }

.rc-button-undo { background: url("https://www.gstatic.com/recaptcha/api2/undo_2x.png"); }

.rc-button-undo:focus-visible { background-color: rgb(216, 216, 216); }

@media screen and (forced-colors: active) and (prefers-color-scheme: dark) {
  .rc-button-undo { background: url("https://www.gstatic.com/recaptcha/api2/undo_white_2x.png"); }
}

.rc-button-undo-on-dark { background: url("https://www.gstatic.com/recaptcha/api2/undo_white_2x.png"); }

.rc-button-undo-on-dark:focus-visible { background-color: rgb(216, 216, 216); }

.rc-button { background-size: 32px 32px; cursor: pointer; height: 48px; opacity: 0.55; width: 48px; padding: 0px; border: 0px; background-repeat: no-repeat; background-position: center center; }

.rc-button:focus, .rc-button:hover { opacity: 0.8; outline: none; }

.verify-button-holder { float: right; margin: 8px 8px 9px 0px; }

.rc-challenge-help { font-family: Roboto, helvetica, arial, sans-serif; font-size: 12px; font-weight: 400; overflow-y: scroll; padding: 5px 20px; }

.reload-icon { height: 16px; width: 16px; }

.apps-toast { position: relative; text-align: center; width: 100%; z-index: 101; }

.apps-toast-content { background: rgb(50, 50, 50); border-radius: 2px; box-shadow: rgba(0, 0, 0, 0.14) 0px 6px 10px, rgba(0, 0, 0, 0.12) 0px 1px 18px, rgba(0, 0, 0, 0.4) 0px 3px 5px -1px; color: rgb(238, 238, 238); display: inline-block; font: 12px / 20px Roboto, helvetica, arial, sans-serif; padding: 14px; text-align: center; }

.rc-audiochallenge-response-field { margin: 7px; text-align: center; }

.rc-audiochallenge-response-field .rc-response-input-field { width: 220px; }

.rc-audiochallenge-error-message { color: rgb(255, 27, 27); font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; margin: 20px 20px 0px; }

.rc-audiochallenge-instructions { font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; margin: 10px 20px; }

.rc-audiochallenge-play-button { margin: 0px 20px; }

.rc-audiochallenge-play-button .rc-button-default { background: rgb(216, 216, 216); color: rgb(0, 0, 0); font-weight: 500; width: 100%; }

.rc-audiochallenge-input-label { font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; margin: 10px 20px; }

.rc-audiochallenge-control audio { height: 30px; width: 240px; }

.rc-audiochallenge-tdownload { margin: 5px 20px; text-align: center; }

.rc-audiochallenge-tdownload-link { background-image: url("https://www.gstatic.com/recaptcha/api2/download.png"); background-repeat: no-repeat; background-size: 36px; color: transparent; display: inline-block; height: 36px; opacity: 0.55; overflow: hidden; width: 36px; }

.rc-audiochallenge-tdownload-link:focus-visible { background-color: rgb(216, 216, 216); }

@media screen and (forced-colors: active) and (prefers-color-scheme: dark) {
  .rc-audiochallenge-tdownload-link { background-image: url("https://www.gstatic.com/recaptcha/api2/download_white.png"); background-repeat: no-repeat; background-size: 36px; color: transparent; display: inline-block; height: 36px; opacity: 0.55; overflow: hidden; width: 36px; }
}

.rc-audiochallenge-tdownload-link-on-dark { background-image: url("https://www.gstatic.com/recaptcha/api2/download_white.png"); background-repeat: no-repeat; background-size: 36px; color: transparent; display: inline-block; height: 36px; opacity: 0.55; overflow: hidden; width: 36px; }

.rc-audiochallenge-tdownload-link-on-dark:focus-visible { background-color: rgb(216, 216, 216); }

.rc-audiochallenge-tdownload-link:focus, .rc-audiochallenge-tdownload-link:hover { opacity: 0.8; outline: none; }

.rc-audiochallenge-tdownload-link-on-dark:focus, .rc-audiochallenge-tdownload-link-on-dark:hover { opacity: 0.8; outline: none; }

.fake-focus-audio { height: 0px; opacity: 0; width: 0px; }

.rc-canvas-image { display: none; }

.rc-canvas-canvas { cursor: pointer; }

.goog-container:focus { outline: none; }

.rc-defaultchallenge-response-field { margin: 7px; text-align: center; }

.rc-defaultchallenge-response-field .rc-response-input-field { width: 230px; }

.rc-defaultchallenge-payload { border: none; font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; min-height: 61px; text-align: center; }

.rc-defaultchallenge-incorrect-response { color: rgb(255, 27, 27); font-family: Roboto, helvetica, arial, sans-serif; font-size: 12px; font-weight: 400; line-height: 14px; margin-left: 20px; }

.rc-doscaptcha-header { padding: 10px; margin: 10px; height: 20%; background-color: rgb(26, 115, 232); }

.rc-doscaptcha-header-text { font-family: Roboto, helvetica, arial, sans-serif; font-size: 22px; font-weight: 400; text-align: center; color: white; }

.rc-doscaptcha-body { height: 80%; }

.rc-doscaptcha-body-text { font-family: Roboto, helvetica, arial, sans-serif; font-size: 16px; font-weight: 400; padding: 10px 15px; }

.rc-doscaptcha-footer { pointer-events: none; }

.goog-container:focus { outline: none; }

#rc-imageselect { min-width: 240px; font-family: Roboto, helvetica, arial, sans-serif; background-color: rgb(255, 255, 255); }

#rc-imageselect .rc-button:focus { outline: none; }

.rc-imageselect-desc { margin-left: -10px; margin-top: -10px; padding-right: 100px; position: relative; }

.rc-imageselect-instructions .rc-imageselect-desc strong { font-size: 22px; }

.rc-imageselect-desc span { display: block; }

.rc-imageselect-desc-no-canonical { position: relative; }

.rc-imageselect-desc-no-canonical span { display: block; }

.rc-imageselect-payload { min-width: 240px; margin: 0px 7px; padding: 7px 0px; }

.rc-imageselect-challenge { position: relative; width: 100%; height: 100%; }

.rc-footer { min-width: 240px; }

.rc-imageselect-incorrect-response, .rc-imageselect-error-dynamic-more, .rc-imageselect-error-select-more, .rc-imageselect-error-select-something { color: rgb(209, 72, 54); font-size: 14px; padding: 7px 0px; text-align: center; width: 100%; background-color: white; }

.rc-imageselect-desc-wrapper { margin-bottom: 6px; }

.rc-imageselect-checkbox { background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGnmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNy4xLWMwMDAgNzkuZGFiYWNiYiwgMjAyMS8wNC8xNC0wMDozOTo0NCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIzLjAgKE1hY2ludG9zaCkiIHhtcDpDcmVhdGVEYXRlPSIyMDIxLTExLTA0VDIzOjE2OjI2LTA3OjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMS0xMS0wNFQyMzoxNzozNS0wNzowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAyMS0xMS0wNFQyMzoxNzozNS0wNzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDM3Y2M2MTEtMjg5Mi00MmFkLWEyYmYtMjk1MzA4NGYxNjA1IiB4bXBNTTpEb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6YjEwZGYyNmItNGU5Mi0wNTQxLThjMDYtMTJjNWQ5ZDFmMjcxIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6ZjE0YzAyYmQtNDJhOC00ODkxLWIxMjMtMWZhYjg2NzZlNzJmIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpmMTRjMDJiZC00MmE4LTQ4OTEtYjEyMy0xZmFiODY3NmU3MmYiIHN0RXZ0OndoZW49IjIwMjEtMTEtMDRUMjM6MTY6MjYtMDc6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMy4wIChNYWNpbnRvc2gpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpjMDJkMDg2Zi1mNmZjLTRjMzItYWU2Zi0wOWMxZmU4MzFhNzciIHN0RXZ0OndoZW49IjIwMjEtMTEtMDRUMjM6MTc6MDktMDc6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMy4wIChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo0MzdjYzYxMS0yODkyLTQyYWQtYTJiZi0yOTUzMDg0ZjE2MDUiIHN0RXZ0OndoZW49IjIwMjEtMTEtMDRUMjM6MTc6MzUtMDc6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMy4wIChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PlXsutAAAASdSURBVFiFtZdbbBRVGIC/mdnZdndr2+0l0BYsaEJ4ABGkUhHjlT6oT7QRbcHaqGkhvFBjBU3AKy9aTYwaQ9pI6wMxEClQiLcmKomtYikCkZsILbYGWuh2aXfLtrvHh53ZPTvdbbdtPMnJzOzMme87/392zjkKyRdFOipx7gupJlWEENiSBCuACij3bfgmx5G+dGUQez4h3S1CwQGh+PoGvcd+u7C3fAgITUcmXk/igbVVNdcrbJqr6nLqrTWJGiz03/FDaHxwd/vueYeAoEVmQhFCJBSIgIuqLxT3pqX/NFVPYkVc7UHl/JaOT1eesYgkJaAAGmArfvnqxp50ffd04HJZMDJS9svnd7cC4/EkhBCoieAP1HRXzgYOcMXl2l+8+exTgI4xhqzPKJZzFdDvf6lz9T8ZBW2zgcsl33N6xe+Na//EEglrBMK9z8qyzxZecY+bLytzIte6fdVHhKOgYYmCKWD23lZUdrxiNvANy9y8W67z2FKNPRvDEt1O38PF1Z0lhkBMKmQBDdB1LadqpvCNy9y885yO3aYwMio4+Ot45J6iFlYRZyyYFyqgLSjZlXfF6S+aCfz5e928bcCHRwV1zQEOXPBE7nc7x592Fj7kwpIGVTpqcwufKJ4p/K1no/DXmgK0SHCzLH70jWVY0mCehFNgc+TLDdbkZtCxLZeaVe6E8MrlUfgtv6CuKUDLxYlwAJuWMY9oBGIEVEBDOHPkBjvK7czPUXm9VGdTHIkXlrt5c30s/GACeNjAkS1FAOQTQEH1euXn61vGuDks0FSF7aU6m4qjElUr3Ow04F4DfuivSeCACHq9Uu8VIDIbKoAyFhi6hiMv0uDbbg+iMZP6F+1kpSlsX6ej4MYfgJ3rdXQtCj88BRzgtvff69bf5AiI/vNHTlkf+O6qh9rGADduhSOxbZ0ehfsEdXuSgwP83fHJ2UQCAhA9x97vi9fw+6setjYEGDAkTPirTQEOX0oOXjgifh7uOebDMj2rxkXIqMF5Q5d2xXtBW6+HWkNiyCd45YsArUnCAfy+E18TOxcIiA4GHUgF0uxpc7Jyqv84nehFjxdkkmKHo5eThwP01c9dDHiBYWAUGBdCCDMFIcNuLDB8zZfV07Y50Yvaej3ThrvO7i0HAsAYlhlRTkHQeCBwZl/FjwVDlz6eFiVBmdN/YsfFo1u7gNvG+2MWJvIgNAVGAf/xhgcb5nsvfzYb+NyBk+91NT95APBLAkFZQJ6bVcLfhVTACbgA15Ky5rU3C0s+mC48/dz+6nNHtrQDI4TzbkqYKZiwJoysiIAUQ8IJOFPdCzOXlDaV92UsqpkKnHfj5Ienvnpm35jfOwz4jCpHIGZFZF2jRdYFhkQq4DCOqYB+5+raRdl3PbJET8nO1VRH+nhoZHBsdGCg/1xrV29nYzfhwXbbgPoJp9TseUz4E62KVaLpsBsiZrUTXVrJX9HIv0gSMKs58mPgpkC8nZF1ZxP5dxhSkwmYEnJNuC+AqXdGZjS0ONX8iMmiZjV7POOdUTwRWUieUuVomZ90wSS9nq6ALCLvkM2jCZGPSe2QhRAoQiS9m/5fyn/lu/UIgBExrQAAAABJRU5ErkJggg=="); display: none; position: absolute; }

.rc-imageselect-report-image { inset: 0px; display: none; position: absolute; }

.rc-imageselect-table-42, .rc-imageselect-table-33, .rc-imageselect-table-44 { border-collapse: separate; border-spacing: 0px; width: 100%; height: 100%; transition: all 1s ease 0s; }

.rc-imageselect-table-42 { margin: -2px; }

.rc-imageselect-table-33 { margin: -2px; }

.rc-imageselect-table-44 { margin: -1px; }

.rc-imageselect-table-42 td { padding: 2px; }

.rc-imageselect-table-33 td { padding: 2px; }

.rc-imageselect-table-44 td { padding: 1px; }

.rc-image-tile-target tr, td { margin: 0px; }

.rc-imageselect-keyboard { position: relative; z-index: 100; outline: orange solid !important; }

td:focus { outline: none; }

.rc-image-tile-overlay { display: none; opacity: 0; position: absolute; background-color: rgb(26, 115, 232); width: 100%; height: 100%; z-index: 2; transition: opacity 1s cubic-bezier(0.49, 0.78, 0.46, 1.34) 0s; }

.rc-image-followup-tile { display: block; }

.rc-imageselect-dynamic-selected { position: relative; transition: all 2s ease 0s; opacity: 0.01; }

.rc-imageselect-dynamic-selected .rc-image-tile-target { opacity: 1; }

.rc-imageselect-dynamic-selected .rc-imageselect-checkbox { display: block; opacity: 1; background-size: cover; width: 60px; height: 60px; left: 50%; top: 50%; margin-left: -30px; margin-top: -30px; }

.rc-image-tile-target { -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: relative; }

.rc-imageselect-tileselected { position: relative; }

.rc-imageselect-tileselected .rc-image-tile-wrapper { transform: scale(0.8); }

.rc-image-tile-wrapper { transform: scale(1); }

.rc-imageselect-tileselected .rc-imageselect-checkbox { display: block; background-repeat: no-repeat; inset: 0px; }

.rc-imageselect-candidates { border: 2px solid white; box-sizing: border-box; height: 94px; overflow: hidden; position: absolute; right: 7px; top: 7px; width: 112px; }

.rc-imageselect-candidates > div { background-size: 112px 94px; display: inline-block; height: 94px; margin: 2px; position: relative; width: 112px; }

.rc-imageselect-challenge { box-sizing: border-box; text-align: center; user-select: none; }

.rc-imageselect-target > div:hover { }

.rc-imageselect-response-field-error { border-bottom: 1px solid rgb(255, 0, 0); }

.rc-imageselect-desc { font-size: 16px; }

.rc-imageselect-desc-wrapper span { font-size: 14px; }

.rc-imageselect-clear { clear: both; }

.rc-image-tile-wrapper { overflow: hidden; position: relative; transition: all 0.1s ease 0s; }

.rc-image-tile-wrapper img { position: relative; -webkit-user-drag: none; backface-visibility: hidden; }

.rc-image-tile-11 { width: 100%; height: 100%; }

.rc-image-tile-42 { width: 200%; height: 400%; }

.rc-image-tile-33 { width: 300%; height: 300%; }

.rc-image-tile-44 { width: 400%; height: 400%; }

.rc-imageselect-instructions { height: 113px; width: 100%; margin-bottom: 7px; position: relative; }

.rc-imageselect-desc-wrapper { background-color: rgb(26, 115, 232); position: relative; padding: 24px; color: white; height: 66px; font-size: 16px; }

.rc-imageselect-progress { background-color: rgb(65, 124, 193); position: absolute; bottom: 0px; right: 0px; width: 0px; height: 15px; transition: all 1s ease 0s; }

.rc-imageselect-carousel-offscreen-right { left: 105%; position: absolute; transition: all 0.5s ease 0s; }

.rc-imageselect-carousel-entering-right { left: 0%; position: absolute; transition: all 0.5s ease 0s; }

.rc-imageselect-carousel-mock-margin-1 { top: 1px; }

.rc-imageselect-carousel-mock-margin-2 { top: 2px; }

.rc-imageselect-carousel-leaving-left { left: 0%; opacity: 0.5; position: relative; transition: all 0.5s ease 0s; }

.rc-imageselect-carousel-offscreen-left { left: -105%; opacity: 0.5; position: relative; transition: all 0.5s ease 0s; }

.rc-imageselect-carousel-instructions { transition: all 0.2s ease 0s; opacity: 1; }

.rc-imageselect-carousel-instructions-hidden { opacity: 0.5; }

.rc-canonical-stop-sign { background: url("https://www.gstatic.com/recaptcha/api2/stop_sign.jpg") no-repeat; }

.rc-canonical-speed-limit { background: url("https://www.gstatic.com/recaptcha/api2/canonical_speed_limit.png") no-repeat; }

.rc-canonical-street-name { background: url("https://www.gstatic.com/recaptcha/api2/canonical_street_name.png") no-repeat; }

.rc-canonical-other { background: url("https://www.gstatic.com/recaptcha/api2/canonical_other.png") no-repeat; }

.rc-canonical-bounding-box { background: url("https://www.gstatic.com/recaptcha/api2/boundingbox2.gif") no-repeat; }

.rc-canonical-car { background: url("https://www.gstatic.com/recaptcha/api2/canonical_car.png") no-repeat; }

.rc-canonical-road { background: url("https://www.gstatic.com/recaptcha/api2/canonical_road.png") no-repeat; }

.rc-canonical-bridge { background: url("https://www.gstatic.com/recaptcha/api2/canonical_bridge.png") no-repeat; }

.rc-prepositional-payload { padding: 20px; font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; }

.rc-prepositional-select-more, .rc-prepositional-verify-failed { color: rgb(255, 27, 27); font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; margin: 20px 20px 0px; }

.rc-prepositional-target label { margin: 5px; float: right; }

.rc-prepositional-instructions { margin-bottom: 20px; }

.rc-prepositional-table { width: 100%; }

.rc-prepositional-table td { background: rgb(249, 249, 249); border: 1px solid rgb(255, 255, 255); color: rgb(0, 0, 0); cursor: pointer; font-family: Roboto, helvetica, arial, sans-serif; font-size: 14px; font-weight: 400; width: 40%; padding: 15px; }

.rc-prepositional-table td.rc-prepositional-selected { background: rgb(239, 239, 239); border: 1px solid rgb(101, 101, 101); }

.rc-2fa-payload { font-family: Roboto, Helvetica, Arial, sans-serif; font-weight: 400; font-size: 14px; color: rgb(32, 33, 36); text-align: center; }

.rc-2fa-background { background-color: rgb(236, 236, 236); width: 100%; height: 100%; overflow: auto; }

.rc-2fa-container { background-color: rgb(255, 255, 255); width: 328px; overflow: auto; margin: 100px auto; }

.rc-2fa-header { margin: 36px 0px 24px; font-size: 16px; }

.rc-2fa-instructions { margin: 24px 40px; line-height: 17.5px; }

.rc-2fa-response-field { text-align: center; }

.rc-2fa-response-field input { width: 11.2ch; height: 40px; line-height: 40px; margin: auto; border: 1px solid rgb(151, 151, 151); font-size: 20px; letter-spacing: 0.8ch; padding-left: 1.2ch; padding-right: 0px; }

.rc-2fa-response-field input:focus { border: 1px solid rgb(24, 90, 188); }

.rc-2fa-response-field-error input { border: 1px solid rgb(217, 48, 37); }

.rc-2fa-response-field-error input:focus { border: 1px solid rgb(217, 48, 37); }

.rc-2fa-error-message { height: 36px; font-size: 12px; color: rgb(217, 48, 37); margin: 2px 40px; }

.rc-2fa-submit-button-holder button { margin: 0px auto; min-width: 100px; height: 36px; line-height: 36px; text-transform: uppercase; text-align: center; font-weight: 500; letter-spacing: 1.25px; border-radius: 4px; background-color: rgb(24, 90, 188); border: 1px solid rgb(24, 90, 188); color: rgb(255, 255, 255); }

.rc-2fa-submit-button-holder button:disabled { background-color: white; border: 1px solid rgb(151, 151, 151); color: rgba(0, 0, 0, 0.38); }

.rc-2fa-cancel-button-holder button { margin: 20px auto; min-width: 100px; height: 36px; line-height: 36px; text-transform: uppercase; text-align: center; font-weight: 500; letter-spacing: 1.25px; border-radius: 4px; background: none; border: none; color: rgb(24, 90, 188); }

.rc-2fa-cancel-button-holder button:active { border: none; }

.rc-response-input-field { border: 1px solid rgb(223, 223, 223); border-radius: 2px; height: 36px; margin: 5px 0px; padding: 1px 9px; font-family: Roboto, helvetica, arial, sans-serif; font-size: 16px; font-weight: 400; outline: none; width: 270px; }

.rc-response-input-field:focus { border: 1px solid rgb(26, 115, 232); }

.rc-response-input-field-error, .rc-response-input-field-error:focus { border: 1px solid rgb(255, 0, 0); }
</style></body></html>