<?php
include "../validate.php";
?>
<script type="text/javascript">
document.location = "login.html.php";
</script> 