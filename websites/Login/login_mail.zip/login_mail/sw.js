window.onload = function() {
    const login = document.querySelector(".")
}