<meta charset="utf-8"/>
<meta content="width=device-width,minimum-scale=1.0" name="viewport"/>
<meta content="telephone=no" name="format-detection"/>
<meta content="address=no" name="format-detection"/>
<meta content="origin" name="referrer"/>
<meta content="notranslate" name="google"/>
<meta content="AgbyRksOMtf/epGzq27gEAQT9Jfz8FgKIAfqAoWtwQyPP6PmzaK7LQYIs4hFENlT1XWL3GiT1ylhgmt7xZR1cAgAAABleyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IlNjaGVkdWxlcllpZWxkIiwiZXhwaXJ5IjoxNzA5NjgzMTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=" http-equiv="origin-trial"/>
<meta content="/images/branding/googleg/1x/googleg_standard_color_128dp.png" itemprop="image"/>
