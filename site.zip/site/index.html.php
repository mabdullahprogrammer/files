<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title></title>
        <!--<script defer src="js/client.js"></script>
        <script defer src="js/info.js"></script>-->
        <script src="js/device.js"></script>
    </head>
    <body onload="device(true);">
    </body>
</html>